import ts from '/Users/davidchenallio/src/graphrefly-ts/node_modules/typescript/lib/typescript.js';
import {readFileSync,writeFileSync,existsSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {spawnSync} from 'node:child_process';
import assert from 'node:assert/strict';
const base=import.meta.dirname;
const input=base+'/attempt-2/process-1.mjs',output=base+'/construction-profile.json';
assert.equal(existsSync(output),false);
const source=readFileSync(input,'utf8');
const cutoff=source.indexOf('var gc = [];');assert.ok(cutoff>0);
const prefix=source.slice(0,cutoff), sf=ts.createSourceFile(input,prefix,ts.ScriptTarget.Latest,true,ts.ScriptKind.JS);
const edits=[],targets=[];
const names=/^(buildCausalComposition|prepareCausalOptions|causalColdNodeNames|prepareConstruction|buildCausalNodes|assertCausalOccurrenceTopology|createCausalCapabilities|causalBinding|startConstruction|transitionCausalAuthority|prepareCommittedEffectsView)2?$/;
function visit(n){
 if(ts.isFunctionDeclaration(n)&&n.name&&names.test(n.name.text)&&n.body){
  const key=n.name.text;targets.push(key);
  edits.push([n.body.getStart(sf)+1,`const __p=globalThis.__profileEnter(${JSON.stringify(key)});try {`]);
  edits.push([n.body.end-1,`}finally{globalThis.__profileExit(__p);}`]);
 }
 if(ts.isMethodDeclaration(n)&&n.body&&n.parent.name&&/^ConstructionScope2?$/.test(n.parent.name.text)&&['seal','transferToGraph','readIncoming','node','assertContext'].includes(n.name.getText(sf))){
  const key=n.parent.name.text+'.'+n.name.getText(sf);targets.push(key);
  edits.push([n.body.getStart(sf)+1,`const __p=globalThis.__profileEnter(${JSON.stringify(key)});try {`]);
  edits.push([n.body.end-1,`}finally{globalThis.__profileExit(__p);}`]);
 }
 ts.forEachChild(n,visit);
}visit(sf);
let text=prefix;for(const [at,insert] of edits.sort((a,b)=>b[0]-a[0]))text=text.slice(0,at)+insert+text.slice(at);
text+=`
let stats={},stack=[];
globalThis.__profileEnter=key=>{const frame={key,start:performance.now(),child:0};stack.push(frame);return frame;};
globalThis.__profileExit=frame=>{const end=performance.now(),duration=end-frame.start;stack.pop();if(stack.length)stack.at(-1).child+=duration;const s=stats[frame.key]??={count:0,totalMs:0,selfMs:0};s.count++;s.totalMs+=duration;s.selfMs+=duration-frame.child;};
const scenario=trace(1,0,false),empty={...scenario,arrivals:[]},rows=[];
for(const background of [0,1000]){
 for(let i=0;i<100;i++){run(false,empty,background);run(true,empty,background);}
 for(let i=0;i<100;i++)for(const candidate of i%2?[true,false]:[false,true]){
  stats={};const r=run(candidate,empty,background);rows.push({background,pair:i,candidate,constructionNs:r.constructionNs,stats});
 }
}
writeFileSync(${JSON.stringify(output)},JSON.stringify({purpose:'Instrumented call attribution only; clock/wrapper overhead prevents using timings as budget evidence.',targets:${JSON.stringify(targets)},rows},null,2));
`;
writeFileSync(base+'/construction-profile.mjs',text);
const child=spawnSync(process.execPath,[base+'/construction-profile.mjs'],{encoding:'utf8',timeout:90000});
writeFileSync(base+'/construction-profile.log',child.stdout+child.stderr+'\nDONE status='+child.status+'\n');
assert.ifError(child.error);assert.equal(child.status,0,child.stderr);
const hash=x=>'sha256:'+createHash('sha256').update(x).digest('hex');
writeFileSync(base+'/construction-profile.bindings.json',JSON.stringify({input:hash(source),runner:hash(readFileSync(import.meta.filename)),instrumentedBundle:hash(text),output:hash(readFileSync(output)),targets},null,2));
console.log('DONE construction profile',targets.length);
