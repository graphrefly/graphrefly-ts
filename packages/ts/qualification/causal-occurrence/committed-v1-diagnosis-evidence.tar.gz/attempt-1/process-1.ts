
import assert from 'node:assert/strict';
import { performance, PerformanceObserver } from 'node:perf_hooks';
import { writeFileSync } from 'node:fs';
import { Graph as ReferenceGraph } from '/var/folders/1k/6k95mf1117q9_klyvs61pml00000gn/T/causal-diagnosis-MCsTJe/d9/graph/graph.ts';
import { causalOccurrenceBundle as referenceBundle } from '/var/folders/1k/6k95mf1117q9_klyvs61pml00000gn/T/causal-diagnosis-MCsTJe/d9/solutions/causal-occurrence.ts';
import { Graph } from '/Users/davidchenallio/src/graphrefly-ts/packages/ts/src/graph/graph.ts';
import { causalOccurrenceBundle, causalOccurrenceDigest } from '/Users/davidchenallio/src/graphrefly-ts/packages/ts/src/solutions/causal-occurrence.ts';
import { constructionOf } from '/Users/davidchenallio/src/graphrefly-ts/packages/ts/src/graph/construction-scope.ts';
const lanes = ['occurrences','admissions','branch-terminals','effect-proposals','effect-admissions','effect-outcomes','evidence','watermarks'];
const props = ['occurrences','admissions','branchTerminals','effectProposals','effectAdmissions','effectOutcomes','evidence','watermarks'];
const opts = {name:'causal',requiredBranches:['a','b'],requiredEvidenceKinds:['proof'],maxOccurrences:64,maxPending:512,maxEffects:64,maxEvidence:512};
const ok = value => ({kind:'ok',value});
const issue = {kind:'issue',code:'failed',message:'failed'};
function trace(count, evidenceCount, reverse, capacity = 64) {
 const arrivals=[];
 const send=(lane, ...values)=>arrivals.push({lane,values});
 for(let i=1;i<=count;i++) {
  const raw={revisionDomain:'run',occurrenceId:'occ-'+i,revision:i,sourceRefs:[{kind:'input',id:'input-'+i}],value:i};
  const occurrence={...raw,digest:causalOccurrenceDigest(raw)};
  const decision={occurrence,decisionId:'decision-'+i,decisionDigest:'sha256:'+'a'.repeat(64),state:'admitted'};
  const proposal={occurrence,effectId:'effect-'+i,requestRef:{kind:'request',id:'request-'+i},proposalDigest:'sha256:'+'b'.repeat(64)};
  const admission={...proposal,state:'admitted',admissionRef:{kind:'admission',id:'admission-'+i}};
  send('occurrences',occurrence); send('admissions',decision);
  send('watermarks',{revisionDomain:'run',revision:i});
  send('branch-terminals',...['a','b'].map(branch=>({occurrence,branch,state:'completed',result:ok(branch)})));
  send('effect-proposals',proposal); send('effect-admissions',admission);
  send('effect-outcomes',{...admission,admissionRef:{kind:'admission',id:'wrong'},state:'failed',result:{kind:'error',error:issue}});
  send('effect-outcomes',{...admission,state:'succeeded',result:ok(i)});
  for(let j=0;j<Math.floor(evidenceCount/count);j++)send('evidence',{occurrence,evidenceKind:'proof',evidenceId:'proof-'+i+'-'+j,evidenceDigest:'sha256:'+'c'.repeat(64),coverage:'included'});
  send('occurrences',occurrence); send('admissions',decision);
 }
 if(reverse)arrivals.reverse();
 return {arrivals,options:{...opts,maxOccurrences:capacity,maxEvidence:Math.max(1,evidenceCount)},count,evidenceCount,reverse,capacity};
}

const originalPorts=['released','currentness','terminals','conservation','coverage','quiescence','issues'];
function run(candidate, scenario, background=0) {
 const runStart=performance.now();const cpuStart=process.cpuUsage();const heapStart=process.memoryUsage().heapUsed;const g=candidate?new Graph():new ReferenceGraph(); const stops=[];
 const retain=g.retain.bind(g);g.retain=(n,o)=>{const stop=retain(n,o);stops.push(stop);return stop;};
 for(let i=0;i<background;i++)g.node([],null,{name:'background/'+i});
 const inputs=Object.fromEntries(props.map(prop=>[prop,g.node([],null,{name:'source/'+prop})]));
 const start=performance.now();
 const ports=(candidate?causalOccurrenceBundle:referenceBundle)(g,{...scenario.options,...inputs});
 if(!candidate)g.node([g.find('causal/authority')],()=>{}, {name:'causal/committed-effects',factory:'causalCommittedEffectsProjection'});
 const constructionNs=(performance.now()-start)*1e6;
 const events=[];const timings=[];const intervals=[];const subscribedAt=performance.now();
 for(const port of originalPorts)stops.push(ports[port].subscribe(m=>{if(m[0]!=='START')events.push([port,m[0],m.length>1?m[1]:null]);}));
 const describeStart=performance.now();const shape=g.describe().nodes.map(({id,factory,deps})=>({id,factory,deps})).sort((a,b)=>a.id.localeCompare(b.id));
 const describeEnd=performance.now();for(const arrival of scenario.arrivals){const t=performance.now();inputs[props[lanes.indexOf(arrival.lane)]].down(arrival.values.map(v=>['DATA',v]));const end=performance.now();timings.push((end-t)*1e6);intervals.push({lane:arrival.lane,start:t,end});}
 const cleanupStart=performance.now();for(const stop of stops.reverse())stop();
 for(const lease of constructionOf(g,'causal')?.roots??[])lease.unsubscribe?.();
 const group=g.topologyGroup();for(const n of g.describe().nodes)group.add(g.find(n.id));group.release();
 assert.equal(g.describe().nodes.length,0);
 return {events,shape,constructionNs,timings,intervals,runStart,runEnd:performance.now(),cpu:process.cpuUsage(cpuStart),heapStart,heapEnd:process.memoryUsage().heapUsed,phases:{constructStart:start,constructEnd:start+constructionNs/1e6,subscribeMs:describeStart-subscribedAt,describeMs:describeEnd-describeStart,cleanupStart}};
}

const gc=[];const observer=new PerformanceObserver(list=>{for(const e of list.getEntries())gc.push({start:e.startTime,duration:e.duration,detail:e.detail});});observer.observe({entryTypes:['gc']});
const tick=()=>new Promise(resolve=>setImmediate(resolve));
const scenario=trace(1,0,false),empty={...scenario,arrivals:[]};
const rows=[];
for(const background of [1000,0]) {
 const before=run(false,scenario,background),after=run(true,scenario,background);
 assert.deepEqual(before.events,after.events);assert.deepEqual(before.shape,after.shape);
 const samples=[];
 for(const [phase,trace,warm,pairs] of [['construction',empty,80,100],['steady',scenario,20,80]]) {
  for(let i=0;i<warm;i++){run(false,trace,background);run(true,trace,background);if(i%10===0)await tick();}
  for(let i=0;i<pairs;i++) {
   for(const candidate of i%2?[true,false]:[false,true]) {
    const value=run(candidate,trace,background);delete value.events;delete value.shape;
    samples.push({phase,pair:i,candidate,...value});await tick();
   }
  }
 }
 rows.push({background,samples});console.log('row done',background);
}
await tick();await tick();for(const e of observer.takeRecords())gc.push({start:e.startTime,duration:e.duration,detail:e.detail});observer.disconnect();
writeFileSync("/Users/davidchenallio/.codex/visualizations/2026/09/06/01a077c7-55e6-7f11-9d4f-e7c51944afb4/committed-view-diagnosis/attempt-1/process-1.json",JSON.stringify({runtime:process.version,platform:process.platform,arch:process.arch,config:{"baseline":"d9","backgrounds":[1000,0]},arrivals:scenario.arrivals.map(x=>x.lane),rows,gc},null,2));
