import json, math, statistics, hashlib
from pathlib import Path
b=Path(__file__).parent
q=lambda a,p=.5: sorted(a)[math.ceil(len(a)*p)-1]
files=[b/'attempt-1/process-0.json',*[b/f'attempt-2/process-{i}.json' for i in [1,2,3]]]
result={'meaning':'Finite diagnostic evidence only; every successful process retained. No replacement of qualification-failed committed-v1.', 'rows':[],'sources':{}}
for f in files:
 r=json.loads(f.read_text());result['sources'][str(f.relative_to(b))]='sha256:'+hashlib.sha256(f.read_bytes()).hexdigest()
 for row in r['rows']:
  arms=[]
  for candidate in [False,True]:
   ss=[s for s in row['samples'] if s['phase']=='steady' and s['candidate']==candidate];cs=[s for s in row['samples'] if s['phase']=='construction' and s['candidate']==candidate]
   assert len(ss)==80 and len(cs)==100
   assert all(len(s['timings'])==len(s['intervals'])==10 for s in ss)
   latency=[max(s['timings']) for s in ss];ct=[s['constructionNs'] for s in cs]
   overlaps=[]
   for s in ss:
    for i,t in enumerate(s['intervals']):
     es=[e for e in r['gc'] if e['start']<t['end'] and e['start']+e['duration']>t['start']]
     if es:overlaps.append({'pair':s['pair'],'arrival':i,'latencyNs':s['timings'][i],'gc':es})
   arms.append({'candidate':candidate,'constructMedianNs':q(ct),'constructP95Ns':q(ct,.95),'steadyMedianMaxNs':q(latency),'steadyP95MaxNs':q(latency,.95),'gcInputOverlaps':overlaps,'gcConstructOverlapSamples':sum(any(e['start']<s['phases']['constructEnd'] and e['start']+e['duration']>s['phases']['constructStart'] for e in r['gc']) for s in cs),'lanes':[{'index':i,'lane':lane,'medianNs':q([s['timings'][i] for s in ss]),'p95Ns':q([s['timings'][i] for s in ss],.95)} for i,lane in enumerate(r['arrivals'])],'maxArrivalCounts':dict(__import__('collections').Counter(str(s['timings'].index(max(s['timings']))) for s in ss))})
  result['rows'].append({'process':str(f.relative_to(b)),'baseline':r['config']['baseline'],'background':row['background'],'constructP95Ratio':arms[1]['constructP95Ns']/arms[0]['constructP95Ns'],'steadyRatio':arms[1]['steadyMedianMaxNs']/arms[0]['steadyMedianMaxNs'],'arms':arms})
profile=json.loads((b/'construction-profile-v2.json').read_text())
result['constructionProfile']=[]
for bg in [0,1000]:
 for arm in [False,True]:
  rows=[x for x in profile['rows'] if x['background']==bg and x['candidate']==arm];suffix='2' if arm else ''
  assert len(rows)==100
  for row in rows:
   assert row['stats']['buildCausalComposition'+suffix]['count']==1
   assert all(not k.startswith(('transitionCausalAuthority','prepareCommittedEffectsView')) for k in row['stats'])
  result['constructionProfile'].append({'background':bg,'candidate':arm,'authorityInvocations':0,'viewHelperInvocations':0,'instrumentedMedianUs':{k:statistics.median(row['stats'][k]['totalMs'] for row in rows)*1000 for k in rows[0]['stats']},'note':'Nested instrumented timings are not additive; whole builder includes graph node creation, topology validation and capability issuance. No time evidence from profile v1: its final background=0 stats object was mutated by the next warmup.'})
old=json.loads((b.parent/'committed-view-implementation/matched-perf-final.json').read_text())
result['original']={'backgroundSteady':old['performanceRows'][3]['steady'],'count64LastThreeSlowBothArms':old['performanceRows'][2]['steady'],'qualificationStillFailed':True}
(b/'summary.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'rows':[{k:v for k,v in r.items() if k!='arms'} for r in result['rows']],'profile':result['constructionProfile']},indent=2))
