import json, math, hashlib
from pathlib import Path
p=Path(__file__).parent
root=Path('/Users/davidchenallio/src/graphrefly-ts')
h=lambda b:'sha256:'+hashlib.sha256(b).hexdigest()
def pct(xs,q):return sorted(xs)[math.ceil(len(xs)*q)-1]
x=json.loads((p/'full-construction-report.json').read_text())
assert len(x['comparisons'])==6 and all(c['matched'] for c in x['comparisons'])
assert [(r['count'],r['evidence'],r['background']) for r in x['performanceRows']]==[(1,0,0),(16,128,0),(64,512,0),(1,0,1000)]
rows=[]
for r in x['performanceRows']:
 c=r['construction'];s=r['steady'];assert len(c['baseline'])==len(c['candidate'])==900
 for arm in ['baseline','candidate']:
  assert c[arm]==sum([b[arm] for b in c['batches']],[])
  assert c[arm+'P95Ns']==pct(c[arm],.95)
  assert s[arm+'MedianP95Ns']==pct(s[arm],.5)
 assert c['ratio']==c['candidateP95Ns']/c['baselineP95Ns']
 assert s['ratio']==s['candidateMedianP95Ns']/s['baselineMedianP95Ns']
 assert c['ratio']<=1.20 and s['ratio']<=1.10
 rows.append({'effects':r['count'],'evidence':r['evidence'],'background':r['background'],'constructionRatio':c['ratio'],'steadyRatio':s['ratio']})
for i in range(4):
 d=json.loads((p/f'process-{i}.json').read_text());assert d['p95Ratio']<1 and d['medianRatio']<=1
 for c in d['comparisons']:assert c['phase']==('faulted' if c['fault'] else 'started')
b=json.loads((p/'bindings-before.json').read_text())
for path,digest in b['sourceBindings'].items():assert h(Path(path).read_bytes())==digest,path
assert h((p/'bundle.mjs').read_bytes())==b['bundle']
assert h((p/'compare.mjs').read_bytes())==b['script']
for path,digest in b['harness'].items():assert h((root/path).read_bytes())==digest
for path in (p/'candidate/packages/ts/src').rglob('*.ts'):assert path.read_bytes()==(root/'packages/ts/src'/path.relative_to(p/'candidate/packages/ts/src')).read_bytes()
full=json.loads((p/'full-construction.check.json').read_text());assert full['exitCode']==0 and full['sourceUnchanged']
assert h((p/'full-construction.log').read_bytes())==full['logDigest']
assert h((p/'full-construction-bundle.mjs').read_bytes())=='sha256:'+json.loads((p/'full-bundle-capture.json').read_text())['sha256']
assert x['runnerDigest']==h((root/'scripts/compare-causal-construction.mjs').read_bytes())
control=json.loads((p/'boundary-report.json').read_text())['results']
assert control['original']['outcome']['result']=='rejected'
assert control['original']['reads']==2 and control['original']['remainingBeforeCleanup']==8
assert control['skip-source-rescan']['outcome']['result']=='accepted'
assert all(c['cleanupNodes']==0 for c in control.values())
helper=json.loads((p/'helper-result.json').read_text());assert helper['passed'] and len(helper['cases'])==168
result={'performanceGatePassed':True,'rows':rows,'constructionSamples':7200,'steadyLifecycles':108,'directMeasuredPairs':3600,'explicitExpectedPhaseChecks':8,'helperCases':168,'customInspectorFaultRejected':True,'runtimeMutationDetected':True,'sourceStillMatchesCandidate':True,'qualificationComplete':False,'reasonIncomplete':'D159 no-network source binding remains stale; full source qualification refresh is outside this material-only batch.'}
(p/'verification.json').write_text(json.dumps(result,indent=2)+'\n')
print('MATERIAL_VERIFICATION_DONE')
