
import assert from 'node:assert/strict';
import {writeFileSync} from 'node:fs';
import {Graph} from '/Users/davidchenallio/src/graphrefly-ts/packages/ts/src/graph/graph.ts';
import {causalOccurrenceBundle,causalOccurrenceRequiredEdges,assertCausalOccurrenceTopology} from '/Users/davidchenallio/src/graphrefly-ts/packages/ts/src/solutions/causal-occurrence.ts';
import {constructionOf} from '/Users/davidchenallio/src/graphrefly-ts/packages/ts/src/graph/construction-scope.ts';
const lanes=['occurrences','admissions','branch-terminals','effect-proposals','effect-admissions','effect-outcomes','evidence','watermarks'];
const props=['occurrences','admissions','branchTerminals','effectProposals','effectAdmissions','effectOutcomes','evidence','watermarks'];
const edges=[...lanes.map(lane=>({from:'source/'+lane,to:'causal/input/'+lane})),...causalOccurrenceRequiredEdges('causal')];
assert.equal(edges.length,30);
const missing=[];
for(let remove=-1;remove<edges.length;remove++){
 const description={edges:edges.filter((e,i)=>i!==remove)};
 try{assertCausalOccurrenceTopology(description,'causal');missing.push({remove,result:'accepted'});}
 catch(e){missing.push({remove,result:'rejected',name:e.name,message:e.message});}
}
const g=new Graph(),inputs=Object.fromEntries(props.map(prop=>[prop,g.node([],null,{name:'source/'+prop})]));
const originalDescribe=g.describe;const native=originalDescribe.bind(g);
let reads=0;g.describe=()=>{const snap=native();return {...snap,get edges(){if(++reads===2)throw new RangeError('second edges read rejected');return snap.edges;}};};
let outcome;try{
 causalOccurrenceBundle(g,{...inputs,name:'causal',requiredBranches:['a'],requiredEvidenceKinds:[],maxOccurrences:1,maxPending:8,maxEffects:1,maxEvidence:1});
 outcome={result:'accepted'};
}catch(e){outcome={result:'rejected',name:e.name,message:e.message,cause:e.cause?.message};}
g.describe=originalDescribe;
const remainingBeforeCleanup=native().nodes.length;
for(const lease of constructionOf(g,'causal')?.roots??[])lease.unsubscribe?.();
const group=g.topologyGroup();for(const n of native().nodes)group.add(g.find(n.id));group.release();
assert.equal(native().nodes.length,0);
writeFileSync('/Users/davidchenallio/.codex/visualizations/2026/09/06/01a077c7-55e6-7f11-9d4f-e7c51944afb4/committed-view-material-trial/skip-source-rescan-boundary-result.json',JSON.stringify({missing,outcome,reads,remainingBeforeCleanup,cleanupNodes:0}));
console.log('BOUNDARY_CHILD_DONE');
