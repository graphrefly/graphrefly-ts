/** One finite, predeclared direct comparison; never replaces the original C gate. */
import assert from 'node:assert/strict';
import {spawnSync} from 'node:child_process';
import {createHash} from 'node:crypto';
import {readFileSync,writeFileSync,mkdirSync,existsSync} from 'node:fs';
import {dirname,join,resolve} from 'node:path';
import {fileURLToPath} from 'node:url';
import {build} from '/Users/davidchenallio/src/graphrefly-ts/node_modules/esbuild/lib/main.js';
const out=dirname(fileURLToPath(import.meta.url));
const root='/Users/davidchenallio/src/graphrefly-ts';
const baseline='03e008ccb6adaf7844b75b0df6309f11c1094330';
const changed='packages/ts/src/solutions/causal-occurrence/construction.ts';
const hash=x=>'sha256:'+createHash('sha256').update(x).digest('hex');
const put=(name,x)=>{assert.equal(existsSync(join(out,name)),false,name);writeFileSync(join(out,name),JSON.stringify(x,null,2)+'\n');};
const git=args=>{const x=spawnSync('git',args,{cwd:root,encoding:'utf8',maxBuffer:32e6});assert.ifError(x.error);assert.equal(x.status,0,x.stderr);return x.stdout;};
assert.equal(git(['rev-parse','HEAD']).trim(),baseline);
assert.deepEqual(git(['diff','--name-only',baseline,'--','packages/ts/src']).trim().split('\n'),[changed]);
const harnessNames=['scripts/compare-causal-authority.mjs','scripts/compare-causal-cold-standalone.mjs'];
const harness=Object.fromEntries(harnessNames.map(p=>[p,readFileSync(join(root,p),'utf8')]));
const self=readFileSync(fileURLToPath(import.meta.url));
put('scope.json',{baseline,qualification:false,changed,layout:'4 fresh processes; each 3 batches, each 100 paired warmups then 300 measured pairs; pair order alternates with process and batch; empty 1-effect construction; all arrays retained',screen:'Proceed to original qualification only if all four process construction p95 ratios are <1 and medians are <=1. Otherwise remove this performance-only patch and retain evidence. This conservative directional screen is not statistical proof or a new performance budget.',originalGate:'Frozen ts-v4 and <=1.20/<=1.10 unchanged',directBaselineMeaning:'Immediate pre-change production source; not frozen ts-v4',user:'好的，继续 after six-local-string proposal; earlier commit request applies'});
const captured={};
await build({stdin:{contents:`export {Graph} from '${root}/packages/ts/src/graph/graph.ts';export {causalOccurrenceBundle} from '${root}/packages/ts/src/solutions/causal-occurrence.ts';export {constructionOf} from '${root}/packages/ts/src/graph/construction-scope.ts';`,loader:'ts',resolveDir:root},outfile:join(out,'capture.mjs'),bundle:true,format:'esm',platform:'node',define:{__GRAPHREFLY_TS_PACKAGE_REVISION__:'"graphrefly-ts:0.9.0"'},metafile:true,plugins:[{name:'freeze-source',setup(b){b.onLoad({filter:/\.ts$/},a=>{const text=readFileSync(a.path,'utf8');captured[a.path]=text;return {contents:text,loader:'ts'};});}}]}).then(result=>{for(const p of Object.keys(result.metafile.inputs).filter(p=>p!=='<stdin>'))assert.ok(captured[resolve(root,p)],p);});
const sourceBindings={};
for(const [path,text] of Object.entries(captured)){
 assert.ok(path.startsWith(root+'/packages/ts/src/'),path);
 assert.equal(readFileSync(path,'utf8'),text,'source changed while capturing');
 const relative=path.slice(root.length+1),old=git(['show',baseline+':'+relative]);
 if(relative!==changed)assert.equal(old,text,relative);
 for(const [arm,bytes] of [['reference',old],['candidate',text]]){const target=join(out,arm,relative);mkdirSync(dirname(target),{recursive:true});writeFileSync(target,bytes);sourceBindings[target]=hash(bytes);}
}
const fixtureSource=harness[harnessNames[0]];
const fixture=fixtureSource.slice(fixtureSource.indexOf('const lanes ='),fixtureSource.indexOf('function graphRun(make, scenario)'));
assert.ok(fixture.includes('function trace('));
const source=harness[harnessNames[1]];
let run=source.slice(source.indexOf('function run(candidate,'),source.indexOf('const scenarios=['));
const lines=run.split('\n'),removed=lines.filter(l=>l.includes('if(!candidate && ${Boolean(baselineCommit)})'));
assert.equal(removed.length,1);run=lines.filter(l=>!removed.includes(l)).join('\n');
assert.ok(run.includes('return {events,shape,constructionNs,timings,phase};'));
const runner=`
import assert from 'node:assert/strict';
import {performance} from 'node:perf_hooks';
import {writeFileSync} from 'node:fs';
import {Graph as ReferenceGraph} from '${out}/reference/packages/ts/src/graph/graph.ts';
import {causalOccurrenceBundle as referenceBundle} from '${out}/reference/packages/ts/src/solutions/causal-occurrence.ts';
import {constructionOf as referenceConstructionOf} from '${out}/reference/packages/ts/src/graph/construction-scope.ts';
import {Graph} from '${out}/candidate/packages/ts/src/graph/graph.ts';
import {causalOccurrenceBundle,causalOccurrenceDigest} from '${out}/candidate/packages/ts/src/solutions/causal-occurrence.ts';
import {constructionOf} from '${out}/candidate/packages/ts/src/graph/construction-scope.ts';
${fixture}
const originalPorts=['startup','released','currentness','terminals','conservation','coverage','quiescence','issues'];
const percentile=(xs,p)=>[...xs].sort((a,b)=>a-b)[Math.ceil(xs.length*p)-1];
${run}
const processIndex=Number(process.argv[2]);
const scenario=trace(1,0,false),empty={...scenario,arrivals:[]};
const comparisons=[];
for(const fault of [false,true]){const a=run(false,scenario,0,fault),b=run(true,scenario,0,fault);assert.deepEqual(a.events,b.events);assert.deepEqual(a.shape,b.shape);assert.equal(a.phase,b.phase);comparisons.push({fault,events:a.events,shape:a.shape,phase:a.phase});}
const batches=[],a=[],b=[];
for(let batch=0;batch<3;batch++){
 for(let i=0;i<100;i++){run((i+processIndex)%2===0,empty);run((i+processIndex)%2!==0,empty);}
 const aa=[],bb=[];
 for(let i=0;i<300;i++){if((i+batch+processIndex)%2){bb.push(run(true,empty).constructionNs);aa.push(run(false,empty).constructionNs);}else{aa.push(run(false,empty).constructionNs);bb.push(run(true,empty).constructionNs);}}
 a.push(...aa);b.push(...bb);batches.push({baseline:aa,candidate:bb,p95Ratio:percentile(bb,.95)/percentile(aa,.95)});
}
writeFileSync('${out}/process-'+processIndex+'.json',JSON.stringify({processIndex,comparisons,batches,baseline:a,candidate:b,baselineP95Ns:percentile(a,.95),candidateP95Ns:percentile(b,.95),p95Ratio:percentile(b,.95)/percentile(a,.95),medianRatio:percentile(b,.5)/percentile(a,.5),medianDeltaNs:percentile(b,.5)-percentile(a,.5)}));
console.log('MATERIAL_PROCESS_DONE '+processIndex);
`;
writeFileSync(join(out,'runner.ts'),runner);
const bundle=join(out,'bundle.mjs');
const compiledBytes={};
const built=await build({stdin:{contents:runner,loader:'ts',resolveDir:root},outfile:bundle,bundle:true,platform:'node',format:'esm',metafile:true,define:{__GRAPHREFLY_TS_PACKAGE_REVISION__:'"graphrefly-ts:0.9.0"'},plugins:[{name:'verify-frozen-source',setup(b){b.onLoad({filter:/\.ts$/},a=>{const text=readFileSync(a.path,'utf8');assert.equal(hash(text),sourceBindings[a.path],a.path);compiledBytes[a.path]=hash(text);return {contents:text,loader:'ts'};});}}]});
for(const p of Object.keys(built.metafile.inputs).filter(p=>p!=='<stdin>'))assert.ok(compiledBytes[resolve(root,p)],p);
put('bindings-before.json',{baseline,sourceBindings,compiledBytes,harness:Object.fromEntries(Object.entries(harness).map(([p,text])=>[p,hash(text)])),script:hash(self),runner:hash(runner),bundle:hash(readFileSync(bundle)),node:process.version});
const results=[];
for(let i=0;i<4;i++){
 const started=new Date().toISOString();
 const child=spawnSync(process.execPath,[bundle,String(i)],{encoding:'utf8',timeout:60000,maxBuffer:10e6});
 writeFileSync(join(out,'process-'+i+'.log'),child.stdout+child.stderr);
 put('process-'+i+'-check.json',{started,ended:new Date().toISOString(),exit:child.status,error:child.error?.message??null});
 assert.ifError(child.error);assert.equal(child.status,0,child.stderr);
 results.push(JSON.parse(readFileSync(join(out,'process-'+i+'.json'),'utf8')));
 for(const [path,text] of Object.entries(captured))assert.equal(readFileSync(path,'utf8'),text,'runtime source drift');
 for(const [path,digest] of Object.entries(sourceBindings))assert.equal(hash(readFileSync(path)),digest,'frozen source drift');
 assert.equal(hash(readFileSync(bundle)),JSON.parse(readFileSync(join(out,'bindings-before.json'),'utf8')).bundle);
 assert.equal(hash(readFileSync(fileURLToPath(import.meta.url))),hash(self));
 for(const [path,text] of Object.entries(harness))assert.equal(readFileSync(join(root,path),'utf8'),text);
 console.log('MATERIAL_PAIR_PROCESS_DONE '+i);
}
put('summary.json',{baseline,qualification:false,results:results.map(({comparisons,batches,baseline,candidate,...rest})=>rest),screenPassed:results.every(x=>x.p95Ratio<1&&x.medianRatio<=1),meaning:'Four fresh-process direct comparisons of immediate pre-change source and six-local candidate. No instrumentation, forced GC, custom inspector or altered checks inside measured construction. Not the frozen ts-v4 gate, not CSP11, and not confidence intervals.'});
console.log('MATERIAL_COMPARISON_DONE');
