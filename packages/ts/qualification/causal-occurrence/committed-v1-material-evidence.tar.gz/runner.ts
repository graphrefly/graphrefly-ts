
import assert from 'node:assert/strict';
import {performance} from 'node:perf_hooks';
import {writeFileSync} from 'node:fs';
import {Graph as ReferenceGraph} from '/Users/davidchenallio/.codex/visualizations/2026/09/06/01a077c7-55e6-7f11-9d4f-e7c51944afb4/committed-view-material-trial/reference/packages/ts/src/graph/graph.ts';
import {causalOccurrenceBundle as referenceBundle} from '/Users/davidchenallio/.codex/visualizations/2026/09/06/01a077c7-55e6-7f11-9d4f-e7c51944afb4/committed-view-material-trial/reference/packages/ts/src/solutions/causal-occurrence.ts';
import {constructionOf as referenceConstructionOf} from '/Users/davidchenallio/.codex/visualizations/2026/09/06/01a077c7-55e6-7f11-9d4f-e7c51944afb4/committed-view-material-trial/reference/packages/ts/src/graph/construction-scope.ts';
import {Graph} from '/Users/davidchenallio/.codex/visualizations/2026/09/06/01a077c7-55e6-7f11-9d4f-e7c51944afb4/committed-view-material-trial/candidate/packages/ts/src/graph/graph.ts';
import {causalOccurrenceBundle,causalOccurrenceDigest} from '/Users/davidchenallio/.codex/visualizations/2026/09/06/01a077c7-55e6-7f11-9d4f-e7c51944afb4/committed-view-material-trial/candidate/packages/ts/src/solutions/causal-occurrence.ts';
import {constructionOf} from '/Users/davidchenallio/.codex/visualizations/2026/09/06/01a077c7-55e6-7f11-9d4f-e7c51944afb4/committed-view-material-trial/candidate/packages/ts/src/graph/construction-scope.ts';
const lanes = ['occurrences','admissions','branch-terminals','effect-proposals','effect-admissions','effect-outcomes','evidence','watermarks'];
const props = ['occurrences','admissions','branchTerminals','effectProposals','effectAdmissions','effectOutcomes','evidence','watermarks'];
const opts = {name:'causal',requiredBranches:['a','b'],requiredEvidenceKinds:['proof'],maxOccurrences:64,maxPending:512,maxEffects:64,maxEvidence:512};
const ok = value => ({kind:'ok',value});
const issue = {kind:'issue',code:'failed',message:'failed'};
function trace(count, evidenceCount, reverse, capacity = 64) {
 const arrivals=[];
 const send=(lane, ...values)=>arrivals.push({lane,values});
 for(let i=1;i<=count;i++) {
  const raw={revisionDomain:'run',occurrenceId:'occ-'+i,revision:i,sourceRefs:[{kind:'input',id:'input-'+i}],value:i};
  const occurrence={...raw,digest:causalOccurrenceDigest(raw)};
  const decision={occurrence,decisionId:'decision-'+i,decisionDigest:'sha256:'+'a'.repeat(64),state:'admitted'};
  const proposal={occurrence,effectId:'effect-'+i,requestRef:{kind:'request',id:'request-'+i},proposalDigest:'sha256:'+'b'.repeat(64)};
  const admission={...proposal,state:'admitted',admissionRef:{kind:'admission',id:'admission-'+i}};
  send('occurrences',occurrence); send('admissions',decision);
  send('watermarks',{revisionDomain:'run',revision:i});
  send('branch-terminals',...['a','b'].map(branch=>({occurrence,branch,state:'completed',result:ok(branch)})));
  send('effect-proposals',proposal); send('effect-admissions',admission);
  send('effect-outcomes',{...admission,admissionRef:{kind:'admission',id:'wrong'},state:'failed',result:{kind:'error',error:issue}});
  send('effect-outcomes',{...admission,state:'succeeded',result:ok(i)});
  for(let j=0;j<Math.floor(evidenceCount/count);j++)send('evidence',{occurrence,evidenceKind:'proof',evidenceId:'proof-'+i+'-'+j,evidenceDigest:'sha256:'+'c'.repeat(64),coverage:'included'});
  send('occurrences',occurrence); send('admissions',decision);
 }
 if(reverse)arrivals.reverse();
 return {arrivals,options:{...opts,maxOccurrences:capacity,maxEvidence:Math.max(1,evidenceCount)},count,evidenceCount,reverse,capacity};
}

const originalPorts=['startup','released','currentness','terminals','conservation','coverage','quiescence','issues'];
const percentile=(xs,p)=>[...xs].sort((a,b)=>a-b)[Math.ceil(xs.length*p)-1];
function run(candidate, scenario, background=0, fault=false) {
 const g=candidate?new Graph():new ReferenceGraph(); const stops=[];
 const retain=g.retain.bind(g);g.retain=(n,o)=>{const stop=retain(n,o);stops.push(stop);return stop;};
 for(let i=0;i<background;i++)g.node([],null,{name:'background/'+i});
 const inputs=Object.fromEntries(props.map(prop=>[prop,fault&&prop==='watermarks'?g.producer(()=>{throw new Error('frozen startup fault');},{name:'source/'+prop}):g.node([],null,{name:'source/'+prop})]));
 const start=performance.now();
 const ports=(candidate?causalOccurrenceBundle:referenceBundle)(g,{...scenario.options,...inputs});
 const constructionNs=(performance.now()-start)*1e6;
 const events=[];const timings=[];
 for(const port of originalPorts)stops.push(ports[port].subscribe(m=>{if(m[0]!=='START')events.push([port,m[0],m.length>1?m[1]:null]);}));
 const shape=g.describe().nodes.map(({id,factory,deps})=>({id,factory,deps}));
 for(const arrival of scenario.arrivals){const t=performance.now();inputs[props[lanes.indexOf(arrival.lane)]].down(arrival.values.map(v=>['DATA',v]));timings.push((performance.now()-t)*1e6);}
 const phase=(candidate?constructionOf:referenceConstructionOf)(g,'causal')?.phase;
 for(const stop of stops.reverse())stop();
 for(const lease of (candidate?constructionOf:referenceConstructionOf)(g,'causal')?.roots??[])lease.unsubscribe?.();
 const group=g.topologyGroup();for(const n of g.describe().nodes)group.add(g.find(n.id));group.release();
 assert.equal(g.describe().nodes.length,0);
 return {events,shape,constructionNs,timings,phase};
}

const processIndex=Number(process.argv[2]);
const scenario=trace(1,0,false),empty={...scenario,arrivals:[]};
const comparisons=[];
for(const fault of [false,true]){const a=run(false,scenario,0,fault),b=run(true,scenario,0,fault);assert.deepEqual(a.events,b.events);assert.deepEqual(a.shape,b.shape);assert.equal(a.phase,b.phase);comparisons.push({fault,events:a.events,shape:a.shape,phase:a.phase});}
const batches=[],a=[],b=[];
for(let batch=0;batch<3;batch++){
 for(let i=0;i<100;i++){run((i+processIndex)%2===0,empty);run((i+processIndex)%2!==0,empty);}
 const aa=[],bb=[];
 for(let i=0;i<300;i++){if((i+batch+processIndex)%2){bb.push(run(true,empty).constructionNs);aa.push(run(false,empty).constructionNs);}else{aa.push(run(false,empty).constructionNs);bb.push(run(true,empty).constructionNs);}}
 a.push(...aa);b.push(...bb);batches.push({baseline:aa,candidate:bb,p95Ratio:percentile(bb,.95)/percentile(aa,.95)});
}
writeFileSync('/Users/davidchenallio/.codex/visualizations/2026/09/06/01a077c7-55e6-7f11-9d4f-e7c51944afb4/committed-view-material-trial/process-'+processIndex+'.json',JSON.stringify({processIndex,comparisons,batches,baseline:a,candidate:b,baselineP95Ns:percentile(a,.95),candidateP95Ns:percentile(b,.95),p95Ratio:percentile(b,.95)/percentile(a,.95),medianRatio:percentile(b,.5)/percentile(a,.5),medianDeltaNs:percentile(b,.5)-percentile(a,.5)}));
console.log('MATERIAL_PROCESS_DONE '+processIndex);
