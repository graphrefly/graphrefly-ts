import assert from 'node:assert/strict';
import {readFileSync,writeFileSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {spawnSync} from 'node:child_process';
import {build} from '/Users/davidchenallio/src/graphrefly-ts/node_modules/esbuild/lib/main.js';
const root='/Users/davidchenallio/src/graphrefly-ts',out=new URL('.',import.meta.url).pathname;
const sourcePath='packages/ts/src/solutions/causal-occurrence/construction.ts';
const original=readFileSync(root+'/'+sourcePath,'utf8');
const anchor='causalOccurrenceRequiredEdges(name, description)';
assert.equal(original.split(anchor).length,2);
const hypothetical=original.replace(anchor,'causalOccurrenceRequiredEdges(name)');
const hash=x=>createHash('sha256').update(x).digest('hex');
writeFileSync(out+'rejected-checker-change.json',JSON.stringify({sourcePath,sourceHash:hash(original),search:anchor,replacement:'causalOccurrenceRequiredEdges(name)',meaning:'Rejected shadow experiment only; no production file change'},null,2));
const results={};
for(const mode of ['original','skip-source-rescan']){
 const sourceHashes={};
 const runner=`
import assert from 'node:assert/strict';
import {writeFileSync} from 'node:fs';
import {Graph} from '${root}/packages/ts/src/graph/graph.ts';
import {causalOccurrenceBundle,causalOccurrenceRequiredEdges,assertCausalOccurrenceTopology} from '${root}/packages/ts/src/solutions/causal-occurrence.ts';
import {constructionOf} from '${root}/packages/ts/src/graph/construction-scope.ts';
const lanes=['occurrences','admissions','branch-terminals','effect-proposals','effect-admissions','effect-outcomes','evidence','watermarks'];
const props=['occurrences','admissions','branchTerminals','effectProposals','effectAdmissions','effectOutcomes','evidence','watermarks'];
const edges=[...lanes.map(lane=>({from:'source/'+lane,to:'causal/input/'+lane})),...causalOccurrenceRequiredEdges('causal')];
assert.equal(edges.length,30);
const missing=[];
for(let remove=-1;remove<edges.length;remove++){
 const description={edges:edges.filter((e,i)=>i!==remove)};
 try{assertCausalOccurrenceTopology(description,'causal');missing.push({remove,result:'accepted'});}
 catch(e){missing.push({remove,result:'rejected',name:e.name,message:e.message});}
}
const g=new Graph(),inputs=Object.fromEntries(props.map(prop=>[prop,g.node([],null,{name:'source/'+prop})]));
const originalDescribe=g.describe;const native=originalDescribe.bind(g);
let reads=0;g.describe=()=>{const snap=native();return {...snap,get edges(){if(++reads===2)throw new RangeError('second edges read rejected');return snap.edges;}};};
let outcome;try{
 causalOccurrenceBundle(g,{...inputs,name:'causal',requiredBranches:['a'],requiredEvidenceKinds:[],maxOccurrences:1,maxPending:8,maxEffects:1,maxEvidence:1});
 outcome={result:'accepted'};
}catch(e){outcome={result:'rejected',name:e.name,message:e.message,cause:e.cause?.message};}
g.describe=originalDescribe;
const remainingBeforeCleanup=native().nodes.length;
for(const lease of constructionOf(g,'causal')?.roots??[])lease.unsubscribe?.();
const group=g.topologyGroup();for(const n of native().nodes)group.add(g.find(n.id));group.release();
assert.equal(native().nodes.length,0);
writeFileSync('${out}${mode}-boundary-result.json',JSON.stringify({missing,outcome,reads,remainingBeforeCleanup,cleanupNodes:0}));
console.log('BOUNDARY_CHILD_DONE');
`;
 writeFileSync(out+mode+'-boundary-runner.ts',runner);
 const bundle=out+mode+'-boundary-bundle.mjs';
 const compiled=await build({stdin:{contents:runner,loader:'ts',resolveDir:root},outfile:bundle,bundle:true,format:'esm',platform:'node',metafile:true,define:{__GRAPHREFLY_TS_PACKAGE_REVISION__:'"graphrefly-ts:0.9.0"'},plugins:[{name:'shadow',setup(b){b.onLoad({filter:/\.ts$/},args=>{
 const text=readFileSync(args.path,'utf8');sourceHashes[args.path]=hash(text);
 return {contents:mode==='skip-source-rescan'&&args.path===root+'/'+sourcePath?hypothetical:text,loader:'ts'};
 });}}]});
 for(const path of Object.keys(compiled.metafile.inputs).filter(x=>x!=='<stdin>'))assert.ok(sourceHashes[root+'/'+path]);
 const check=spawnSync(process.execPath,[bundle],{encoding:'utf8',timeout:60000});
 writeFileSync(out+mode+'-boundary.log',check.stdout+check.stderr);
 assert.ifError(check.error);assert.equal(check.status,0,check.stderr);
 for(const [path,digest] of Object.entries(sourceHashes))assert.equal(hash(readFileSync(path)),digest);
 results[mode]={...JSON.parse(readFileSync(out+mode+'-boundary-result.json','utf8')),sourceHashes,bundleHash:hash(readFileSync(bundle))};
}
assert.deepEqual(results.original.missing,results['skip-source-rescan'].missing);
assert.equal(results.original.outcome.result,'rejected');
assert.equal(results['skip-source-rescan'].outcome.result,'accepted');
writeFileSync(out+'boundary-report.json',JSON.stringify({qualification:false,results,conclusion:'Deleting the rescan preserves the 30 ordinary missing-edge checks but changes a supported custom-inspection failure during real construction. Reject this global shortcut.'},null,2));
console.log('BOUNDARY_CHECK_DONE');
