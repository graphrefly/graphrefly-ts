
import assert from 'node:assert/strict';
import {performance} from 'node:perf_hooks';
import {writeFileSync} from 'node:fs';
import {Graph, Graph as ReferenceGraph} from '/Users/davidchenallio/src/graphrefly-ts/packages/ts/src/graph/graph.ts';
import {causalOccurrenceBundle, causalOccurrenceBundle as referenceBundle, causalOccurrenceDigest} from '/Users/davidchenallio/src/graphrefly-ts/packages/ts/src/solutions/causal-occurrence.ts';
import {constructionOf} from '/Users/davidchenallio/src/graphrefly-ts/packages/ts/src/graph/construction-scope.ts';
const originalPorts=['released','currentness','terminals','conservation','coverage','quiescence','issues'];
const mode="counts";
const probe=globalThis.__coldProbe={active:false,records:[],stack:[],counts:{},
 enter(name){if(!this.active)return null;this.counts[name]=(this.counts[name]??0)+1;if(mode!=='phases')return null;const token={name,start:performance.now(),children:0};this.stack.push(token);return token;},
 leave(token){if(!token)return;const end=performance.now();assert.equal(this.stack.pop(),token);const inclusiveMs=end-token.start;const parent=this.stack.at(-1);if(parent)parent.children+=inclusiveMs;this.records.push({name:token.name,inclusiveMs,selfMs:inclusiveMs-token.children});},
 bump(name){if(this.active)this.counts[name]=(this.counts[name]??0)+1;},
 reset(){assert.equal(this.stack.length,0);this.records=[];this.counts={};}
};
const lanes = ['occurrences','admissions','branch-terminals','effect-proposals','effect-admissions','effect-outcomes','evidence','watermarks'];
const props = ['occurrences','admissions','branchTerminals','effectProposals','effectAdmissions','effectOutcomes','evidence','watermarks'];
const opts = {name:'causal',requiredBranches:['a','b'],requiredEvidenceKinds:['proof'],maxOccurrences:64,maxPending:512,maxEffects:64,maxEvidence:512};
const ok = value => ({kind:'ok',value});
const issue = {kind:'issue',code:'failed',message:'failed'};
function trace(count, evidenceCount, reverse, capacity = 64) {
 const arrivals=[];
 const send=(lane, ...values)=>arrivals.push({lane,values});
 for(let i=1;i<=count;i++) {
  const raw={revisionDomain:'run',occurrenceId:'occ-'+i,revision:i,sourceRefs:[{kind:'input',id:'input-'+i}],value:i};
  const occurrence={...raw,digest:causalOccurrenceDigest(raw)};
  const decision={occurrence,decisionId:'decision-'+i,decisionDigest:'sha256:'+'a'.repeat(64),state:'admitted'};
  const proposal={occurrence,effectId:'effect-'+i,requestRef:{kind:'request',id:'request-'+i},proposalDigest:'sha256:'+'b'.repeat(64)};
  const admission={...proposal,state:'admitted',admissionRef:{kind:'admission',id:'admission-'+i}};
  send('occurrences',occurrence); send('admissions',decision);
  send('watermarks',{revisionDomain:'run',revision:i});
  send('branch-terminals',...['a','b'].map(branch=>({occurrence,branch,state:'completed',result:ok(branch)})));
  send('effect-proposals',proposal); send('effect-admissions',admission);
  send('effect-outcomes',{...admission,admissionRef:{kind:'admission',id:'wrong'},state:'failed',result:{kind:'error',error:issue}});
  send('effect-outcomes',{...admission,state:'succeeded',result:ok(i)});
  for(let j=0;j<Math.floor(evidenceCount/count);j++)send('evidence',{occurrence,evidenceKind:'proof',evidenceId:'proof-'+i+'-'+j,evidenceDigest:'sha256:'+'c'.repeat(64),coverage:'included'});
  send('occurrences',occurrence); send('admissions',decision);
 }
 if(reverse)arrivals.reverse();
 return {arrivals,options:{...opts,maxOccurrences:capacity,maxEvidence:Math.max(1,evidenceCount)},count,evidenceCount,reverse,capacity};
}

function run(candidate, scenario, background=0) {
 const g=candidate?new Graph():new ReferenceGraph(); const stops=[];
 const retain=g.retain.bind(g);g.retain=(n,o)=>{const stop=retain(n,o);stops.push(stop);return stop;};
 for(let i=0;i<background;i++)g.node([],null,{name:'background/'+i});
 const inputs=Object.fromEntries(props.map(prop=>[prop,g.node([],null,{name:'source/'+prop})]));
 const start=performance.now();
 const ports=(candidate?causalOccurrenceBundle:referenceBundle)(g,{...scenario.options,...inputs});
 if(!candidate) {
  // Same physical resources and startup fact deliveries; old runtime has no C ownership guarantee.
  const startup=g.node([],null,{name:'causal/startup',factory:'graphConstructionStartup',initial:{kind:'graph-startup',instance:'causal',epoch:1,state:'starting'}});
  g.node([ports.quiescence],()=>{}, {name:'causal/causal-quiescence',factory:'causalLifecycleQuiescence'});
  g.node([g.find('causal/authority')],()=>{}, {name:'causal/committed-effects',factory:'causalCommittedEffectsProjection'});
  g.retain(startup); startup.down([['DATA',{kind:'graph-startup',instance:'causal',epoch:1,state:'started'}]]);
 }
 const constructionNs=(performance.now()-start)*1e6;
 const events=[];const timings=[];
 for(const port of originalPorts)stops.push(ports[port].subscribe(m=>{if(m[0]!=='START')events.push([port,m[0],m.length>1?m[1]:null]);}));
 const shape=g.describe().nodes.map(({id,factory,deps})=>({id,factory,deps})).sort((a,b)=>a.id.localeCompare(b.id));
 for(const arrival of scenario.arrivals){const t=performance.now();inputs[props[lanes.indexOf(arrival.lane)]].down(arrival.values.map(v=>['DATA',v]));timings.push((performance.now()-t)*1e6);}
 for(const stop of stops.reverse())stop();
 for(const lease of constructionOf(g,'causal')?.roots??[])lease.unsubscribe?.();
 const group=g.topologyGroup();for(const n of g.describe().nodes)group.add(g.find(n.id));group.release();
 assert.equal(g.describe().nodes.length,0);
 return {events,shape,constructionNs,timings};
}

const scenario=trace(1,0,false),empty={...scenario,arrivals:[]};
for(let i=0;i<200;i++)run(true,empty);
const samples=[];for(let i=0;i<500;i++){probe.reset();probe.active=true;const x=run(true,empty);probe.active=false;samples.push({constructionNs:x.constructionNs,counts:probe.counts,phases:probe.records});}
probe.reset();probe.active=true;const behavior=run(true,scenario);probe.active=false;const traceCounts=probe.counts;
probe.reset();probe.active=true;const background=run(true,empty,1000);probe.active=false;
assert.equal(probe.stack.length,0);
writeFileSync("/Users/davidchenallio/.codex/visualizations/2026/09/06/01a077c7-55e6-7f11-9d4f-e7c51944afb4/committed-view-cold-phases/counts-result.json",JSON.stringify({samples,behavior:{events:behavior.events,shape:behavior.shape},traceCounts,backgroundCounts:probe.counts,backgroundNodes:background.shape.length}));
console.log('COLD_PHASE_CHILD_DONE '+mode);
