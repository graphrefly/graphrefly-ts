from pathlib import Path
import json,hashlib,tarfile,subprocess
root=Path('/Users/davidchenallio/src/graphrefly-ts');out=Path(__file__).parent;q=root/'packages/ts/qualification/causal-occurrence'
sha=lambda b:'sha256:'+hashlib.sha256(b).hexdigest()
read=lambda n:json.loads((out/n).read_text())
v=read('attempt-verification.json');assert v['verified'] and v['qualificationPassed']
assert not (q/'committed-v3-receipt.json').exists(),'immutable receipt already exists'
current={str(f.relative_to(root)):sha(f.read_bytes()) for f in (root/'packages/ts/src').rglob('*') if f.is_file()}
assert current==v['sourceDigests'],'source changed after verification'
for p,h in v['runnerDigests'].items():assert sha((root/p).read_bytes())==h,p
for p,h in v['reportDigests'].items():assert sha((out/p).read_bytes())==h,p
assert read('closure-final.json')==v['qualificationBindings']
# Remeasure the current closure and constant bindings immediately before sealing.
measurement=out/'closure-seal.json'
r=subprocess.run(['pnpm','exec','tsx',str(out/'measure-closure.mts'),str(measurement)],cwd=root,capture_output=True,text=True)
(out/'seal-closure.log').write_text(r.stdout+r.stderr)
assert r.returncode==0,r.stdout+r.stderr
assert json.loads(measurement.read_text())==v['qualificationBindings']
for c in v['checks']:
 assert read(c['id']+'.check.json')==c
 assert sha((out/(c['id']+'.log')).read_bytes())==c['logDigest']
 assert read(c['id']+'.bindings.json')=={'before':current,'after':current}

# Retain actual final source and the generated binding files, never credentials or live directories.
for f in (root/'packages/ts/src').rglob('*'):
 if f.is_file():
  target=out/'source-snapshots'/f.relative_to(root);target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(f.read_bytes())
changed=subprocess.check_output(['git','diff','--name-only'],cwd=root,text=True).splitlines()
for n in changed:
 if n.startswith('packages/ts/evals/'):
  f=root/n;target=out/'candidate-bindings'/n;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(f.read_bytes())
for p in read('runner-bindings.json'):
 f=root/p;target=out/'runner-snapshots'/p;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(f.read_bytes())
soak=read('root-soak.check.json')
review=f'''# committed-v3：已批准的测试拆分与离线资格完成

Owner：graphrefly-ts；同一 work CAUSAL-COMMITTED-VIEW-TS。用户明确“批准” committed-v2 待审方案后执行。本批只修改离线测试的组织方式、三个 current 摘要及五个派生工件；生产 runtime、C/core、公共 API、wave protocol 与真实执行许可未变。

## 验收结果

- 原 120 排列拆为 120 个串行参数化 case 加一个 enumeration/support 对照；专项 121 passed，100 项因筛选未执行。全部候选/public/hidden verifier、6000 次显式 fresh VM context、rebinding/disjointness 和 bank-support 断言保留。
- 完整 no-network soak：221 passed，{soak['elapsedSeconds']:.2f} 秒。没有和本任务其他重测试并行；保留完整日志及结束标记。
- 默认全量：2257 passed，4 个原有 Podman live opt-in skips（3 个 local-untrusted-JS、1 个 PostgreSQL）。最终资格绑定与被验收源码一致。
- 原 causal/construction/cold mutation：73 / 25 / 16 分类检测通过。新 view mutation：11（8 实际输出、2 不可变、1 工作量）；另 2 项 deferred 邻接审计仅为结构检查，不计 runtime kill。
- 独立 plain-code/oracle：两臂各 12 场景、2 热输入顺序、33 行工作量/观测；原八 ports 分别对照冻结 ts-v8 和合格 d9c868dc，各 6 轨迹及 startup fault 一致。d9 对照添加一个空 view Node 匹配物理资源，不代表旧实现具备新能力。
- required-edge 168、incoming 144、资源 12 快照和 2 负对照、组合资源、browser、lint/typecheck、build/export、artifact、owner/workspace/dashboard 检查通过。

## 接受的取舍

用户批准将原来全部 120 排列合计 5 秒改为每个排列及 enumeration 各 5 秒。测试数从 101 变为 221；总验证工作未减少，不据此承诺更快，也不将通过解释为恢复了旧的合计 5 秒门槛。library 用户的入口、认知负担和 runtime 成本没有变化。

历史 committed-v2 的 96 pass/5 fail 及诊断继续保留；本次通过不证明首次超时或 grant 失败的历史根因。没有删除失败样本或重写旧收据。

## 性能与证据边界

独立复核 material-v1 原始 7200 构造样本、108 稳态 lifecycle 和六条对照轨迹；原四行 construction ≤1.20 / steady ≤1.10 均通过。全部被测 runtime 与实际 harness 摘要相同；431 个源码文件中唯一差异是本次测试文件，位于测量闭包之外。没有新性能运行，也没有新增性能提升声明。历史 1.839833 异常原因仍未知。

本次 receipt、archive 绑定命令、原始报告、源码、测试、runner、oracle、基线、运行前后摘要及静态审阅。批准本身是同一 work 的测试调整许可，不另立 D# 或执行 grant。

本批完成的是 private committed-effects view 及其离线资格。graph-owned lifecycle 与未终结义务仍不因 UI 退订而结算。按用户等级隐藏入口、完整 preset、业务 materializer/current-at-dispatch guard、真实 inbox 和 B121 仍未完成；没有 provider/live/spend 或自动下游工作。
'''
review_path=q/'committed-v3-review.md';review_path.write_text(review)
archive=q/'committed-v3-evidence.tar.gz';members={}
with tarfile.open(archive,'w:gz') as t:
 for f in sorted(out.rglob('*')):
  if f.is_file() and '__pycache__' not in f.parts:
   n=str(f.relative_to(out));members[n]={'digest':sha(f.read_bytes()),'bytes':f.stat().st_size};t.add(f,arcname=n,recursive=False)
receipt={'schema':'graphrefly-ts/causal-committed-view-evidence/v1','owner':'graphrefly-ts','work':'graphrefly-ts:CAUSAL-COMMITTED-VIEW-TS','revision':'committed-v3','status':'qualified','baselineCommit':read('authorization.json')['baseline'],'authorization':read('authorization.json'),'productionRuntimeCommit':'861a9a468c5d767997a4bec70df159f327faa512','verification':v,'review':read('static-review.json'),'bindings':{str(review_path.relative_to(root)):sha(review_path.read_bytes()),str(archive.relative_to(root)):sha(archive.read_bytes())},'archiveMembers':members,'finalChangedFiles':{p:sha((root/p).read_bytes()) for p in changed},'postSealValidationPath':'packages/ts/qualification/causal-occurrence/committed-v3-closeout.json'}
(q/'committed-v3-receipt.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n')
with tarfile.open(archive) as t:
 assert {m.name for m in t.getmembers()}==set(members)
 for n,b in members.items():
  raw=t.extractfile(n).read();assert sha(raw)==b['digest'] and len(raw)==b['bytes'],n
print('SEALED_QUALIFIED_ATTEMPT',len(members),'members',archive.stat().st_size,'bytes')
