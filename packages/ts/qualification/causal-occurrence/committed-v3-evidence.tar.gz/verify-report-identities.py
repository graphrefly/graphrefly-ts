from pathlib import Path
import json,hashlib,subprocess,tarfile,io
root=Path('/Users/davidchenallio/src/graphrefly-ts');out=Path(__file__).parent
src=root/'packages/ts/src';q=root/'packages/ts/qualification/causal-occurrence'
sha=lambda b:'sha256:'+hashlib.sha256(b).hexdigest()
read=lambda n:json.loads((out/n).read_text())
current=lambda p:sha((root/p).read_bytes())
scripts={'causal-mutations':'qualify-causal-occurrence','construction-mutations':'qualify-causal-construction','cold-mutations':'qualify-causal-cold-assembly','view-mutations':'qualify-causal-committed-view','view-oracle':'compare-causal-committed-view','required-edges':'compare-causal-required-edges','incoming':'compare-causal-incoming','resource-verifier':'verify-causal-construction','frozen-standalone':'compare-causal-cold-standalone','qualified-standalone':'compare-causal-cold-standalone','combined-resources':'measure-causal-cold-resources'}
for n,s in scripts.items():assert read(n+'.json')['runnerDigest']==current('scripts/'+s+'.mjs'),n
for n,fields in {
'causal-mutations':{'testDigest':'solutions-causal-occurrence.d791.test.ts'},
'view-mutations':{'testDigest':'causal-committed-view.d163.test.ts'},
'construction-mutations':{'testDigest':'graph-construction.d161.test.ts','incomingTestDigest':'graph-construction-incoming.d161.test.ts'},
'cold-mutations':{'testDigest':'graph-construction.d161.test.ts','incomingTestDigest':'graph-construction-incoming.d161.test.ts','assemblyTestDigest':'causal-cold-assembly.d162.test.ts'}
}.items():
 for k,p in fields.items():assert read(n+'.json')[k]==sha((src/'__tests__'/p).read_bytes()),(n,k)
r=read('causal-mutations.json')
expected=['solutions/causal-occurrence.ts',*['solutions/causal-occurrence/'+n+'.ts' for n in ['construction','committed-view','contracts','identity','lifecycle','evidence','transition','capabilities']],'graph/construction-scope.ts']
assert list(r['sourceFiles'])==expected
for p,h in r['sourceFiles'].items():assert sha((src/p).read_bytes())==h,p
assert sha(''.join('\n// QUALIFICATION_FILE '+p+'\n'+(src/p).read_text() for p in expected).encode())==r['sourceDigest']
for p,h in r['toolchainDigests'].items():assert current(p)==h,p
assert r['runtime']=={'node':'v24.18.0','platform':'darwin','arch':'arm64'}
for p,h in read('view-mutations.json')['source'].items():assert sha((src/'solutions/causal-occurrence'/(p+'.ts')).read_bytes())==h,p
def direct_closure(closure):
 for p,h in closure.items():assert current(p)==h,p
for n in ['construction-mutations','cold-mutations']:direct_closure(read(n+'.json')['baseline']['closure'])
for n in ['resource-verifier','combined-resources']:direct_closure(read(n+'.json')['closure'])
r=read('required-edges.json');f=json.loads((q/'ts-v7-helper-inputs.json').read_text())
assert r['sourceDigest']==sha((src/'solutions/causal-occurrence/construction.ts').read_bytes())
assert r['frozenArchiveDigest']==sha((q/'ts-v7-helper-inputs.json').read_bytes())
assert r['frozenSourceDigest']==f['files']['packages/ts/src/solutions/causal-occurrence.ts']['digest']
assert f['receiptDigest']==sha((q/'ts-v7-receipt.json').read_bytes())
r=read('incoming.json');f=json.loads((q/'ts-v6-inputs.json').read_text())
assert r['frozenDigest']==sha((q/'ts-v6-inputs.json').read_bytes())
assert r['baselineReceiptDigest']==f['receiptDigest']==sha((q/'ts-v6-receipt.json').read_bytes())
for p,h in r['closure'].items():
 # Existing macOS /var versus /private/var labels can leave reference paths under current/.
 if '/reference/' in p or p.startswith('frozen/'):
  name=p.split('/reference/',1)[1] if '/reference/' in p else p.removeprefix('frozen/')
  item=f['files'].get('packages/ts/src/'+name)
  expected_hash=item['digest'] if item else sha((src/name).read_bytes())
 else:
  assert p.startswith('current/'),p
  expected_hash=sha((src/p.removeprefix('current/')).read_bytes())
 assert expected_hash==h,p
r=read('view-oracle.json')
assert r['oracleDigest']==current('scripts/fixtures/causal-committed-oracle.mjs')
for arm in r['results']:
 marker='/instrumented/' if arm['instrumented'] else '/actual/'
 for p,h in arm['closure'].items():
  assert marker in p,p
  name=p.split(marker,1)[1];raw=(src/name).read_bytes()
  if arm['instrumented'] and name=='solutions/causal-occurrence/committed-view.ts':
   anchor=b'const effects = Object.freeze('
   assert raw.count(anchor)==1
   raw=raw.replace(anchor,b'globalThis.__viewBuilds = (globalThis.__viewBuilds ?? 0) + 1; const effects = Object.freeze(')
  assert sha(raw)==h,p
fixed='d9c868dc8c2cec395f96a5ae327f692cc37c6df7'
frozen=json.loads((q/'ts-v8-cold-inputs.json').read_text())
assert frozen['receiptDigest']==sha((q/'ts-v8-receipt.json').read_bytes())
archive=subprocess.check_output(['git','archive',fixed,'packages/ts/src'],cwd=root)
with tarfile.open(fileobj=io.BytesIO(archive)) as t:
 gitfiles={m.name:t.extractfile(m).read() for m in t.getmembers() if m.isfile()}
jsobject={'sourceCommit':fixed,'files':{p:{'text':raw.decode(),'digest':sha(raw)} for p,raw in sorted(gitfiles.items())}}
gitdigest=sha(json.dumps(jsobject,ensure_ascii=False,separators=(',',':')).encode())
previous=(root/'scripts/compare-causal-authority.mjs').read_text()
fixture=previous[previous.index('const lanes ='):previous.index('function graphRun(make, scenario)')]
for n,commit in [('frozen-standalone',None),('qualified-standalone',fixed)]:
 r=read(n+'.json');assert r['baselineCommit']==commit
 assert r['fixtureDigest']==sha(fixture.encode())
 assert r['frozenDigest']==(gitdigest if commit else sha((q/'ts-v8-cold-inputs.json').read_bytes()))
 assert r['runtime']=='v24.18.0'
 for p,h in r['closure'].items():
  if p.startswith('frozen/'):
   name='packages/ts/src/'+p.removeprefix('frozen/')
   expected_hash=sha(gitfiles[name]) if commit else frozen['files'][name]['digest']
  else:expected_hash=current(p)
  assert h==expected_hash,(n,p)
tests=(src/'__tests__/graph-construction.d161.test.ts').read_text()
fixture=tests[tests.index('class CountingDispatcher'):tests.index('// Independent finite ownership oracle')]
assert read('resource-verifier.json')['fixtureDigest']==sha(fixture.encode())
assert read('combined-resources.json')['fixtureDigest']==sha((src/'__tests__/causal-cold-assembly.d162.test.ts').read_bytes())
result={'passed':True,'reportDigests':{n+'.json':sha((out/(n+'.json')).read_bytes()) for n in scripts},'runnerTestSourceOracleAndClosuresVerified':True,'standaloneBaselines':[None,fixed],'runtimeSourceCommit':'861a9a468c5d767997a4bec70df159f327faa512','legacyIncomingPathNormalization':'Reference marker takes precedence over current/ prefix on macOS; resolve bytes against frozen files with existing current-source fallback.'}
(out/'report-identities-verification.json').write_text(json.dumps(result,indent=2)+'\n')
print('REPORT_IDENTITIES_VERIFIED',len(scripts))
