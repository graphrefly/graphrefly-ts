from pathlib import Path
import json,tarfile,hashlib,math
root=Path('/Users/davidchenallio/src/graphrefly-ts'); out=Path(__file__).parent
sha=lambda b:'sha256:'+hashlib.sha256(b).hexdigest()
q=root/'packages/ts/qualification/causal-occurrence'
r=json.loads((q/'committed-v1-material-receipt.json').read_bytes())
for path,h in r['bindings'].items(): assert sha((root/path).read_bytes())==h,path
with tarfile.open(q/'committed-v1-material-evidence.tar.gz') as t:
 data={n:t.extractfile(n).read() for n in t.getnames() if t.getmember(n).isfile()}
 assert set(data)==set(r['archiveMembers'])
 for n,h in r['archiveMembers'].items():assert sha(data[n])==h,n
 x=json.loads(data['full-construction-report.json']);c=json.loads(data['full-construction.check.json']);b=json.loads(data['full-construction.bindings.json'])
 current={str(f.relative_to(root)):sha(f.read_bytes()) for f in (root/'packages/ts/src').rglob('*') if f.is_file()}
 assert b['before']==b['after']
 changed_source={k for k in set(current)|set(b['before']) if current.get(k)!=b['before'].get(k)}
 approved_test='packages/ts/src/__tests__/solutions-agentic-memory-work-item-root-eval-live.test.ts'
 assert changed_source=={approved_test},changed_source
 assert approved_test not in x['closure']
 import subprocess
 assert sha(subprocess.check_output(['git','show','e81e18e4:'+approved_test],cwd=root))==b['before'][approved_test]
 assert not any(k.startswith('packages/ts/src/') and '__tests__' not in k and current[k]!=b['before'][k] for k in current)
 approved_delta={approved_test:{'before':b['before'][approved_test],'after':current[approved_test]}}
 assert c['exitCode']==0 and c['sourceUnchanged'] and not c['changed']
 assert sha(data['full-construction.log'])==c['logDigest']
 assert x['runnerDigest']==sha((root/'scripts/compare-causal-construction.mjs').read_bytes())
 assert len(x['comparisons'])==6 and all(z['matched'] for z in x['comparisons'])
 for path,h in x['closure'].items():
  if path.startswith('packages/ts/'):assert sha((root/path).read_bytes())==h,path
 for n,raw in data.items():
  if n.startswith('candidate/packages/ts/src/'):assert raw==(root/n.removeprefix('candidate/')).read_bytes(),n
 bindings=json.loads(data['bindings-before.json'])
 for path,h in bindings['harness'].items():assert sha((root/path).read_bytes())==h,path
 assert sha(data['bundle.mjs'])==bindings['bundle'] and sha(data['compare.mjs'])==bindings['script']
 percentile=lambda a,q:sorted(a)[math.ceil(len(a)*q)-1]
 rows=[]
 assert [(z['count'],z['evidence'],z['background']) for z in x['performanceRows']]==[(1,0,0),(16,128,0),(64,512,0),(1,0,1000)]
 for row in x['performanceRows']:
  construction=row['construction'];steady=row['steady']
  for arm in ['baseline','candidate']:
   assert len(construction[arm])==900
   assert construction[arm]==sum([z[arm] for z in construction['batches']],[])
   assert construction[arm+'P95Ns']==percentile(construction[arm],.95)
   assert steady[arm+'MedianP95Ns']==sorted(steady[arm])[len(steady[arm])//2]
  cr=construction['candidateP95Ns']/construction['baselineP95Ns'];sr=steady['candidateMedianP95Ns']/steady['baselineMedianP95Ns']
  assert cr==construction['ratio'] and cr<=1.20
  assert sr==steady['ratio'] and sr<=1.10
  rows.append({'effects':row['count'],'evidence':row['evidence'],'background':row['background'],'constructionRatio':cr,'steadyRatio':sr})
 boundary=json.loads(data['boundary-report.json'])['results']
 assert boundary['original']['outcome']['result']=='rejected'
 assert boundary['skip-source-rescan']['outcome']['result']=='accepted'
 assert boundary['original']['reads']==2 and boundary['original']['remainingBeforeCleanup']==8
 assert all(z['cleanupNodes']==0 for z in boundary.values())
 result={'passed':True,'sourceFiles':len(current),'retainedReceipt':'packages/ts/qualification/causal-occurrence/committed-v1-material-receipt.json','receiptDigest':sha((q/'committed-v1-material-receipt.json').read_bytes()),'archiveDigest':sha((q/'committed-v1-material-evidence.tar.gz').read_bytes()),'archiveMembersVerified':len(data),'originalGateRecomputed':True,'newPerformanceRun':False,'traceComparisons':6,'constructionSamples':7200,'steadyLifecycles':108,'rows':rows,'customInspectorRuntimeNegativeControl':True,'unchangedMeasuredRuntimeAndHarness':True,'sourceDifferencesOutsideMeasuredClosure':approved_delta}
 (out/'retained-performance-verification.json').write_text(json.dumps(result,indent=2)+'\n')
 print('RETAINED_PERFORMANCE_VERIFIED',len(current),'source files',len(data),'archive members')
