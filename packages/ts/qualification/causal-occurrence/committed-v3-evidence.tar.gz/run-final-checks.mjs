import {readFileSync} from 'node:fs';
import {spawnSync} from 'node:child_process';
import {dirname,join} from 'node:path';
import {fileURLToPath} from 'node:url';
const dir=dirname(fileURLToPath(import.meta.url));
for(const {id} of JSON.parse(readFileSync(join(dir,'remaining-checks.json')))){
 const r=JSON.parse(readFileSync(join(dir,id+'.check.json')));if(r.exitCode!==0||!r.sourceUnchanged)throw new Error('prior qualification failed '+id);
}
const checks=[
 ['artifact-check','pnpm','run','eval:root:artifacts:check'],
 ['lint','pnpm','run','lint'],
 ['closure-final','pnpm','exec','tsx',join(dir,'measure-closure.mts'),join(dir,'closure-final.json')],
 ['report-identities','python3',join(dir,'verify-report-identities.py')],
 ['workspace','npm','--prefix','/Users/davidchenallio/src/graphrefly','run','authority:check:workspace'],
 ['dashboard','node','/Users/davidchenallio/src/graphrefly/dashboard/build.mjs','--check'],
 ['attempt-verification','python3',join(dir,'verify-attempt.py')],
];
for(const args of checks){const r=spawnSync(process.execPath,[join(dir,'run-check.mjs'),...args],{stdio:'inherit'});if(r.status!==0)process.exit(r.status??1);}
console.log('FINAL_CHECKS_DONE');
