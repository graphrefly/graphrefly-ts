from pathlib import Path
import hashlib,json,subprocess
root=Path('/Users/davidchenallio/src/graphrefly-ts');out=Path(__file__).parent
sha=lambda b:'sha256:'+hashlib.sha256(b).hexdigest()
initial=json.loads((out/'initial-tracked-bindings.json').read_text())
base='packages/ts/evals/graph-native-rerun-avoidance/'
allowed={base+'implementation-manifest.ts',*[base+'artifacts/'+n for n in ['root-eval-artifact-set.json','root-eval-describe.json','root-eval-live-qualification.json','root-eval-observe-events.jsonl','root-eval-topology-qualification.json']],'packages/ts/src/__tests__/solutions-agentic-memory-work-item-root-eval-live.test.ts','packages/ts/qualification/causal-occurrence/README.md','plan/work.jsonl'}
changed={p for p,h in initial.items() if not (root/p).is_file() or sha((root/p).read_bytes())!='sha256:'+h}
assert changed<=allowed,changed-allowed
assert 'packages/ts/src/__tests__/solutions-agentic-memory-work-item-root-eval-live.test.ts' in changed
for p,h in json.loads((out/'runner-bindings.json').read_text()).items():assert sha((root/p).read_bytes())==h,p
other=root.parent/'graphrefly'
for p,h in json.loads((out/'unrelated-root-bindings.json').read_text()).items():assert sha((other/p).read_bytes())=='sha256:'+h,p
# Only the existing owner work row may change, never adjacent records.
old=subprocess.check_output(['git','show','e81e18e4:plan/work.jsonl'],cwd=root).decode().splitlines()
new=(root/'plan/work.jsonl').read_text().splitlines();assert len(old)==len(new)
for a,b in zip(old,new):
 if a!=b:assert json.loads(a)['id']==json.loads(b)['id']=='CAUSAL-COMMITTED-VIEW-TS'
result={'passed':True,'initialTrackedFiles':len(initial),'protectedTrackedFiles':len(initial)-len(allowed),'changed':sorted(changed),'runnerAndConfigUnchanged':True,'unrelatedRootEditsPreserved':True,'productionSourceChanged':False,'publicApiOrProtocolChanged':False}
(out/'scope-verification.json').write_text(json.dumps(result,indent=2)+'\n')
print('SCOPE_VERIFIED',len(initial),'tracked files')
