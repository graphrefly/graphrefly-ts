from pathlib import Path
import json,hashlib
root=Path('/Users/davidchenallio/src/graphrefly-ts');out=Path(__file__).parent
sha=lambda b:'sha256:'+hashlib.sha256(b).hexdigest()
read=lambda n:json.loads((out/n).read_text())
source={str(p.relative_to(root)):sha(p.read_bytes()) for p in (root/'packages/ts/src').rglob('*') if p.is_file()}
checks=[]
for p in sorted(out.glob('*.check.json')):
 c=json.loads(p.read_text());i=c['id'];b=read(i+'.bindings.json')
 assert c['exitCode']==0 and c['sourceUnchanged'] and not c['changed'] and c['signal'] is None,i
 assert b['before']==b['after']==source,i
 log=(out/(i+'.log')).read_bytes()
 assert sha(log)==c['logDigest'] and b'CHECK_DONE ' in log,i
 checks.append(c)
required={x['id'] for x in read('remaining-checks.json')}|{'root-soak','shuffle-targeted','artifact-refresh','artifact-check','closure','closure-final','retained-performance','report-identities','scope','lint','workspace','dashboard'}
assert required<={c['id'] for c in checks},required-{c['id'] for c in checks}
assert '2257 passed | 4 skipped (2261)' in (out/'full-test.log').read_text()
assert '221 passed (221)' in (out/'root-soak.log').read_text()
assert '121 passed | 100 skipped (221)' in (out/'shuffle-targeted.log').read_text()
for name,n in [('causal-mutations',73),('construction-mutations',25),('cold-mutations',16),('view-mutations',11)]:
 r=read(name+'.json');assert r['complete'] and len(r['mutations'])==n
 assert all(m['outcome'] in ['killed','detected'] for m in r['mutations'])
identities=read('report-identities-verification.json');assert identities['passed']
for name,h in identities['reportDigests'].items():assert sha((out/name).read_bytes())==h,name
oracle=read('view-oracle.json');assert oracle['passed']
assert len(oracle['results'])==2 and {a['instrumented'] for a in oracle['results']}=={False,True}
for arm in oracle['results']:
 assert len(arm['comparisons'])==12 and arm['hotOrders']==2 and len(arm['measures'])==33
 for c in arm['comparisons']:
  for checkpoint in c['checkpoints']:assert checkpoint['actual']==checkpoint['expected']
 for m in arm['measures']:
  assert m['reconnections']==20 and m['actualPhaseChangePercent']==m['rate']
  assert m['viewBuilds']==(m['accepted'] if arm['instrumented'] else None)
  assert len(m['samples'])==m['total']
  assert m['medianNs']==sorted(m['samples'])[len(m['samples'])//2]
for n in ['frozen-standalone','qualified-standalone']:
 r=read(n+'.json');assert len(r['comparisons'])==6 and all(c['matched'] for c in r['comparisons'])
 for c in r['comparisons']:
  assert c['baseline']==c['candidate'] and c['baselinePhase']==c['candidatePhase']
 fault=r['startupFault'];a=fault['baseline'];b=fault['candidate']
 assert fault['matched'] and a['events']==b['events'] and a['phase']==b['phase']=='faulted'
 added={'id':'causal/committed-effects','factory':'causalCommittedEffectsProjection','deps':['causal/authority']}
 assert [z for z in b['shape'] if z['id']=='causal/committed-effects']==[added]
 assert [z for z in a['shape'] if z['id']!='causal/committed-effects']==[z for z in b['shape'] if z['id']!='causal/committed-effects']
 if n=='qualified-standalone':assert [z for z in a['shape'] if z['id']=='causal/committed-effects']==[added]
assert read('retained-performance-verification.json')['passed'] and read('scope-verification.json')['passed']
assert read('closure.json')==read('closure-final.json')
result={'verified':True,'qualificationPassed':True,'sourceFiles':len(source),'sourceDigests':source,'runnerDigests':read('runner-bindings.json'),'checks':checks,'failedCheckIds':[],'sourceUnchangedDuringChecks':True,'qualificationBindings':read('closure-final.json'),'reportDigests':identities['reportDigests'],'testBoundaryChange':'120 serial cases plus enumeration,5000ms per case; old aggregate5000ms constraint explicitly replaced by user approval','priorFailurePreserved':True,'performance':read('retained-performance-verification.json'),'nonClaims':['No claim of total test speedup','No runtime/API/protocol change','No provider/live/spend or downstream authorization','No complete audience hiding/preset/materializer/inbox qualification']}
(out/'attempt-verification.json').write_text(json.dumps(result,indent=2)+'\n')
print('ATTEMPT_VERIFIED',len(checks),'checks',len(source),'source files')
