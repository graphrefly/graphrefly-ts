import { execFileSync } from "node:child_process";
import {
	cpSync,
	existsSync,
	mkdirSync,
	mkdtempSync,
	readdirSync,
	readFileSync,
	rmSync,
	writeFileSync,
} from "node:fs";
import { builtinModules } from "node:module";
import { tmpdir } from "node:os";
import { dirname, join, resolve } from "node:path";
import { fileURLToPath } from "node:url";

const ROOT = resolve(dirname(fileURLToPath(import.meta.url)), "..");
const PKG = join(ROOT, "packages", "ts");
const TSC = join(ROOT, "node_modules", ".bin", "tsc");
const packageJson = JSON.parse(readFileSync(join(PKG, "package.json"), "utf8"));
const nodeBuiltins = new Set(builtinModules.flatMap((name) => [name, `node:${name}`]));
const removedEcosystemSubpaths = [
	"./adapters/nestjs",
	"./adapters/nestjs/microservices",
	"./adapters/nestjs/native",
	"./adapters/nestjs/websockets",
	"./adapters/react",
	"./adapters/solid",
	"./adapters/svelte",
	"./adapters/vue",
];
const expectedSubpaths = {
	"./adapters": {
		present: [
			"CanonicalProtobufError",
			"decodeCanonicalWireBridgeEnvelope",
			"decodeCanonicalWireEdgeFrame",
			"encodeCanonicalWireBridgeEnvelope",
			"encodeCanonicalWireEdgeFrame",
			"wireBridgeProtobuf",
			"subscribeNodeValues",
			"readableStore",
			"writableStore",
			"externalStore",
			"recordReadableStore",
			"memoryAgenticMemoryPassiveStoreFrameAdapter",
			"persistAgenticMemoryRecords",
			"openPersistentAgenticMemoryRecords",
			"loadAgenticMemoryRecordsState",
		],
		absent: [
			"useNodeValue",
			"useNodeInput",
			"useNodeRecord",
			"createNodeValue",
			"createNodeInput",
			"createNodeRecord",
			"nodeReadable",
			"nodeWritable",
			"nodeRecord",
			"fromNestReq",
			"toNestHttp",
			"assertKeyedRateLimitRequest",
			"keyedRateLimitAdmissionBundle",
			"localFixedWindowRateLimitBundle",
			"evaluateFixedWindowRateLimitTransition",
			"evaluateSlidingWindowRateLimitTransition",
			"evaluateTokenBucketRateLimitTransition",
		],
	},
	"./committed-facts": {
		present: [
			"appendLogCommittedFactJournal",
			"committedFactJournalCursor",
			"committedFactJournalCursorCodec",
		],
		absent: [],
	},
	"./cqrs/messaging": { present: ["cqrsMessagingRecipe"], absent: [] },
	"./cqrs/work-queue": { present: ["cqrsWorkQueueRecipe"], absent: [] },
	"./executors/tool-provider": {
		present: ["toolProviderExecutionRecipe"],
		absent: [],
	},
	"./executors/execution-environment": {
		present: [
			"executionEnvironmentTarget",
			"environmentPinnedExecutorProfile",
			"environmentPinnedExecutorRoute",
			"requestEnvironmentPinnedToolProviderRun",
			"localHostExecutionGate",
		],
		absent: [
			"nodeProcessDriver",
			"postgresqlToolProviderRuntime",
			"toolProviderRunAdmissionProjector",
		],
	},
	"./executors/local-container-postgresql": {
		present: [
			"LOCAL_CONTAINER_POSTGRESQL_COMPATIBILITY",
			"localContainerPostgresqlDockerEngineApiV0PreflightReadiness",
			"localContainerPostgresqlManifest",
			"localContainerPostgresqlReadiness",
			"localContainerPostgresqlRuntime",
		],
		absent: [
			"DockerClient",
			"LocalSandboxDriver",
			"PodmanDriver",
			"containerId",
			"dockerClient",
			"dockerSocket",
			"engineClient",
			"hostPath",
			"mountSource",
			"postgresqlToolProviderRuntime",
			"providerRegistry",
			"secretHandle",
			"selectLocalSandbox",
			"toolProviderRunAdmissionProjector",
		],
	},
	"./executors/managed-cloud-postgresql": {
		present: [
			"MANAGED_CLOUD_POSTGRESQL_COMPATIBILITY",
			"MANAGED_CLOUD_POSTGRESQL_DEPLOYMENT_PROFILE",
			"managedCloudPostgresqlManifest",
			"managedCloudPostgresqlReadiness",
			"managedCloudPostgresqlRuntime",
			"postgresql16ManagedCloudControlStore",
			"authenticatedWssManagedCloudTransport",
		],
		absent: [
			"executeManagedCloudPostgresqlClaim",
			"toolProviderRunAdmissionProjector",
			"postgresqlToolProviderRuntime",
		],
	},
	"./executors/customer-hosted-postgresql": {
		present: [
			"CUSTOMER_HOSTED_POSTGRESQL_COMPATIBILITY",
			"customerHostedPostgresqlRelease",
			"customerHostedPostgresqlEnrollment",
			"customerHostedPostgresqlReadiness",
			"customerHostedPostgresqlRuntime",
			"postgresql16CustomerHostedControlStore",
			"authenticatedOutboundCustomerHostedTransport",
			"customerHostedPostgresqlEvidenceOutbox",
		],
		absent: ["toolProviderRunAdmissionProjector", "postgresqlToolProviderRuntime"],
	},
	"./executors/postgresql-run-operations": {
		present: [
			"POSTGRESQL_RUN_OPERATIONS_COMPATIBILITY",
			"postgresql16RunOperationsStore",
			"postgresqlRunOperationEligibility",
			"postgresqlRunOperationMaterialization",
		],
		absent: ["postgresqlToolProviderRuntime", "customerHostedPostgresqlRuntime"],
	},
	"./solutions/shared-control-panel-authority": {
		present: [
			"SHARED_CONTROL_PANEL_AUTHORITY_COMPATIBILITY",
			"createSharedControlPanelAuthority",
			"sharedControlPanelCapabilitySupported",
			"sharedControlPanelAdmissionFingerprint",
			"sharedControlPanelAdmitCanvasSubscriptionIntent",
		],
		absent: [
			"POSTGRESQL_SHARED_CONTROL_PANEL_COMPATIBILITY",
			"POSTGRESQL_SHARED_CONTROL_PANEL_SCHEMA",
			"postgresql16SharedControlPanelStore",
			"createSharedControlPanelMemoryPersistence",
			"canonical",
			"snapshot",
			"validateOccurrence",
			"validateSubscription",
			"validateRecordedTerminalOutcome",
		],
	},
	"./testing/shared-control-panel-memory-persistence": {
		present: ["createSharedControlPanelMemoryPersistence"],
		absent: ["createSharedControlPanelAuthority", "postgresql16SharedControlPanelStore"],
	},
	"./solutions/production-evaluation-authority": {
		present: [
			"PRODUCTION_EVALUATION_AUTHORITY_COMPATIBILITY",
			"createProductionEvaluationAuthority",
			"sameProductionCandidate",
		],
		absent: [
			"createProductionEvaluationMemoryPersistence",
			"productionEvaluationCanonical",
			"productionEvaluationSnapshot",
		],
	},
	"./testing/production-evaluation-memory-persistence": {
		present: ["createProductionEvaluationMemoryPersistence"],
		absent: ["createProductionEvaluationAuthority"],
	},
	"./executors/tool-provider-adapters": {
		present: [
			"localBuiltinToolProviderBinding",
			"localBuiltinToolProviderAdapterPack",
			"processToolProviderBinding",
			"processToolProviderAdapterPack",
			"processToolProviderCatalog",
			"httpToolProviderCatalog",
			"httpToolProviderRuntime",
		],
		absent: ["attachToolProviderAdapterRuntime", "toolProviderExecutionRecipe"],
	},
	"./executors/postgresql-tool-provider": {
		present: ["postgresqlToolProviderCatalog", "postgresqlToolProviderRuntime"],
		absent: [
			"attachToolProviderAdapterRuntime",
			"toolProviderExecutionRecipe",
			"httpToolProviderRuntime",
		],
	},
	"./executors/tool-provider-runtime": {
		present: ["attachToolProviderAdapterRuntime"],
		absent: [],
	},
	"./inspection/boundary": { present: ["boundaryManifest"], absent: [] },
	"./orchestration/messaging": { present: ["orchestrationMessagingRecipe"], absent: [] },
	"./orchestration/work-queue": { present: ["orchestrationWorkQueueRecipe"], absent: [] },
	"./rate-limit": {
		present: [
			"assertKeyedRateLimitRequest",
			"keyedRateLimitAdmissionBundle",
			"localFixedWindowRateLimitBundle",
			"evaluateFixedWindowRateLimitTransition",
			"evaluateSlidingWindowRateLimitTransition",
			"evaluateTokenBucketRateLimitTransition",
		],
		absent: ["attachKeyedRateLimitAuthority", "RateLimitStore", "rateLimitBundle"],
	},
	"./memory": {
		present: ["validateMemoryFragment", "filterMemoryFragments", "memoryRetrievalBundle"],
		absent: ["agenticMemoryBundle", "workItemAuthoringProjector", "persistAgenticMemoryRecords"],
	},
	"./memory/semantic": {
		present: ["validateMemoryFragment", "filterMemoryFragments", "memoryRetrievalBundle"],
		absent: ["agenticMemoryBundle", "workItemAuthoringProjector", "persistAgenticMemoryRecords"],
	},
	"./scoring": {
		present: [
			"cosineSimilarity",
			"admissionScored",
			"admissionFilter3D",
			"scoreSubjects",
			"rankScoredSubjects",
			"normalizeScoreSignal",
			"isFiniteScore",
		],
		absent: ["memoryRetrievalBundle", "agenticMemoryBundle", "workItemAuthoringProjector"],
	},
	"./solutions/agentic-memory": {
		present: [
			"agenticMemoryBundle",
			"agenticMemoryRecordFrame",
			"agenticMemoryRetentionBundle",
			"admitAgenticMemoryRecordProposals",
			"agenticMemoryRecordAdmissionBundle",
			"projectAgenticMemoryRecordAdmissionPolicySource",
			"agenticMemoryRecordAdmissionPolicySourceBundle",
			"applyAgenticMemoryRecordAdmissions",
			"agenticMemoryRecordApplicationBundle",
			"projectAgenticMemoryRecordApplicationPriorEvidence",
			"projectAgenticMemoryRecordApplicationEvidenceFacts",
			"agenticMemoryRecordApplicationPriorEvidenceBundle",
			"agenticMemoryRecordApplicationEvidenceFactsBundle",
			"agenticMemoryConsolidationApplicationBundle",
			"agenticMemoryCommittedFactReadMaterializationBundle",
			"projectAgenticMemoryCommittedFactReadMaterialization",
			"agenticMemoryDurabilityGateBundle",
			"agenticMemoryDurabilityGateInput",
			"projectAgenticMemoryDurabilityGate",
			"agenticMemoryDurabilityResultMayAdvance",
			"agenticMemoryDurabilityAdvanceOnCommittedOrDuplicatePolicy",
			"agenticMemoryDurabilityUncertainResolutionStatus",
			"agenticMemoryCommittedFactLogStartupRead",
			"agenticMemoryCommittedFactLogAppendAttempt",
		],
		absent: [
			"workItemAuthoringProjector",
			"workItemEffectRunProjector",
			"persistAgenticMemoryRecords",
		],
	},
	"./solutions/agentic-work-item-memory": {
		present: ["mapAgenticWorkItemMemoryBridge", "agenticWorkItemMemoryBridgeBundle"],
		absent: [
			"agenticMemoryBundle",
			"mapAgenticWorkItemMemoryApplicationRecipe",
			"agenticWorkItemMemoryApplicationRecipeBundle",
			"workItemAuthoringProjector",
			"workItemEffectRunProjector",
			"persistAgenticMemoryRecords",
		],
	},
	"./solutions/agentic-work-item-memory-application": {
		present: [
			"mapAgenticWorkItemMemoryApplicationRecipe",
			"agenticWorkItemMemoryApplicationRecipeBundle",
		],
		absent: [
			"agenticMemoryBundle",
			"mapAgenticWorkItemMemoryBridge",
			"workItemAuthoringProjector",
			"persistAgenticMemoryRecords",
		],
	},
	"./solutions/work-item": {
		present: [
			"workItemAuthoringProjector",
			"workItemDomainActionAdmissionProjector",
			"workItemWorkQueueRecipe",
		],
		absent: ["agenticMemoryBundle", "workItemEffectRunProjector"],
	},
	"./solutions/work-item/scheduling": {
		present: [
			"isWorkspaceProposalProjectionReleaseMaterial",
			"validateWorkspaceProposalProjectionReleaseMaterial",
			"workspaceProposalProjectionReleaseDiagnosticProjector",
		],
		absent: [
			"genericFamilyFactReader",
			"readFamilyFact",
			"recordFamilyOutcome",
			"selectorAdapter",
			"selectorAdapterRegistry",
			"providerHandle",
			"storageHandle",
			"queryHandle",
			"opaqueProviderCursor",
			"providerCursor",
		],
	},
};

const forbiddenFrameworkSpecifiers = [
	'from "react"',
	"from 'react'",
	'require("react")',
	"require('react')",
	'from "vue"',
	"from 'vue'",
	'require("vue")',
	"require('vue')",
	'from "solid-js"',
	"from 'solid-js'",
	'require("solid-js")',
	"require('solid-js')",
	'from "svelte/store"',
	"from 'svelte/store'",
	'require("svelte/store")',
	"require('svelte/store')",
];

const rootAbsentExports = [
	"assertKeyedRateLimitRequest",
	"keyedRateLimitAdmissionBundle",
	"localFixedWindowRateLimitBundle",
	"evaluateFixedWindowRateLimitTransition",
	"evaluateSlidingWindowRateLimitTransition",
	"evaluateTokenBucketRateLimitTransition",
	"KeyedRateLimitTransitionError",
	"appendLogCommittedFactJournal",
	"committedFactJournalCursor",
	"committedFactJournalCursorCodec",
	"PRODUCTION_EVALUATION_AUTHORITY_COMPATIBILITY",
	"createProductionEvaluationAuthority",
	"createProductionEvaluationMemoryPersistence",
	"sameProductionCandidate",
	"LOCAL_CONTAINER_POSTGRESQL_COMPATIBILITY",
	"localContainerPostgresqlDockerEngineApiV0PreflightReadiness",
	"localContainerPostgresqlManifest",
	"localContainerPostgresqlReadiness",
	"localContainerPostgresqlRuntime",
	"MANAGED_CLOUD_POSTGRESQL_COMPATIBILITY",
	"MANAGED_CLOUD_POSTGRESQL_DEPLOYMENT_PROFILE",
	"managedCloudPostgresqlManifest",
	"managedCloudPostgresqlReadiness",
	"managedCloudPostgresqlRuntime",
	"executeManagedCloudPostgresqlClaim",
	"postgresql16ManagedCloudControlStore",
	"authenticatedWssManagedCloudTransport",
	"POSTGRESQL_RUN_OPERATIONS_COMPATIBILITY",
	"postgresql16RunOperationsStore",
	"postgresqlRunOperationEligibility",
	"postgresqlRunOperationMaterialization",
	"attachToolProviderAdapterRuntime",
	"toolProviderExecutionRecipe",
	"localBuiltinToolProviderBinding",
	"processToolProviderBinding",
	"httpToolProviderCatalog",
	"httpToolProviderRuntime",
	"useNodeValue",
	"useNodeInput",
	"useNodeRecord",
	"createNodeValue",
	"createNodeInput",
	"createNodeRecord",
	"nodeReadable",
	"nodeWritable",
	"nodeRecord",
	"boundaryManifest",
	"AGENTIC_MEMORY_RECORD_CHANGE_FORMAT",
	"AGENTIC_MEMORY_RECORD_SNAPSHOT_FORMAT",
	"AGENTIC_MEMORY_RECORD_STORAGE_FRAME_VERSION",
	"AGENTIC_MEMORY_PASSIVE_STORE_FRAME_CURSOR_KIND",
	"agenticMemoryRecordChangeFrame",
	"agenticMemoryRecordSnapshotFrame",
	"agenticMemoryRecordsSnapshotKey",
	"assertAgenticMemoryRecordChangeFrame",
	"assertAgenticMemoryRecordSnapshotFrame",
	"loadAgenticMemoryRecordsState",
	"memoryAgenticMemoryPassiveStoreFrameAdapter",
	"openPersistentAgenticMemoryRecords",
	"persistAgenticMemoryRecords",
	"isWorkspaceProposalProjectionReleaseMaterial",
	"validateWorkspaceProposalProjectionReleaseMaterial",
	"workspaceProposalProjectionReleaseDiagnosticProjector",
];

const rootAbsentTypeExports = [
	"KeyedRateLimitRequest",
	"KeyedRateLimitOutcome",
	"KeyedRateLimitAdmission",
	"FixedWindowRateLimitPolicy",
	"SlidingWindowRateLimitState",
	"TokenBucketRateLimitTransition",
	"LocalFixedWindowRateLimitOptions",
	"ProductionEvaluationAuthority",
	"ProductionEvaluationPersistencePort",
	"ProductionEvaluationCampaignRevision",
	"ProductionMigrationActionProposal",
	"BoundaryManifest",
	"BoundaryNode",
	"BoundaryRole",
	"InputBoundaryNode",
	"OutputBoundaryNode",
	"WorkspaceProposalProjectionRelease",
	"WorkspaceProposalProjectionReleaseDiagnostic",
	"WorkspaceProposalProjectionReleaseDiagnosticProjectorBundle",
	"WorkspaceProposalProjectionReleaseDiagnosticProjectorOptions",
	"WorkspaceProposalProjectionReleaseTargetKind",
	"WorkspaceProposalProjectionReleaseValidationResult",
	"AgenticMemoryPassiveStoreFrameAdapter",
	"AgenticMemoryPassiveStoreFrameAuditEntry",
	"AgenticMemoryPassiveStoreFrameCursor",
	"AgenticMemoryPassiveStoreFrameReadOptions",
	"AgenticMemoryPassiveStoreFrameReadResult",
	"AgenticMemoryPassiveStoreFrameStatus",
	"AgenticMemoryPassiveStoreFrameStatusState",
	"AgenticMemoryPassiveStoreFrameWriteResult",
	"AgenticMemoryRecordChangeFrame",
	"AgenticMemoryRecordSnapshotFrame",
	"AgenticMemoryRecordsPersistenceCursor",
	"AgenticMemoryRecordsPersistenceError",
	"AgenticMemoryRecordsPersistenceHandle",
	"AgenticMemoryRecordsPersistenceStatus",
	"AgenticMemoryRecordsRestoreState",
	"LoadAgenticMemoryRecordsStateOptions",
	"OpenPersistentAgenticMemoryRecordsOptions",
	"PersistAgenticMemoryRecordsOptions",
	"PersistentAgenticMemoryRecords",
];

function fail(message) {
	console.error(`check-ts-package-exports: ${message}`);
	process.exit(1);
}

function assert(condition, message) {
	if (!condition) fail(message);
}

function exportTarget(subpath, condition, key) {
	const entry = packageJson.exports?.[subpath]?.[condition]?.[key];
	assert(typeof entry === "string", `${subpath} missing exports.${condition}.${key}`);
	return join(PKG, entry);
}

function declarationExportNames(file) {
	const source = readFileSync(file, "utf8");
	const names = new Set();
	for (const match of source.matchAll(/export\s*\{([\s\S]*?)\}\s*(?:from\s*["'][^"']+["'])?;/g)) {
		for (const rawSpecifier of match[1].split(",")) {
			const specifier = rawSpecifier.trim().replace(/^type\s+/, "");
			if (specifier === "") continue;
			const parts = specifier.split(/\s+as\s+/);
			const exported = parts.at(-1);
			if (exported !== undefined && /^[A-Za-z_$][\w$]*$/.test(exported)) names.add(exported);
		}
	}
	return [...names].sort();
}

function errorOutput(err) {
	const stdout =
		typeof err.stdout === "string"
			? err.stdout
			: Buffer.isBuffer(err.stdout)
				? err.stdout.toString("utf8")
				: "";
	const stderr =
		typeof err.stderr === "string"
			? err.stderr
			: Buffer.isBuffer(err.stderr)
				? err.stderr.toString("utf8")
				: "";
	return `${stdout}${stderr}`;
}

function validateExportTree(value, path) {
	if (typeof value === "string") {
		assert(value.startsWith("./"), `${path} must be a package-relative target`);
		assert(existsSync(join(PKG, value)), `${path} target missing: ${value}`);
		return;
	}
	assert(
		value !== null && typeof value === "object",
		`${path} must be a string or condition object`,
	);
	for (const [key, child] of Object.entries(value)) {
		validateExportTree(child, `${path}.${key}`);
	}
}

function expectTscFailure(tmp, file, expectedNames) {
	const config = `tsconfig.${file}.json`;
	writeFileSync(
		join(tmp, config),
		JSON.stringify(
			{
				compilerOptions: {
					target: "ES2022",
					module: "NodeNext",
					moduleResolution: "NodeNext",
					strict: true,
					noEmit: true,
					skipLibCheck: true,
				},
				include: [file],
			},
			null,
			"\t",
		),
	);
	try {
		execFileSync(TSC, ["-p", config], { cwd: tmp, stdio: "pipe" });
		fail(`${file} unexpectedly typechecked; forbidden type-only exports leaked`);
	} catch (e) {
		const out = errorOutput(e);
		for (const name of expectedNames) {
			assert(
				out.includes(name),
				`${file} failed for an unexpected reason; missing diagnostic for ${name}`,
			);
		}
	}
}

validateExportTree(packageJson.exports, "exports");
const rateLimitPublicExports = declarationExportNames(
	exportTarget("./rate-limit", "import", "types"),
);
assert(rateLimitPublicExports.length > 0, "./rate-limit must expose public DTS symbols");

for (const subpath of removedEcosystemSubpaths) {
	assert(
		packageJson.exports?.[subpath] === undefined,
		`${subpath} must move to an ecosystem package`,
	);
}

for (const subpath of Object.keys(expectedSubpaths)) {
	assert(packageJson.exports?.[subpath] !== undefined, `${subpath} missing from package exports`);
	for (const [condition, extension] of [
		["import", ".js"],
		["require", ".cjs"],
	]) {
		const runtimeTarget = exportTarget(subpath, condition, "default");
		assert(
			existsSync(runtimeTarget),
			`${subpath} ${condition} runtime target missing: ${runtimeTarget}`,
		);
		assert(
			runtimeTarget.endsWith(extension),
			`${subpath} ${condition} runtime target should end with ${extension}`,
		);
		const typeTarget = exportTarget(subpath, condition, "types");
		assert(existsSync(typeTarget), `${subpath} ${condition} type target missing: ${typeTarget}`);
	}
}

for (const field of ["dependencies", "optionalDependencies", "peerDependencies"]) {
	assert(packageJson[field] === undefined, `${field} must be absent from the strict core manifest`);
}

for (const file of readdirSync(join(PKG, "dist"), { recursive: true, withFileTypes: true })) {
	if (!file.isFile() || (!file.name.endsWith(".js") && !file.name.endsWith(".cjs"))) continue;
	const path = join(file.parentPath, file.name);
	const source = readFileSync(path, "utf8");
	const specifiers = [
		...source.matchAll(/^\s*(?:import|export)\s+(?:[\s\S]*?\s+from\s+)?["']([^"']+)["'];?\s*$/gm),
		...source.matchAll(/^[^"'`]*\bimport\s*\(\s*["']([^"']+)["']\s*\)/gm),
		...source.matchAll(/^[^"'`]*\brequire\s*\(\s*["']([^"']+)["']\s*\)/gm),
	].map((match) => match[1]);
	for (const specifier of specifiers) {
		assert(
			specifier.startsWith(".") || nodeBuiltins.has(specifier),
			`${path} contains non-built-in bare import: ${specifier}`,
		);
	}
}

for (const rel of [
	"dist/index.js",
	"dist/index.cjs",
	"dist/adapters/index.js",
	"dist/adapters/index.cjs",
]) {
	const file = join(PKG, rel);
	assert(existsSync(file), `${rel} missing; run pnpm --filter @graphrefly/ts build`);
	const text = readFileSync(file, "utf8");
	for (const specifier of forbiddenFrameworkSpecifiers) {
		assert(
			!text.includes(specifier),
			`${rel} imports framework peer through the universal/adapters build: ${specifier}`,
		);
	}
}

const tmp = mkdtempSync(join(tmpdir(), "graphrefly-ts-export-smoke-"));

try {
	mkdirSync(join(tmp, "node_modules", "@graphrefly"), { recursive: true });
	const tmpPkg = join(tmp, "node_modules", "@graphrefly", "ts");
	mkdirSync(tmpPkg, { recursive: true });
	cpSync(join(PKG, "package.json"), join(tmpPkg, "package.json"));
	cpSync(join(PKG, "dist"), join(tmpPkg, "dist"), { recursive: true });
	writeFileSync(
		join(tmp, "package.json"),
		JSON.stringify({ type: "module", private: true }, null, "\t"),
	);

	const rootAbsentChecks = rootAbsentExports
		.map(
			(name) =>
				`assert(!Object.hasOwn(root, ${JSON.stringify(name)}), ${JSON.stringify(`@graphrefly/ts must not export ${name}`)});`,
		)
		.join("\n");

	const runtimeAssertions = `{
	const root = await load("@graphrefly/ts");
	${rootAbsentChecks}
}
{
	const root = await load("@graphrefly/ts");
	const orchestration = await load("@graphrefly/ts/orchestration");
	const rateLimit = await load("@graphrefly/ts/rate-limit");
	for (const name of Object.keys(rateLimit)) {
		assert(!Object.hasOwn(root, name), \`@graphrefly/ts must not export rate-limit symbol \${name}\`);
		assert(!Object.hasOwn(orchestration, name), \`@graphrefly/ts/orchestration must not export rate-limit symbol \${name}\`);
	}
}
${Object.entries(expectedSubpaths)
	.map(([subpath, { present, absent }]) => {
		const specifier = `@graphrefly/ts${subpath.slice(1)}`;
		const presentChecks = present
			.map((name) =>
				name === "LOCAL_CONTAINER_POSTGRESQL_COMPATIBILITY"
					? `assert(mod[${JSON.stringify(name)}] === "graphrefly-local-container-postgresql-v1", ${JSON.stringify(`${specifier}.${name}`)});`
					: name === "MANAGED_CLOUD_POSTGRESQL_COMPATIBILITY"
						? `assert(mod[${JSON.stringify(name)}] === "graphrefly-managed-cloud-postgresql-v2", ${JSON.stringify(`${specifier}.${name}`)});`
						: name === "MANAGED_CLOUD_POSTGRESQL_DEPLOYMENT_PROFILE"
							? `assert(mod[${JSON.stringify(name)}] === "control-plane-managed-kubernetes", ${JSON.stringify(`${specifier}.${name}`)});`
							: name === "CUSTOMER_HOSTED_POSTGRESQL_COMPATIBILITY"
								? `assert(mod[${JSON.stringify(name)}] === "customer-hosted-postgresql-v1", ${JSON.stringify(`${specifier}.${name}`)});`
								: name === "POSTGRESQL_RUN_OPERATIONS_COMPATIBILITY"
									? `assert(mod[${JSON.stringify(name)}] === "postgresql-run-operations-v1", ${JSON.stringify(`${specifier}.${name}`)});`
									: name === "SHARED_CONTROL_PANEL_AUTHORITY_COMPATIBILITY"
										? `assert(mod[${JSON.stringify(name)}] === "shared-control-panel-authority-v1", ${JSON.stringify(`${specifier}.${name}`)});`
										: name === "PRODUCTION_EVALUATION_AUTHORITY_COMPATIBILITY"
											? `assert(mod[${JSON.stringify(name)}] === "production-evaluation-authority-v1", ${JSON.stringify(`${specifier}.${name}`)});`
											: `assert(typeof mod[${JSON.stringify(name)}] === "function", ${JSON.stringify(`${specifier}.${name}`)});`,
			)
			.join("\n");
		const absentChecks = absent
			.map(
				(name) =>
					`assert(!Object.hasOwn(mod, ${JSON.stringify(name)}), ${JSON.stringify(`${specifier} must not export ${name}`)});`,
			)
			.join("\n");
		return `{
	const mod = await load(${JSON.stringify(specifier)});
	${presentChecks}
	${absentChecks}
}`;
	})
	.join("\n")}`;

	writeFileSync(
		join(tmp, "esm-smoke.mjs"),
		`import assert from "node:assert/strict";
const load = (specifier) => import(specifier);
${runtimeAssertions}
`,
	);

	writeFileSync(
		join(tmp, "cjs-smoke.cjs"),
		`const assert = require("node:assert/strict");
const load = (specifier) => require(specifier);
${runtimeAssertions.replaceAll("await load", "load")}
{
	const { graph } = require("@graphrefly/ts");
	const { textMeasurementProvider } = require("@graphrefly/ts/solutions/reactive-layout");
	const g = graph();
	const measured = textMeasurementProvider({
		graph: g,
		text: g.state("abc"),
		font: g.state("10px test"),
		adapter: g.state({
			measureSegment() {
				throw new Error("measurement unavailable");
			},
		}),
	});
	const messages = [];
	const unsubscribe = measured.subscribe((message) => messages.push(message));
	assert.match(JSON.stringify(messages), /"code":"measurement.failed"/);
	assert.equal(
		messages[1]?.[1]?.[0]?.details?.message,
		"measurement unavailable",
		"CJS root Graph and reactive-layout subpath must share dependency context",
	);
	unsubscribe();
}
`,
	);

	writeFileSync(
		join(tmp, "types-smoke.mts"),
		`import { externalStore, readableStore, recordReadableStore, subscribeNodeValues, wireBridgeProtobuf, writableStore, type AgenticMemoryPassiveStoreFrameAdapter, type AgenticMemoryPassiveStoreFrameCursor, type AgenticMemoryPassiveStoreFrameReadResult, type AgenticMemoryPassiveStoreFrameStatus, type AgenticMemoryPassiveStoreFrameWriteResult, type WireBridgeProtobufBundle, type WireBridgeProtobufData, type WireBridgeProtobufIssue, type WireBridgeProtobufOptions, type WireBridgeProtobufStatus } from "@graphrefly/ts/adapters";
import {
	appendLogCommittedFactJournal,
	committedFactJournalCursor,
	committedFactJournalCursorCodec,
	type CommittedFactJournalBackend,
	type CommittedFactJournalBatch,
	type CommittedFactJournalFact,
	type CommittedFactJournalProfile,
} from "@graphrefly/ts/committed-facts";
import {
	toolProviderExecutionRecipe,
	type ToolProviderExecutionRecipeBundle,
	type ToolProviderExecutionRecipeOptions,
} from "@graphrefly/ts/executors/tool-provider";
import {
	httpToolProviderCatalog,
	httpToolProviderRuntime,
	localBuiltinToolProviderAdapterPack,
	localBuiltinToolProviderBinding,
	processToolProviderAdapterPack,
	processToolProviderBinding,
	processToolProviderCatalog,
	type HttpToolProviderDriver,
	type HttpToolProviderRuntimeBundle,
	type HttpToolProviderRuntimeOptions,
	type LocalBuiltinToolProviderBindingOptions,
	type ProcessToolProviderBindingOptions,
} from "@graphrefly/ts/executors/tool-provider-adapters";
import {
	attachToolProviderAdapterRuntime,
	type ToolProviderAdapterBinding,
	type ToolProviderAdapterExecutionRetentionEntry,
	type ToolProviderAdapterInputRetentionEntry,
	type ToolProviderAdapterRunContext,
	type ToolProviderAdapterRunIssueRetentionEntry,
	type ToolProviderAdapterRunRequestRetentionEntry,
	type ToolProviderAdapterRunResult,
	type ToolProviderAdapterRunStatusRetentionEntry,
	type ToolProviderAdapterRuntimeHandle,
	type ToolProviderAdapterRuntimeIndexRetentionPolicy,
	type ToolProviderAdapterRuntimeOptions,
	type ToolProviderAdapterRuntimeRetentionEvidenceEntry,
	type ToolProviderAdapterRuntimeRetentionIndex,
	type ToolProviderAdapterRuntimeRetentionOrder,
	type ToolProviderAdapterRuntimeRetentionPolicy,
	type ToolProviderAdapterRuntimeStatus,
	type ToolProviderAdapterRuntimeStatusKind,
	type ToolProviderPublicTextPolicy,
} from "@graphrefly/ts/executors/tool-provider-runtime";
import { boundaryManifest, type BoundaryManifest, type BoundaryNode, type BoundaryRole } from "@graphrefly/ts/inspection/boundary";
import {
	validateMemoryFragment,
	type MemoryFragment as MemoryNamespaceFragment,
} from "@graphrefly/ts/memory";
import {
	memoryRetrievalBundle,
	type MemoryRetrievalBundleOptions,
} from "@graphrefly/ts/memory/semantic";
import {
	assertKeyedRateLimitRequest,
	evaluateFixedWindowRateLimitTransition,
	evaluateSlidingWindowRateLimitTransition,
	evaluateTokenBucketRateLimitTransition,
	keyedRateLimitAdmissionBundle,
	localFixedWindowRateLimitBundle,
	type FixedWindowRateLimitPolicy,
	type KeyedRateLimitRequest,
	type LocalFixedWindowRateLimitOptions,
	type SlidingWindowRateLimitState,
	type TokenBucketRateLimitTransition,
} from "@graphrefly/ts/rate-limit";
import {
	admissionScored,
	cosineSimilarity,
	isFiniteScore,
	normalizeScoreSignal,
	rankScoredSubjects,
	scoreSubjects,
	type ScoredSubject,
	type ScorePolicy,
	type ScoringPolicy,
	type ScoreSignal,
	type ScoreSubject,
} from "@graphrefly/ts/scoring";
import {
	AGENTIC_MEMORY_RECORD_APPLICATION_MATERIAL_IDENTITY_ALGORITHM,
	AGENTIC_MEMORY_DURABILITY_ADVANCE_ON_COMMITTED_OR_DUPLICATE_POLICY,
	admitAgenticMemoryRecordProposals,
	agenticMemoryBundle,
	agenticMemoryConsolidationApplicationBundle,
	agenticMemoryDurabilityAdvanceOnCommittedOrDuplicatePolicy,
	agenticMemoryDurabilityGateBundle,
	agenticMemoryDurabilityGateInput,
	projectAgenticMemoryDurabilityGate,
	agenticMemoryDurabilityResultMayAdvance,
	agenticMemoryDurabilityUncertainResolutionStatus,
	agenticMemoryCommittedFactLogAppendAttempt,
	agenticMemoryCommittedFactLogStartupRead,
	type AgenticMemoryCommittedFactLogAppendAttemptOptions,
	type AgenticMemoryCommittedFactLogAppendAttemptResult,
	type AgenticMemoryCommittedFactLogStartupReadOptions,
	type AgenticMemoryCommittedFactLogStartupReadResult,
	type AgenticMemoryDurabilityGateBundleOptions,
	type AgenticMemoryDurabilityGateInput,
	type AgenticMemoryBundleOptions as FocusedAgenticMemoryBundleOptions,
	type AgenticMemoryConsolidationApplicationBundle,
	type AgenticMemoryConsolidationApplicationBundleOptions,
	type AgenticMemoryRecord as FocusedAgenticMemoryRecord,
	agenticMemoryRecordAdmissionBundle,
	type AgenticMemoryRecordAdmissionPolicy,
	agenticMemoryRecordAdmissionPolicySourceBundle,
	projectAgenticMemoryRecordAdmissionPolicySource,
	agenticMemoryRecordApplicationBundle,
	type AgenticMemoryRecordApplicationBundleOptions,
	type AgenticMemoryRecordApplicationMaterialIdentity,
	type AgenticMemoryRecordApplicationOperationStatus,
	type AgenticMemoryRecordApplicationOptions,
	type AgenticMemoryRecordApplicationPolicy,
	type AgenticMemoryRecordApplicationPriorEvidence,
	applyAgenticMemoryRecordAdmissions,
} from "@graphrefly/ts/solutions/agentic-memory";
import {
	agenticWorkItemMemoryApplicationRecipeBundle,
	mapAgenticWorkItemMemoryApplicationRecipe,
	type AgenticWorkItemMemoryApplicationRecipeBundleOptions,
	type AgenticWorkItemMemoryApplicationRecipeResult,
} from "@graphrefly/ts/solutions/agentic-work-item-memory-application";
import {
	agenticWorkItemMemoryBridgeBundle,
	mapAgenticWorkItemMemoryBridge,
	type AgenticWorkItemMemoryBridgeResult,
	type AgenticWorkItemMemoryBridgeStatus,
	type AgenticWorkItemMemoryMappingPolicy,
	type AgenticWorkItemMemoryRecordCandidate,
} from "@graphrefly/ts/solutions/agentic-work-item-memory";
import {
	workItemAuthoringProjector,
	type WorkItemProjection,
} from "@graphrefly/ts/solutions/work-item";
import {
	isWorkspaceProposalProjectionReleaseMaterial,
	validateWorkspaceProposalProjectionReleaseMaterial,
	workspaceProposalProjectionReleaseDiagnosticProjector,
	type WorkspaceProposalProjectionRelease,
	type WorkspaceProposalProjectionReleaseDiagnostic,
	type WorkspaceProposalProjectionReleaseDiagnosticProjectorBundle,
	type WorkspaceProposalProjectionReleaseDiagnosticProjectorOptions,
	type WorkspaceProposalProjectionReleaseTargetKind,
	type WorkspaceProposalProjectionReleaseValidationResult,
} from "@graphrefly/ts/solutions/work-item/scheduling";

void externalStore;
void readableStore;
void recordReadableStore;
void subscribeNodeValues;
void wireBridgeProtobuf;
void writableStore;
void appendLogCommittedFactJournal;
void committedFactJournalCursor;
void committedFactJournalCursorCodec;
void toolProviderExecutionRecipe;
void attachToolProviderAdapterRuntime;
void httpToolProviderCatalog;
void httpToolProviderRuntime;
void localBuiltinToolProviderAdapterPack;
void localBuiltinToolProviderBinding;
void processToolProviderAdapterPack;
void processToolProviderBinding;
void processToolProviderCatalog;
void boundaryManifest;
void validateMemoryFragment;
void memoryRetrievalBundle;
void assertKeyedRateLimitRequest;
void evaluateFixedWindowRateLimitTransition;
void evaluateSlidingWindowRateLimitTransition;
void evaluateTokenBucketRateLimitTransition;
void keyedRateLimitAdmissionBundle;
void localFixedWindowRateLimitBundle;
void admissionScored;
void cosineSimilarity;
void isFiniteScore;
void normalizeScoreSignal;
void rankScoredSubjects;
void scoreSubjects;
void AGENTIC_MEMORY_RECORD_APPLICATION_MATERIAL_IDENTITY_ALGORITHM;
void AGENTIC_MEMORY_DURABILITY_ADVANCE_ON_COMMITTED_OR_DUPLICATE_POLICY;
void admitAgenticMemoryRecordProposals;
void agenticMemoryBundle;
void agenticMemoryConsolidationApplicationBundle;
void agenticMemoryDurabilityAdvanceOnCommittedOrDuplicatePolicy;
void agenticMemoryDurabilityGateBundle;
void agenticMemoryDurabilityGateInput;
void agenticMemoryDurabilityResultMayAdvance;
void agenticMemoryDurabilityUncertainResolutionStatus;
void agenticMemoryCommittedFactLogAppendAttempt;
void agenticMemoryCommittedFactLogStartupRead;
void agenticMemoryRecordAdmissionBundle;
void agenticMemoryRecordAdmissionPolicySourceBundle;
void agenticMemoryRecordApplicationBundle;
void applyAgenticMemoryRecordAdmissions;
void projectAgenticMemoryDurabilityGate;
void projectAgenticMemoryRecordAdmissionPolicySource;
void agenticWorkItemMemoryApplicationRecipeBundle;
void agenticWorkItemMemoryBridgeBundle;
void mapAgenticWorkItemMemoryApplicationRecipe;
void mapAgenticWorkItemMemoryBridge;
void workItemAuthoringProjector;
void isWorkspaceProposalProjectionReleaseMaterial;
void validateWorkspaceProposalProjectionReleaseMaterial;
void workspaceProposalProjectionReleaseDiagnosticProjector;

declare const manifest: BoundaryManifest;
declare const committedFactJournalBackend: CommittedFactJournalBackend<
	CommittedFactJournalBatch,
	CommittedFactJournalFact,
	ReturnType<typeof committedFactJournalCursor>
>;
declare const committedFactJournalProfile: CommittedFactJournalProfile<
	CommittedFactJournalFact,
	CommittedFactJournalBatch,
	ReturnType<typeof committedFactJournalCursor>
>;
const role: BoundaryRole = "input";
const node: BoundaryNode | undefined = manifest.inputs[0] ?? manifest.outputs[0];
declare const memoryNamespaceFragment: MemoryNamespaceFragment;
declare const memoryRetrievalOptions: MemoryRetrievalBundleOptions;
declare const scoringPolicy: ScoringPolicy;
declare const scorePolicy: ScorePolicy;
declare const scoreSignal: ScoreSignal;
declare const scoreSubject: ScoreSubject;
declare const scoredSubject: ScoredSubject;
declare const focusedAgenticMemoryBundleOptions: FocusedAgenticMemoryBundleOptions;
declare const focusedConsolidationApplicationBundle: AgenticMemoryConsolidationApplicationBundle;
declare const focusedConsolidationApplicationBundleOptions: AgenticMemoryConsolidationApplicationBundleOptions;
declare const factLogAppendAttemptOptions: AgenticMemoryCommittedFactLogAppendAttemptOptions;
declare const factLogAppendAttemptResult: AgenticMemoryCommittedFactLogAppendAttemptResult;
declare const factLogStartupReadOptions: AgenticMemoryCommittedFactLogStartupReadOptions;
declare const factLogStartupReadResult: AgenticMemoryCommittedFactLogStartupReadResult;
declare const durabilityGateBundleOptions: AgenticMemoryDurabilityGateBundleOptions;
declare const durabilityGateInput: AgenticMemoryDurabilityGateInput;
declare const focusedAgenticMemoryRecord: FocusedAgenticMemoryRecord;
declare const agenticMemoryRecordAdmissionPolicy: AgenticMemoryRecordAdmissionPolicy;
declare const agenticMemoryRecordApplicationPolicy: AgenticMemoryRecordApplicationPolicy;
declare const agenticMemoryRecordApplicationOptions: AgenticMemoryRecordApplicationOptions;
declare const agenticMemoryRecordApplicationBundleOptions: AgenticMemoryRecordApplicationBundleOptions;
declare const agenticMemoryRecordApplicationMaterialIdentity: AgenticMemoryRecordApplicationMaterialIdentity;
declare const agenticMemoryRecordApplicationOperationStatus: AgenticMemoryRecordApplicationOperationStatus;
declare const agenticMemoryRecordApplicationPriorEvidence: AgenticMemoryRecordApplicationPriorEvidence;
declare const agenticWorkItemMemoryApplicationRecipeBundleOptions: AgenticWorkItemMemoryApplicationRecipeBundleOptions;
declare const agenticWorkItemMemoryApplicationRecipeResult: AgenticWorkItemMemoryApplicationRecipeResult;
declare const agenticWorkItemMemoryBridgeResult: AgenticWorkItemMemoryBridgeResult;
declare const agenticWorkItemMemoryBridgeStatus: AgenticWorkItemMemoryBridgeStatus;
declare const agenticWorkItemMemoryMappingPolicy: AgenticWorkItemMemoryMappingPolicy;
declare const agenticWorkItemMemoryRecordCandidate: AgenticWorkItemMemoryRecordCandidate;
declare const workItemProjection: WorkItemProjection;
declare const recipeBundle: ToolProviderExecutionRecipeBundle;
declare const recipeOptions: ToolProviderExecutionRecipeOptions;
declare const runtimeBinding: ToolProviderAdapterBinding;
declare const runtimeExecutionRetentionEntry: ToolProviderAdapterExecutionRetentionEntry;
declare const runtimeInputRetentionEntry: ToolProviderAdapterInputRetentionEntry;
declare const runtimeRunContext: ToolProviderAdapterRunContext;
declare const runtimeRunIssueRetentionEntry: ToolProviderAdapterRunIssueRetentionEntry;
declare const runtimeRunRequestRetentionEntry: ToolProviderAdapterRunRequestRetentionEntry;
declare const runtimeRunResult: ToolProviderAdapterRunResult;
declare const runtimeRunStatusRetentionEntry: ToolProviderAdapterRunStatusRetentionEntry;
declare const runtimeHandle: ToolProviderAdapterRuntimeHandle;
declare const runtimeIndexRetentionPolicy: ToolProviderAdapterRuntimeIndexRetentionPolicy<unknown>;
declare const runtimeOptions: ToolProviderAdapterRuntimeOptions;
declare const runtimeRetentionEvidenceEntry: ToolProviderAdapterRuntimeRetentionEvidenceEntry;
declare const runtimeRetentionIndex: ToolProviderAdapterRuntimeRetentionIndex;
const runtimeRetentionOrder: ToolProviderAdapterRuntimeRetentionOrder = "fifo";
declare const runtimeRetentionPolicy: ToolProviderAdapterRuntimeRetentionPolicy;
declare const runtimeStatus: ToolProviderAdapterRuntimeStatus;
declare const runtimeStatusKind: ToolProviderAdapterRuntimeStatusKind;
declare const publicTextPolicy: ToolProviderPublicTextPolicy;
declare const fixedWindowRateLimitPolicy: FixedWindowRateLimitPolicy;
declare const keyedRateLimitRequest: KeyedRateLimitRequest;
declare const localFixedWindowRateLimitOptions: LocalFixedWindowRateLimitOptions;
declare const slidingWindowRateLimitState: SlidingWindowRateLimitState;
declare const tokenBucketRateLimitTransition: TokenBucketRateLimitTransition;
declare const httpDriver: HttpToolProviderDriver;
declare const httpRuntimeBundle: HttpToolProviderRuntimeBundle;
declare const httpRuntimeOptions: HttpToolProviderRuntimeOptions;
declare const localBindingOptions: LocalBuiltinToolProviderBindingOptions;
declare const processBindingOptions: ProcessToolProviderBindingOptions;
declare const projectionRelease: WorkspaceProposalProjectionRelease;
declare const projectionReleaseDiagnostic: WorkspaceProposalProjectionReleaseDiagnostic;
declare const projectionReleaseDiagnosticProjectorBundle: WorkspaceProposalProjectionReleaseDiagnosticProjectorBundle;
declare const projectionReleaseDiagnosticProjectorOptions: WorkspaceProposalProjectionReleaseDiagnosticProjectorOptions;
declare const projectionReleaseValidationResult: WorkspaceProposalProjectionReleaseValidationResult;
declare const protobufBundle: WireBridgeProtobufBundle;
	declare const protobufData: WireBridgeProtobufData;
	declare const protobufIssue: WireBridgeProtobufIssue;
	declare const protobufOptions: WireBridgeProtobufOptions;
	declare const protobufStatus: WireBridgeProtobufStatus;
	declare const passiveStoreFrameAdapter: AgenticMemoryPassiveStoreFrameAdapter;
	declare const passiveStoreFrameCursor: AgenticMemoryPassiveStoreFrameCursor;
	declare const passiveStoreFrameReadResult: AgenticMemoryPassiveStoreFrameReadResult;
	declare const passiveStoreFrameStatus: AgenticMemoryPassiveStoreFrameStatus;
	declare const passiveStoreFrameWriteResult: AgenticMemoryPassiveStoreFrameWriteResult;
	const projectionReleaseTargetKind: WorkspaceProposalProjectionReleaseTargetKind = "family-read-model-query";
void role;
void node;
void committedFactJournalBackend;
void committedFactJournalProfile;
void memoryNamespaceFragment;
void memoryRetrievalOptions;
void scoringPolicy;
void scorePolicy;
void scoreSignal;
void scoreSubject;
void scoredSubject;
void focusedAgenticMemoryBundleOptions;
void focusedConsolidationApplicationBundle;
void focusedConsolidationApplicationBundleOptions;
void factLogAppendAttemptOptions;
void factLogAppendAttemptResult;
void factLogStartupReadOptions;
void factLogStartupReadResult;
void durabilityGateBundleOptions;
void durabilityGateInput;
void focusedAgenticMemoryRecord;
void agenticMemoryRecordAdmissionPolicy;
void agenticMemoryRecordApplicationPolicy;
void agenticMemoryRecordApplicationOptions;
void agenticMemoryRecordApplicationBundleOptions;
void agenticMemoryRecordApplicationMaterialIdentity;
void agenticMemoryRecordApplicationOperationStatus;
void agenticMemoryRecordApplicationPriorEvidence;
void agenticWorkItemMemoryApplicationRecipeBundleOptions;
void agenticWorkItemMemoryApplicationRecipeResult;
void agenticWorkItemMemoryBridgeResult;
void agenticWorkItemMemoryBridgeStatus;
void agenticWorkItemMemoryMappingPolicy;
void agenticWorkItemMemoryRecordCandidate;
void workItemProjection;
void recipeBundle;
void recipeOptions;
void runtimeBinding;
void runtimeExecutionRetentionEntry;
void runtimeInputRetentionEntry;
void runtimeRunContext;
void runtimeRunIssueRetentionEntry;
void runtimeRunRequestRetentionEntry;
void runtimeRunResult;
void runtimeRunStatusRetentionEntry;
void runtimeHandle;
void runtimeIndexRetentionPolicy;
void runtimeOptions;
void runtimeRetentionEvidenceEntry;
void runtimeRetentionIndex;
void runtimeRetentionOrder;
void runtimeRetentionPolicy;
void runtimeStatus;
void runtimeStatusKind;
void publicTextPolicy;
void fixedWindowRateLimitPolicy;
void keyedRateLimitRequest;
void localFixedWindowRateLimitOptions;
void slidingWindowRateLimitState;
void tokenBucketRateLimitTransition;
void httpDriver;
void httpRuntimeBundle;
void httpRuntimeOptions;
void localBindingOptions;
void processBindingOptions;
void projectionRelease;
void projectionReleaseDiagnostic;
void projectionReleaseDiagnosticProjectorBundle;
void projectionReleaseDiagnosticProjectorOptions;
void projectionReleaseValidationResult;
void projectionReleaseTargetKind;
void protobufBundle;
	void protobufData;
	void protobufIssue;
	void protobufOptions;
	void protobufStatus;
	void passiveStoreFrameAdapter;
	void passiveStoreFrameCursor;
	void passiveStoreFrameReadResult;
	void passiveStoreFrameStatus;
	void passiveStoreFrameWriteResult;
	`,
	);
	const rootForbiddenExports = [
		...new Set([...rootAbsentExports, ...rootAbsentTypeExports, ...rateLimitPublicExports]),
	];
	const rootForbiddenNames = rootForbiddenExports.join(", ");
	writeFileSync(
		join(tmp, "root-negative.mts"),
		`import type { ${rootForbiddenNames} } from "@graphrefly/ts";
`,
	);
	writeFileSync(
		join(tmp, "adapters-negative.mts"),
		`import type { ${expectedSubpaths["./adapters"].absent.join(", ")} } from "@graphrefly/ts/adapters";
`,
	);
	writeFileSync(
		join(tmp, "orchestration-negative.mts"),
		`import type { ${rateLimitPublicExports.join(", ")} } from "@graphrefly/ts/orchestration";
`,
	);
	writeFileSync(
		join(tmp, "scheduling-negative.mts"),
		`import type { ${expectedSubpaths["./solutions/work-item/scheduling"].absent.join(", ")} } from "@graphrefly/ts/solutions/work-item/scheduling";
`,
	);

	writeFileSync(
		join(tmp, "tsconfig.json"),
		JSON.stringify(
			{
				compilerOptions: {
					target: "ES2022",
					module: "NodeNext",
					moduleResolution: "NodeNext",
					strict: true,
					noEmit: true,
					skipLibCheck: true,
				},
				include: ["types-smoke.mts"],
			},
			null,
			"\t",
		),
	);

	execFileSync(process.execPath, ["esm-smoke.mjs"], { cwd: tmp, stdio: "pipe" });
	execFileSync(process.execPath, ["cjs-smoke.cjs"], { cwd: tmp, stdio: "pipe" });
	execFileSync(TSC, ["-p", "tsconfig.json"], { cwd: tmp, stdio: "pipe" });
	expectTscFailure(tmp, "root-negative.mts", rootForbiddenExports);
	expectTscFailure(tmp, "adapters-negative.mts", expectedSubpaths["./adapters"].absent);
	expectTscFailure(tmp, "orchestration-negative.mts", rateLimitPublicExports);
	expectTscFailure(
		tmp,
		"scheduling-negative.mts",
		expectedSubpaths["./solutions/work-item/scheduling"].absent,
	);
} catch (e) {
	fail(`${e.message ?? e}\n${errorOutput(e)}`.trim());
} finally {
	rmSync(tmp, { recursive: true, force: true });
}

console.log("check-ts-package-exports: package ESM/CJS/DTS subpath smoke passed");
