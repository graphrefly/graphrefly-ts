/**
 * Graph-visible wire bridge envelope helpers (D134).
 *
 * This first slice is transport-free: commands become outbound envelope facts,
 * remote receipts enter only through the inbound fact node, and retry/ack timeout
 * state is surfaced through graph-visible attempts/status/errors nodes.
 */

import { type Ctx, depBatch } from "../ctx/types.js";
import type { Graph } from "../graph/graph.js";
import {
	nextRetryDelayMs,
	type RetryPolicy,
	retryPolicy,
	shouldRetry,
} from "../graph/resilience.js";
import { canonicalTupleKey } from "../identity.js";
import type { Node } from "../node/node.js";
import { errorPayload } from "../protocol/messages.js";
import type {
	CanonicalWireBridgeDataBody,
	CanonicalWireBridgeEnvelope,
	CanonicalWireBridgeMetadata,
	CanonicalWireBridgePayload,
	CanonicalWireEdgeFrame,
} from "./bridge-protobuf.js";
import {
	CanonicalProtobufError,
	decodeCanonicalWireBridgeEnvelope,
	encodeCanonicalWireBridgeEnvelope,
} from "./bridge-protobuf.js";
import type {
	AttachedCommandSources,
	BridgeState,
	RemoteCallRequest,
	RemoteCallResponse,
	RemoteResponderBundle,
	RemoteResponderHandler,
	RemoteResponderHandlerDefinition,
	RemoteResponderOptions,
	WireBridgeAckDriverBundle,
	WireBridgeAckDriverIssue,
	WireBridgeAckDriverOptions,
	WireBridgeAckDriverStatus,
	WireBridgeBundle,
	WireBridgeCommand,
	WireBridgeEnvelope,
	WireBridgeEnvelopeType,
	WireBridgeEvent,
	WireBridgeInvalidIngress,
	WireBridgeMetadata,
	WireBridgeOptions,
	WireBridgePayload,
	WireBridgeProtobufBundle,
	WireBridgeProtobufData,
	WireBridgeProtobufIssue,
	WireBridgeProtobufOptions,
	WireBridgeProtobufStatus,
} from "./bridge-types.js";

export type {
	CanonicalProtobufErrorCategory,
	CanonicalWireBridgeDataBody,
	CanonicalWireBridgeEnvelope,
	CanonicalWireBridgeMetadata,
	CanonicalWireBridgePayload,
	CanonicalWireEdgeFrame,
} from "./bridge-protobuf.js";
export {
	CanonicalProtobufError,
	decodeCanonicalWireBridgeEnvelope,
	decodeCanonicalWireEdgeFrame,
	encodeCanonicalWireBridgeEnvelope,
	encodeCanonicalWireEdgeFrame,
} from "./bridge-protobuf.js";
export { remoteCall } from "./bridge-remote-call.js";
export type {
	RemoteCallBundle,
	RemoteCallError,
	RemoteCallOptions,
	RemoteCallRequest,
	RemoteCallResponse,
	RemoteCallResult,
	RemoteCallStatus,
	RemoteCallStatusState,
	RemoteCallTimeout,
	RemoteResponderBundle,
	RemoteResponderEvent,
	RemoteResponderHandler,
	RemoteResponderHandlerDefinition,
	RemoteResponderOptions,
	RemoteResponderStatus,
	RemoteResponderStatusState,
	WireBridgeAck,
	WireBridgeAckDriverBundle,
	WireBridgeAckDriverIssue,
	WireBridgeAckDriverOptions,
	WireBridgeAckDriverStatus,
	WireBridgeAttempt,
	WireBridgeBundle,
	WireBridgeCommand,
	WireBridgeEnvelope,
	WireBridgeEnvelopeType,
	WireBridgeEvent,
	WireBridgeMetadata,
	WireBridgeNack,
	WireBridgeOptions,
	WireBridgePayload,
	WireBridgeProtobufBundle,
	WireBridgeProtobufData,
	WireBridgeProtobufIssue,
	WireBridgeProtobufOptions,
	WireBridgeProtobufStatus,
	WireBridgeStatus,
} from "./bridge-types.js";

import {
	guardedInboundNode,
	invalidIngress,
	isInvalidIngress,
	projectAcks,
	projectAttempts,
	projectCursor,
	projectErrors,
	projectNacks,
	projectOutbound,
	projectStatus,
} from "./bridge-projections.js";
import {
	normalizeRemoteHandlers,
	remoteResponderErrorsNode,
	remoteResponderEventsNode,
	remoteResponderRequestsNode,
	remoteResponderResponseCommandsNode,
	remoteResponderStatusNode,
} from "./bridge-remote-responder.js";
import {
	bridgePayloadError,
	envelopeTypes,
	isSafeNonNegativeInteger,
	isSafePositiveInteger,
	normalizeWireBridgePayload,
	shouldTrackAck,
	validateCommand,
	validateInboundEnvelope,
	validatePayloadForType,
} from "./bridge-validation.js";

const bridgeCommandSources = new WeakMap<
	WireBridgeBundle<unknown, unknown>,
	AttachedCommandSources<unknown>
>();
const bridgeInboundTargets = new WeakMap<
	WireBridgeBundle<unknown, unknown>,
	Node<WireBridgeEnvelope<unknown> | WireBridgeInvalidIngress>
>();
const bridgeInboundSources = new WeakMap<
	WireBridgeBundle<unknown, unknown>,
	{ sources: Node<WireBridgeEnvelope<unknown> | WireBridgeInvalidIngress>[] }
>();

/** Stable D134 idempotency key helper scoped to one bridge session and sequence.
 * @param sessionId - Stable identifier used by the emitted record.
 * @param seq - seq value used by the helper.
 * @returns The stable key or reference string.
 * @category adapters
 * @example
 * ```ts
 * import { wireBridgeIdempotencyKey } from "@graphrefly/ts/adapters";
 * ```
 */
export function wireBridgeIdempotencyKey(sessionId: string, seq: number): string {
	return canonicalTupleKey([sessionId, String(seq)]);
}

/** Create a D134 wire bridge envelope with ordered metadata.
 * @param input - Input value to project or validate.
 * @returns A `WireBridgeEnvelope<TData>` value.
 * @category adapters
 * @example
 * ```ts
 * import { wireBridgeEnvelope } from "@graphrefly/ts/adapters";
 * ```
 */
export function wireBridgeEnvelope<TData = unknown>(input: {
	readonly sessionId: string;
	readonly type: WireBridgeEnvelopeType;
	readonly seq: number;
	readonly cursor?: number;
	readonly payload?: WireBridgePayload<TData>;
	readonly idempotencyKey?: string;
	readonly attempt?: number;
	readonly maxAttempts?: number;
	readonly timestampMs?: number;
	readonly ackForSeq?: number;
	readonly requestId?: string;
}): WireBridgeEnvelope<TData> {
	if (typeof input.sessionId !== "string" || input.sessionId.length === 0) {
		throw new RangeError("wireBridgeEnvelope: sessionId must be a non-empty string");
	}
	if (!envelopeTypes.has(input.type)) {
		throw new RangeError("wireBridgeEnvelope: type is not recognized");
	}
	if (!isSafePositiveInteger(input.seq)) {
		throw new RangeError("wireBridgeEnvelope: seq must be a positive integer");
	}
	const cursor = input.cursor ?? 0;
	if (!isSafeNonNegativeInteger(cursor)) {
		throw new RangeError("wireBridgeEnvelope: cursor must be a non-negative integer");
	}
	const attempt = input.attempt ?? 1;
	if (!isSafePositiveInteger(attempt)) {
		throw new RangeError("wireBridgeEnvelope: attempt must be a positive integer");
	}
	const maxAttempts = input.maxAttempts ?? attempt;
	if (!isSafePositiveInteger(maxAttempts) || maxAttempts < attempt) {
		throw new RangeError("wireBridgeEnvelope: maxAttempts must be >= attempt");
	}
	if (input.ackForSeq !== undefined && !isSafePositiveInteger(input.ackForSeq)) {
		throw new RangeError("wireBridgeEnvelope: ackForSeq must be a positive integer");
	}
	if ((input.type === "ack" || input.type === "nack") && input.ackForSeq === undefined) {
		throw new RangeError(`wireBridgeEnvelope: ${input.type} envelope requires ackForSeq`);
	}
	if (input.idempotencyKey !== undefined && input.idempotencyKey.length === 0) {
		throw new RangeError("wireBridgeEnvelope: idempotencyKey must be a non-empty string");
	}
	const payloadError = validatePayloadForType(input.type, input.payload, "wireBridgeEnvelope");
	if (payloadError !== undefined) {
		throw new RangeError(payloadError);
	}
	const payload = normalizeWireBridgePayload(
		input.payload,
		`wireBridgeEnvelope ${input.type} envelope`,
	) as WireBridgePayload<TData> | undefined;
	return {
		sessionId: input.sessionId,
		type: input.type,
		payload,
		metadata: {
			seq: input.seq,
			cursor,
			idempotencyKey: input.idempotencyKey ?? wireBridgeIdempotencyKey(input.sessionId, input.seq),
			attempt,
			maxAttempts,
			timestampMs: input.timestampMs,
			ackForSeq: input.ackForSeq,
			requestId: input.requestId,
		},
	};
}

/**
 * Creates a wire bridge.
 *
 * @param graph - Graph that owns the created nodes or projector.
 * @param opts - Options that configure the helper.
 * @returns The wire bridge result.
 * @category adapters
 * @example
 * ```ts
 * import { wireBridge } from "@graphrefly/ts/adapters";
 * ```
 */
export function wireBridge<TOutbound = unknown, TInbound = unknown>(
	graph: Graph,
	opts: WireBridgeOptions,
): WireBridgeBundle<TOutbound, TInbound> {
	const name = opts.name ?? "wireBridge";
	const policy = opts.retry ?? retryPolicy();
	const command = graph.node<WireBridgeCommand<TOutbound>>([], null, {
		name: `${name}/command`,
		factory: "wireBridgeCommand",
	});
	const inboundCore = graph.node<WireBridgeEnvelope<TInbound> | WireBridgeInvalidIngress>(
		[],
		null,
		{
			name: `${name}/inbound`,
			factory: "wireBridgeInbound",
		},
	);
	const inbound = guardedInboundNode(inboundCore, opts.sessionId);
	const events = wireBridgeEventsNode<TOutbound, TInbound>(
		graph,
		command,
		inboundCore,
		name,
		opts,
		policy,
	);
	const outbound = projectOutbound(graph, events, name);
	const acks = projectAcks(graph, events, name);
	const nacks = projectNacks(graph, events, name);
	const status = projectStatus(graph, events, name, opts.sessionId);
	const errors = projectErrors(graph, events, name);
	const cursor = projectCursor(graph, events, name);
	const attempts = projectAttempts(graph, events, name);
	const bundle: WireBridgeBundle<TOutbound, TInbound> = {
		sessionId: opts.sessionId,
		command,
		outbound,
		inbound,
		events,
		acks,
		nacks,
		status,
		errors,
		cursor,
		attempts,
		start: () => command.down([["DATA", { kind: "start" }]]),
		send: (payload, sendOpts) =>
			command.down([
				[
					"DATA",
					{
						kind: "send",
						payload,
						idempotencyKey: sendOpts?.idempotencyKey,
						requestId: sendOpts?.requestId,
					},
				],
			]),
		ack: (ackForSeq, ackOpts) =>
			command.down([
				[
					"DATA",
					{
						kind: "ack",
						ackForSeq,
						idempotencyKey: ackOpts?.idempotencyKey,
						requestId: ackOpts?.requestId,
					},
				],
			]),
		nack: (ackForSeq, error, nackOpts) =>
			command.down([
				[
					"DATA",
					{
						kind: "nack",
						ackForSeq,
						error,
						idempotencyKey: nackOpts?.idempotencyKey,
						requestId: nackOpts?.requestId,
					},
				],
			]),
		close: (reason, closeOpts) =>
			command.down([
				["DATA", { kind: "close", reason, idempotencyKey: closeOpts?.idempotencyKey }],
			]),
	};
	bridgeCommandSources.set(bundle as WireBridgeBundle<unknown, unknown>, { sources: [] });
	bridgeInboundTargets.set(bundle as WireBridgeBundle<unknown, unknown>, inboundCore);
	bridgeInboundSources.set(bundle as WireBridgeBundle<unknown, unknown>, { sources: [] });
	return bundle;
}

type WireBridgeAckTimeoutCommand = Extract<
	WireBridgeCommand<never>,
	{ readonly kind: "ack-timeout" }
>;

type WireBridgeAckDriverEvent =
	| {
			readonly kind: "command";
			readonly command: WireBridgeAckTimeoutCommand;
			readonly pending: number;
			readonly nowMs: number;
	  }
	| {
			readonly kind: "issue";
			readonly issue: WireBridgeAckDriverIssue;
			readonly pending: number;
			readonly nowMs?: number;
	  }
	| { readonly kind: "state"; readonly pending: number; readonly nowMs?: number };

interface AckDriverPendingAttempt {
	readonly seq: number;
	attempt: number;
	observedAtMs?: number;
	timedOutAttempt?: number;
	timedOutAtMs?: number;
	retryDueAtMs?: number;
	retryReleasedAttempt?: number;
}

interface AckDriverState {
	nowMs?: number;
	pending: Map<number, AckDriverPendingAttempt>;
}

/** D502 explicit graph-visible ack-timeout command driver for a wireBridge.
 * @param graph - Graph that owns the created nodes or projector.
 * @param bridge - bridge value used by the helper.
 * @param opts - Options that configure the helper.
 * @returns A `WireBridgeAckDriverBundle` value.
 * @category adapters
 * @example
 * ```ts
 * import { wireBridgeAckDriver } from "@graphrefly/ts/adapters";
 * ```
 */
export function wireBridgeAckDriver<TOutbound = unknown, TInbound = unknown>(
	graph: Graph,
	bridge: WireBridgeBundle<TOutbound, TInbound>,
	opts: WireBridgeAckDriverOptions,
): WireBridgeAckDriverBundle {
	const name = opts.name ?? `${bridge.sessionId}/wireBridgeAckDriver`;
	if (!Number.isFinite(opts.timeoutMs) || opts.timeoutMs < 0) {
		throw new RangeError("wireBridgeAckDriver: timeoutMs must be a non-negative finite number");
	}
	const topology = graph.topologyGroup({ name: `${name}.wireBridgeAckDriver` });
	const active = { current: true };
	const events = topology.add(wireBridgeAckDriverEventsNode(graph, bridge, opts, name, active));
	const commands = topology.add(
		graph.node<WireBridgeCommand<never>>([events], wireBridgeAckDriverCommandsFn(), {
			name: `${name}/commands`,
			factory: "wireBridgeAckDriverCommands",
		}),
	);
	const issues = topology.add(wireBridgeAckDriverIssuesNode(graph, events, name));
	const status = topology.add(wireBridgeAckDriverStatusNode(graph, events, name));
	let released = false;
	return {
		commands,
		status,
		issues,
		release() {
			if (released) return;
			active.current = false;
			try {
				topology.release({ reason: `${name}.wireBridgeAckDriver.release` });
				released = true;
			} catch (error) {
				active.current = true;
				throw error;
			}
		},
	};
}

function wireBridgeAckDriverEventsNode<TOutbound, TInbound>(
	graph: Graph,
	bridge: WireBridgeBundle<TOutbound, TInbound>,
	opts: WireBridgeAckDriverOptions,
	name: string,
	active: { current: boolean },
): Node<WireBridgeAckDriverEvent> {
	return graph.node<WireBridgeAckDriverEvent>(
		[opts.clock, bridge.attempts, bridge.acks, bridge.nacks, bridge.status],
		(ctx) => {
			let state = ctx.state.get<AckDriverState>();
			if (state === undefined) {
				state = { pending: new Map() };
				ctx.state.set(state);
			}
			let touched = false;
			for (const rawClock of depBatch(ctx, 0) ?? []) {
				if (!Number.isFinite(rawClock) || (rawClock as number) < 0) {
					ctx.down([
						[
							"DATA",
							{
								kind: "issue",
								issue: {
									code: "wire-bridge-ack-driver-clock-invalid",
									message: "wireBridgeAckDriver: clock facts must be non-negative finite numbers",
									nowMs: rawClock as number,
								},
								pending: state.pending.size,
								nowMs: state.nowMs,
							} satisfies WireBridgeAckDriverEvent,
						],
					]);
					touched = true;
					continue;
				}
				const nowMs = rawClock as number;
				if (state.nowMs !== undefined && nowMs < state.nowMs) {
					ctx.down([
						[
							"DATA",
							{
								kind: "issue",
								issue: {
									code: "wire-bridge-ack-driver-clock-regressed",
									message: "wireBridgeAckDriver: clock facts must be monotonic",
									nowMs,
								},
								pending: state.pending.size,
								nowMs: state.nowMs,
							} satisfies WireBridgeAckDriverEvent,
						],
					]);
					touched = true;
					continue;
				}
				state.nowMs = nowMs;
				touched = true;
			}
			for (const rawAttempt of depBatch(ctx, 1) ?? []) {
				const attempt = rawAttempt as { readonly seq: number; readonly attempt: number };
				state.pending.set(attempt.seq, {
					seq: attempt.seq,
					attempt: attempt.attempt,
					observedAtMs: state.nowMs,
				});
				touched = true;
			}
			for (const rawAck of depBatch(ctx, 2) ?? []) {
				state.pending.delete((rawAck as { readonly ackForSeq: number }).ackForSeq);
				touched = true;
			}
			for (const rawNack of depBatch(ctx, 3) ?? []) {
				state.pending.delete((rawNack as { readonly ackForSeq: number }).ackForSeq);
				touched = true;
			}
			for (const rawStatus of depBatch(ctx, 4) ?? []) {
				const status = rawStatus as {
					readonly state?: string;
					readonly pending?: number;
					readonly lastSeq?: number;
					readonly lastDelayMs?: number;
				};
				if (status.pending === 0) state.pending.clear();
				else if (status.state === "exhausted" && status.lastSeq !== undefined) {
					state.pending.delete(status.lastSeq);
				} else if (
					status.state === "waiting" &&
					status.lastSeq !== undefined &&
					status.lastDelayMs !== undefined
				) {
					const pending = state.pending.get(status.lastSeq);
					if (
						pending?.timedOutAtMs !== undefined &&
						pending.retryReleasedAttempt !== pending.attempt
					) {
						pending.retryDueAtMs = pending.timedOutAtMs + status.lastDelayMs;
					}
				}
				touched = true;
			}
			const nowMs = state.nowMs;
			let emittedCommand = false;
			if (active.current && nowMs !== undefined) {
				for (const pending of state.pending.values()) {
					if (pending.observedAtMs === undefined) {
						pending.observedAtMs = nowMs;
						touched = true;
					}
					if (
						pending.observedAtMs !== undefined &&
						nowMs - pending.observedAtMs >= opts.timeoutMs &&
						pending.timedOutAttempt !== pending.attempt
					) {
						const command: WireBridgeAckTimeoutCommand = {
							kind: "ack-timeout",
							seq: pending.seq,
							attempt: pending.attempt,
							observedAtMs: nowMs,
						};
						pending.timedOutAttempt = pending.attempt;
						pending.timedOutAtMs = nowMs;
						ctx.down([["DATA", { kind: "command", command, pending: state.pending.size, nowMs }]]);
						emittedCommand = true;
						touched = true;
					} else if (
						pending.retryDueAtMs !== undefined &&
						nowMs >= pending.retryDueAtMs &&
						pending.retryReleasedAttempt !== pending.attempt
					) {
						const command: WireBridgeAckTimeoutCommand = {
							kind: "ack-timeout",
							seq: pending.seq,
							attempt: pending.attempt,
							observedAtMs: nowMs,
						};
						pending.retryReleasedAttempt = pending.attempt;
						ctx.down([["DATA", { kind: "command", command, pending: state.pending.size, nowMs }]]);
						emittedCommand = true;
						touched = true;
					}
				}
			}
			if (touched && !emittedCommand) {
				ctx.down([["DATA", { kind: "state", pending: state.pending.size, nowMs }]]);
			}
		},
		{
			name: `${name}/events`,
			factory: "wireBridgeAckDriverEvents",
			partial: true,
			completeWhenDepsComplete: false,
			errorWhenDepsError: false,
		},
	);
}

function wireBridgeAckDriverCommandsFn(): (ctx: Ctx) => void {
	return (ctx) => {
		for (const raw of depBatch(ctx, 0) ?? []) {
			const event = raw as WireBridgeAckDriverEvent;
			if (event.kind === "command") ctx.down([["DATA", event.command]]);
		}
	};
}

function wireBridgeAckDriverIssuesNode(
	graph: Graph,
	events: Node<WireBridgeAckDriverEvent>,
	name: string,
): Node<WireBridgeAckDriverIssue> {
	return graph.node<WireBridgeAckDriverIssue>(
		[events],
		(ctx) => {
			for (const raw of depBatch(ctx, 0) ?? []) {
				const event = raw as WireBridgeAckDriverEvent;
				if (event.kind === "issue") ctx.down([["DATA", event.issue]]);
			}
		},
		{ name: `${name}/issues`, factory: "wireBridgeAckDriverIssues" },
	);
}

function wireBridgeAckDriverStatusNode(
	graph: Graph,
	events: Node<WireBridgeAckDriverEvent>,
	name: string,
): Node<WireBridgeAckDriverStatus> {
	return graph.node<WireBridgeAckDriverStatus>(
		[events],
		(ctx) => {
			let next =
				ctx.state.get<WireBridgeAckDriverStatus>() ??
				({
					state: "idle",
					pending: 0,
					commands: 0,
					issues: 0,
				} satisfies WireBridgeAckDriverStatus);
			for (const raw of depBatch(ctx, 0) ?? []) {
				const event = raw as WireBridgeAckDriverEvent;
				if (event.kind === "command") {
					next = {
						...next,
						state: "timed-out",
						pending: event.pending,
						commands: next.commands + 1,
						nowMs: event.nowMs,
						lastCommand: event.command,
					};
				} else if (event.kind === "issue") {
					next = {
						...next,
						state: "issues",
						pending: event.pending,
						issues: next.issues + 1,
						nowMs: event.nowMs,
						lastIssue: event.issue,
					};
				} else {
					next = {
						...next,
						state: event.pending > 0 ? "active" : "idle",
						pending: event.pending,
						nowMs: event.nowMs,
					};
				}
			}
			ctx.state.set(next);
			ctx.down([["DATA", next]]);
		},
		{ name: `${name}/status`, factory: "wireBridgeAckDriverStatus" },
	);
}

type WireBridgeProtobufInboundResult =
	| { readonly kind: "decoded"; readonly envelope: WireBridgeEnvelope<WireBridgeProtobufData> }
	| {
			readonly kind: "issue";
			readonly issue: WireBridgeProtobufIssue;
			readonly invalid: WireBridgeInvalidIngress;
	  };

type WireBridgeProtobufOutboundResult =
	| { readonly kind: "encoded"; readonly bytes: Uint8Array }
	| { readonly kind: "issue"; readonly issue: WireBridgeProtobufIssue };

type WireBridgeProtobufEvent =
	| {
			readonly kind: "inbound";
			readonly result: WireBridgeProtobufInboundResult;
	  }
	| {
			readonly kind: "outbound";
			readonly result: WireBridgeProtobufOutboundResult;
	  };

type WireBridgeProtobufInboundEvent = Extract<
	WireBridgeProtobufEvent,
	{ readonly kind: "inbound" }
>;
type WireBridgeProtobufOutboundEvent = Extract<
	WireBridgeProtobufEvent,
	{ readonly kind: "outbound" }
>;

/**
 * D498 focused canonical protobuf byte adapter over an existing semantic wireBridge bundle.
 *
 * This helper owns no transport/session/retry policy and does not add wireBridge core options.
 * Malformed bytes become graph-visible issue/invalid facts, never local protocol terminals.
 * @param graph - Graph that owns the created nodes or projector.
 * @param bridge - bridge value used by the helper.
 * @param opts - Options that configure the helper.
 * @returns A `WireBridgeProtobufBundle` value.
 * @category adapters
 * @example
 * ```ts
 * import { wireBridgeProtobuf } from "@graphrefly/ts/adapters";
 * ```
 */
export function wireBridgeProtobuf(
	graph: Graph,
	bridge: WireBridgeBundle<WireBridgeProtobufData, WireBridgeProtobufData>,
	opts: WireBridgeProtobufOptions = {},
): WireBridgeProtobufBundle {
	const name = opts.name ?? "wireBridgeProtobuf";
	const topology = graph.topologyGroup({ name: `${name}.wireBridgeProtobuf` });
	const inboundBytes = topology.node<Uint8Array>([], null, {
		name: `${name}/inboundBytes`,
		factory: "wireBridgeProtobufInboundBytes",
	});
	const inboundResults = topology.node<WireBridgeProtobufInboundResult>(
		[inboundBytes],
		(ctx) => {
			for (const bytes of depBatch(ctx, 0) ?? []) {
				const result = wireBridgeProtobufInboundResult(bytes as Uint8Array, bridge.sessionId);
				ctx.down([["DATA", result]]);
			}
		},
		{
			name: `${name}/inboundResults`,
			factory: "wireBridgeProtobufInboundResults",
			partial: true,
			completeWhenDepsComplete: false,
			errorWhenDepsError: false,
		},
	);
	const outboundResults = topology.node<WireBridgeProtobufOutboundResult>(
		[bridge.outbound],
		(ctx) => {
			for (const envelope of depBatch(ctx, 0) ?? []) {
				let result: WireBridgeProtobufOutboundResult;
				try {
					const canonical = canonicalEnvelopeFromSemantic(
						envelope as WireBridgeEnvelope<WireBridgeProtobufData>,
					);
					result = { kind: "encoded", bytes: encodeCanonicalWireBridgeEnvelope(canonical) };
				} catch (error) {
					const issue = protobufIssue("outbound", "encode", error);
					result = { kind: "issue", issue };
				}
				ctx.down([["DATA", result]]);
			}
		},
		{
			name: `${name}/outboundResults`,
			factory: "wireBridgeProtobufOutboundResults",
			partial: true,
			completeWhenDepsComplete: false,
			errorWhenDepsError: false,
		},
	);
	const inboundEvents = topology.node<WireBridgeProtobufInboundEvent>(
		[inboundResults],
		(ctx) => {
			for (const result of depBatch(ctx, 0) ?? []) {
				ctx.down([
					["DATA", { kind: "inbound", result: result as WireBridgeProtobufInboundResult }],
				]);
			}
		},
		{
			name: `${name}/inboundEvents`,
			factory: "wireBridgeProtobufInboundEvents",
			partial: true,
			completeWhenDepsComplete: false,
			errorWhenDepsError: false,
		},
	);
	const outboundEvents = topology.node<WireBridgeProtobufOutboundEvent>(
		[outboundResults],
		(ctx) => {
			for (const result of depBatch(ctx, 0) ?? []) {
				ctx.down([
					["DATA", { kind: "outbound", result: result as WireBridgeProtobufOutboundResult }],
				]);
			}
		},
		{
			name: `${name}/outboundEvents`,
			factory: "wireBridgeProtobufOutboundEvents",
			partial: true,
			completeWhenDepsComplete: false,
			errorWhenDepsError: false,
		},
	);
	const inboundDecoded = topology.node<
		WireBridgeEnvelope<WireBridgeProtobufData> | WireBridgeInvalidIngress
	>(
		[inboundEvents],
		(ctx) => {
			for (const raw of depBatch(ctx, 0) ?? []) {
				const event = raw as WireBridgeProtobufInboundEvent;
				const result = event.result;
				ctx.down([["DATA", result.kind === "decoded" ? result.envelope : result.invalid]]);
			}
		},
		{
			name: `${name}/inboundDecoded`,
			factory: "wireBridgeProtobufInboundDecoded",
			partial: true,
			completeWhenDepsComplete: false,
			errorWhenDepsError: false,
		},
	);
	const outboundBytes = topology.node<Uint8Array>(
		[outboundEvents],
		(ctx) => {
			for (const raw of depBatch(ctx, 0) ?? []) {
				const event = raw as WireBridgeProtobufOutboundEvent;
				if (event.result.kind === "encoded") {
					ctx.down([["DATA", event.result.bytes]]);
				}
			}
		},
		{
			name: `${name}/outboundBytes`,
			factory: "wireBridgeProtobufOutboundBytes",
			partial: true,
			completeWhenDepsComplete: false,
			errorWhenDepsError: false,
		},
	);
	const issues = topology.node<WireBridgeProtobufIssue>(
		[inboundEvents, outboundEvents],
		(ctx) => {
			for (const raw of depBatch(ctx, 0) ?? []) {
				const event = raw as WireBridgeProtobufInboundEvent;
				const result = event.result;
				if (result.kind === "issue") ctx.down([["DATA", result.issue]]);
			}
			for (const raw of depBatch(ctx, 1) ?? []) {
				const event = raw as WireBridgeProtobufOutboundEvent;
				const result = event.result;
				if (result.kind === "issue") ctx.down([["DATA", result.issue]]);
			}
		},
		{
			name: `${name}/issues`,
			factory: "wireBridgeProtobufIssues",
			partial: true,
			completeWhenDepsComplete: false,
			errorWhenDepsError: false,
		},
	);
	const status = topology.node<WireBridgeProtobufStatus>(
		[inboundEvents, outboundEvents],
		(ctx) => {
			let status =
				ctx.state.get<WireBridgeProtobufStatus>() ??
				({ decoded: 0, encoded: 0, issues: 0, state: "idle" } satisfies WireBridgeProtobufStatus);
			const emitStatus = (next: WireBridgeProtobufStatus) => {
				status = next;
				ctx.state.set(status);
				ctx.down([["DATA", status]]);
			};
			for (const raw of depBatch(ctx, 0) ?? []) {
				const event = raw as WireBridgeProtobufInboundEvent;
				const result = event.result;
				if (result.kind === "decoded") {
					emitStatus({
						...status,
						decoded: status.decoded + 1,
						state: status.issues > 0 ? "issues" : "active",
					});
				} else {
					emitStatus({
						...status,
						issues: status.issues + 1,
						state: "issues",
						lastIssue: result.issue,
					});
				}
			}
			for (const raw of depBatch(ctx, 1) ?? []) {
				const event = raw as WireBridgeProtobufOutboundEvent;
				const result = event.result;
				if (result.kind === "encoded") {
					emitStatus({
						...status,
						encoded: status.encoded + 1,
						state: status.issues > 0 ? "issues" : "active",
					});
				} else {
					emitStatus({
						...status,
						issues: status.issues + 1,
						state: "issues",
						lastIssue: result.issue,
					});
				}
			}
		},
		{
			name: `${name}/status`,
			factory: "wireBridgeProtobufStatus",
			partial: true,
			completeWhenDepsComplete: false,
			errorWhenDepsError: false,
		},
	);
	try {
		attachWireBridgeInboundSource(bridge, inboundDecoded);
	} catch (error) {
		topology.release({ reason: `${name}.wireBridgeProtobuf.failedAttach` });
		throw error;
	}
	let released = false;
	return {
		inboundBytes,
		outboundBytes,
		issues,
		status,
		release() {
			if (released) return;
			detachWireBridgeInboundSource(bridge, inboundDecoded);
			try {
				topology.release({ reason: `${name}.wireBridgeProtobuf.release` });
				released = true;
			} catch (error) {
				attachWireBridgeInboundSource(bridge, inboundDecoded);
				throw error;
			}
		},
	};
}

/**
 * Creates a remote responder handler.
 *
 * @param operation - Remote operation descriptor.
 * @param handle - Handle for the remote responder operation.
 * @returns The remote responder handler result.
 * @category adapters
 * @example
 * ```ts
 * import { remoteResponderHandler } from "@graphrefly/ts/adapters";
 * ```
 */
export function remoteResponderHandler<TRequest = unknown, TResponse = unknown>(
	operation: string,
	handle: RemoteResponderHandler<TRequest, TResponse>,
): RemoteResponderHandlerDefinition<TRequest, TResponse> {
	if (operation.length === 0) {
		throw new RangeError("remoteResponderHandler: operation must be non-empty");
	}
	if (typeof handle !== "function") {
		throw new TypeError("remoteResponderHandler: handle must be a function");
	}
	return { operation, handle };
}

/** D147 remote responder over inbound wireBridge request facts and outbound command facts.
 * @param graph - Graph that owns the created nodes or projector.
 * @param bridge - bridge value used by the helper.
 * @param opts - Options that configure the helper.
 * @returns A `RemoteResponderBundle<TRequest, TResponse>` value.
 * @category adapters
 * @example
 * ```ts
 * import { remoteResponder } from "@graphrefly/ts/adapters";
 * ```
 */
export function remoteResponder<TRequest = unknown, TResponse = unknown>(
	graph: Graph,
	bridge: WireBridgeBundle<RemoteCallResponse<TResponse>, RemoteCallRequest<TRequest>>,
	opts: RemoteResponderOptions<TRequest, TResponse> = {},
): RemoteResponderBundle<TRequest, TResponse> {
	const name = opts.name ?? "remoteResponder";
	const handlers = normalizeRemoteHandlers(opts.handlers ?? []);
	const topology = graph.topologyGroup({ name: `${name}.remoteResponder` });
	const events = topology.add(
		remoteResponderEventsNode(
			graph,
			wireBridgeInboundTarget(bridge),
			name,
			bridge.sessionId,
			handlers,
			opts.rejectUnknown === true,
		),
	);
	const responseCommands = topology.add(remoteResponderResponseCommandsNode(graph, events, name));
	const requests = topology.add(remoteResponderRequestsNode(graph, events, name));
	const status = topology.add(remoteResponderStatusNode(graph, events, name));
	const errors = topology.add(remoteResponderErrorsNode(graph, events, name));
	try {
		attachWireBridgeCommandSource(bridge, responseCommands);
	} catch (error) {
		topology.release({ reason: `${name}.remoteResponder.failedAttach` });
		throw error;
	}
	let released = false;
	return {
		events,
		responseCommands,
		requests,
		status,
		errors,
		release() {
			if (released) return;
			detachWireBridgeCommandSource(bridge, responseCommands);
			try {
				topology.release({ reason: `${name}.remoteResponder.release` });
				released = true;
			} catch (error) {
				attachWireBridgeCommandSource(bridge, responseCommands);
				throw error;
			}
		},
	};
}

function wireBridgeEventsNode<TOutbound, TInbound>(
	graph: Graph,
	command: Node<WireBridgeCommand<TOutbound>>,
	inbound: Node<WireBridgeEnvelope<TInbound> | WireBridgeInvalidIngress>,
	name: string,
	opts: WireBridgeOptions,
	policy: RetryPolicy,
): Node<WireBridgeEvent<TOutbound, TInbound>> {
	const now = opts.now ?? Date.now;
	return graph.node<WireBridgeEvent<TOutbound, TInbound>>(
		[command, inbound],
		(ctx) => {
			const state = initBridgeState<TOutbound>(ctx);

			const emitOutbound = (
				type: WireBridgeEnvelopeType,
				payload: WireBridgePayload<TOutbound> | undefined,
				commandOpts: { idempotencyKey?: string; requestId?: string; ackForSeq?: number } = {},
				beforeEmit?: () => void,
			) => {
				if (!isSafePositiveInteger(state.nextSeq)) {
					ctx.down([
						[
							"DATA",
							{
								kind: "invalid",
								error: `${opts.sessionId}: next outbound seq exceeded Number.MAX_SAFE_INTEGER`,
							},
						],
					]);
					return;
				}
				const seq = state.nextSeq;
				let envelope: WireBridgeEnvelope<TOutbound>;
				try {
					const normalizedPayload = normalizeWireBridgePayload(
						payload,
						`wireBridge: outbound ${type} envelope`,
					) as WireBridgePayload<TOutbound> | undefined;
					envelope = wireBridgeEnvelope<TOutbound>({
						sessionId: opts.sessionId,
						type,
						seq,
						cursor: state.cursor,
						payload: normalizedPayload,
						idempotencyKey: commandOpts.idempotencyKey,
						attempt: 1,
						maxAttempts: policy.maxAttempts,
						timestampMs: now(),
						ackForSeq: commandOpts.ackForSeq,
						requestId: commandOpts.requestId,
					});
				} catch (error) {
					ctx.down([
						[
							"DATA",
							{
								kind: "invalid",
								error: error instanceof Error ? error.message : String(error),
							},
						],
					]);
					return;
				}
				state.nextSeq++;
				beforeEmit?.();
				ctx.down([["DATA", { kind: "outbound", envelope }]]);
				if (shouldTrackAck(type)) state.pending.set(envelope.metadata.seq, { envelope });
			};

			for (const raw of depBatch(ctx, 1) ?? []) {
				processInbound(ctx, state, raw, opts.sessionId);
			}
			const inboundTerminal = ctx.terminal[1];
			if (inboundTerminal !== false && inboundTerminal !== undefined && !state.terminalReported) {
				state.terminalReported = true;
				const error =
					inboundTerminal === true
						? `${opts.sessionId}: inbound protocol COMPLETE is local misuse; remote completion must arrive as a DATA envelope fact`
						: `${opts.sessionId}: inbound protocol ERROR ${String(
								errorPayload(inboundTerminal),
							)} is local misuse; remote errors must arrive as DATA envelope facts`;
				ctx.down([["DATA", { kind: "invalid", error }]]);
			}
			for (const raw of depBatch(ctx, 0) ?? []) {
				const invalid = validateCommand(raw);
				if (invalid !== undefined) {
					ctx.down([["DATA", { kind: "invalid", error: invalid }]]);
					continue;
				}
				const commandValue = raw as WireBridgeCommand<TOutbound>;
				switch (commandValue.kind) {
					case "start":
						emitOutbound("start", undefined, commandValue);
						break;
					case "send":
						emitOutbound("data", { kind: "data", value: commandValue.payload }, commandValue);
						break;
					case "ack":
						emitOutbound("ack", undefined, {
							idempotencyKey: commandValue.idempotencyKey,
							requestId: commandValue.requestId,
							ackForSeq: commandValue.ackForSeq,
						});
						break;
					case "nack":
						emitOutbound(
							"nack",
							{ kind: "error", error: errorPayload(commandValue.error) },
							{
								idempotencyKey: commandValue.idempotencyKey,
								requestId: commandValue.requestId,
								ackForSeq: commandValue.ackForSeq,
							},
						);
						break;
					case "ack-timeout":
						processAckTimeoutCommand(ctx, state, commandValue, opts, policy, now);
						break;
					case "close":
						emitOutbound(
							"close",
							commandValue.reason === undefined
								? { kind: "close" }
								: { kind: "close", reason: commandValue.reason },
							commandValue,
							() => {
								state.pending.clear();
							},
						);
						break;
				}
			}
		},
		{
			name: `${name}/events`,
			factory: "wireBridgeEvents",
			partial: true,
			errorWhenDepsError: false,
			completeWhenDepsComplete: false,
			terminalAsRealInput: true,
		},
	);
}

function initBridgeState<TPayload>(ctx: Ctx): BridgeState<TPayload> {
	let state = ctx.state.get<BridgeState<TPayload>>();
	if (state === undefined) {
		state = {
			cleanupInstalled: false,
			nextSeq: 1,
			cursor: 0,
			remoteCursor: 0,
			terminalReported: false,
			pending: new Map(),
		};
		ctx.state.set(state);
	}
	if (!state.cleanupInstalled) {
		state.cleanupInstalled = true;
		ctx.onDeactivation(() => {
			state.cleanupInstalled = false;
			state.pending.clear();
		});
	}
	return state;
}

function attachWireBridgeCommandSource<TOutbound, TInbound>(
	bridge: WireBridgeBundle<TOutbound, TInbound>,
	source: Node<WireBridgeCommand<TOutbound>>,
): void {
	const attached = bridgeCommandSources.get(bridge as WireBridgeBundle<unknown, unknown>);
	if (attached === undefined) {
		throw new Error("remoteResponder: bridge command source registry missing");
	}
	const sources = attached.sources as Node<WireBridgeCommand<TOutbound>>[];
	const previousSources = [...sources];
	if (!sources.includes(source)) sources.push(source);
	try {
		bridge.command.replaceDeps([...sources], wireBridgeCommandSourceFn(sources.length));
	} catch (error) {
		sources.splice(0, sources.length, ...previousSources);
		bridge.command.replaceDeps(
			[...previousSources],
			wireBridgeCommandSourceFn(previousSources.length),
		);
		throw error;
	}
}

function detachWireBridgeCommandSource<TOutbound, TInbound>(
	bridge: WireBridgeBundle<TOutbound, TInbound>,
	source: Node<WireBridgeCommand<TOutbound>>,
): void {
	const attached = bridgeCommandSources.get(bridge as WireBridgeBundle<unknown, unknown>);
	if (attached === undefined) {
		throw new Error("remoteResponder: bridge command source registry missing");
	}
	const sources = attached.sources as Node<WireBridgeCommand<TOutbound>>[];
	if (!sources.includes(source)) return;
	const previousSources = [...sources];
	const nextSources = sources.filter((candidate) => candidate !== source);
	sources.splice(0, sources.length, ...nextSources);
	try {
		bridge.command.replaceDeps([...nextSources], wireBridgeCommandSourceFn(nextSources.length));
	} catch (error) {
		sources.splice(0, sources.length, ...previousSources);
		bridge.command.replaceDeps(
			[...previousSources],
			wireBridgeCommandSourceFn(previousSources.length),
		);
		throw error;
	}
}

function attachWireBridgeInboundSource<TOutbound, TInbound>(
	bridge: WireBridgeBundle<TOutbound, TInbound>,
	source: Node<WireBridgeEnvelope<TInbound> | WireBridgeInvalidIngress>,
): void {
	const attached = bridgeInboundSources.get(bridge as WireBridgeBundle<unknown, unknown>);
	if (attached === undefined) {
		throw new Error("wireBridgeProtobuf: bridge inbound source registry missing");
	}
	const sources = attached.sources as Node<
		WireBridgeEnvelope<TInbound> | WireBridgeInvalidIngress
	>[];
	const previousSources = [...sources];
	if (!sources.includes(source)) sources.push(source);
	try {
		wireBridgeInboundTarget(bridge).replaceDeps(
			[...sources],
			wireBridgeInboundSourceFn(sources.length),
		);
	} catch (error) {
		sources.splice(0, sources.length, ...previousSources);
		wireBridgeInboundTarget(bridge).replaceDeps(
			[...previousSources],
			wireBridgeInboundSourceFn(previousSources.length),
		);
		throw error;
	}
}

function detachWireBridgeInboundSource<TOutbound, TInbound>(
	bridge: WireBridgeBundle<TOutbound, TInbound>,
	source: Node<WireBridgeEnvelope<TInbound> | WireBridgeInvalidIngress>,
): void {
	const attached = bridgeInboundSources.get(bridge as WireBridgeBundle<unknown, unknown>);
	if (attached === undefined) {
		throw new Error("wireBridgeProtobuf: bridge inbound source registry missing");
	}
	const sources = attached.sources as Node<
		WireBridgeEnvelope<TInbound> | WireBridgeInvalidIngress
	>[];
	if (!sources.includes(source)) return;
	const previousSources = [...sources];
	const nextSources = sources.filter((candidate) => candidate !== source);
	sources.splice(0, sources.length, ...nextSources);
	try {
		wireBridgeInboundTarget(bridge).replaceDeps(
			[...nextSources],
			wireBridgeInboundSourceFn(nextSources.length),
		);
	} catch (error) {
		sources.splice(0, sources.length, ...previousSources);
		wireBridgeInboundTarget(bridge).replaceDeps(
			[...previousSources],
			wireBridgeInboundSourceFn(previousSources.length),
		);
		throw error;
	}
}

function wireBridgeInboundTarget<TInbound>(
	bridge: WireBridgeBundle<unknown, TInbound>,
): Node<WireBridgeEnvelope<TInbound> | WireBridgeInvalidIngress> {
	const target = bridgeInboundTargets.get(bridge as WireBridgeBundle<unknown, unknown>);
	if (target === undefined) {
		throw new Error("remoteResponder: bridge inbound target registry missing");
	}
	return target as Node<WireBridgeEnvelope<TInbound> | WireBridgeInvalidIngress>;
}

function wireBridgeCommandSourceFn<TOutbound>(sourceCount: number): (ctx: Ctx) => void {
	return (ctx) => {
		for (let i = 0; i < sourceCount; i += 1) {
			for (const command of depBatch(ctx, i) ?? []) {
				ctx.down([["DATA", command as WireBridgeCommand<TOutbound>]]);
			}
		}
	};
}

function wireBridgeInboundSourceFn<TInbound>(sourceCount: number): (ctx: Ctx) => void {
	return (ctx) => {
		for (let i = 0; i < sourceCount; i += 1) {
			for (const envelope of depBatch(ctx, i) ?? []) {
				ctx.down([["DATA", envelope as WireBridgeEnvelope<TInbound> | WireBridgeInvalidIngress]]);
			}
		}
	};
}

function wireBridgeProtobufInboundResult(
	bytes: Uint8Array,
	sessionId: string,
): WireBridgeProtobufInboundResult {
	try {
		const envelope = semanticEnvelopeFromCanonical(decodeCanonicalWireBridgeEnvelope(bytes));
		return { kind: "decoded", envelope };
	} catch (error) {
		const issue = protobufIssue("inbound", "decode", error);
		return {
			kind: "issue",
			issue,
			invalid: invalidIngress(`${sessionId}: ${issue.message}`),
		};
	}
}

function semanticEnvelopeFromCanonical(
	envelope: CanonicalWireBridgeEnvelope,
): WireBridgeEnvelope<WireBridgeProtobufData> {
	const metadata = semanticMetadataFromCanonical(envelope.metadata);
	switch (envelope.payload.kind) {
		case "start":
			return wireBridgeEnvelope({
				sessionId: envelope.sessionId,
				type: "start",
				seq: metadata.seq,
				cursor: metadata.cursor,
				idempotencyKey: metadata.idempotencyKey,
				attempt: metadata.attempt,
				maxAttempts: metadata.maxAttempts,
				timestampMs: metadata.timestampMs,
				requestId: metadata.requestId,
			});
		case "ack":
			return wireBridgeEnvelope({
				sessionId: envelope.sessionId,
				type: "ack",
				seq: metadata.seq,
				cursor: metadata.cursor,
				idempotencyKey: metadata.idempotencyKey,
				attempt: metadata.attempt,
				maxAttempts: metadata.maxAttempts,
				timestampMs: metadata.timestampMs,
				ackForSeq: metadata.ackForSeq,
				requestId: metadata.requestId,
			});
		case "data":
			return wireBridgeEnvelope({
				sessionId: envelope.sessionId,
				type: "data",
				seq: metadata.seq,
				cursor: metadata.cursor,
				payload: { kind: "data", value: envelope.payload.body },
				idempotencyKey: metadata.idempotencyKey,
				attempt: metadata.attempt,
				maxAttempts: metadata.maxAttempts,
				timestampMs: metadata.timestampMs,
				requestId: metadata.requestId,
			});
		case "nack":
			if (envelope.payload.error === undefined) {
				throw new CanonicalProtobufError(
					"missing_required",
					"semantic wireBridge nack requires error bytes",
				);
			}
			return wireBridgeEnvelope({
				sessionId: envelope.sessionId,
				type: "nack",
				seq: metadata.seq,
				cursor: metadata.cursor,
				payload: { kind: "error", error: envelope.payload.error },
				idempotencyKey: metadata.idempotencyKey,
				attempt: metadata.attempt,
				maxAttempts: metadata.maxAttempts,
				timestampMs: metadata.timestampMs,
				ackForSeq: metadata.ackForSeq,
				requestId: metadata.requestId,
			});
		case "status":
			return wireBridgeEnvelope({
				sessionId: envelope.sessionId,
				type: "status",
				seq: metadata.seq,
				cursor: metadata.cursor,
				payload: { kind: "status", status: envelope.payload.status },
				idempotencyKey: metadata.idempotencyKey,
				attempt: metadata.attempt,
				maxAttempts: metadata.maxAttempts,
				timestampMs: metadata.timestampMs,
				requestId: metadata.requestId,
			});
		case "error":
			return wireBridgeEnvelope({
				sessionId: envelope.sessionId,
				type: "error",
				seq: metadata.seq,
				cursor: metadata.cursor,
				payload: { kind: "error", error: envelope.payload.error },
				idempotencyKey: metadata.idempotencyKey,
				attempt: metadata.attempt,
				maxAttempts: metadata.maxAttempts,
				timestampMs: metadata.timestampMs,
				requestId: metadata.requestId,
			});
		case "close":
			return wireBridgeEnvelope({
				sessionId: envelope.sessionId,
				type: "close",
				seq: metadata.seq,
				cursor: metadata.cursor,
				payload:
					envelope.payload.reason === undefined
						? { kind: "close" }
						: { kind: "close", reason: envelope.payload.reason },
				idempotencyKey: metadata.idempotencyKey,
				attempt: metadata.attempt,
				maxAttempts: metadata.maxAttempts,
				timestampMs: metadata.timestampMs,
				requestId: metadata.requestId,
			});
	}
}

function canonicalEnvelopeFromSemantic(
	envelope: WireBridgeEnvelope<WireBridgeProtobufData>,
): CanonicalWireBridgeEnvelope {
	return {
		sessionId: envelope.sessionId,
		metadata: {
			seq: BigInt(envelope.metadata.seq),
			cursor: BigInt(envelope.metadata.cursor),
			idempotencyKey: envelope.metadata.idempotencyKey,
			attempt: envelope.metadata.attempt,
			maxAttempts: envelope.metadata.maxAttempts,
			timestampMs:
				envelope.metadata.timestampMs === undefined
					? undefined
					: BigInt(envelope.metadata.timestampMs),
			ackForSeq:
				envelope.metadata.ackForSeq === undefined ? undefined : BigInt(envelope.metadata.ackForSeq),
			requestId: envelope.metadata.requestId,
		},
		payload: canonicalPayloadFromSemantic(envelope),
	};
}

function canonicalPayloadFromSemantic(
	envelope: WireBridgeEnvelope<WireBridgeProtobufData>,
): CanonicalWireBridgePayload {
	const payload = envelope.payload;
	switch (envelope.type) {
		case "start":
			return { kind: "start" };
		case "ack":
			return { kind: "ack" };
		case "data":
			if (payload?.kind !== "data") {
				throw new CanonicalProtobufError("missing_required", "data envelope requires data payload");
			}
			return { kind: "data", body: canonicalDataBody(payload.value) };
		case "nack":
			if (payload?.kind !== "error") {
				throw new CanonicalProtobufError(
					"missing_required",
					"nack envelope requires error payload",
				);
			}
			return { kind: "nack", error: requiredBytes(payload.error, "nack error") };
		case "status":
			if (payload?.kind !== "status") {
				throw new CanonicalProtobufError(
					"missing_required",
					"status envelope requires status payload",
				);
			}
			return { kind: "status", status: requiredBytes(payload.status, "status") };
		case "error":
			if (payload?.kind !== "error") {
				throw new CanonicalProtobufError(
					"missing_required",
					"error envelope requires error payload",
				);
			}
			return { kind: "error", error: requiredBytes(payload.error, "error") };
		case "close":
			if (payload?.kind !== "close") {
				throw new CanonicalProtobufError(
					"missing_required",
					"close envelope requires close payload",
				);
			}
			return { kind: "close", reason: optionalBytes(payload.reason, "close reason") };
	}
}

function canonicalDataBody(value: unknown): CanonicalWireBridgeDataBody {
	if (value instanceof Uint8Array) return { kind: "value", value };
	if (
		typeof value === "object" &&
		value !== null &&
		(value as { readonly kind?: unknown }).kind === "value"
	) {
		const bytes = (value as { readonly value?: unknown }).value;
		if (bytes instanceof Uint8Array) return { kind: "value", value: bytes };
	}
	if (
		typeof value === "object" &&
		value !== null &&
		(value as { readonly kind?: unknown }).kind === "wire_edge"
	) {
		const frame = (value as { readonly frame?: unknown }).frame;
		return { kind: "wire_edge", frame: frame as CanonicalWireEdgeFrame };
	}
	throw new CanonicalProtobufError(
		"malformed",
		"wireBridgeProtobuf data payload must be Uint8Array or CanonicalWireBridgeDataBody",
	);
}

function semanticMetadataFromCanonical(metadata: CanonicalWireBridgeMetadata): WireBridgeMetadata {
	return {
		seq: safeSemanticNumber(metadata.seq, "seq"),
		cursor: safeSemanticNumber(metadata.cursor, "cursor"),
		idempotencyKey: metadata.idempotencyKey,
		attempt: metadata.attempt,
		maxAttempts: metadata.maxAttempts,
		timestampMs:
			metadata.timestampMs === undefined
				? undefined
				: safeSemanticNumber(metadata.timestampMs, "timestamp_ms"),
		ackForSeq:
			metadata.ackForSeq === undefined
				? undefined
				: safeSemanticNumber(metadata.ackForSeq, "ack_for_seq"),
		requestId: metadata.requestId,
	};
}

function safeSemanticNumber(value: bigint, field: string): number {
	if (value > BigInt(Number.MAX_SAFE_INTEGER)) {
		throw new CanonicalProtobufError(
			"malformed",
			`${field} exceeds semantic wireBridge Number.MAX_SAFE_INTEGER range`,
		);
	}
	return Number(value);
}

function requiredBytes(value: unknown, field: string): Uint8Array {
	if (value instanceof Uint8Array) return value;
	throw new CanonicalProtobufError("malformed", `wireBridgeProtobuf ${field} must be Uint8Array`);
}

function optionalBytes(value: unknown, field: string): Uint8Array | undefined {
	if (value === undefined) return undefined;
	if (value instanceof Uint8Array) return value;
	throw new CanonicalProtobufError("malformed", `wireBridgeProtobuf ${field} must be Uint8Array`);
}

function protobufIssue(
	direction: WireBridgeProtobufIssue["direction"],
	operation: WireBridgeProtobufIssue["operation"],
	error: unknown,
): WireBridgeProtobufIssue {
	return {
		direction,
		operation,
		message: error instanceof Error ? error.message : String(error),
		category: error instanceof CanonicalProtobufError ? error.category : undefined,
	};
}

function processAckTimeoutCommand<TPayload>(
	ctx: Ctx,
	state: BridgeState<TPayload>,
	command: Extract<WireBridgeCommand<TPayload>, { readonly kind: "ack-timeout" }>,
	opts: WireBridgeOptions,
	policy: RetryPolicy,
	now: () => number,
): void {
	const pending = state.pending.get(command.seq);
	if (pending === undefined || pending.envelope.metadata.attempt !== command.attempt) return;
	const current = pending.envelope;
	const emitRetryOutbound = () => {
		const attempt = current.metadata.attempt + 1;
		const retry = wireBridgeEnvelope<TPayload>({
			sessionId: current.sessionId,
			type: current.type,
			seq: current.metadata.seq,
			cursor: state.cursor,
			payload: current.payload,
			idempotencyKey: current.metadata.idempotencyKey,
			attempt,
			maxAttempts: policy.maxAttempts,
			timestampMs: now(),
			requestId: current.metadata.requestId,
		});
		pending.envelope = retry;
		pending.timeoutReportedAttempt = undefined;
		pending.retryDueAtMs = undefined;
		ctx.down([["DATA", { kind: "outbound", envelope: retry }]]);
	};
	if (pending.timeoutReportedAttempt === current.metadata.attempt) {
		if (
			pending.retryDueAtMs !== undefined &&
			command.observedAtMs !== undefined &&
			command.observedAtMs < pending.retryDueAtMs
		) {
			return;
		}
		emitRetryOutbound();
		return;
	}
	ctx.down([
		[
			"DATA",
			{
				kind: "timeout",
				seq: current.metadata.seq,
				attempt: current.metadata.attempt,
			} satisfies WireBridgeEvent<TPayload, unknown>,
		],
	]);
	if (!shouldRetry(policy, current.metadata.attempt)) {
		const error = `${opts.sessionId}: ack timeout for seq ${current.metadata.seq}`;
		state.pending.delete(current.metadata.seq);
		ctx.down([
			[
				"DATA",
				{
					kind: "exhausted",
					seq: current.metadata.seq,
					attempt: current.metadata.attempt,
					error,
				} satisfies WireBridgeEvent<TPayload, unknown>,
			],
		]);
		return;
	}
	const attempt = current.metadata.attempt + 1;
	const delayMs = nextRetryDelayMs(policy, attempt) ?? 0;
	const error = `${opts.sessionId}: ack timeout for seq ${current.metadata.seq}`;
	pending.timeoutReportedAttempt = current.metadata.attempt;
	if (delayMs > 0 && command.observedAtMs !== undefined) {
		pending.retryDueAtMs = command.observedAtMs + delayMs;
	}
	ctx.down([
		[
			"DATA",
			{
				kind: "retry",
				seq: current.metadata.seq,
				attempt,
				delayMs,
				error,
			} satisfies WireBridgeEvent<TPayload, unknown>,
		],
	]);
	if (pending.retryDueAtMs !== undefined) return;
	emitRetryOutbound();
}

function processInbound<TOutbound, TInbound>(
	ctx: Ctx,
	state: BridgeState<TOutbound>,
	input: unknown,
	sessionId: string,
): void {
	if (isInvalidIngress(input)) {
		ctx.down([["DATA", { kind: "invalid", error: input.error }]]);
		return;
	}
	const invalid = validateInboundEnvelope(input);
	if (invalid !== undefined) {
		ctx.down([["DATA", { kind: "invalid", error: invalid }]]);
		return;
	}
	const envelope = input as WireBridgeEnvelope<TInbound>;
	if (envelope.sessionId !== sessionId) {
		ctx.down([
			[
				"DATA",
				{
					kind: "session-mismatch",
					expected: sessionId,
					actual: envelope.sessionId,
				} satisfies WireBridgeEvent<TOutbound, TInbound>,
			],
		]);
		return;
	}
	const seq = envelope.metadata.seq;
	const expected = state.cursor + 1;
	if (seq <= state.cursor) {
		ctx.down([["DATA", { kind: "duplicate", seq, cursor: state.cursor }]]);
		return;
	}
	if (seq > expected) {
		ctx.down([["DATA", { kind: "out-of-order", seq, expected }]]);
		return;
	}
	if (envelope.metadata.cursor < state.remoteCursor) {
		ctx.down([
			[
				"DATA",
				{
					kind: "invalid",
					error: `${sessionId}: inbound cursor ${envelope.metadata.cursor} regressed below ${state.remoteCursor}`,
				},
			],
		]);
		return;
	}
	state.remoteCursor = envelope.metadata.cursor;
	state.cursor = seq;
	ctx.down([["DATA", { kind: "cursor", cursor: state.cursor }]]);
	ctx.down([["DATA", { kind: "inbound", envelope }]]);
	if (envelope.type === "ack" && envelope.metadata.ackForSeq !== undefined) {
		const pending = state.pending.get(envelope.metadata.ackForSeq);
		if (pending === undefined) {
			ctx.down([
				["DATA", { kind: "late-receipt", receipt: "ack", ackForSeq: envelope.metadata.ackForSeq }],
			]);
			return;
		}
		state.pending.delete(envelope.metadata.ackForSeq);
		ctx.down([
			[
				"DATA",
				{
					kind: "ack",
					ackForSeq: envelope.metadata.ackForSeq,
					envelope,
					outbound: pending.envelope,
				} satisfies WireBridgeEvent<TOutbound, TInbound>,
			],
		]);
	} else if (envelope.type === "nack" && envelope.metadata.ackForSeq !== undefined) {
		const pending = state.pending.get(envelope.metadata.ackForSeq);
		if (pending === undefined) {
			ctx.down([
				["DATA", { kind: "late-receipt", receipt: "nack", ackForSeq: envelope.metadata.ackForSeq }],
			]);
			return;
		}
		state.pending.delete(envelope.metadata.ackForSeq);
		ctx.down([
			[
				"DATA",
				{
					kind: "nack",
					ackForSeq: envelope.metadata.ackForSeq,
					envelope,
					outbound: pending.envelope,
					error: bridgePayloadError(envelope.payload, "remote nack"),
				} satisfies WireBridgeEvent<TOutbound, TInbound>,
			],
		]);
	}
}
