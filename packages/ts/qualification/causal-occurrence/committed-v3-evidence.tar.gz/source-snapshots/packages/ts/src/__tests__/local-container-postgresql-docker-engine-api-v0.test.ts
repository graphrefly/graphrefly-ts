import { describe, expect, it } from "vitest";
import {
	LOCAL_CONTAINER_POSTGRESQL_BACKEND_FAMILY,
	LOCAL_CONTAINER_POSTGRESQL_COMPATIBILITY,
	type LocalContainerPostgresqlManifest,
	localContainerPostgresqlDockerEngineApiV0PreflightReadiness,
	localContainerPostgresqlManifest,
} from "../executors/local-container-postgresql.js";
import {
	certifyDockerEngineApiV0LocalContainerPostgresql,
	type DockerEngineApiV0CertifiedHostMatrixEntry,
	type DockerEngineApiV0ContainmentEvidence,
	type DockerEngineApiV0HostResult,
	type DockerEngineApiV0ImageDigestEvidence,
	type DockerEngineApiV0LocalContainerPostgresqlHost,
	type DockerEngineApiV0NetworkDenialEvidence,
	dockerEngineApiV0CertifiedHostMatrixEntry,
	dockerEngineApiV0LocalContainerPostgresqlDriver,
} from "../executors/local-container-postgresql-docker-engine-api-v0.js";

const digest = `sha256:${"b".repeat(64)}`;
const imageRef = `registry.example.test/graphrefly/postgresql@${digest}`;

const manifest = (): LocalContainerPostgresqlManifest =>
	localContainerPostgresqlManifest({
		kind: "local-container-postgresql-manifest",
		manifestId: "manifest:pg-d624",
		revision: "revision:d624",
		fingerprint: "fingerprint:pg-d624",
		imageDigest: digest,
		engineCompatibilityRevision: LOCAL_CONTAINER_POSTGRESQL_COMPATIBILITY,
		backendFamily: LOCAL_CONTAINER_POSTGRESQL_BACKEND_FAMILY,
		backendCertificationRevision: "docker-certification:d624-v0",
		recipeRevision: "postgresql-read-only-query-v1",
		sandboxRevision: "sandbox:d624",
		mountPolicyRevision: "mount:d624",
		networkPolicyRevision: "network:deny:d624",
		resourcePolicyRevision: "resources:d624",
		stopGraceMs: 5,
		attestationRefs: [{ kind: "attestation", id: "manifest:d624" }],
	});

describe("Docker Engine API v0 local-container PostgreSQL broker (D624)", () => {
	it("certifies ready only after every explicit host proof succeeds", async () => {
		const host = dockerHost();
		const preflight = await certifyDockerEngineApiV0LocalContainerPostgresql({
			manifest: manifest(),
			host,
			imageRef,
			hostPlatform: "darwin/arm64",
			guestPlatform: "linux/arm64",
			runtimeRevision: "docker-desktop:4.27",
			certifiedHostMatrix: certifiedHostMatrix("desktop"),
			vmRuntimeRevision: "docker-desktop-vm:linuxkit:1",
			observedAtMs: 10,
			ttlMs: 100,
			probeLabel: "opaque-probe-label",
		});
		const readiness = localContainerPostgresqlDockerEngineApiV0PreflightReadiness(preflight);

		expect(readiness).toMatchObject({
			state: "ready",
			backendFamilyVerified: true,
			imageDigestVerified: true,
			noEngineSocketMountVerified: true,
			destinationPinnedEgressDenyVerified: true,
			cleanupVerified: true,
		});
		expect(host.calls).toEqual([
			"readVersion",
			"inspectImageDigest",
			"createProbeNetwork",
			"createProbeContainer",
			"inspectProbeContainment",
			"startProbeContainer",
			"waitProbeContainer",
			"verifyProbeNetworkDenials",
			"verifyProbeCancellationAndSecretDestruction",
			"removeProbeContainer",
			"removeProbeNetwork",
		]);
		const visible = JSON.stringify(preflight);
		expect(visible).not.toContain("opaque-probe-binding");
		expect(visible).not.toContain("opaque-network-binding");
		expect(visible).not.toContain("docker.sock");
		expect(visible).not.toContain("registry.example.test");
	});

	it("projects generic host image and network proof to exact public preflight fields", async () => {
		const preflight = await certifyDockerEngineApiV0LocalContainerPostgresql({
			manifest: manifest(),
			host: dockerHost({
				imageDigest: {
					imageDigestPresent: true,
					imageDigestVerified: true,
					rawInspectPayload: { socketPath: "/var/run/docker.sock" },
				},
				networkDenial: {
					...networkDenialEvidence(),
					containerId: "private-container-id",
					engineClientHandle: "private-engine-client",
				},
			}),
			imageRef,
			hostPlatform: "linux/amd64",
			guestPlatform: "linux/amd64",
			runtimeRevision: "docker-engine:24",
			certifiedHostMatrix: certifiedHostMatrix("linux"),
			observedAtMs: 10,
			ttlMs: 100,
		});

		expect(localContainerPostgresqlDockerEngineApiV0PreflightReadiness(preflight)).toMatchObject({
			state: "ready",
			imageDigestPresent: true,
			imageDigestVerified: true,
			destinationPinnedEgressDenyVerified: true,
			cleanupVerified: true,
		});
		const visible = JSON.stringify(preflight);
		expect(visible).not.toContain("rawInspectPayload");
		expect(visible).not.toContain("docker.sock");
		expect(visible).not.toContain("private-container-id");
		expect(visible).not.toContain("private-engine-client");
	});

	it("fails closed for Podman, daemon-only reachability, and each missing network proof", async () => {
		const podman = await certifyDockerEngineApiV0LocalContainerPostgresql({
			manifest: manifest(),
			host: dockerHost({
				version: {
					detectedBackend: "podman",
					engineReachable: true,
					engineApiRevision: "podman-api:4.9",
					engineRevision: "podman:4.9",
				},
			}),
			imageRef,
			hostPlatform: "linux/amd64",
			guestPlatform: "linux/amd64",
			runtimeRevision: "podman:4.9",
			certifiedHostMatrix: certifiedHostMatrix("linux"),
			observedAtMs: 10,
			ttlMs: 100,
		});
		expect(localContainerPostgresqlDockerEngineApiV0PreflightReadiness(podman)).toMatchObject({
			state: "unavailable",
			backendFamilyVerified: false,
		});

		const daemonOnlyHost = dockerHost({ failCall: "createProbeContainer" });
		const daemonOnly = await certifyDockerEngineApiV0LocalContainerPostgresql({
			manifest: manifest(),
			host: daemonOnlyHost,
			imageRef,
			hostPlatform: "linux/amd64",
			guestPlatform: "linux/amd64",
			runtimeRevision: "docker-engine:24",
			certifiedHostMatrix: certifiedHostMatrix("linux"),
			observedAtMs: 10,
			ttlMs: 100,
		});
		expect(localContainerPostgresqlDockerEngineApiV0PreflightReadiness(daemonOnly).state).toBe(
			"unavailable",
		);
		expect(daemonOnlyHost.calls).toContain("removeProbeNetwork");

		for (const field of [
			"destinationPinnedEgressDenyVerified",
			"metadataEgressDenyVerified",
			"linkLocalEgressDenyVerified",
			"loopbackEgressDenyVerified",
			"hostGatewayEgressDenyVerified",
			"dnsRebindingResistanceVerified",
		] as const) {
			const preflight = await certifyDockerEngineApiV0LocalContainerPostgresql({
				manifest: manifest(),
				host: dockerHost({
					networkDenial: { ...networkDenialEvidence(), [field]: false },
				}),
				imageRef,
				hostPlatform: "linux/amd64",
				guestPlatform: "linux/amd64",
				runtimeRevision: "docker-engine:24",
				certifiedHostMatrix: certifiedHostMatrix("linux"),
				observedAtMs: 10,
				ttlMs: 100,
			});
			expect(localContainerPostgresqlDockerEngineApiV0PreflightReadiness(preflight).state).toBe(
				"unavailable",
			);
		}
	});

	it("cleans allocated probe resources after every fail-closed host result", async () => {
		for (const failCall of [
			"createProbeContainer",
			"inspectProbeContainment",
			"startProbeContainer",
			"waitProbeContainer",
			"verifyProbeNetworkDenials",
			"verifyProbeCancellationAndSecretDestruction",
		] as const) {
			const host = dockerHost({ failCall });
			const preflight = await certifyDockerEngineApiV0LocalContainerPostgresql({
				manifest: manifest(),
				host,
				imageRef,
				hostPlatform: "linux/amd64",
				guestPlatform: "linux/amd64",
				runtimeRevision: "docker-engine:24",
				certifiedHostMatrix: certifiedHostMatrix("linux"),
				observedAtMs: 10,
				ttlMs: 100,
			});

			expect(localContainerPostgresqlDockerEngineApiV0PreflightReadiness(preflight).state).toBe(
				"unavailable",
			);
			expect(host.calls).toContain("removeProbeNetwork");
			if (failCall !== "createProbeContainer") expect(host.calls).toContain("removeProbeContainer");
		}
	});

	it("records cleanup evidence when host proof methods throw after allocation", async () => {
		for (const throwCall of [
			"createProbeContainer",
			"inspectProbeContainment",
			"startProbeContainer",
			"waitProbeContainer",
			"verifyProbeNetworkDenials",
			"verifyProbeCancellationAndSecretDestruction",
		] as const) {
			const host = dockerHost({ throwCall });
			const preflight = await certifyDockerEngineApiV0LocalContainerPostgresql({
				manifest: manifest(),
				host,
				imageRef,
				hostPlatform: "linux/amd64",
				guestPlatform: "linux/amd64",
				runtimeRevision: "docker-engine:24",
				certifiedHostMatrix: certifiedHostMatrix("linux"),
				observedAtMs: 10,
				ttlMs: 100,
			});

			const readiness = localContainerPostgresqlDockerEngineApiV0PreflightReadiness(preflight);
			expect(readiness.state, throwCall).toBe("unavailable");
			expect(readiness.cleanupVerified, throwCall).toBe(true);
			expect(readiness.engineReachable, throwCall).toBe(true);
			expect(readiness.imageDigestPresent, throwCall).toBe(true);
			expect(readiness.imageDigestVerified, throwCall).toBe(true);
			if (
				throwCall === "startProbeContainer" ||
				throwCall === "waitProbeContainer" ||
				throwCall === "verifyProbeNetworkDenials" ||
				throwCall === "verifyProbeCancellationAndSecretDestruction"
			) {
				expect(readiness.noEngineSocketMountVerified, throwCall).toBe(true);
				expect(readiness.noHostBindMountVerified, throwCall).toBe(true);
			}
			if (throwCall === "verifyProbeCancellationAndSecretDestruction")
				expect(readiness.destinationPinnedEgressDenyVerified, throwCall).toBe(true);
			expect(host.calls, throwCall).toContain("removeProbeNetwork");
			if (throwCall !== "createProbeContainer")
				expect(host.calls).toContain("removeProbeContainer");
			expect(JSON.stringify(preflight), throwCall).not.toContain("opaque-probe-binding");
			expect(JSON.stringify(preflight), throwCall).not.toContain("opaque-network-binding");
		}
	});

	it("records thrown cleanup as unverifiable after host exception", async () => {
		const host = dockerHost({
			throwCall: "waitProbeContainer",
			throwCleanupCall: "removeProbeContainer",
		});
		const preflight = await certifyDockerEngineApiV0LocalContainerPostgresql({
			manifest: manifest(),
			host,
			imageRef,
			hostPlatform: "linux/amd64",
			guestPlatform: "linux/amd64",
			runtimeRevision: "docker-engine:24",
			certifiedHostMatrix: certifiedHostMatrix("linux"),
			observedAtMs: 10,
			ttlMs: 100,
		});

		const readiness = localContainerPostgresqlDockerEngineApiV0PreflightReadiness(preflight);
		expect(readiness.state).toBe("unavailable");
		expect(readiness.cleanupVerified).toBe(false);
		expect(host.calls).toContain("removeProbeContainer");
		expect(host.calls).toContain("removeProbeNetwork");
	});

	it("rejects root user aliases and records cleanup failure as unavailable", async () => {
		for (const containerUser of ["0", "0:0", "0:65532", "root"]) {
			const preflight = await certifyDockerEngineApiV0LocalContainerPostgresql({
				manifest: manifest(),
				host: dockerHost({
					containment: { ...containmentEvidence(), containerUser },
				}),
				imageRef,
				hostPlatform: "linux/amd64",
				guestPlatform: "linux/amd64",
				runtimeRevision: "docker-engine:24",
				certifiedHostMatrix: certifiedHostMatrix("linux"),
				observedAtMs: 10,
				ttlMs: 100,
			});
			expect(localContainerPostgresqlDockerEngineApiV0PreflightReadiness(preflight).state).toBe(
				"unavailable",
			);
		}

		const host = dockerHost({ removeProbeContainer: { ok: false } });
		const preflight = await certifyDockerEngineApiV0LocalContainerPostgresql({
			manifest: manifest(),
			host,
			imageRef,
			hostPlatform: "linux/amd64",
			guestPlatform: "linux/amd64",
			runtimeRevision: "docker-engine:24",
			certifiedHostMatrix: certifiedHostMatrix("linux"),
			observedAtMs: 10,
			ttlMs: 100,
		});

		const readiness = localContainerPostgresqlDockerEngineApiV0PreflightReadiness(preflight);
		expect(readiness.state).toBe("unavailable");
		expect(readiness.cleanupVerified).toBe(false);
		expect(host.calls).toContain("removeProbeContainer");
		expect(host.calls).toContain("removeProbeNetwork");
	});

	it("maps local-container driver lifecycle through exact host methods without arbitrary create body", async () => {
		const host = dockerHost({ failOnAbortedRunCleanupContext: true });
		const driver = dockerEngineApiV0LocalContainerPostgresqlDriver({
			host,
			imageRef,
		});
		const abortController = new AbortController();
		const context = {
			runId: "run:d624",
			attempt: 1,
			sessionEpoch: "epoch:d624",
			manifestFingerprint: "fingerprint:pg-d624",
			signal: abortController.signal,
		};
		const binding = await driver.create(context, {
			contractVersion: "1",
			source: { id: "source:1", revision: "r:1" },
			sourceProfile: { id: "profile:source", revision: "r:1" },
			queryPlan: { id: "plan:1", revision: "r:1" },
			executorProfile: { id: "profile:executor", revision: "r:1" },
			schemaRef: "schema:1",
		});
		await driver.start(binding, context);
		const result = await driver.wait(binding, context);
		abortController.abort("user-cancel");
		await driver.stop(binding, context, 5);
		await driver.kill(binding, context);
		await driver.remove(binding, context);

		expect(result).toEqual({
			columns: ["answer"],
			rows: [[42]],
			rowCount: 1,
			byteLength: 2,
		});
		expect(host.calls).toEqual([
			"createRunContainer",
			"startRunContainer",
			"waitRunContainer",
			"stopRunContainer",
			"killRunContainer",
			"removeRunContainer",
		]);
		expect(JSON.stringify(result)).not.toContain("opaque-run-binding");
		expect(host.runCreateImageRefs).toEqual([imageRef]);
	});

	it("requires an explicit public certified host matrix before reporting ready", async () => {
		const hostWithoutMatrix = dockerHost();
		const withoutMatrix = await certifyDockerEngineApiV0LocalContainerPostgresql({
			manifest: manifest(),
			host: hostWithoutMatrix,
			imageRef,
			hostPlatform: "linux/amd64",
			guestPlatform: "linux/amd64",
			runtimeRevision: "docker-engine:24",
			certifiedHostMatrix: [],
			observedAtMs: 10,
			ttlMs: 100,
		});
		expect(
			localContainerPostgresqlDockerEngineApiV0PreflightReadiness(withoutMatrix),
		).toMatchObject({
			state: "unavailable",
			hostPlatformVerified: false,
		});
		expect(hostWithoutMatrix.calls).toEqual(["readVersion"]);

		const hostWithPrivateMatrixRef = dockerHost();
		const privateMatrixRef = await certifyDockerEngineApiV0LocalContainerPostgresql({
			manifest: manifest(),
			host: hostWithPrivateMatrixRef,
			imageRef,
			hostPlatform: "linux/amd64",
			guestPlatform: "linux/amd64",
			runtimeRevision: "docker-engine:24",
			certifiedHostMatrix: [
				{
					...certifiedHostMatrix("linux")[0],
					proofRefs: [
						{ kind: "attestation", id: "docker-engine-api-v0:host-matrix:private-socket" },
					],
				},
			],
			observedAtMs: 10,
			ttlMs: 100,
		});
		expect(
			localContainerPostgresqlDockerEngineApiV0PreflightReadiness(privateMatrixRef),
		).toMatchObject({
			state: "unavailable",
			hostPlatformVerified: false,
		});
		expect(JSON.stringify(privateMatrixRef)).not.toContain("private-socket");
		expect(hostWithPrivateMatrixRef.calls).toEqual(["readVersion"]);

		const hostWithDuplicateMatrixRef = dockerHost();
		const duplicateMatrixRef = await certifyDockerEngineApiV0LocalContainerPostgresql({
			manifest: manifest(),
			host: hostWithDuplicateMatrixRef,
			imageRef,
			hostPlatform: "linux/amd64",
			guestPlatform: "linux/amd64",
			runtimeRevision: "docker-engine:24",
			certifiedHostMatrix: [
				{
					...certifiedHostMatrix("linux")[0],
					proofRefs: [
						{ kind: "attestation", id: "docker-engine-api-v0:host-matrix:linux-amd64-v1" },
						{ kind: "attestation", id: "docker-engine-api-v0:host-matrix:linux-amd64-v1" },
					],
				},
			],
			observedAtMs: 10,
			ttlMs: 100,
		});
		expect(
			localContainerPostgresqlDockerEngineApiV0PreflightReadiness(duplicateMatrixRef),
		).toMatchObject({
			state: "unavailable",
			hostPlatformVerified: false,
		});
		expect(hostWithDuplicateMatrixRef.calls).toEqual(["readVersion"]);
	});

	it("normalizes certified host matrix entries through the focused D624 helper", () => {
		const linux = dockerEngineApiV0CertifiedHostMatrixEntry(certifiedHostMatrix("linux")[0]);
		const desktop = dockerEngineApiV0CertifiedHostMatrixEntry(certifiedHostMatrix("desktop")[0]);

		expect(linux).toEqual(certifiedHostMatrix("linux")[0]);
		expect(desktop).toEqual(certifiedHostMatrix("desktop")[0]);
		expect(Object.isFrozen(linux)).toBe(true);
		expect(Object.isFrozen(linux?.proofRefs)).toBe(true);
		expect(JSON.stringify(linux)).not.toMatch(/socket|client|handle|private/u);
		expect(JSON.stringify(desktop)).not.toMatch(/socket|client|handle|private/u);
	});

	it("rejects invalid certified host matrix entries without leaking private material", () => {
		for (const entry of [
			{ ...certifiedHostMatrix("linux")[0], hostPlatform: "linux/docker.sock" },
			{ ...certifiedHostMatrix("linux")[0], guestPlatform: "darwin/arm64" },
			{ ...certifiedHostMatrix("linux")[0], runtimeRevision: "runtime:unavailable" },
			{ ...certifiedHostMatrix("linux")[0], engineApiRevision: "docker-api:socket" },
			{ ...certifiedHostMatrix("linux")[0], engineRevision: "docker-engine:unknown" },
			{
				...certifiedHostMatrix("linux")[0],
				vmRuntimeRevision: "docker-desktop-vm:linuxkit:1",
			},
			{
				...certifiedHostMatrix("desktop")[0],
				vmRuntimeRevision: undefined,
			},
			{
				...certifiedHostMatrix("desktop")[0],
				vmRuntimeRevision: "docker-desktop-vm:private-socket",
			},
			{
				...certifiedHostMatrix("linux")[0],
				proofRefs: [
					{ kind: "attestation", id: "docker-engine-api-v0:host-matrix:linux-amd64-v1" },
					{ kind: "attestation", id: "docker-engine-api-v0:host-matrix:linux-amd64-v1" },
				],
			},
			{
				...certifiedHostMatrix("linux")[0],
				proofRefs: [
					{
						kind: "attestation",
						id: "docker-engine-api-v0:host-matrix:linux-amd64-v1",
						metadata: { socketPath: "/var/run/docker.sock" },
					},
				],
			},
			{
				...certifiedHostMatrix("linux")[0],
				proofRefs: [{ kind: "policy", id: "docker-engine-api-v0:host-matrix:linux-amd64-v1" }],
			},
		] as const) {
			const normalized = dockerEngineApiV0CertifiedHostMatrixEntry(entry);
			expect(normalized, JSON.stringify(entry)).toBeUndefined();
		}
	});

	it("rejects fallback matrix matches when observed coordinates are private or unavailable", async () => {
		for (const scenario of [
			{
				name: "private host platform",
				hostPlatform: "linux/docker.sock",
				guestPlatform: "linux/amd64",
				runtimeRevision: "docker-engine:24",
				version: undefined,
				matrix: [
					{
						...certifiedHostMatrix("linux")[0],
						hostPlatform: "linux/unknown",
					},
				],
			},
			{
				name: "private runtime revision",
				hostPlatform: "linux/amd64",
				guestPlatform: "linux/amd64",
				runtimeRevision: "runtime:docker.sock",
				version: undefined,
				matrix: [
					{
						...certifiedHostMatrix("linux")[0],
						runtimeRevision: "runtime:unavailable",
					},
				],
			},
			{
				name: "private engine api revision",
				hostPlatform: "linux/amd64",
				guestPlatform: "linux/amd64",
				runtimeRevision: "docker-engine:24",
				version: {
					detectedBackend: "docker-engine",
					engineReachable: true,
					engineApiRevision: "docker-api:socket",
					engineRevision: "docker-engine:24.0.7",
				},
				matrix: [
					{
						...certifiedHostMatrix("linux")[0],
						engineApiRevision: "docker-api:unavailable",
					},
				],
			},
			{
				name: "private engine revision",
				hostPlatform: "linux/amd64",
				guestPlatform: "linux/amd64",
				runtimeRevision: "docker-engine:24",
				version: {
					detectedBackend: "docker-engine",
					engineReachable: true,
					engineApiRevision: "docker-api:1.44",
					engineRevision: "docker-engine:docker.sock",
				},
				matrix: [
					{
						...certifiedHostMatrix("linux")[0],
						engineRevision: "docker-engine:unavailable",
					},
				],
			},
		] as const) {
			const host = dockerHost({ version: scenario.version });
			const preflight = await certifyDockerEngineApiV0LocalContainerPostgresql({
				manifest: manifest(),
				host,
				imageRef,
				hostPlatform: scenario.hostPlatform,
				guestPlatform: scenario.guestPlatform,
				runtimeRevision: scenario.runtimeRevision,
				certifiedHostMatrix: scenario.matrix,
				observedAtMs: 10,
				ttlMs: 100,
			});

			expect(
				localContainerPostgresqlDockerEngineApiV0PreflightReadiness(preflight).state,
				scenario.name,
			).toBe("unavailable");
			expect(host.calls, scenario.name).toEqual(["readVersion"]);
			expect(JSON.stringify(preflight), scenario.name).not.toMatch(/docker\.sock|socket/u);
		}
	});

	it("rejects Linux host matrix matches when callers supply a VM runtime revision", async () => {
		const host = dockerHost();
		const preflight = await certifyDockerEngineApiV0LocalContainerPostgresql({
			manifest: manifest(),
			host,
			imageRef,
			hostPlatform: "linux/amd64",
			guestPlatform: "linux/amd64",
			runtimeRevision: "docker-engine:24",
			certifiedHostMatrix: certifiedHostMatrix("linux"),
			vmRuntimeRevision: "docker-desktop-vm:linuxkit:1",
			observedAtMs: 10,
			ttlMs: 100,
		});

		expect(localContainerPostgresqlDockerEngineApiV0PreflightReadiness(preflight)).toMatchObject({
			state: "unavailable",
			hostPlatformVerified: false,
		});
		expect(host.calls).toEqual(["readVersion"]);
	});

	it("rejects desktop host matrix matches when the required VM runtime coordinate is missing or private", async () => {
		for (const scenario of [
			{
				name: "missing vm runtime revision",
				vmRuntimeRevision: undefined,
			},
			{
				name: "private vm runtime revision",
				vmRuntimeRevision: "docker-desktop-vm:private-socket",
			},
		] as const) {
			const host = dockerHost();
			const preflight = await certifyDockerEngineApiV0LocalContainerPostgresql({
				manifest: manifest(),
				host,
				imageRef,
				hostPlatform: "darwin/arm64",
				guestPlatform: "linux/arm64",
				runtimeRevision: "docker-desktop:4.27",
				certifiedHostMatrix: certifiedHostMatrix("desktop"),
				...(scenario.vmRuntimeRevision === undefined
					? {}
					: { vmRuntimeRevision: scenario.vmRuntimeRevision }),
				observedAtMs: 10,
				ttlMs: 100,
			});

			expect(
				localContainerPostgresqlDockerEngineApiV0PreflightReadiness(preflight).state,
				scenario.name,
			).toBe("unavailable");
			expect(host.calls, scenario.name).toEqual(["readVersion"]);
			expect(JSON.stringify(preflight), scenario.name).not.toMatch(/private-socket/u);
		}
	});
});

function certifiedHostMatrix(
	kind: "desktop" | "linux",
): readonly DockerEngineApiV0CertifiedHostMatrixEntry[] {
	return [
		kind === "desktop"
			? {
					hostPlatform: "darwin/arm64",
					guestPlatform: "linux/arm64",
					runtimeRevision: "docker-desktop:4.27",
					engineApiRevision: "docker-api:1.44",
					engineRevision: "docker-engine:24.0.7",
					vmRuntimeRevision: "docker-desktop-vm:linuxkit:1",
					proofRefs: [
						{ kind: "attestation", id: "docker-engine-api-v0:host-matrix:desktop-arm64-v1" },
					],
				}
			: {
					hostPlatform: "linux/amd64",
					guestPlatform: "linux/amd64",
					runtimeRevision: "docker-engine:24",
					engineApiRevision: "docker-api:1.44",
					engineRevision: "docker-engine:24.0.7",
					proofRefs: [
						{ kind: "attestation", id: "docker-engine-api-v0:host-matrix:linux-amd64-v1" },
					],
				},
	];
}

function dockerHost(
	opts: {
		readonly version?: DockerEngineApiV0HostResultParameters["version"];
		readonly imageDigest?: DockerEngineApiV0ImageDigestEvidence & Record<string, unknown>;
		readonly containment?: DockerEngineApiV0ContainmentEvidence;
		readonly networkDenial?: DockerEngineApiV0NetworkDenialEvidence & Record<string, unknown>;
		readonly failCall?:
			| "createProbeContainer"
			| "inspectProbeContainment"
			| "startProbeContainer"
			| "waitProbeContainer"
			| "verifyProbeNetworkDenials"
			| "verifyProbeCancellationAndSecretDestruction";
		readonly throwCall?:
			| "createProbeContainer"
			| "inspectProbeContainment"
			| "startProbeContainer"
			| "waitProbeContainer"
			| "verifyProbeNetworkDenials"
			| "verifyProbeCancellationAndSecretDestruction";
		readonly throwCleanupCall?: "removeProbeContainer" | "removeProbeNetwork";
		readonly removeProbeContainer?: DockerEngineApiV0HostResult<void>;
		readonly failOnAbortedRunCleanupContext?: boolean;
	} = {},
): DockerEngineApiV0LocalContainerPostgresqlHost & {
	readonly calls: string[];
	readonly runCreateImageRefs: string[];
} {
	const calls: string[] = [];
	const runCreateImageRefs: string[] = [];
	return {
		calls,
		runCreateImageRefs,
		readVersion: () => {
			calls.push("readVersion");
			return ok(
				opts.version ?? {
					detectedBackend: "docker-engine",
					engineReachable: true,
					engineApiRevision: "docker-api:1.44",
					engineRevision: "docker-engine:24.0.7",
				},
			);
		},
		inspectImageDigest: () => {
			calls.push("inspectImageDigest");
			return ok(opts.imageDigest ?? { imageDigestPresent: true, imageDigestVerified: true });
		},
		createProbeNetwork: () => {
			calls.push("createProbeNetwork");
			return ok({ opaqueNetworkBinding: "opaque-network-binding" });
		},
		createProbeContainer: () => {
			calls.push("createProbeContainer");
			if (opts.throwCall === "createProbeContainer")
				throw new Error("D624 create probe container threw");
			return opts.failCall === "createProbeContainer"
				? ({ ok: false } as const)
				: ok({ opaqueProbeBinding: "opaque-probe-binding" });
		},
		inspectProbeContainment: () => {
			calls.push("inspectProbeContainment");
			if (opts.throwCall === "inspectProbeContainment")
				throw new Error("D624 inspect probe containment threw");
			return opts.failCall === "inspectProbeContainment"
				? ({ ok: false } as const)
				: ok(opts.containment ?? containmentEvidence());
		},
		startProbeContainer: () => {
			calls.push("startProbeContainer");
			if (opts.throwCall === "startProbeContainer")
				throw new Error("D624 start probe container threw");
			return opts.failCall === "startProbeContainer" ? ({ ok: false } as const) : ok(undefined);
		},
		waitProbeContainer: () => {
			calls.push("waitProbeContainer");
			if (opts.throwCall === "waitProbeContainer")
				throw new Error("D624 wait probe container threw");
			return opts.failCall === "waitProbeContainer" ? ({ ok: false } as const) : ok(undefined);
		},
		verifyProbeNetworkDenials: () => {
			calls.push("verifyProbeNetworkDenials");
			if (opts.throwCall === "verifyProbeNetworkDenials")
				throw new Error("D624 verify probe network denials threw");
			return opts.failCall === "verifyProbeNetworkDenials"
				? ({ ok: false } as const)
				: ok(opts.networkDenial ?? networkDenialEvidence());
		},
		verifyProbeCancellationAndSecretDestruction: () => {
			calls.push("verifyProbeCancellationAndSecretDestruction");
			if (opts.throwCall === "verifyProbeCancellationAndSecretDestruction")
				throw new Error("D624 verify probe cancellation and secret destruction threw");
			if (opts.failCall === "verifyProbeCancellationAndSecretDestruction")
				return { ok: false } as const;
			return ok({
				cancellationVerified: true,
				cleanupVerified: true,
				artifactResolverReady: true,
				credentialResolverReady: true,
				secretDestructionVerified: true,
			});
		},
		removeProbeContainer: () => {
			calls.push("removeProbeContainer");
			if (opts.throwCleanupCall === "removeProbeContainer")
				throw new Error("D624 remove probe container threw");
			return opts.removeProbeContainer ?? ok(undefined);
		},
		removeProbeNetwork: () => {
			calls.push("removeProbeNetwork");
			if (opts.throwCleanupCall === "removeProbeNetwork")
				throw new Error("D624 remove probe network threw");
			return ok(undefined);
		},
		createRunContainer: ({ imageRef: nextImageRef }) => {
			calls.push("createRunContainer");
			runCreateImageRefs.push(nextImageRef);
			return ok({ opaqueRunBinding: "opaque-run-binding" });
		},
		startRunContainer: () => {
			calls.push("startRunContainer");
			return ok(undefined);
		},
		waitRunContainer: () => {
			calls.push("waitRunContainer");
			return ok({
				columns: ["answer"],
				rows: [[42]],
				rowCount: 1,
				byteLength: 2,
			});
		},
		stopRunContainer: (_binding, context) => {
			calls.push("stopRunContainer");
			if (opts.failOnAbortedRunCleanupContext && context.signal.aborted) return { ok: false };
			return ok(undefined);
		},
		killRunContainer: (_binding, context) => {
			calls.push("killRunContainer");
			if (opts.failOnAbortedRunCleanupContext && context.signal.aborted) return { ok: false };
			return ok(undefined);
		},
		removeRunContainer: (_binding, context) => {
			calls.push("removeRunContainer");
			if (opts.failOnAbortedRunCleanupContext && context.signal.aborted) return { ok: false };
			return ok(undefined);
		},
	};
}

interface DockerEngineApiV0HostResultParameters {
	readonly version: {
		readonly detectedBackend: "docker-engine" | "podman" | "unknown" | "unavailable";
		readonly engineReachable: boolean;
		readonly engineApiRevision: string;
		readonly engineRevision: string;
	};
}

function containmentEvidence(): DockerEngineApiV0ContainmentEvidence {
	return {
		isolationVerified: true,
		containerUser: "65532:65532",
		noNewPrivilegesVerified: true,
		readOnlyRootFilesystemVerified: true,
		boundedFilesystemImportVerified: true,
		noEngineSocketMountVerified: true,
		noHostNetworkVerified: true,
		noHostBindMountVerified: true,
		cpuMemoryPidsTimeBoundsVerified: true,
	};
}

function networkDenialEvidence(): DockerEngineApiV0NetworkDenialEvidence {
	return {
		destinationPinnedEgressDenyVerified: true,
		metadataEgressDenyVerified: true,
		linkLocalEgressDenyVerified: true,
		loopbackEgressDenyVerified: true,
		hostGatewayEgressDenyVerified: true,
		dnsRebindingResistanceVerified: true,
	};
}

function ok<T>(value: T): DockerEngineApiV0HostResult<T> {
	return { ok: true, value };
}
