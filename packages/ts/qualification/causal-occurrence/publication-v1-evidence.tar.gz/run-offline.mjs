import {spawnSync} from 'node:child_process';
import {readFileSync,writeFileSync,cpSync} from 'node:fs';
import {dirname,join} from 'node:path';
import {fileURLToPath} from 'node:url';
const dir=dirname(fileURLToPath(import.meta.url));
const root='/Users/davidchenallio/src/graphrefly-ts';
const checks=[];let keepBinding=false;let phase="pre";
function check(id,command){const r=spawnSync(process.execPath,[join(dir,'run-check.mjs'),id,...command],{cwd:root,stdio:'inherit'});const binding=r.status===0?spawnSync('python3',[join(dir,'verify-bindings.py'),phase,id],{cwd:root,stdio:'inherit'}):null;checks.push({id,exitCode:r.status,signal:r.signal,bindingExitCode:binding?.status});return r.status===0&&binding?.status===0;}
try {
 if(!check('c-performance',['node','scripts/compare-causal-construction.mjs','--output',join(dir,'c-performance.json')]))throw Error('original C performance qualification failed; retain before wider currentness refresh');
 if(!check('c-performance-verify',['python3',join(dir,'verify-c-performance.py')]))throw Error('original C raw statistics/budgets failed before currentness refresh');
 const refresh=spawnSync('python3',[join(dir,'refresh-manifest.py')],{cwd:root,stdio:'inherit'});if(refresh.status!==0)throw Error('manifest refresh failed');
 const binding=spawnSync('python3',[join(dir,'verify-bindings.py'),'snapshot-refresh'],{cwd:root,stdio:'inherit'});if(binding.status!==0)throw Error('unapproved refresh delta');phase='post';
 if(!check('root-soak',['pnpm','run','test:root-eval-soak']))throw Error('full soak failed');
 for(const row of JSON.parse(readFileSync(join(dir,'remaining-checks.json'))))if(!check(row.id,row.command))throw Error(row.id+' failed');
 if(!check('closure',['pnpm','exec','tsx',join(dir,'measure-closure.mts'),join(dir,'final-closure.json')]))throw Error('closure binding failed');
 keepBinding=true;
} catch(error) { console.log('OFFLINE_QUALIFICATION_FAILED',String(error)); }
finally {
 if(!keepBinding){const before=join(dir,'before-current-binding'),evalRoot=join(root,'packages/ts/evals/graph-native-rerun-avoidance');cpSync(join(before,'implementation-manifest.ts'),join(evalRoot,'implementation-manifest.ts'));cpSync(join(before,'artifacts'),join(evalRoot,'artifacts'),{recursive:true});}
 writeFileSync(join(dir,'offline-sequence.json'),JSON.stringify({checks,passed:keepBinding,currentBindingKept:keepBinding},null,2)+'\n');
 console.log('OFFLINE_QUALIFICATION_DONE',keepBinding);process.exitCode=keepBinding?0:1;
}
