from pathlib import Path
import json,hashlib,sys
q=Path(__file__).parent;root=Path('/Users/davidchenallio/src/graphrefly-ts')
sha=lambda p:'sha256:'+hashlib.sha256(p.read_bytes()).hexdigest()
def read(name):return json.loads((q/name).read_text())
def snapshot():
 return {str(p.relative_to(root)):sha(p) for d in ['packages/ts/src','examples/spending-alerts','scripts','docs/design','packages/ts/evals/graph-native-rerun-avoidance'] for p in (root/d).rglob('*') if p.is_file()}
def verify(name,expected):
 c=read(name+'.check.json');b=read(name+'.bindings.json')
 assert c['exitCode']==0 and c['sourceUnchanged'] and not c['changed'],name
 assert sha(q/(name+'.log'))==c['logDigest'],name+' log'
 assert b['before']==b['after']==expected,name+' source identity'
 return c
base=read('final-lint.bindings.json')['after']
freeze=read('performance-freeze-v2.json')
assert all(base.get(p)==v for p,v in freeze['sources'].items()),'freeze closure'
mode=sys.argv[1]
if mode=='publication':
 for name in ['publication-performance-v2','publication-differential-v2','publication-mutations-v4','focused-final','final-lint']:verify(name,base)
 assert read('performance-v2.json.manifest.json')==freeze
 assert snapshot()==base,'current source changed'
elif mode=='snapshot-refresh':
 current=snapshot();prefix='packages/ts/evals/graph-native-rerun-avoidance/'
 delta=[p for p in base.keys()|current.keys() if base.get(p)!=current.get(p)]
 assert all(p==prefix+'implementation-manifest.ts' or p.startswith(prefix+'artifacts/') for p in delta),delta
 out=q/'after-current-binding.json';assert not out.exists()
 out.write_text(json.dumps({'files':current,'allowedChanges':delta},indent=2)+'\n')
elif mode in ['pre','post']:
 expected=base if mode=='pre' else read('after-current-binding.json')['files']
 verify(sys.argv[2],expected)
 assert snapshot()==expected,'current source changed'
else:raise AssertionError(mode)
print('SOURCE_IDENTITIES_VERIFIED',mode)
