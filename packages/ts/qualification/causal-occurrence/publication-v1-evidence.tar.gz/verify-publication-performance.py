from pathlib import Path
import json,math,hashlib,itertools,subprocess
subprocess.run(['python3',str(Path(__file__).parent/'verify-bindings.py'),'publication'],check=True)
q=Path(__file__).parent
r=json.loads((q/'performance-v2.json').read_text())
assert r['complete'] and not r['checkOnly'] and not r['failures']
percentile=lambda a,p: sorted(a)[max(0,math.ceil(len(a)*p)-1)]
median=lambda a:percentile(a,.5)
def verify_stats(s,n):
 a=s['samples'];assert len(a)==n and all(math.isfinite(x) and x>=0 for x in a)
 assert s['p50Ns']==percentile(a,.5) and s['p95Ns']==percentile(a,.95)
 return a
profiles=set(itertools.product([1,16,64],[0,1024,8192],[False,True]))
assert {(x['count'],x['bytes'],x['observe']) for x in r['construction']}==profiles and len(r['construction'])==18
for x in r['construction']:
 a=verify_stats(x['production'],900);b=verify_stats(x['reference'],900)
 assert len(x['batches'])==3
 assert a==sum((z['production'] for z in x['batches']),[]) and b==sum((z['reference'] for z in x['batches']),[])
 assert all(len(z[k])==300 for z in x['batches'] for k in ['production','reference'])
 assert x['ratio']==percentile(a,.95)/percentile(b,.95) and x['ratio']<=1.20 and x['passed']
assert {(x['count'],x['bytes'],x['observe'],x['rate'],x['messageCount']) for x in r['steady']}=={p+(rate,m) for p in profiles for rate in [0,1,100] for m in [1,2]} and len(r['steady'])==108
for x in r['steady']:
 assert [b['order'] for b in x['batches']]==['AB','BA','AB']
 for b in x['batches']:
  for arm in ['production','reference','plain']:verify_stats(b[arm],300)
  assert b['actualChanges']==x['rate']*3 and b['actualChangePercent']==x['rate']
  assert b['ratio']==b['production']['p95Ns']/b['reference']['p95Ns']
 ratio=median([b['production']['p95Ns'] for b in x['batches']])/median([b['reference']['p95Ns'] for b in x['batches']])
 assert x['ratio']==ratio and ratio<=1.10 and x['passed']
assert {(x['count'],x['bytes'],x['observe'],x['first']) for x in r['recovery']}=={p+(first,) for p in profiles for first in [False,True]} and len(r['recovery'])==36
for x in r['recovery']:
 for arm in ['production','reference']:verify_stats(x['cold'][arm],900)
 for arm in ['production','reference','plain']:verify_stats(x['reconnections'][arm],20)
 z=x['resources'];assert z['nodes']==26 and z['roots']==2 and z['extraRetainedRoots']==0
 assert z['indexSize']=={'production':x['count'],'reference':x['count']} and z['frameBytes']<=1048576 and z['indexLimit']==64
assert len(r['checks'])==18
for x in r['checks']:
 assert x['actual']==x['expected'] and len(x['committed']['effects'])==x['count']
 assert len(x['actual']['rows'])==x['count'] and all(row['material']=='matched' and row['recorded']=='admitted-no-outcome' for row in x['actual']['rows'])
 if x['bytes']:
  assert all(len(m['body']['payloadText'].encode())==x['bytes'] for frame in x['inputs'] for m in frame['body']['materials'])
sha=lambda p:'sha256:'+hashlib.sha256(p.read_bytes()).hexdigest()
freeze=json.loads((q/'performance-freeze-v2.json').read_text());assert sha(q/'performance-v2.json.bundle.mjs')==freeze['bundleDigest']
for name in ['publication-performance-v2','publication-differential-v2','publication-mutations-v4','focused-final','final-lint']:
 c=json.loads((q/(name+'.check.json')).read_text());assert c['exitCode']==0 and c['sourceUnchanged']
 assert sha(q/(name+'.log'))==c['logDigest']
summary={'passed':True,'reportDigest':sha(q/'performance-v2.json'),'constructionRows':18,'steadyRows':108,'recoveryRows':36,'coldRecoverySamplesPerArm':32400,'constructionSamplesPerArm':16200,'steadySamplesPerArm':97200,'reconnectionsPerArm':720,'constructionMaxRatio':max(x['ratio'] for x in r['construction']),'steadyMaxRatio':max(x['ratio'] for x in r['steady']),'noHostOrAudienceQualification':True}
(q/'publication-performance-verification.json').write_text(json.dumps(summary,indent=2)+'\n')
print('PUBLICATION_PERFORMANCE_VERIFIED',summary)
