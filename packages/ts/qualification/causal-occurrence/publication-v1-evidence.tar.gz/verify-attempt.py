from pathlib import Path
import json,hashlib
root=Path('/Users/davidchenallio/src/graphrefly-ts');out=Path(__file__).parent
src=root/'packages/ts/src'
sha=lambda b:'sha256:'+hashlib.sha256(b).hexdigest()
read=lambda n:json.loads((out/n).read_text())
source={str(p.relative_to(root)):sha(p.read_bytes()) for p in (root/'packages/ts/src').rglob('*') if p.is_file()}
checks=[]
import subprocess
required=[x['id'] for x in read('remaining-checks.json')]+['root-soak','closure']
for name in required:
 subprocess.run(['python3',str(out/'verify-bindings.py'),'post',name],check=True)
 checks.append(read(name+'.check.json'))
for name in ['c-performance','c-performance-verify','publication-performance-v2','publication-differential-v2','publication-mutations-v4','focused-final','final-lint']:
 c=read(name+'.check.json');b=read(name+'.bindings.json')
 assert c['exitCode']==0 and c['sourceUnchanged'] and not c['changed'] and c['signal'] is None,name
 assert b['before']==b['after']==read('final-lint.bindings.json')['after'],name
 assert sha((out/(name+'.log')).read_bytes())==c['logDigest']
 checks.append(c)
assert '2367 passed | 4 skipped (2371)' in (out/'full-test.log').read_text()
assert '221 passed (221)' in (out/'root-soak.log').read_text()
for name,n in [('causal-mutations',73),('construction-mutations',25),('cold-mutations',16),('view-mutations',11)]:
 r=read(name+'.json');assert r['complete'] and len(r['mutations'])==n
 assert all(m['outcome'] in ['killed','detected'] for m in r['mutations'])
identities=read('report-identities-verification.json');assert identities['passed']
for name,h in identities['reportDigests'].items():assert sha((out/name).read_bytes())==h,name
oracle=read('view-oracle.json');assert oracle['passed']
assert len(oracle['results'])==2 and {a['instrumented'] for a in oracle['results']}=={False,True}
for arm in oracle['results']:
 assert len(arm['comparisons'])==12 and arm['hotOrders']==2 and len(arm['measures'])==33
 for c in arm['comparisons']:
  for checkpoint in c['checkpoints']:assert checkpoint['actual']==checkpoint['expected']
 for m in arm['measures']:
  assert m['reconnections']==20 and m['actualPhaseChangePercent']==m['rate']
  assert m['viewBuilds']==(m['accepted'] if arm['instrumented'] else None)
  assert len(m['samples'])==m['total']
  assert m['medianNs']==sorted(m['samples'])[len(m['samples'])//2]
for n in ['frozen-standalone','qualified-standalone']:
 r=read(n+'.json');assert len(r['comparisons'])==6 and all(c['matched'] for c in r['comparisons'])
 for c in r['comparisons']:
  assert c['baseline']==c['candidate'] and c['baselinePhase']==c['candidatePhase']
 fault=r['startupFault'];a=fault['baseline'];b=fault['candidate']
 assert fault['matched'] and a['events']==b['events'] and a['phase']==b['phase']=='faulted'
 added={'id':'causal/committed-effects','factory':'causalCommittedEffectsProjection','deps':['causal/authority']}
 assert [z for z in b['shape'] if z['id']=='causal/committed-effects']==[added]
 assert [z for z in a['shape'] if z['id']!='causal/committed-effects']==[z for z in b['shape'] if z['id']!='causal/committed-effects']
 if n=='qualified-standalone':assert [z for z in a['shape'] if z['id']=='causal/committed-effects']==[added]
publication=read('mutations-v4.json')
assert publication['complete'] and len(publication['results'])==14
assert publication['results'][0]['id']=='unchanged' and publication['results'][0]['outcome']=='passed' and publication['results'][0]['checks']==111
assert all(m['outcome']=='detected' and any('AssertionError' in f['reason'] for f in m['failed']) for m in publication['results'][1:])
for mutation in publication['results']:
 folder=out/'mutations-v4.json.artifacts';name=mutation['id']
 assert sha((folder/(name+'.ts')).read_bytes())==mutation['loadedDigest'],name
 assert sha((folder/(name+'.result.json')).read_bytes())==mutation['resultDigest'],name
 raw=json.loads((folder/(name+'.result.json')).read_text())
 assertions=[a for suite in raw['testResults'] for a in suite['assertionResults'] if a['status'] in ['passed','failed']]
 failures=[{'name':a['fullName'],'reason':'\n'.join(a['failureMessages'])} for a in assertions if a['status']=='failed']
 assert len(assertions)==mutation['checks'] and failures==mutation['failed'],name
 assert raw['success']==(name=='unchanged'),name
assert publication['sourceDigest']==sha((root/'examples/spending-alerts/causal-publication.ts').read_bytes())
assert publication['testDigest']==sha((src/'__tests__/spending-alerts-causal-publication.test.ts').read_bytes())
assert publication['runnerDigest']==sha((root/'scripts/qualify-spending-publication.mjs').read_bytes())
for verification,report in [('publication-performance-verification.json','performance-v2.json'),('c-performance-verification.json','c-performance.json')]:
 v=read(verification);assert v['passed'] and v['reportDigest']==sha((out/report).read_bytes())
for name in ['mutations-v4.json','performance-v2.json','c-performance.json','publication-performance-verification.json','c-performance-verification.json','performance-freeze-v2.json','performance-v2.json.bundle.mjs','performance-v2.json.manifest.json']:
 identities['reportDigests'][name]=sha((out/name).read_bytes())
assert read('offline-sequence.json')['passed'] and read('offline-sequence.json')['currentBindingKept']
result={'verified':True,'qualificationPassed':True,'sourceFiles':len(source),'sourceDigests':source,'checks':checks,'sourceUnchangedDuringChecks':True,'qualificationBindings':read('final-closure.json'),'reportDigests':identities['reportDigests'],'priorFailuresPreserved':True,'performance':read('publication-performance-verification.json'),'originalC':read('c-performance-verification.json'),'nonClaims':['No provider/live/spend or downstream authorization','No complete audience hiding/preset/current dispatch guard/inbox qualification']}
(out/'attempt-verification.json').write_text(json.dumps(result,indent=2)+'\n')
print('ATTEMPT_VERIFIED',len(checks),'checks',len(source),'source files')
