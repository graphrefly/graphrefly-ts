import {readFileSync} from 'node:fs';
import {spawnSync} from 'node:child_process';
import {dirname,join} from 'node:path';
import {fileURLToPath} from 'node:url';
const dir=dirname(fileURLToPath(import.meta.url));
const soak=JSON.parse(readFileSync(join(dir,'root-soak.check.json')));
if(soak.exitCode!==0||!soak.sourceUnchanged)throw new Error('complete soak must pass before qualification continues');
for(const {id,command} of JSON.parse(readFileSync(join(dir,'remaining-checks.json')))){
 const r=spawnSync(process.execPath,[join(dir,'run-check.mjs'),id,...command],{stdio:'inherit'});
 if(r.status!==0){console.log('REMAINING_CHECKS_STOPPED '+id);process.exit(r.status??1);}
}
console.log('REMAINING_CHECKS_DONE');
