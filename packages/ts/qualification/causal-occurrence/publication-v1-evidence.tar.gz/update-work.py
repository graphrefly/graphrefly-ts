from pathlib import Path
import hashlib,json,sys
root=Path('/Users/davidchenallio/src/graphrefly-ts');p=root/'plan/work.jsonl';prefix='packages/ts/qualification/causal-occurrence/publication-v1'
receipt=json.loads((root/(prefix+'-receipt.json')).read_text());qualified=receipt['status']=='qualified';assert qualified==receipt['verification']['qualificationPassed']
rows=p.read_text().splitlines();found=0
for i,line in enumerate(rows):
 w=json.loads(line)
 if w.get('id')!='CAUSAL-PUBLICATION-MATERIAL-TS':continue
 found+=1;assert w['owner']=='graphrefly-ts' and w['status']=='planned'
 for suffix in ['-receipt.json','-review.md']:
  ref=prefix+suffix;assert all(e['ref']!=ref for e in w['evidence_refs'])
  w['evidence_refs'].append({'ref':ref,'digest':'sha256:'+hashlib.sha256((root/ref).read_bytes()).hexdigest()})
 if qualified:
  w['status']='complete';w['produces']=[{'artifact_ref':'graphrefly-ts:causal-publication-material-evidence','schema':'graphrefly-ts/causal-publication-material-evidence/v1','revision':'publication-v1'}]
  w['note']+=' 2026-09-09 same approved slice qualified: approved typecheck prerequisite, independent oracle/plain/reference,110 publication tests/146 focused,13 actual loadable publication mutants. Publication v1 timing failed7steady rows and timed out incomplete; retained without GC attribution. Bounded frozen-flat-binding validation reuse fixed repeated work; mutable/new/accessor/identity/dependency negatives retained. Reference/oracle/harness/protocol unchanged, v2 completed18construction/108steady/36cold-recovery profiles with independently recomputed maximum ratios1.107467/1.004283 below1.20/1.10; absolute64x8KiB all-new single-DATA p95 about10.326ms remains material cost. Original C uninstrumented four-row gate independently passed max1.171772/1.000909. Full offline soak221pass/default2367pass+4existing skips; original73+25+16+11 mutations,oracle/helpers/resources/two standalone baselines,browser/lint/typecheck/build/export/artifact/owner gates passed. Current three qualification constants and five generated artifacts retain only validated final-source refresh. All commands, raw samples, actual mutant artifacts, source identities, failed attempts and static review preserved in publication-v1. Completes only finite private material association/passive publication; matching material grants no effect. No audience-hidden entry/full preset/B121/current dispatch guard/inbox/provider/live/spend or automatic downstream completion/authorization. Earlier commit instruction applies.'
 else:
  w['note']+=' 2026-09-09 publication-v1 retains current candidate and immutable incomplete qualification evidence: '+receipt['verification']['reason']+'. Source and earlier failed attempts retained; no complete qualification or downstream authorization. Earlier commit instruction applies.'
 rows[i]=json.dumps(w,ensure_ascii=False,separators=(',',':'))
assert found==1
p.write_text('\n'.join(rows)+'\n');print('WORK_UPDATED', 'complete' if qualified else 'planned')
