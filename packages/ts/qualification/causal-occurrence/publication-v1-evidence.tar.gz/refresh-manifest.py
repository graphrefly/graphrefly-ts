from pathlib import Path
import subprocess,re,json,time
root=Path('/Users/davidchenallio/src/graphrefly-ts');out=Path(__file__).parent
p=root/'packages/ts/evals/graph-native-rerun-avoidance/implementation-manifest.ts'
records=[]
def run(args):
 start=time.monotonic();r=subprocess.run(args,cwd=root,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
 records.append({'command':args,'exitCode':r.returncode,'elapsedSeconds':time.monotonic()-start,'output':r.stdout});assert r.returncode==0,r.stdout
 return r.stdout
base='packages/ts/evals/graph-native-rerun-avoidance/'
manifest=run(['pnpm','exec','tsx',base+'measure-root-eval-implementation.ts']).strip()
assert re.fullmatch(r'sha256:[a-f0-9]{64}',manifest),manifest
s=p.read_text();s,n=re.subn(r'(export const CURRENT_IMPLEMENTATION_MANIFEST_DIGEST =\s*)"sha256:[a-f0-9]{64}"',lambda m:m[1]+'"'+manifest+'"',s);assert n==1;p.write_text(s)
text=run(['pnpm','exec','tsx','-e',"import {ROOT_EVAL_TOPOLOGY_QUALIFICATION as q, ROOT_EVAL_TOPOLOGY_NO_NETWORK_QA_ARTIFACT_DIGEST as a} from './"+base+"root-eval-topology-qualification.ts'; console.log(JSON.stringify({qualification:q.qualificationDigest,artifact:a}));"])
obj=json.loads(text)
s=p.read_text()
for key,value in [('CURRENT_QUALIFICATION_DIGEST',obj['qualification']),('CURRENT_QUALIFICATION_ARTIFACT_DIGEST',obj['artifact'])]:
 s,n=re.subn(r'(export const '+key+r' =\s*)"sha256:[a-f0-9]{64}"',lambda m:m[1]+'"'+value+'"',s);assert n==1
p.write_text(s)
run(['pnpm','run','eval:root:artifacts'])
(out/'final-manifest-refresh.json').write_text(json.dumps(records,indent=2)+'\n')
print('MANIFEST_REFRESH_DONE',manifest,obj)
