from pathlib import Path
import json,math,hashlib
q=Path(__file__).parent;root=Path('/Users/davidchenallio/src/graphrefly-ts')
x=json.loads((q/'c-performance.json').read_text());c=json.loads((q/'c-performance.check.json').read_text())
sha=lambda p:'sha256:'+hashlib.sha256(p.read_bytes()).hexdigest()
assert c['exitCode']==0 and c['sourceUnchanged'] and sha(q/'c-performance.log')==c['logDigest']
assert x['runnerDigest']==sha(root/'scripts/compare-causal-construction.mjs')
assert x['frozenDigest']==sha(root/'packages/ts/qualification/causal-occurrence/ts-v4-construction-inputs.json')
assert len(x['comparisons'])==6 and all(z['matched'] for z in x['comparisons'])
assert [(z['count'],z['evidence'],z['background']) for z in x['performanceRows']]==[(1,0,0),(16,128,0),(64,512,0),(1,0,1000)]
p=lambda a,q: sorted(a)[math.ceil(len(a)*q)-1]
rows=[]
for row in x['performanceRows']:
 a=row['construction'];b=row['steady']
 for arm in ['baseline','candidate']:
  assert len(a[arm])==900 and len(a['batches'])==3
  assert all(len(z[arm])==300 for z in a['batches'])
  assert a[arm]==sum((z[arm] for z in a['batches']),[])
  assert a[arm+'P95Ns']==p(a[arm],.95)
  assert len(b[arm])==(9 if row['count']==64 else 15)
  assert all(math.isfinite(v) and v>=0 for v in a[arm]+b[arm])
  assert b[arm+'MedianP95Ns']==p(b[arm],.5)
 cr=a['candidateP95Ns']/a['baselineP95Ns'];sr=b['candidateMedianP95Ns']/b['baselineMedianP95Ns']
 assert cr==a['ratio'] and sr==b['ratio']
 rows.append({'effects':row['count'],'evidence':row['evidence'],'background':row['background'],'constructionRatio':cr,'steadyRatio':sr,'passed':cr<=1.20 and sr<=1.10})
for path,digest in x['closure'].items():
 if path.startswith('packages/ts/'):assert sha(root/path)==digest,path
summary={'passed':all(r['passed'] for r in rows),'reportDigest':sha(q/'c-performance.json'),'originalThresholds':{'construction':1.20,'steady':1.10},'rows':rows}
(q/'c-performance-verification.json').write_text(json.dumps(summary,indent=2)+'\n')
print('C_PERFORMANCE_VERIFIED',summary)
assert summary['passed'],'original C cost budget failed'
