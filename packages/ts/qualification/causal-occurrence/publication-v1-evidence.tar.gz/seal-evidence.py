from pathlib import Path
import json,hashlib,tarfile,gzip,io,subprocess,sys
q=Path(__file__).parent;root=Path('/Users/davidchenallio/src/graphrefly-ts')
sha=lambda b:'sha256:'+hashlib.sha256(b).hexdigest()
read=lambda n:json.loads((q/n).read_text())
qualified=sys.argv[1]=='qualified'
if qualified:
 subprocess.run(['python3',str(q/'verify-attempt.py')],check=True)
 verification=read('attempt-verification.json');assert verification['qualificationPassed']
else:
 verification={'qualificationPassed':False,'reason':sys.argv[2]}
 assert not (q/'offline-sequence.json').exists() or not read('offline-sequence.json')['passed']
base=read('final-lint.bindings.json')['after']
after=read('after-current-binding.json')['files'] if qualified else base
for p,d in after.items():assert sha((root/p).read_bytes())==d,p
changed=subprocess.check_output(['git','diff','--name-only','HEAD'],cwd=root,text=True).splitlines()
changed+=subprocess.check_output(['git','ls-files','--others','--exclude-standard'],cwd=root,text=True).splitlines()
inputs={p:sha((root/p).read_bytes()) for p in changed if p!='plan/work.jsonl' and not p.startswith('packages/ts/qualification/')}
for p in inputs:
 dest=q/'final-source'/p;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes((root/p).read_bytes())
(q/'applied.patch').write_bytes(subprocess.check_output(['git','diff','--binary','HEAD','--',*inputs.keys()],cwd=root))
(q/'final-changed-files.json').write_text(json.dumps(inputs,indent=2)+'\n')
package=root/'packages/ts/qualification/causal-occurrence';stem='publication-v1'
archive=package/(stem+'-evidence.tar.gz');receipt=package/(stem+'-receipt.json');review=package/(stem+'-review.md')
assert review.exists() and not archive.exists() and not receipt.exists()
members={}
paths=sorted(p for p in q.rglob('*') if p.is_file() and '__pycache__' not in p.parts)
with archive.open('xb') as raw:
 with gzip.GzipFile(fileobj=raw,mode='wb',mtime=0) as zipped:
  with tarfile.open(fileobj=zipped,mode='w') as tar:
   for p in paths:
    data=p.read_bytes();name=str(p.relative_to(q));members[name]={'digest':sha(data),'bytes':len(data)}
    info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644;tar.addfile(info,io.BytesIO(data))
for name,meta in members.items():assert sha((q/name).read_bytes())==meta['digest'],name
for p,d in after.items():assert sha((root/p).read_bytes())==d,p
result={'schema':'graphrefly-ts/causal-publication-material-evidence/v1','owner':'graphrefly-ts','work':'graphrefly-ts:CAUSAL-PUBLICATION-MATERIAL-TS','revision':'publication-v1','status':'qualified' if qualified else 'incomplete','baselineCommit':'69d7fd5df1d96e574ef9d20fb6c7b378474906c7','authorization':read('authorization.json'),'verification':verification,'review':read('static-review-final.json'),'bindings':{str(p.relative_to(root)):sha(p.read_bytes()) for p in [review,archive]},'archiveMembers':members,'finalChangedFiles':inputs,'nonClaims':['No public API, wave protocol or C semantic change','No full preset, audience-hidden entry or B121 qualification','Passive material association grants no effect execution','No inbox/provider/live/spend or automatic downstream dispatch']}
receipt.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print('EVIDENCE_SEALED',str(receipt),len(members),'files',archive.stat().st_size,'bytes',result['status'])
