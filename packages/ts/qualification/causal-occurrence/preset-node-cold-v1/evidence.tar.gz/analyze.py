import json,pathlib,statistics,csv,sys
p=pathlib.Path(sys.argv[1]);read=lambda f:json.loads(f.read_text())
assert read(p/'run-exit.json')['exitCode']==0 and read(p/'run-01/completion.json')['completed']
rows=read(p/'run-01/summary.json');out={};table=[]
for mode in ['off','summary']:
 def select(a,v):return sorted([x for x in rows if x['mode']==mode and x['arm']==a and x['variant']==v],key=lambda x:x['batch'])
 cells={};overhead={}
 for arm in ['candidate','reference']:
  c=select(arm,'control');q=select(arm,'probe')
  overhead[arm]={'batchP50ContrastsUs':[(a['total']['p50Ms']-b['total']['p50Ms'])*1000 for a,b in zip(q,c)],'medianBatchP50ContrastUs':statistics.median((a['total']['p50Ms']-b['total']['p50Ms'])*1000 for a,b in zip(q,c)),'interpretation':'Observed contrast, including instrumentation/JIT/order/system differences; not exact clock overhead'}
  for variant in ['control','probe']:
   selected=select(arm,variant);cells[arm+'/'+variant]={'batchTotalUs':[{k:v*1000 for k,v in r['total'].items()} for r in selected]}
 c=select('candidate','probe');r=select('reference','probe');nodes=[]
 for id in c[0]['nodes']:
  a=[x['nodes'][id] for x in c];b=[x['nodes'][id] for x in r]
  n={'id':id,'candidateMedianBatchP50Us':statistics.median(x['p50Ms']*1000 for x in a),'referenceMedianBatchP50Us':statistics.median(x['p50Ms']*1000 for x in b),'batchP50DeltasUs':[(x['p50Ms']-y['p50Ms'])*1000 for x,y in zip(a,b)],'candidateMeanUs':statistics.mean(x['meanMs']*1000 for x in a),'referenceMeanUs':statistics.mean(x['meanMs']*1000 for x in b),'batchMeanDeltasUs':[(x['meanMs']-y['meanMs'])*1000 for x,y in zip(a,b)]}
  n['medianBatchP50DeltaUs']=statistics.median(n['batchP50DeltasUs']);nodes.append(n);table.append({'mode':mode,**n})
 stages={key:{arm:{v:statistics.mean(x['stages'][key][v]['meanMs']*1000 for x in rr) for v in ['totalMs','nodeMs','residualMs']} for arm,rr in [('candidate',c),('reference',r)]} for key in c[0]['stages']}
 out[mode]={'cells':cells,'overheadContrast':overhead,'nodesByTypicalCost':sorted(nodes,key=lambda n:-n['candidateMedianBatchP50Us']),'nodesByTypicalDelta':sorted(nodes,key=lambda n:-n['medianBatchP50DeltaUs']),'stagesMeanUs':stages,'aggregateProbeMeanUs':{arm:{k:statistics.mean(x[k]['meanMs']*1000 for x in rr) for k in ['total','nodeTotal','residual']} for arm,rr in [('candidate',c),('reference',r)]}}
# Keep largest raw intervals as observations; do not delete or recalculate qualification.
largest=[];count=0;measured=0
for line in (p/'run-01/samples.jsonl').open():
 s=json.loads(line);count+=1
 if s['variant']!='probe' or s['phase']!='measured':continue
 for n in s['nodes']:
  measured+=1;largest.append({'mode':s['mode'],'arm':s['arm'],'batch':s['batch'],'index':s['index'],'id':n['id'],'durationUs':(n['end']-n['start'])*1000})
 largest=sorted(largest,key=lambda n:-n['durationUs'])[:10]
assert count==12800 and measured==285600
out['rawCounts']={'constructions':count,'measuredNodeIntervals':measured};out['largestNodeIntervals']=largest
out['limitations']=['All raw samples retained; typical quantiles are descriptive, not replacement qualification estimator','No exclusive CPU claim: wall-time node interval may include scheduling or GC','Residual includes all work outside node bodies and recording overhead','Instrumentation makes exact uninstrumented per-node costs unidentifiable','Cold node creation only; no business execution ranking']
(p/'node-analysis.json').write_text(json.dumps(out,indent=2)+'\n')
with (p/'node-ranking.csv').open('w') as f:
 w=csv.DictWriter(f,fieldnames=list(table[0]));w.writeheader();w.writerows(table)
for mode in ['off','summary']:
 print(mode,'TOP COST',[(n['id'],round(n['candidateMedianBatchP50Us'],3),round(n['referenceMedianBatchP50Us'],3)) for n in out[mode]['nodesByTypicalCost'][:5]])
 print(mode,'TOP DELTA',[(n['id'],round(n['medianBatchP50DeltaUs'],3),[round(x,3) for x in n['batchP50DeltasUs']]) for n in out[mode]['nodesByTypicalDelta'][:3]])
 print(mode,'PROBE CONTRAST',out[mode]['overheadContrast'])
print('LARGEST',largest[:3]);print('NODE_ANALYSIS_DONE',count,measured)
