from pathlib import Path
import json,hashlib,math,collections
root=Path('/Users/davidchenallio/src/graphrefly-ts');out=Path(__file__).parent
sha=lambda b:'sha256:'+hashlib.sha256(b).hexdigest()
read=lambda n:json.loads((out/n).read_text())
ids=['artifact-refresh','closure','root-soak','causal-mutations','view-mutations','construction-mutations','cold-mutations','view-oracle','required-edges','incoming','resource-verifier','retained-performance','full-test','browser','artifact-check','lint','build-exports','frozen-standalone','qualified-standalone','combined-resources','scope','report-identities','workspace-preclose','dashboard-preclose']
source={str(f.relative_to(root)):sha(f.read_bytes()) for f in (root/'packages/ts/src').rglob('*') if f.is_file()}
for i in ids:
 c=read(i+'.check.json'); b=read(i+'.bindings.json')
 assert c['exitCode']==0 and c['signal'] is None and c['sourceUnchanged'] and not c['changed'],i
 assert b['before']==b['after']==source,i
 log=(out/(i+'.log')).read_bytes();assert sha(log)==c['logDigest'] and b'CHECK_DONE ' in log,i
assert '2257 passed | 4 skipped (2261)' in (out/'full-test.log').read_text()
assert '101 passed' in (out/'root-soak.log').read_text()
for name,n in [('causal-mutations',73),('construction-mutations',25),('cold-mutations',16),('view-mutations',11)]:
 r=read(name+'.json');assert r['complete'] and len(r['mutations'])==n
 assert all(m['outcome'] in ['killed','detected'] for m in r['mutations'])
view=read('view-mutations.json');assert len(view['baseline'])==2 and all(b['outcome']=='passed' for b in view['baseline'])
assert len(view['structural'])==2 and all(b['passed'] for b in view['structural'])
assert collections.Counter(m['kind'] for m in view['mutations'])=={'runtime-output':8,'immutability':2,'work-count':1}
causal=read('causal-mutations.json');assert collections.Counter(m['kind'] for m in causal['mutations'])=={'behavior':44,'structure':29}
for name,n in [('required-edges',168),('incoming',144)]:
 r=read(name+'.json');assert r['passed'] and len(r['cases'])==n
resource=read('resource-verifier.json');assert resource['passed'] and len(resource['snapshots'])==12 and resource['negativeControls']==2
for name in ['frozen-standalone','qualified-standalone']:
 r=read(name+'.json');assert len(r['comparisons'])==6
 for c in r['comparisons']:assert c['matched'] and c['baseline']==c['candidate'] and c['baselinePhase']==c['candidatePhase']
 f=r['startupFault'];assert f['matched'] and f['baseline']['events']==f['candidate']['events'] and f['candidate']['phase']=='faulted'
r=read('view-oracle.json');assert r['passed'] and len(r['results'])==2
for arm in r['results']:
 assert len(arm['comparisons'])==12 and arm['hotOrders']==2 and len(arm['measures'])==33
 for c in arm['comparisons']:
  for checkpoint in c['checkpoints']:assert checkpoint['actual']==checkpoint['expected']
 for m in arm['measures']:
  assert m['reconnections']==20
  assert m['actualPhaseChangePercent']==m['rate']
  if arm['instrumented']:assert m['viewBuilds']==m['accepted']
  else:assert m['viewBuilds'] is None
  assert len(m['samples'])==m['total']
  assert m['medianNs']==sorted(m['samples'])[len(m['samples'])//2]
  assert m['p95Ns']==sorted(m['samples'])[math.ceil(len(m['samples'])*.95)-1]
assert read('report-identities-verification.json')['passed']
for name,h in read('report-identities-verification.json')['reportDigests'].items():assert sha((out/name).read_bytes())==h,name
assert read('retained-performance-verification.json')['passed'] and read('scope-verification.json')['passed']
result={'passed':True,'checkIds':ids,'sourceFiles':len(source),'coverage':{'default':{'passed':2257,'failed':0,'skipped':4},'rootSoak':101,'viewFocused':18,'mutations':{'causal':73,'construction':25,'coldCategorized':16,'view':11,'viewDeferredWriteAdjacencyOnly':2},'plainComparisonsPerArm':12,'hotInputOrdersPerArm':2,'workloadRowsPerArm':33,'requiredEdgeCases':168,'incomingCases':144,'resourceSnapshots':12,'resourceNegativeControls':2,'standaloneBaselines':2,'standaloneTracesPerBaseline':6},'performanceReuse':read('retained-performance-verification.json'),'boundary':'Finite private committed-effects qualification; no materializer/preset/graded-hiding/current-dispatch authorization.'}
(out/'evidence-verification.json').write_text(json.dumps(result,indent=2)+'\n')
print('EVIDENCE_VERIFICATION_DONE',len(ids),'checks',len(source),'source files')
