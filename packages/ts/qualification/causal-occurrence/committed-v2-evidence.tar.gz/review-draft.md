# committed-v2：稳定源码离线资格刷新

审阅草稿：2257 默认测试、四组 mutation、独立对照和构建检查已通过；显式 101 项离线 soak 尚在运行。只有该检查完成并通过，才会封存 complete 收据和更新 work。

Owner 为 graphrefly-ts，沿用 CAUSAL-COMMITTED-VIEW-TS。最终目标是关闭已批准的 D163 私有视图实施资格；本轮没有修改生产源码。源码 commit 为 861a9a468c5d767997a4bec70df159f327faa512，manifest 为 ace2a62f…；旧 qualification drift 由新离线验收覆盖。三项 current 摘要按既有依赖顺序计算，五个派生工件仅变化摘要；拓扑、run summary、历史工件、科学方法、真实许可未变。生成阶段是待验收候选，生成器的 passed 常量不能自行证明成功。

新证据包括默认 2257 passed / 4 既有 Podman live opt-in skips；原 causal 73（44 行为、29 结构）、construction 25、cold 16 分类检测、新 view 11（8 实际输出、2 不可变、1 工作量）；两处 deferred 标记只有邻接审计，不计 runtime kill。结构 bypass-only 对照须通过，实际断开 authority→view 后须产生可运行图的输出断言失败。

独立 plain-code/oracle 在计数版和实际 runtime 各覆盖 12 个双启动顺序场景、2 个热输入顺序、33 行工作量/观测结果。原八 ports 分别对冻结 ts-v8 和合格 cold-v1 commit d9c868dc 的六条轨迹/startup fault 比较。后者添加相同物理 Node 供原 ports 比较，不能冒称实现相同的新视图功能。168 helper、144 incoming、12 资源快照和 2 个资源负对照也重新执行。

V1 exact records、V2 deferred、V3 单提交共用最终视图由 focused/oracle/mutation 交叉覆盖；V4 正常 DATA 恢复、V5 双启动、V6 UI 退订期间 wrong/exact outcome、V7 replay/回收、V8 不可变/错 graph/epoch 由 focused 和对应 runtime 检测覆盖；V9 原 ports 由两组 standalone 对照；V10 无关变化零重建、每相关 commit 至多一次、真实 watermark 与 fresh outcome 压力由独立计数和原始样本覆盖。

上一轮 material-v1 的原始无插桩性能 gate 继续使用：本轮从已封存 tar 验证全部 145 成员和前后全部 431 源码摘要，复算 7200 构造样本与 108 稳态 lifecycle，四行 construction/steady 均满足原 ≤1.20/≤1.10。不是本轮重新跑或选取更好批次。历史失败与 1.839833 异常原因未知这一事实继续保留。

该结果不证明普通用户入口已按等级隐藏、不证明 assessment/coverage/issues/startup 全部按需恢复、不实现 materializer/current-at-dispatch guard、真实 inbox、B121 或 effect 执行许可。视图保留的是已提交事实，UI 退订不结束 graph-owned lifecycle。O(E+D) 相关重建及 JSON 观察字节仍然存在；本轮并行负载下描述性时长不用于新的速度比较。

最终封存将包括精确源/工具闭包、全部执行日志及 DONE、独立结果/负对照、runtime mutation 分类、人和 agent 共用的审阅稿、原性能收据的哈希链接，以及 owner/workspace/dashboard gate。当前 root 仓库存在其他工作的未提交改动，本批不写 root 文件。
