from pathlib import Path
import json,hashlib
root=Path('/Users/davidchenallio/src/graphrefly-ts');out=Path(__file__).parent
sha=lambda b:'sha256:'+hashlib.sha256(b).hexdigest()
read=lambda n:json.loads((out/n).read_text())
source={str(p.relative_to(root)):sha(p.read_bytes()) for p in (root/'packages/ts/src').rglob('*') if p.is_file()}
failed={'root-soak','soak-five-isolated','shuffle-profile'}
checks=[]
for p in sorted(out.glob('*.check.json')):
 c=json.loads(p.read_text());i=c['id'];b=read(i+'.bindings.json')
 assert c['exitCode']==(1 if i in failed else 0),i
 assert c['sourceUnchanged'] and not c['changed'] and c['signal'] is None,i
 assert b['before']==b['after']==source,i
 log=(out/(i+'.log')).read_bytes()
 assert sha(log)==c['logDigest'] and b'CHECK_DONE ' in log,i
 checks.append(c)
assert failed=={c['id'] for c in checks if c['exitCode']!=0}
assert '2257 passed | 4 skipped (2261)' in (out/'full-test.log').read_text()
assert '5 failed | 96 passed (101)' in (out/'root-soak.log').read_text()
assert '1 failed | 4 passed | 96 skipped (101)' in (out/'soak-five-isolated.log').read_text()
assert '1 passed | 100 skipped (101)' in (out/'soak-grant-isolated.log').read_text()
assert '1 failed | 100 skipped (101)' in (out/'shuffle-profile.log').read_text()
for name,n in [('causal-mutations',73),('construction-mutations',25),('cold-mutations',16),('view-mutations',11)]:
 r=read(name+'.json');assert r['complete'] and len(r['mutations'])==n
 assert all(m['outcome'] in ['killed','detected'] for m in r['mutations'])
identities=read('report-identities-verification.json')
assert identities['passed']
for name,h in identities['reportDigests'].items():assert sha((out/name).read_bytes())==h,name
oracle=read('view-oracle.json');assert oracle['passed']
for arm in oracle['results']:
 assert len(arm['comparisons'])==12 and arm['hotOrders']==2 and len(arm['measures'])==33
 for c in arm['comparisons']:
  for checkpoint in c['checkpoints']:assert checkpoint['actual']==checkpoint['expected']
 for m in arm['measures']:
  assert m['reconnections']==20 and m['actualPhaseChangePercent']==m['rate']
  assert m['viewBuilds']==(m['accepted'] if arm['instrumented'] else None)
  assert len(m['samples'])==m['total']
  assert m['medianNs']==sorted(m['samples'])[len(m['samples'])//2]
assert read('retained-performance-verification.json')['passed']
withdrawal=read('candidate-binding-withdrawal.json')
for path,h in withdrawal['restoredFiles'].items():assert sha((root/path).read_bytes())==h,path
for path,h in withdrawal['candidateFiles'].items():assert sha((out/'unqualified-candidate'/path).read_bytes())==h,path
initial=read('initial-tracked-bindings.json')
assert all(sha((root/p).read_bytes())==h for p,h in initial.items()),'existing tracked files changed before seal'
result={'verified':True,'qualificationPassed':False,'sourceFiles':len(source),'checks':checks,'failedCheckIds':sorted(failed),'sourceUnchanged':True,'allPreexistingTrackedFilesRestored':True,'candidateQualificationBindings':read('closure.json'),'reportDigests':identities['reportDigests'],'proposalUnapplied':read('shuffle-proposal.json'),'nextFullConfirmationExecuted':False,'reason':'Five-case isolation still fails original5000ms aggregate shuffle watchdog; no further unchanged full rerun.'}
(out/'attempt-verification.json').write_text(json.dumps(result,indent=2)+'\n')
print('ATTEMPT_VERIFIED_NOT_QUALIFIED',len(checks),'checks',len(source),'source files')
