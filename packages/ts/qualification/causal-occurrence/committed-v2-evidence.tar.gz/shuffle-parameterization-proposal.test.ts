import { execFileSync, spawn } from "node:child_process";
import { readFileSync } from "node:fs";
import {
	chmod,
	cp,
	link,
	mkdir,
	mkdtemp,
	readdir,
	readFile,
	realpath,
	rm,
	stat,
	symlink,
	writeFile,
} from "node:fs/promises";
import { tmpdir } from "node:os";
import { basename, join, resolve } from "node:path";
import { pathToFileURL } from "node:url";
import { runInNewContext } from "node:vm";
import { describe, expect, it, vi } from "vitest";
import {
	empiricalSha256,
	empiricalStrictJsonDigest,
} from "../../evals/graph-native-rerun-avoidance/canonical.js";
import { createCurrentExactModelHarnessProfileInput } from "../../evals/graph-native-rerun-avoidance/current-exact-profile.js";
import {
	assertRootEvalObservationRuntimeShape,
	assertRootEvalObservationSequence,
	createRootEvalTopology,
	type EvalAdmittedEffect,
	type EvalBudgetState,
	type EvalEffectOutcome,
	type EvalProviderOutcome,
	emptyEvalProviderOutcomeReasonCounts,
	ROOT_EVAL_MAX_AVAILABILITY_RETRIES,
	ROOT_EVAL_MAX_CAPACITY_RETRIES,
	ROOT_EVAL_MAX_PROVIDER_DISPATCHES_PER_WORK_ITEM,
	ROOT_EVAL_NO_NETWORK_CURRENT_KEY_BEFORE,
	ROOT_EVAL_TOPOLOGY_REVISION,
	type RootEvalRunResult,
	rootEvalMaximumObservationOccurrences,
	rootEvalMaximumProviderAttempts,
	rootEvalMaximumRetryAttempts,
	rootEvalScheduleFeasibility,
	runRootEval,
} from "../../evals/graph-native-rerun-avoidance/eval-topology.js";
import {
	checkRootEvalGeneratedArtifactSnapshot,
	ROOT_EVAL_ARTIFACT_DIRECTORY,
} from "../../evals/graph-native-rerun-avoidance/generate-root-eval-artifacts.js";
import {
	createDeepSeekV4Flash0731TogetherStructuredProfileDefinition,
	createInjectedNoNetworkProfileQualification,
	exactQualifiedProfileCatalogInput,
} from "../../evals/graph-native-rerun-avoidance/model-harness-profile.js";
import { MODEL_HARNESS_PROFILE_NO_NETWORK_QA_ARTIFACT_DIGEST } from "../../evals/graph-native-rerun-avoidance/model-harness-profile-qualification.js";
import {
	advanceRootEvalD145CharterLedger,
	createRootEvalD152QualificationEpoch,
	latestRootEvalGraphSpend,
	nextRootEvalD145DevelopmentOrdinal,
	ROOT_EVAL_D145_CONFIRMATORY_GENERATION_HARD_CAP_MICROUSD,
	ROOT_EVAL_D145_CONFIRMATORY_HARD_CAP_MICROUSD,
	ROOT_EVAL_D145_DEVELOPMENT_GENERATION_HARD_CAP_MICROUSD,
	ROOT_EVAL_D145_DEVELOPMENT_HARD_CAP_MICROUSD,
	ROOT_EVAL_D145_EMPTY_CHARTER_LEDGER,
	ROOT_EVAL_D145_HISTORICAL_CONFIRMATORY_TASK_SET_REF,
	ROOT_EVAL_D145_HISTORICAL_HELD_OUT_SEAL_DIGEST,
	ROOT_EVAL_D145_TOTAL_HARD_CAP_MICROUSD,
	readRootEvalD145CharterLedger,
	reconcileRootEvalD145ConsumedPreclaimFailure,
	rootEvalD145ConsumedPreclaimReconciliationDigest,
	rootEvalD145DevelopmentGenerationRef,
	rootEvalD145DevelopmentTaskSetRef,
	rootEvalD152DevelopmentGenerationRef,
	writeRootEvalD145CharterLedger,
} from "../../evals/graph-native-rerun-avoidance/root-eval-charter-ledger.js";
import {
	commitRootEvalD145CharterReconciliation,
	ROOT_EVAL_D145_CHARTER_RECONCILIATION_SCHEMA,
	ROOT_EVAL_D145_CHARTER_TRANSACTION_SCHEMA,
	ROOT_EVAL_D145_STALE_TRANSACTION_RECONCILIATION_SCHEMA,
	recoverRootEvalD145CharterTransaction,
} from "../../evals/graph-native-rerun-avoidance/root-eval-charter-transaction.js";
import {
	advanceRootEvalD152Ledger,
	commitRootEvalD152Transaction,
	createRootEvalD152Ledger,
	nextRootEvalD152DevelopmentOrdinal,
	ROOT_EVAL_D152_LEDGER_SCHEMA,
	readRootEvalD152Ledger,
} from "../../evals/graph-native-rerun-avoidance/root-eval-d152-ledger.js";
import {
	awaitRootEvalCallerSettlement,
	createRootEvalLiveExecutor,
	createRootEvalLiveTransportQualificationExecutor,
	createRootEvalNoNetworkQualificationExecutor,
	parseRootEvalLiveProviderResponse as parseCandidateProviderResponse,
	qualifyRootEvalMechanismTaskFamily,
	ROOT_EVAL_BILLING_SETTLEMENT_LEASE_MS,
	ROOT_EVAL_CALLER_SETTLEMENT_DEADLINE_MS,
	ROOT_EVAL_LIVE_BUGGY_REPLACEMENT,
	ROOT_EVAL_LIVE_DECISION_REF,
	ROOT_EVAL_LIVE_WRITABLE_PATH,
	ROOT_EVAL_MAX_BILLING_OBSERVATIONS,
	ROOT_EVAL_MAX_POST_CUTOFF_CAUSAL_TAIL_MS,
	ROOT_EVAL_PROVIDER_SETTLEMENT_LEASE_MS,
	ROOT_EVAL_RETRY_SETTLEMENT_LEASE_MS,
	ROOT_EVAL_TOOL_SETTLEMENT_LEASE_MS,
	RootEvalCallerSettlementDeadlineExpired,
	readRootEvalBoundedResponseBytes,
	rootEvalWorkspaceForAdmission,
} from "../../evals/graph-native-rerun-avoidance/root-eval-live.js";
import {
	acquireRootEvalLiveClaim,
	acquireRootEvalLiveClaimForNoNetworkQualification,
	admitRootEvalLiveConsumedPreclaimFailure,
	admitRootEvalLiveOperatorConfiguration,
	admitRootEvalLivePrecredentialGateReceipt,
	admitRootEvalLiveZeroByok,
	assertRootEvalRunResultAdmissionShape,
	buildRootEvalLiveOperatorConfigurationArtifactBytes,
	constructRootEvalLiveEvidence,
	evaluateRootEvalLiveAdmission,
	parseRootEvalLiveCredential,
	persistRootEvalLiveEvidence,
	persistRootEvalLivePreclaimFailure,
	persistRootEvalLivePrecredentialGateReceipt,
	qualifyRootEvalLivePrivateInputs,
	ROOT_EVAL_CURRENT_IMPLEMENTATION_MANIFEST_DIGEST,
	ROOT_EVAL_CURRENT_QUALIFICATION_ARTIFACT_DIGEST,
	ROOT_EVAL_CURRENT_QUALIFICATION_DIGEST,
	ROOT_EVAL_CURRENT_TASK_BINDING_DIGEST,
	ROOT_EVAL_HISTORICAL_D85_IMPLEMENTATION_MANIFEST_DIGEST,
	ROOT_EVAL_HISTORICAL_D85_QUALIFICATION_ARTIFACT_DIGEST,
	ROOT_EVAL_HISTORICAL_D85_QUALIFICATION_DIGEST,
	ROOT_EVAL_HISTORICAL_D85_TASK_BINDING_DIGEST,
	ROOT_EVAL_LIVE_AUTHORITY_VIOLATION_CODES,
	ROOT_EVAL_LIVE_BUDGET_PARTITION,
	ROOT_EVAL_LIVE_CAMPAIGN_HARD_CAP_MICROUSD,
	ROOT_EVAL_LIVE_CAMPAIGN_PURPOSE,
	ROOT_EVAL_LIVE_CAMPAIGN_SLOT,
	ROOT_EVAL_LIVE_CLAIM_REF,
	ROOT_EVAL_LIVE_CLAIM_SCHEMA,
	ROOT_EVAL_LIVE_EVIDENCE_SCHEMA,
	ROOT_EVAL_LIVE_EXECUTION_CLAIM_SCHEMA,
	ROOT_EVAL_LIVE_EXECUTION_GRANT_SCHEMA,
	ROOT_EVAL_LIVE_GENERATION_REF,
	ROOT_EVAL_LIVE_HELD_OUT_SEAL_DIGEST,
	ROOT_EVAL_LIVE_OPERATOR_CONFIGURATION_DECISION_REF,
	ROOT_EVAL_LIVE_OPERATOR_CONFIGURATION_NAME,
	ROOT_EVAL_LIVE_OPERATOR_CONFIGURATION_SCHEMA,
	ROOT_EVAL_LIVE_PARTITION_HARD_CAP_MICROUSD,
	ROOT_EVAL_LIVE_PRECLAIM_FAILURE_SCHEMA,
	ROOT_EVAL_LIVE_PRECREDENTIAL_GATE_RECEIPT_NAME,
	ROOT_EVAL_LIVE_PRECREDENTIAL_GATE_RECEIPT_SCHEMA,
	ROOT_EVAL_LIVE_PRICING_SOURCE,
	ROOT_EVAL_LIVE_REPLICATE_COUNT,
	ROOT_EVAL_LIVE_SUCCESS_VIOLATION_CODES,
	ROOT_EVAL_LIVE_TASK_SET_REF,
	ROOT_EVAL_LIVE_ZDR_SOURCE,
	type RootEvalLiveClaim,
	type RootEvalLiveEvidenceInput,
	readRootEvalLiveConsumedDevelopmentPreclaimFailures,
	readRootEvalLiveCurrentKey,
	readRootEvalLivePrecredentialGateReceipt,
	readRootEvalLivePricing,
	readRootEvalLiveRefreshablePrecredentialGateReceipt,
	recoverRootEvalLiveClaimAuthority,
	replaceRootEvalLiveOperatorConfiguration,
	replaceRootEvalLivePrecredentialGateReceipt,
} from "../../evals/graph-native-rerun-avoidance/root-eval-live-authority.js";
import {
	assertRootEvalTaskStimulusContract,
	createRootEvalTaskManifest,
	ROOT_EVAL_D157_HORIZON_DIRECTORY_NAME,
	ROOT_EVAL_D157_HORIZON_SLOTS,
	ROOT_EVAL_D159_HORIZON_DIRECTORY_NAME,
	ROOT_EVAL_D159_HORIZON_SLOTS,
	ROOT_EVAL_DEVELOPMENT_TASK_SET_REFS,
	ROOT_EVAL_DEVELOPMENT_TASKS,
	ROOT_EVAL_IRRELEVANT_SOURCE_REPLICATES,
	ROOT_EVAL_SUPPORTED_DEVELOPMENT_SLOTS,
	type RootEvalTaskDefinition,
	readRootEvalTaskManifest,
	rootEvalCandidateWorkspaceSnapshotDigest,
	rootEvalD159DevelopmentRegistryPairwiseAudit,
	rootEvalDevelopmentRegistryPairwiseAudit,
	rootEvalDevelopmentTaskSetRef,
	rootEvalMechanismDiscriminationOracle,
	rootEvalMechanismPairwiseAudit,
	rootEvalScriptedMechanismReplacement,
	rootEvalTask,
	rootEvalTaskBindings,
	rootEvalTaskManifestDisjointAudit,
	rootEvalToolCandidateCatalog,
	rootEvalVariantOrderSupportsIrrelevantControls,
} from "../../evals/graph-native-rerun-avoidance/root-eval-task.js";
import {
	assertRootEvalD157PrecommitEligibility,
	ensureRootEvalDevelopmentTaskManifest,
	prepareRootEvalD157HorizonForNoNetworkQualification,
	prepareRootEvalD159HorizonForNoNetworkQualification,
	ROOT_EVAL_D157_HORIZON_RECEIPT_NAME,
	ROOT_EVAL_D159_HORIZON_RECEIPT_NAME,
	readRootEvalD157HorizonReceipt,
	readRootEvalD159HorizonReceipt,
	readRootEvalFrozenDevelopmentManifestAudit,
} from "../../evals/graph-native-rerun-avoidance/root-eval-task-manifest-store.js";
import { settledRootEvalSpend } from "../../evals/graph-native-rerun-avoidance/settled-spend.js";
import { graph } from "../graph/graph.js";
import { strictJsonCodec } from "../json/codec.js";

const ROOT_EVAL_DEVELOPMENT_TASK = ROOT_EVAL_DEVELOPMENT_TASKS[0]!;
const DEFAULT_TEST_WORK_ITEM_ID = "root-eval-test/candidate-work-item";

function correctCandidate(
	task: RootEvalTaskDefinition,
	workItemRole: "source" | "target",
	workItemId: string,
) {
	const catalog = rootEvalToolCandidateCatalog(task, workItemRole, workItemId);
	const replacement =
		workItemRole === "source" ? task.sourceFixtureCorrectText : task.fixtureCorrectText;
	const candidate = catalog.candidates.find(
		(entry) => entry.replacementDigest === empiricalStrictJsonDigest(replacement),
	);
	if (candidate === undefined) throw new Error("test candidate catalog lost verified intervention");
	return { catalog, candidate };
}

function parseRootEvalLiveProviderResponse(
	input: Omit<
		Parameters<typeof parseCandidateProviderResponse>[0],
		"candidateRefs" | "candidateCatalogDigest"
	> &
		Partial<
			Pick<
				Parameters<typeof parseCandidateProviderResponse>[0],
				"candidateRefs" | "candidateCatalogDigest"
			>
		>,
) {
	const catalog = rootEvalToolCandidateCatalog(
		ROOT_EVAL_DEVELOPMENT_TASK,
		"target",
		DEFAULT_TEST_WORK_ITEM_ID,
	);
	return parseCandidateProviderResponse({
		candidateRefs: catalog.candidates.map((candidate) => candidate.candidateRef) as [
			string,
			string,
		],
		candidateCatalogDigest: catalog.catalogDigest,
		...input,
	});
}

const repositoryRoot = resolve(import.meta.dirname, "../../../..");
const pricing = Object.freeze({
	inputMicrousdPerMillionTokens: 140_000 as const,
	outputMicrousdPerMillionTokens: 280_000 as const,
	cacheReadMicrousdPerMillionTokens: 30_000 as const,
});
const historicalFireworksPricing = Object.freeze({
	inputMicrousdPerMillionTokens: 220_000 as const,
	outputMicrousdPerMillionTokens: 660_000 as const,
	cacheReadMicrousdPerMillionTokens: 7_000 as const,
});
const boundedCurrentness = Object.freeze({
	implementationCommit: "a".repeat(40),
	repositoryStateDigest: empiricalStrictJsonDigest("d138-repository-state"),
	artifactSetDigest: empiricalStrictJsonDigest("d138-artifact-set"),
});
const testPartitionLedgerDigest = empiricalStrictJsonDigest({ kind: "d145-test-ledger" });
const testTaskManifestDigest = empiricalStrictJsonDigest({ kind: "d145-test-task-manifest" });

const arms = Object.freeze([
	"cold",
	"relevant-applied",
	"proposal-only",
	"admission-rejected",
	"irrelevant-applied",
	"wrong-scope-applied",
] as const);

const memoryProvenance = Object.freeze({
	cold: "none",
	"relevant-applied": "relevant-applied",
	"proposal-only": "proposal-only",
	"admission-rejected": "admission-rejected",
	"irrelevant-applied": "irrelevant-applied",
	"wrong-scope-applied": "wrong-scope-applied",
} as const);

const providerOutcomeReasonCounts = Object.freeze({
	...emptyEvalProviderOutcomeReasonCounts(),
	"tool-proposed": ROOT_EVAL_LIVE_REPLICATE_COUNT * arms.length,
});

function admissionIds(count = ROOT_EVAL_LIVE_REPLICATE_COUNT * arms.length): readonly string[] {
	const result: string[] = [];
	for (let replicate = 1; replicate <= ROOT_EVAL_LIVE_REPLICATE_COUNT; replicate += 1)
		for (const arm of arms) {
			const workItemId = `${ROOT_EVAL_LIVE_GENERATION_REF}/replicate-${replicate}/${arm}`;
			result.push(
				`effect-run:work-item:${workItemId}:effect-plan:1:${workItemId}/plan:provider-and-exact-tool/dispatch-1/admission`,
			);
			if (result.length === count) return Object.freeze(result);
		}
	return Object.freeze(result);
}

function sourceAdmissionId(replicate: number, dispatchOrdinal = 1): string {
	const workItemId = `${ROOT_EVAL_LIVE_TASK_SET_REF}/instance-${replicate}/source-work-item`;
	return `effect-run:work-item:${workItemId}:effect-plan:1:${workItemId}/plan:source-provider-and-exact-tool/dispatch-${dispatchOrdinal}/admission`;
}

function allProviderAdmissionIds(): readonly string[] {
	const result: string[] = [];
	for (let replicate = 1; replicate <= ROOT_EVAL_LIVE_REPLICATE_COUNT; replicate += 1) {
		for (
			let dispatchOrdinal = 1;
			dispatchOrdinal <= ROOT_EVAL_MAX_PROVIDER_DISPATCHES_PER_WORK_ITEM;
			dispatchOrdinal += 1
		)
			result.push(sourceAdmissionId(replicate, dispatchOrdinal));
		for (const arm of arms) {
			const workItemId = `${ROOT_EVAL_LIVE_GENERATION_REF}/replicate-${replicate}/${arm}`;
			for (
				let dispatchOrdinal = 1;
				dispatchOrdinal <= ROOT_EVAL_MAX_PROVIDER_DISPATCHES_PER_WORK_ITEM;
				dispatchOrdinal += 1
			)
				result.push(
					`effect-run:work-item:${workItemId}:effect-plan:1:${workItemId}/plan:provider-and-exact-tool/dispatch-${dispatchOrdinal}/admission`,
				);
		}
	}
	return Object.freeze(result);
}

function providerBytes(): Uint8Array {
	const { candidate: correct } = correctCandidate(
		ROOT_EVAL_DEVELOPMENT_TASK,
		"target",
		DEFAULT_TEST_WORK_ITEM_ID,
	);
	return new TextEncoder().encode(
		JSON.stringify({
			id: "generation:test",
			model: "deepseek/deepseek-v4-flash-20260731",
			provider: "Together",
			choices: [
				{
					index: 0,
					finish_reason: "stop",
					native_finish_reason: "stop",
					logprobs: null,
					message: {
						role: "assistant",
						content: JSON.stringify({ candidateRef: correct.candidateRef }),
					},
				},
			],
			usage: {
				prompt_tokens: 1_000,
				completion_tokens: 100,
				total_tokens: 1_100,
				cost: 0.000157,
				prompt_tokens_details: { cached_tokens: 100 },
			},
		}),
	);
}

function historicalFireworksProviderBytes(): Uint8Array {
	const decoded = JSON.parse(new TextDecoder().decode(providerBytes())) as Record<string, unknown>;
	decoded.provider = "Fireworks";
	decoded.usage = {
		...(decoded.usage as Record<string, unknown>),
		cost: 0.0002647,
	};
	return new TextEncoder().encode(JSON.stringify(decoded));
}

function providerBytesForTask(
	task: RootEvalTaskDefinition,
	workItemId = DEFAULT_TEST_WORK_ITEM_ID,
): Uint8Array {
	const { candidate: correct } = correctCandidate(task, "target", workItemId);
	const decoded = JSON.parse(new TextDecoder().decode(providerBytes())) as {
		choices: Array<{ message: { content: string } }>;
	};
	decoded.choices[0]!.message.content = JSON.stringify({ candidateRef: correct.candidateRef });
	return new TextEncoder().encode(JSON.stringify(decoded));
}

function providerBytesForSourceTask(
	task: RootEvalTaskDefinition,
	workItemId = task.sourceWorkItemRef,
): Uint8Array {
	const { candidate: correct } = correctCandidate(task, "source", workItemId);
	const decoded = JSON.parse(new TextDecoder().decode(providerBytes())) as {
		choices: Array<{ message: { content: string } }>;
	};
	decoded.choices[0]!.message.content = JSON.stringify({ candidateRef: correct.candidateRef });
	return new TextEncoder().encode(JSON.stringify(decoded));
}

function providerBytesForEffect(
	effect: Pick<EvalAdmittedEffect, "replicate" | "workItemRole" | "workItemId">,
	tasks: readonly RootEvalTaskDefinition[] = ROOT_EVAL_DEVELOPMENT_TASKS,
): Uint8Array {
	const task = tasks[effect.replicate - 1]!;
	return effect.workItemRole === "source"
		? providerBytesForSourceTask(task, effect.workItemId)
		: providerBytesForTask(task, effect.workItemId);
}

function truncatedProviderBytes(): Uint8Array {
	const decoded = JSON.parse(new TextDecoder().decode(providerBytes())) as {
		choices: Array<Record<string, unknown>>;
	};
	decoded.choices[0] = Object.freeze({
		...decoded.choices[0],
		finish_reason: "length",
		native_finish_reason: "length",
	});
	return new TextEncoder().encode(JSON.stringify(decoded));
}

function precredentialGateReceiptBytes(completedAtMs: number): Uint8Array {
	const material = {
		schemaVersion: ROOT_EVAL_LIVE_PRECREDENTIAL_GATE_RECEIPT_SCHEMA,
		decisionRef: ROOT_EVAL_LIVE_DECISION_REF,
		generationRef: ROOT_EVAL_LIVE_GENERATION_REF,
		implementationManifestDigest: ROOT_EVAL_CURRENT_IMPLEMENTATION_MANIFEST_DIGEST,
		qualificationArtifactDigest: ROOT_EVAL_CURRENT_QUALIFICATION_ARTIFACT_DIGEST,
		qualificationDigest: ROOT_EVAL_CURRENT_QUALIFICATION_DIGEST,
		implementationCommit: boundedCurrentness.implementationCommit,
		repositoryStateDigest: boundedCurrentness.repositoryStateDigest,
		artifactSetDigest: boundedCurrentness.artifactSetDigest,
		completedAtMs,
	};
	return new TextEncoder().encode(
		JSON.stringify({ ...material, receiptDigest: empiricalStrictJsonDigest(material) }),
	);
}

function precredentialGateReceipt(completedAtMs: number) {
	return admitRootEvalLivePrecredentialGateReceipt({
		bytes: precredentialGateReceiptBytes(completedAtMs),
		nowMs: completedAtMs,
	});
}

function operatorConfigurationBytes(declaredAtMs: number, duplicateKey = false): Uint8Array {
	const encoded = new TextDecoder().decode(
		buildRootEvalLiveOperatorConfigurationArtifactBytes({
			workspaceName: "GraphReFly",
			workspaceSlug: "graph-re-fly",
			keyName: "Local Eval 2",
			byokCredentialCount: 0,
			providerObservation: "Together Not configured",
			source: "maintainer-declared-openrouter-settings",
			declaredAtMs,
			configurationRevision: "2026-09-04.d158.v1",
			revoked: false,
			credentialFingerprintDigest: empiricalSha256(
				new TextEncoder().encode("sk-or-v1-a44-middle-credential-e06"),
			),
			keyVisiblePrefix: "sk-or-v1-a44",
			keyVisibleSuffix: "e06",
			guardrailId: "2c97d3e1-b4cc-4246-95d7-33eb27fb65ab",
			guardrailName: "B112 DeepSeek V4 Flash",
			guardrailDescription:
				"Dedicated Local Eval 2 guardrail for the B112 DeepSeek V4 Flash 0731 Fireworks-only structured-proposal route.",
			keyAssigned: true,
			restrictionMode: "only-allow",
			paidEndpointTrainingAllowed: false,
			providerEligible: true,
			requestDataCollection: "deny",
			requestZdrRequired: true,
			allowedModels: ["deepseek/deepseek-v4-flash-0731"],
			allowedProviders: ["Fireworks", "Together"],
		}),
	);
	return new TextEncoder().encode(
		duplicateKey
			? encoded.replace('"keyAssigned":true', '"keyAssigned":false,"keyAssigned":true')
			: encoded,
	);
}

function liveEvidenceInput(
	replicateCount = ROOT_EVAL_LIVE_REPLICATE_COUNT,
): RootEvalLiveEvidenceInput {
	const workItemCount = replicateCount * arms.length;
	const fixtureProviderOutcomeReasonCounts = Object.freeze({
		...emptyEvalProviderOutcomeReasonCounts(),
		"tool-proposed": workItemCount,
	});
	const pricingMaterial = {
		sourceUrl: ROOT_EVAL_LIVE_PRICING_SOURCE,
		modelRef: "deepseek/deepseek-v4-flash-0731" as const,
		endpointModelRef: "deepseek/deepseek-v4-flash-20260731" as const,
		providerName: "Together" as const,
		providerRef: "together" as const,
		quantization: "unknown" as const,
		inputMicrousdPerMillionTokens: 140_000 as const,
		outputMicrousdPerMillionTokens: 280_000 as const,
		cacheReadMicrousdPerMillionTokens: 30_000 as const,
		zeroDataRetention: true as const,
		promptTraining: false as const,
		zdrSourceUrl: ROOT_EVAL_LIVE_ZDR_SOURCE,
		zdrResponseDigest: empiricalStrictJsonDigest("zdr"),
		observedAtMs: 1,
		officialResponseDigest: empiricalStrictJsonDigest("pricing"),
	};
	const pricingObservation = {
		...pricingMaterial,
		observationDigest: empiricalStrictJsonDigest(pricingMaterial),
	};
	const zeroMaterial = {
		workspaceSlug: "graph-re-fly" as const,
		keyName: "Local Eval 2" as const,
		byokCredentialCount: 0 as const,
		providerObservation: "Together Not configured" as const,
		observedAtMs: 1,
		precredentialGateCompletedAtMs: 0,
		precredentialGateReceiptDigest: empiricalStrictJsonDigest("precredential-gates"),
		sourceArtifactDigest: empiricalStrictJsonDigest("zero-source"),
	};
	const zeroByok = {
		...zeroMaterial,
		observationDigest: empiricalStrictJsonDigest(zeroMaterial),
	};
	const currentKeyBeforeMaterial = {
		limitMicrousd: 32_000_000 as const,
		remainingMicrousd: 13_000_000,
		usageMicrousd: 19_000_000,
		limitReset: "none" as const,
		isManagementKey: false as const,
	};
	const currentKeyBefore = {
		...currentKeyBeforeMaterial,
		admissionDigest: empiricalStrictJsonDigest(currentKeyBeforeMaterial),
	};
	const currentKeyAfterMaterial = {
		...currentKeyBeforeMaterial,
		remainingMicrousd: 12_999_900,
		usageMicrousd: 19_000_100,
	};
	const currentKeyAfter = {
		...currentKeyAfterMaterial,
		admissionDigest: empiricalStrictJsonDigest(currentKeyAfterMaterial),
	};
	const testExecutionGrantDigest = empiricalStrictJsonDigest("test-execution-grant");
	const claimMaterial = {
		schemaVersion: ROOT_EVAL_LIVE_EXECUTION_CLAIM_SCHEMA,
		executionMode: "live" as const,
		executionRef: `root-eval-${ROOT_EVAL_LIVE_CAMPAIGN_SLOT}-together-test`,
		executionGrantDigest: testExecutionGrantDigest,
		claimRef: ROOT_EVAL_LIVE_CLAIM_REF,
		decisionRef: ROOT_EVAL_LIVE_DECISION_REF,
		generationRef: ROOT_EVAL_LIVE_GENERATION_REF,
		campaignPurpose: ROOT_EVAL_LIVE_CAMPAIGN_PURPOSE,
		taskSetRef: ROOT_EVAL_LIVE_TASK_SET_REF,
		taskManifestDigest: testTaskManifestDigest,
		replicateCount: ROOT_EVAL_LIVE_REPLICATE_COUNT,
		heldOutSealDigest: ROOT_EVAL_LIVE_HELD_OUT_SEAL_DIGEST,
		budgetPartition: ROOT_EVAL_LIVE_BUDGET_PARTITION,
		partitionHardCapMicrousd: ROOT_EVAL_LIVE_PARTITION_HARD_CAP_MICROUSD,
		partitionSpentBeforeMicrousd: 0,
		partitionLedgerDigest: testPartitionLedgerDigest,
		developmentQualificationStreakBefore: 0,
		implementationCoordinate: `worktree:${"a".repeat(40)}:${ROOT_EVAL_CURRENT_IMPLEMENTATION_MANIFEST_DIGEST}`,
		implementationManifestDigest: ROOT_EVAL_CURRENT_IMPLEMENTATION_MANIFEST_DIGEST,
		qualificationArtifactDigest: ROOT_EVAL_CURRENT_QUALIFICATION_ARTIFACT_DIGEST,
		qualificationDigest: ROOT_EVAL_CURRENT_QUALIFICATION_DIGEST,
		taskBindingDigest: ROOT_EVAL_CURRENT_TASK_BINDING_DIGEST,
		pricingObservationDigest: pricingObservation.observationDigest,
		zeroByokObservationDigest: zeroByok.observationDigest,
		credentialBindingDigest: empiricalStrictJsonDigest({
			bindingRef: "openrouter.local-eval-2",
			bindingRevision: "2026-09-01.d152.v1",
		}),
		credentialFingerprintDigest: empiricalStrictJsonDigest("test-credential-fingerprint"),
		currentKeyBeforeDigest: currentKeyBefore.admissionDigest,
		recoveryEnvelope: {
			pricing: pricingObservation,
			zeroByok,
			currentKeyBefore,
		},
		campaignHardCapMicrousd: ROOT_EVAL_LIVE_CAMPAIGN_HARD_CAP_MICROUSD,
		localEvalNoResetLimitMicrousd: 32_000_000 as const,
	};
	const claim = { ...claimMaterial, claimDigest: empiricalStrictJsonDigest(claimMaterial) };
	const verificationDiagnostics = {
		kind: "eval-verification-diagnostics" as const,
		armOrder: arms,
		stageCounts: Object.fromEntries(
			arms.map((arm) => [
				arm,
				{
					completedWorkItems: replicateCount,
					exactToolAdmitted: replicateCount,
					scopedChange: arm === "relevant-applied" ? replicateCount : 0,
					publicSemanticPassed: arm === "relevant-applied" ? replicateCount : 0,
					hiddenVerifierPassed: arm === "relevant-applied" ? replicateCount : 0,
					cleanupCompleted: replicateCount,
					passed: arm === "relevant-applied" ? replicateCount : 0,
				},
			]),
		),
		terminalReasonCounts: Object.fromEntries(
			arms.map((arm) => [
				arm,
				{
					"cleanup-incomplete": 0,
					"provider-failed": 0,
					"exact-tool-failed": 0,
					"no-change": arm === "relevant-applied" ? 0 : replicateCount,
					"wrong-scope": 0,
					"public-semantic-failed": 0,
					"hidden-verifier-failed": 0,
					passed: arm === "relevant-applied" ? replicateCount : 0,
				},
			]),
		),
		completedWorkItems: workItemCount,
	};
	const observation = {
		path: "eval/observation",
		msg: [
			"DATA",
			{
				kind: "eval-observation",
				topologyRevision: ROOT_EVAL_TOPOLOGY_REVISION,
				solutionIdentities: [
					"work-item-execution",
					"agentic-work-item-memory-application",
					"agentic-memory-record-use",
					"agentic-memory-retrieval",
				],
				campaignRef: ROOT_EVAL_LIVE_GENERATION_REF,
				campaignPurpose: ROOT_EVAL_LIVE_CAMPAIGN_PURPOSE,
				taskSetRef: ROOT_EVAL_LIVE_TASK_SET_REF,
				generationRef: ROOT_EVAL_LIVE_GENERATION_REF,
				replicate: replicateCount,
				replicateCount,
				heldOutSealDigest: ROOT_EVAL_LIVE_HELD_OUT_SEAL_DIGEST,
				budgetPartition: ROOT_EVAL_LIVE_BUDGET_PARTITION,
				partitionHardCapMicrousd: ROOT_EVAL_LIVE_PARTITION_HARD_CAP_MICROUSD,
				partitionSpentBeforeMicrousd: 0,
				partitionLedgerDigest: claimMaterial.partitionLedgerDigest,
				executionGrantDigest: testExecutionGrantDigest,
				developmentQualification: {
					kind: "eval-development-qualification-state",
					campaignPurpose: ROOT_EVAL_LIVE_CAMPAIGN_PURPOSE,
					generationRef: ROOT_EVAL_LIVE_GENERATION_REF,
					status: "qualified",
					generationQualified: true,
					consecutiveQualifyingGenerations: 1,
					requiredConsecutiveGenerations: 2,
					heldOutEligible: false,
				},
				armOrder: [
					"cold",
					"relevant-applied",
					"proposal-only",
					"admission-rejected",
					"irrelevant-applied",
					"wrong-scope-applied",
				],
				memoryProvenance,
				evaluableReplicates: replicateCount,
				excludedTechnicalReplicates: [],
				sourceTechnicalExcludedReplicates: [],
				matchedRelevantOverColdWins: replicateCount,
				verificationDiagnostics,
				completedArms: 6,
				activeProviderEffects: 0,
				activeToolEffects: 0,
				activeRetryEffects: 0,
				activeBillingEffects: 0,
				activeAdmittedEffects: 0,
				providerCapacity: {
					kind: "eval-provider-capacity-state",
					pacingRevision: workItemCount,
					providerStartIntervalMs: 30_000,
					consecutiveUsableResponses: workItemCount % 3,
					mode: "paced-serial",
					initialMaxConcurrentEffects: 1,
					maxConcurrentEffects: 1,
					activeEffects: 0,
					proposalCount: workItemCount,
					pendingProposalCount: 0,
					pendingFirstAttemptProposalCount: 0,
					pendingRetryProposalCount: 0,
					retryProposalCount: 0,
					admittedProposalCount: workItemCount,
					admittedRetryProposalCount: 0,
					settledProposalCount: workItemCount,
					settledRetryProposalCount: 0,
					rejectedProposalCount: 0,
					rejectedRetryProposalCount: 0,
					cooldownOutstandingReadinessCount: 0,
					rateLimitFeedbackCount: 0,
				},
				scheduleFeasibility: rootEvalScheduleFeasibility(replicateCount),
				progressLease: {
					kind: "eval-progress-lease-state",
					campaignRef: ROOT_EVAL_LIVE_GENERATION_REF,
					revision: 1,
					occurrenceDigest: empiricalStrictJsonDigest("fixture-campaign-complete"),
					nextExpectedOccurrence: "campaign-complete",
					leaseMs: 0,
					deadlineOffsetMs: 0,
					maximumFinitePathMs: rootEvalScheduleFeasibility(replicateCount).maximumFinitePathMs,
					state: "complete",
					stoppingReason: "campaign-complete",
				},
				admittedAttempts: workItemCount,
				admittedRetryAttempts: 0,
				retryProposalCount: 0,
				pendingRetryProposalCount: 0,
				rejectedRetryProposalCount: 0,
				settledRetryAttemptCount: 0,
				providerCallCount: workItemCount,
				activeReservedMicrousd: 0,
				providerReportedMicrousd: 100,
				pricingRoundingAllowanceMicrousd: 1,
				providerReportedLowerBoundMicrousd: 99,
				unreportedSettledUpperBoundMicrousd: 0,
				accountedUpperBoundMicrousd: 100,
				observedBilledMicrousd: 100,
				billingObservationCount: 4,
				billingStableIntervals: 3,
				reconciledBilledMicrousd: 100,
				billingDisposition: "reconciled",
				providerOutcomeReasonCounts: fixtureProviderOutcomeReasonCounts,
				stoppingReason: "campaign-complete",
				finding: "positive-differential",
			},
		] as never,
		tier: 3,
		seq: workItemCount + 1,
	};
	const progressObservations = Array.from({ length: workItemCount }, (_, completedWorkItems) => {
		const completedByArm = Object.fromEntries(
			arms.map((arm, armIndex) => [
				arm,
				Math.floor(completedWorkItems / arms.length) +
					(armIndex < completedWorkItems % arms.length ? 1 : 0),
			]),
		) as Record<(typeof arms)[number], number>;
		const progressDiagnostics = {
			kind: "eval-verification-diagnostics" as const,
			armOrder: arms,
			stageCounts: Object.fromEntries(
				arms.map((arm) => {
					const completed = completedByArm[arm];
					const passed = arm === "relevant-applied" ? completed : 0;
					return [
						arm,
						{
							completedWorkItems: completed,
							exactToolAdmitted: completed,
							scopedChange: passed,
							publicSemanticPassed: passed,
							hiddenVerifierPassed: passed,
							cleanupCompleted: completed,
							passed,
						},
					];
				}),
			),
			terminalReasonCounts: Object.fromEntries(
				arms.map((arm) => {
					const completed = completedByArm[arm];
					return [
						arm,
						{
							"cleanup-incomplete": 0,
							"provider-failed": 0,
							"exact-tool-failed": 0,
							"no-change": arm === "relevant-applied" ? 0 : completed,
							"wrong-scope": 0,
							"public-semantic-failed": 0,
							"hidden-verifier-failed": 0,
							passed: arm === "relevant-applied" ? completed : 0,
						},
					];
				}),
			),
			completedWorkItems,
		};
		const providerReportedMicrousd = completedWorkItems * 3;
		const replicate = Math.floor(Math.max(0, completedWorkItems - 1) / arms.length) + 1;
		const completedArms =
			completedWorkItems === 0 ? 0 : ((completedWorkItems - 1) % arms.length) + 1;
		return {
			...observation,
			seq: completedWorkItems + 1,
			msg: [
				"DATA",
				{
					...(observation.msg[1] as Readonly<Record<string, unknown>>),
					replicate,
					completedArms,
					verificationDiagnostics: progressDiagnostics,
					activeProviderEffects: 0,
					activeToolEffects: 0,
					activeRetryEffects: 0,
					activeBillingEffects: 0,
					activeAdmittedEffects: 0,
					providerCapacity: {
						kind: "eval-provider-capacity-state",
						pacingRevision: completedWorkItems,
						providerStartIntervalMs: 30_000,
						consecutiveUsableResponses: completedWorkItems % 3,
						mode: "paced-serial",
						initialMaxConcurrentEffects: 1,
						maxConcurrentEffects: 1,
						activeEffects: 0,
						proposalCount: completedWorkItems,
						pendingProposalCount: 0,
						pendingFirstAttemptProposalCount: 0,
						pendingRetryProposalCount: 0,
						retryProposalCount: 0,
						admittedProposalCount: completedWorkItems,
						admittedRetryProposalCount: 0,
						settledProposalCount: completedWorkItems,
						settledRetryProposalCount: 0,
						rejectedProposalCount: 0,
						rejectedRetryProposalCount: 0,
						cooldownOutstandingReadinessCount: 0,
						rateLimitFeedbackCount: 0,
					},
					admittedAttempts: completedWorkItems,
					providerCallCount: completedWorkItems,
					providerReportedMicrousd,
					pricingRoundingAllowanceMicrousd: providerReportedMicrousd === 0 ? 0 : 1,
					providerReportedLowerBoundMicrousd: Math.max(0, providerReportedMicrousd - 1),
					accountedUpperBoundMicrousd: providerReportedMicrousd,
					observedBilledMicrousd: null,
					billingObservationCount: 0,
					billingStableIntervals: 0,
					reconciledBilledMicrousd: null,
					billingDisposition: "pending",
					providerOutcomeReasonCounts: {
						...fixtureProviderOutcomeReasonCounts,
						"tool-proposed": completedWorkItems,
					},
					developmentQualification: {
						kind: "eval-development-qualification-state",
						campaignPurpose: ROOT_EVAL_LIVE_CAMPAIGN_PURPOSE,
						generationRef: ROOT_EVAL_LIVE_GENERATION_REF,
						status: "pending",
						generationQualified: null,
						consecutiveQualifyingGenerations: 0,
						requiredConsecutiveGenerations: 2,
						heldOutEligible: false,
					},
					evaluableReplicates: null,
					excludedTechnicalReplicates: [],
					sourceTechnicalExcludedReplicates: [],
					matchedRelevantOverColdWins: null,
					stoppingReason: "none",
					finding: "pending",
				},
			] as never,
		};
	});
	const graphResult: RootEvalRunResult = {
		finding: {
			kind: "eval-efficacy-finding",
			campaignRef: ROOT_EVAL_LIVE_GENERATION_REF,
			replicateCount,
			armOrder: [
				"cold",
				"relevant-applied",
				"proposal-only",
				"admission-rejected",
				"irrelevant-applied",
				"wrong-scope-applied",
			],
			passCounts: {
				cold: 0,
				"relevant-applied": replicateCount,
				"proposal-only": 0,
				"admission-rejected": 0,
				"irrelevant-applied": 0,
				"wrong-scope-applied": 0,
			},
			evaluableReplicates: replicateCount,
			excludedTechnicalReplicates: [],
			sourceTechnicalExcludedReplicates: [],
			matchedRelevantOverColdWins: replicateCount,
			verificationDiagnostics,
			completedWorkItems: workItemCount,
			admittedAttempts: workItemCount,
			providerCallCount: workItemCount,
			activeReservedMicrousd: 0,
			providerReportedMicrousd: 100,
			pricingRoundingAllowanceMicrousd: 1,
			providerReportedLowerBoundMicrousd: 99,
			unreportedSettledUpperBoundMicrousd: 0,
			accountedUpperBoundMicrousd: 100,
			observedBilledMicrousd: 100,
			billingObservationCount: 4,
			billingStableIntervals: 3,
			reconciledBilledMicrousd: 100,
			billingDisposition: "reconciled",
			providerOutcomeReasonCounts: fixtureProviderOutcomeReasonCounts,
			finding: "positive-differential",
			stoppingReason: "campaign-complete",
		},
		observations: [...progressObservations, observation],
		peakConcurrentEffects: 1,
		executedAdmissionIds: admissionIds(workItemCount),
	};
	const observationValues = graphResult.observations.map((event) => event.msg[1] as never);
	for (const [index, value] of observationValues.entries())
		assertRootEvalObservationRuntimeShape(value, `fixture observation[${index}]`);
	assertRootEvalObservationSequence(observationValues, "fixture observation");
	return {
		claim,
		currentKeyBefore,
		currentKeyAfter,
		pricing: pricingObservation,
		zeroByok,
		providerCalls: workItemCount,
		graphResult,
		partialGraphObservations: graphResult.observations,
		failure: null,
		cleanupDisposition: "complete",
	};
}

async function currentClaimInput(privateRoot: string) {
	const nowMs = Date.now();
	const credential = parseRootEvalLiveCredential(
		new TextEncoder().encode("OPENROUTER_API_KEY=sk-or-v1-a44-middle-credential-e06\n"),
	);
	const pricing = await readRootEvalLivePricing({
		nowMs,
		fetchImpl: (async (url: string | URL | Request) => {
			const target = String(url);
			const body =
				target === ROOT_EVAL_LIVE_PRICING_SOURCE
					? {
							data: {
								id: "deepseek/deepseek-v4-flash-0731",
								endpoints: [
									{
										provider_name: "Together",
										tag: "together",
										quantization: "unknown",
										model_id: "deepseek/deepseek-v4-flash-0731",
										name: "Together | deepseek/deepseek-v4-flash-20260731",
										supported_parameters: [
											"max_tokens",
											"reasoning",
											"response_format",
											"structured_outputs",
										],
										pricing: {
											prompt: "0.00000014",
											completion: "0.00000028",
											input_cache_read: "0.00000003",
										},
									},
								],
							},
						}
					: {
							data: [
								{
									provider_name: "Together",
									tag: "together",
									model_id: "deepseek/deepseek-v4-flash-0731",
									name: "Together | deepseek/deepseek-v4-flash-20260731",
								},
							],
						};
			const response = new Response(JSON.stringify(body), { status: 200 });
			Object.defineProperty(response, "url", { value: target });
			return response;
		}) as typeof fetch,
	});
	const zeroByok = admitRootEvalLiveZeroByok({
		credential,
		nowMs,
		precredentialGateReceipt: precredentialGateReceipt(nowMs - 1),
		bytes: operatorConfigurationBytes(nowMs),
	});
	const currentKeyBefore = await readRootEvalLiveCurrentKey({
		credential,
		fetchImpl: (async () =>
			new Response(
				JSON.stringify({
					data: {
						limit: 32,
						limit_remaining: 13,
						usage: 19,
						limit_reset: null,
						is_management_key: false,
						rate_limit: { requests: 1, interval: "1d" },
					},
				}),
				{ status: 200 },
			)) as typeof fetch,
	});
	return {
		privateRoot,
		implementationCoordinate: `worktree:${"a".repeat(40)}:${ROOT_EVAL_CURRENT_IMPLEMENTATION_MANIFEST_DIGEST}`,
		implementationManifestDigest: ROOT_EVAL_CURRENT_IMPLEMENTATION_MANIFEST_DIGEST,
		qualificationArtifactDigest: ROOT_EVAL_CURRENT_QUALIFICATION_ARTIFACT_DIGEST,
		qualificationDigest: ROOT_EVAL_CURRENT_QUALIFICATION_DIGEST,
		taskBindingDigest: ROOT_EVAL_CURRENT_TASK_BINDING_DIGEST,
		taskManifestDigest: testTaskManifestDigest,
		pricing,
		zeroByok,
		credential,
		currentKeyBefore,
		partitionSpentBeforeMicrousd: 0,
		partitionLedgerDigest: testPartitionLedgerDigest,
		developmentQualificationStreakBefore: 0,
		nowMs,
	};
}

function refreshedCurrentKeys(input: RootEvalLiveEvidenceInput): RootEvalLiveEvidenceInput {
	const refresh = <T extends { readonly admissionDigest: string }>(value: T | null): T | null => {
		if (value === null) return null;
		const { admissionDigest: _digest, ...material } = value;
		return { ...material, admissionDigest: empiricalStrictJsonDigest(material) } as T;
	};
	const refreshed = {
		...input,
		currentKeyBefore: refresh(input.currentKeyBefore),
		currentKeyAfter: refresh(input.currentKeyAfter),
	};
	return withRehashedClaim(refreshed, {
		currentKeyBeforeDigest: refreshed.currentKeyBefore?.admissionDigest ?? null,
	});
}

function withRehashedCurrentKey(
	input: RootEvalLiveEvidenceInput,
	which: "before" | "after",
	patch: Readonly<Record<string, unknown>>,
): RootEvalLiveEvidenceInput {
	const key = which === "before" ? "currentKeyBefore" : "currentKeyAfter";
	const current = input[key];
	if (current === null) throw new TypeError("test current key missing");
	const { admissionDigest: _digest, ...material } = current;
	const mutated = { ...material, ...patch };
	return {
		...input,
		[key]: { ...mutated, admissionDigest: empiricalStrictJsonDigest(mutated) },
	} as RootEvalLiveEvidenceInput;
}

function withRehashedClaim(
	input: RootEvalLiveEvidenceInput,
	patch: Readonly<Record<string, unknown>>,
): RootEvalLiveEvidenceInput {
	const { claimDigest: _digest, ...current } = input.claim;
	const material = { ...current, ...patch };
	return {
		...input,
		claim: { ...material, claimDigest: empiricalStrictJsonDigest(material) } as never,
	};
}

function withRehashedPricing(
	input: RootEvalLiveEvidenceInput,
	patch: Readonly<Record<string, unknown>>,
): RootEvalLiveEvidenceInput {
	const { observationDigest: _digest, ...current } = input.pricing;
	const material = { ...current, ...patch };
	const pricingObservation = {
		...material,
		observationDigest: empiricalStrictJsonDigest(material),
	} as never;
	return withRehashedClaim(
		{ ...input, pricing: pricingObservation },
		{ pricingObservationDigest: pricingObservation.observationDigest },
	);
}

function withRehashedZeroByok(
	input: RootEvalLiveEvidenceInput,
	patch: Readonly<Record<string, unknown>>,
): RootEvalLiveEvidenceInput {
	const { observationDigest: _digest, ...current } = input.zeroByok;
	const material = { ...current, ...patch };
	const zeroByok = { ...material, observationDigest: empiricalStrictJsonDigest(material) } as never;
	return withRehashedClaim(
		{ ...input, zeroByok },
		{ zeroByokObservationDigest: zeroByok.observationDigest },
	);
}

function withGraphResult(
	input: RootEvalLiveEvidenceInput,
	graphPatch: Partial<RootEvalRunResult> = {},
	findingPatch: Partial<RootEvalRunResult["finding"]> = {},
): RootEvalLiveEvidenceInput {
	if (input.graphResult === null) throw new TypeError("test graph result missing");
	const graphResult = {
		...input.graphResult,
		...graphPatch,
		finding: { ...input.graphResult.finding, ...findingPatch },
	};
	return { ...input, graphResult, partialGraphObservations: graphResult.observations };
}

function withTerminalObservation(
	input: RootEvalLiveEvidenceInput,
	patch: Readonly<Record<string, unknown>>,
): RootEvalLiveEvidenceInput {
	if (input.graphResult === null) throw new TypeError("test graph result missing");
	const event = input.graphResult.observations.at(-1);
	if (event === undefined || event.msg[0] !== "DATA")
		throw new TypeError("test terminal observation missing");
	const observation = event.msg[1] as unknown as Readonly<Record<string, unknown>>;
	const pendingBillingPatch =
		patch.finding === "pending"
			? {
					evaluableReplicates: null,
					excludedTechnicalReplicates: [],
					sourceTechnicalExcludedReplicates: [],
					matchedRelevantOverColdWins: null,
					observedBilledMicrousd: null,
					billingObservationCount: 0,
					billingStableIntervals: 0,
					reconciledBilledMicrousd: null,
					billingDisposition: "pending",
				}
			: {};
	return withGraphResult(input, {
		observations: [
			...input.graphResult.observations.slice(0, -1),
			{ ...event, msg: ["DATA", { ...observation, ...pendingBillingPatch, ...patch }] as never },
		],
	});
}

function withRejectedBillingTerminal(input: RootEvalLiveEvidenceInput): RootEvalLiveEvidenceInput {
	const billingPatch = {
		providerReportedMicrousd: 85_284,
		pricingRoundingAllowanceMicrousd: 22,
		providerReportedLowerBoundMicrousd: 85_262,
		unreportedSettledUpperBoundMicrousd: 0,
		accountedUpperBoundMicrousd: 85_284,
		observedBilledMicrousd: 85_261,
		billingObservationCount: 4,
		billingStableIntervals: 3,
		reconciledBilledMicrousd: 0,
		billingDisposition: "rejected" as const,
		stoppingReason: "campaign-complete" as const,
	};
	const findingInput = withGraphResult(input, {}, billingPatch);
	return withTerminalObservation(findingInput, billingPatch);
}

describe("D145 live-boundary qualification over immutable D116/D117 and D118/D120 evidence", () => {
	it("releases resolved reservations from the latest Graph spend snapshot", () => {
		expect(
			latestRootEvalGraphSpend([
				{
					providerReportedMicrousd: 4_718,
					unreportedSettledUpperBoundMicrousd: 0,
					activeReservedMicrousd: 400_000,
				},
				{
					providerReportedMicrousd: 6_419,
					unreportedSettledUpperBoundMicrousd: 0,
					activeReservedMicrousd: 0,
				},
			]),
		).toEqual({
			providerReportedMicrousd: 6_419,
			unreportedSettledUpperBoundMicrousd: 0,
			accountedUpperBoundMicrousd: 6_419,
		});
	});

	it("opens a fresh D152 qualification epoch without inheriting historical efficacy authority", () => {
		const epoch = createRootEvalD152QualificationEpoch({
			supersededHistoricalLedgerDigest: `sha256:${"a".repeat(64)}`,
			carriedDevelopmentSpentMicrousd: 12_000_000,
			carriedConfirmatorySpentMicrousd: 500_000,
		});
		expect(epoch).toMatchObject({
			decisionRef: "graphrefly-ts:D152",
			developmentQualificationStreak: 0,
			heldOutSealDigest: null,
			heldOutConsumed: false,
			developmentManifestSlots: ["development-1", "development-2"],
			carriedDevelopmentSpentMicrousd: 12_000_000,
			carriedConfirmatorySpentMicrousd: 500_000,
		});
		expect(epoch.epochDigest).toMatch(/^sha256:[0-9a-f]{64}$/u);
		expect(() =>
			createRootEvalD152QualificationEpoch({
				supersededHistoricalLedgerDigest: "not-a-digest",
				carriedDevelopmentSpentMicrousd: 0,
				carriedConfirmatorySpentMicrousd: 0,
			}),
		).toThrow(/historical ledger digest/u);
	});

	it("starts the D156 efficacy streak at development-3 even when older entries qualified", () => {
		let ledger = createRootEvalD152Ledger(ROOT_EVAL_D145_EMPTY_CHARTER_LEDGER);
		const advanceQualified = (ordinal: number, consecutiveQualifyingGenerations: number) =>
			advanceRootEvalD152Ledger({
				ledger,
				generationRef: rootEvalD152DevelopmentGenerationRef(ordinal),
				taskSetRef: rootEvalDevelopmentTaskSetRef(ordinal),
				taskManifestDigest: empiricalStrictJsonDigest(["d156-epoch-manifest", ordinal]),
				providerReportedMicrousd: 0,
				unreportedSettledUpperBoundMicrousd: 0,
				accountedUpperBoundMicrousd: 0,
				admissionStatus: "admitted",
				developmentQualification: {
					kind: "eval-development-qualification-state",
					campaignPurpose: "development",
					generationRef: rootEvalD152DevelopmentGenerationRef(ordinal),
					status: "qualified",
					generationQualified: true,
					consecutiveQualifyingGenerations,
					requiredConsecutiveGenerations: 2,
					heldOutEligible: consecutiveQualifyingGenerations === 2,
				},
				evidenceDigest: empiricalStrictJsonDigest(["d156-epoch-evidence", ordinal]),
			});
		ledger = advanceQualified(1, 0);
		expect(ledger.developmentQualificationStreak).toBe(0);
		ledger = advanceQualified(2, 0);
		expect(ledger.developmentQualificationStreak).toBe(0);
		ledger = advanceQualified(3, 1);
		expect(ledger.developmentQualificationStreak).toBe(1);
	});

	it("retains old partition receipts while the approved development-3 cap reaches exactly USD 40", () => {
		let historical = ROOT_EVAL_D145_EMPTY_CHARTER_LEDGER;
		for (const [index, cost] of [12_000_000, 12_000_000, 4_000_000].entries()) {
			historical = advanceRootEvalD145CharterLedger({
				ledger: historical,
				generationRef: rootEvalD145DevelopmentGenerationRef(index + 1),
				campaignPurpose: "development",
				taskSetRef: rootEvalD145DevelopmentTaskSetRef(index + 1),
				taskManifestDigest: empiricalStrictJsonDigest(["cap-test-historical-manifest", index]),
				budgetPartition: "development-usd-36",
				providerReportedMicrousd: cost,
				unreportedSettledUpperBoundMicrousd: 0,
				accountedUpperBoundMicrousd: cost,
				admissionStatus: "rejected",
				developmentQualification: null,
				evidenceDigest: empiricalStrictJsonDigest(["cap-test-historical-evidence", index]),
			});
		}
		let ledger = createRootEvalD152Ledger(historical);
		const advance = (ordinal: number, reported: number, unknown: number) =>
			advanceRootEvalD152Ledger({
				ledger,
				generationRef: rootEvalD152DevelopmentGenerationRef(ordinal),
				taskSetRef: rootEvalDevelopmentTaskSetRef(ordinal),
				taskManifestDigest: empiricalStrictJsonDigest(["cap-test-manifest", ordinal]),
				providerReportedMicrousd: reported,
				unreportedSettledUpperBoundMicrousd: unknown,
				accountedUpperBoundMicrousd: reported + unknown,
				admissionStatus: "rejected",
				developmentQualification: null,
				evidenceDigest: empiricalStrictJsonDigest(["cap-test-evidence", ordinal]),
			});
		ledger = advance(1, 3_727_166, 0);
		ledger = advance(2, 93_139, 4_000_000);
		const historicEntries = JSON.stringify(ledger.entries);
		expect(ledger.developmentSpentMicrousd).toBe(35_820_305);
		expect(() => advance(3, 4_179_696, 0)).toThrow(/spend boundary/);
		const next = advance(3, 4_179_695, 0);
		expect(next.developmentSpentMicrousd).toBe(40_000_000);
		expect(JSON.stringify(next.entries.slice(0, 2))).toBe(historicEntries);
		expect(next.entries[1]!.unreportedSettledUpperBoundMicrousd).toBe(4_000_000);
		expect(next.entries.map((entry) => entry.budgetPartition)).toEqual([
			"development-usd-36",
			"development-usd-36",
			"development-usd-40",
		]);
		expect(next.confirmatorySpentMicrousd).toBe(0);
		expect(next.heldOutConsumed).toBe(false);
		expect(nextRootEvalD152DevelopmentOrdinal(next)).toBe(4);
	});

	it("carries historical spend but resets efficacy authority in the durable D152 ledger", () => {
		const historical = advanceRootEvalD145CharterLedger({
			ledger: ROOT_EVAL_D145_EMPTY_CHARTER_LEDGER,
			generationRef: rootEvalD145DevelopmentGenerationRef(1),
			campaignPurpose: "development",
			taskSetRef: rootEvalD145DevelopmentTaskSetRef(1),
			taskManifestDigest: empiricalStrictJsonDigest("historical-manifest"),
			budgetPartition: "development-usd-36",
			providerReportedMicrousd: 1_000,
			unreportedSettledUpperBoundMicrousd: 0,
			accountedUpperBoundMicrousd: 1_000,
			admissionStatus: "admitted",
			developmentQualification: {
				kind: "eval-development-qualification-state",
				campaignPurpose: "development",
				generationRef: rootEvalD145DevelopmentGenerationRef(1),
				status: "qualified",
				generationQualified: true,
				consecutiveQualifyingGenerations: 1,
				requiredConsecutiveGenerations: 2,
				relevantPasses: 5,
				bestControlPasses: 0,
				irrelevantPasses: 0,
				requiredMargin: 2,
			},
			evidenceDigest: empiricalStrictJsonDigest("historical-evidence"),
		});
		const opened = createRootEvalD152Ledger(historical);
		expect(opened).toMatchObject({
			schemaVersion: ROOT_EVAL_D152_LEDGER_SCHEMA,
			decisionRef: "graphrefly-ts:D152",
			supersededHistoricalLedgerDigest: historical.ledgerDigest,
			carriedDevelopmentSpentMicrousd: 1_000,
			developmentSpentMicrousd: 1_000,
			developmentQualificationStreak: 0,
			heldOutSealDigest: null,
			heldOutConsumed: false,
			entries: [],
		});
		const next = advanceRootEvalD152Ledger({
			ledger: opened,
			generationRef: rootEvalD152DevelopmentGenerationRef(1),
			taskSetRef: rootEvalDevelopmentTaskSetRef(1),
			taskManifestDigest: empiricalStrictJsonDigest("d152-development-1-manifest"),
			providerReportedMicrousd: 2_000,
			unreportedSettledUpperBoundMicrousd: 0,
			accountedUpperBoundMicrousd: 2_000,
			admissionStatus: "rejected",
			developmentQualification: null,
			evidenceDigest: empiricalStrictJsonDigest("d152-development-1-evidence"),
		});
		expect(next.developmentSpentMicrousd).toBe(3_000);
		expect(next.entries).toHaveLength(1);
		expect(next.developmentQualificationStreak).toBe(0);
		expect(() =>
			advanceRootEvalD152Ledger({
				ledger: opened,
				generationRef: rootEvalD152DevelopmentGenerationRef(1),
				taskSetRef: rootEvalDevelopmentTaskSetRef(1),
				taskManifestDigest: empiricalStrictJsonDigest("overspend-manifest"),
				providerReportedMicrousd: 12_000_001,
				unreportedSettledUpperBoundMicrousd: 0,
				accountedUpperBoundMicrousd: 12_000_001,
				admissionStatus: "rejected",
				developmentQualification: null,
				evidenceDigest: empiricalStrictJsonDigest("overspend-evidence"),
			}),
		).toThrow(/accounted upper bound|spend boundary/u);
	});

	it("atomically conserves historical D145 spend partitions and its old development gate", async () => {
		const temporary = await mkdtemp(join(tmpdir(), "graphrefly-d145-charter-ledger-"));
		const path = join(await realpath(temporary), "charter.json");
		try {
			const empty = await readRootEvalD145CharterLedger(path);
			expect(empty).toEqual(ROOT_EVAL_D145_EMPTY_CHARTER_LEDGER);
			expect(ROOT_EVAL_D145_DEVELOPMENT_HARD_CAP_MICROUSD).toBe(36_000_000);
			expect(ROOT_EVAL_D145_DEVELOPMENT_GENERATION_HARD_CAP_MICROUSD).toBe(12_000_000);
			expect(ROOT_EVAL_D145_CONFIRMATORY_HARD_CAP_MICROUSD).toBe(6_000_000);
			expect(ROOT_EVAL_D145_CONFIRMATORY_GENERATION_HARD_CAP_MICROUSD).toBe(6_000_000);
			expect(ROOT_EVAL_D145_TOTAL_HARD_CAP_MICROUSD).toBe(42_000_000);
			const qualified = (count: 1 | 2) => ({
				kind: "eval-development-qualification-state" as const,
				campaignPurpose: "development" as const,
				generationRef: `development-${count}`,
				status: "qualified" as const,
				generationQualified: true as const,
				consecutiveQualifyingGenerations: count,
				requiredConsecutiveGenerations: 2 as const,
				heldOutEligible: count === 2,
			});
			const first = advanceRootEvalD145CharterLedger({
				ledger: empty,
				generationRef: rootEvalD145DevelopmentGenerationRef(1),
				campaignPurpose: "development",
				taskSetRef: rootEvalD145DevelopmentTaskSetRef(1),
				taskManifestDigest: empiricalStrictJsonDigest("development-1-manifest"),
				budgetPartition: "development-usd-36",
				providerReportedMicrousd: 101,
				unreportedSettledUpperBoundMicrousd: 0,
				accountedUpperBoundMicrousd: 101,
				admissionStatus: "admitted",
				developmentQualification: qualified(1),
				evidenceDigest: empiricalStrictJsonDigest("development-1-evidence"),
			});
			await writeRootEvalD145CharterLedger(path, first);
			expect((await stat(path)).mode & 0o777).toBe(0o600);
			expect(await readRootEvalD145CharterLedger(path)).toEqual(first);
			expect(nextRootEvalD145DevelopmentOrdinal(first)).toBe(2);
			expect(() =>
				advanceRootEvalD145CharterLedger({
					ledger: first,
					generationRef: rootEvalD145DevelopmentGenerationRef(3),
					campaignPurpose: "development",
					taskSetRef: rootEvalD145DevelopmentTaskSetRef(3),
					taskManifestDigest: empiricalStrictJsonDigest("unproven-gap-manifest"),
					budgetPartition: "development-usd-36",
					providerReportedMicrousd: 0,
					unreportedSettledUpperBoundMicrousd: 0,
					accountedUpperBoundMicrousd: 0,
					admissionStatus: "rejected",
					developmentQualification: null,
					evidenceDigest: empiricalStrictJsonDigest("unproven-gap-evidence"),
				}),
			).toThrow(/development generation order/u);
			const rejectedCandidate = advanceRootEvalD145CharterLedger({
				ledger: first,
				generationRef: rootEvalD145DevelopmentGenerationRef(2),
				campaignPurpose: "development",
				taskSetRef: rootEvalD145DevelopmentTaskSetRef(2),
				taskManifestDigest: empiricalStrictJsonDigest("development-rejected-manifest"),
				budgetPartition: "development-usd-36",
				providerReportedMicrousd: 1,
				unreportedSettledUpperBoundMicrousd: 0,
				accountedUpperBoundMicrousd: 1,
				admissionStatus: "rejected",
				developmentQualification: qualified(2),
				evidenceDigest: empiricalStrictJsonDigest("development-rejected-evidence"),
			});
			expect(rejectedCandidate).toMatchObject({
				developmentQualificationStreak: 0,
				entries: expect.arrayContaining([
					expect.objectContaining({
						generationRef: rootEvalD145DevelopmentGenerationRef(2),
						generationQualified: false,
					}),
				]),
			});
			const { ledgerDigest: _rejectedDigest, ...rejectedMaterial } = rejectedCandidate;
			const gappedMaterial = Object.freeze({
				...rejectedMaterial,
				entries: Object.freeze([
					rejectedCandidate.entries[0]!,
					Object.freeze({
						...rejectedCandidate.entries[1]!,
						generationRef: rootEvalD145DevelopmentGenerationRef(3),
						taskSetRef: rootEvalD145DevelopmentTaskSetRef(3),
					}),
				]),
			});
			expect(() =>
				nextRootEvalD145DevelopmentOrdinal({
					...gappedMaterial,
					ledgerDigest: empiricalStrictJsonDigest(gappedMaterial),
				}),
			).toThrow(/conservation invalid/u);
			const staleStreakMaterial = Object.freeze({
				...rejectedMaterial,
				developmentQualificationStreak: 1,
			});
			expect(() =>
				nextRootEvalD145DevelopmentOrdinal({
					...staleStreakMaterial,
					ledgerDigest: empiricalStrictJsonDigest(staleStreakMaterial),
				}),
			).toThrow(/conservation invalid/u);
			expect(() =>
				advanceRootEvalD145CharterLedger({
					ledger: first,
					generationRef: "confirmatory-too-early",
					campaignPurpose: "confirmatory",
					taskSetRef: ROOT_EVAL_D145_HISTORICAL_CONFIRMATORY_TASK_SET_REF,
					taskManifestDigest: ROOT_EVAL_D145_HISTORICAL_HELD_OUT_SEAL_DIGEST,
					budgetPartition: "confirmatory-usd-6",
					providerReportedMicrousd: 1,
					unreportedSettledUpperBoundMicrousd: 0,
					accountedUpperBoundMicrousd: 1,
					admissionStatus: "admitted",
					developmentQualification: null,
					evidenceDigest: empiricalStrictJsonDigest("too-early"),
				}),
			).toThrow(/not authorized/u);
			const second = advanceRootEvalD145CharterLedger({
				ledger: first,
				generationRef: rootEvalD145DevelopmentGenerationRef(2),
				campaignPurpose: "development",
				taskSetRef: rootEvalD145DevelopmentTaskSetRef(2),
				taskManifestDigest: empiricalStrictJsonDigest("development-2-manifest"),
				budgetPartition: "development-usd-36",
				providerReportedMicrousd: 202,
				unreportedSettledUpperBoundMicrousd: 0,
				accountedUpperBoundMicrousd: 202,
				admissionStatus: "admitted",
				developmentQualification: qualified(2),
				evidenceDigest: empiricalStrictJsonDigest("development-2-evidence"),
			});
			const confirmatory = advanceRootEvalD145CharterLedger({
				ledger: second,
				generationRef: "confirmatory-1",
				campaignPurpose: "confirmatory",
				taskSetRef: ROOT_EVAL_D145_HISTORICAL_CONFIRMATORY_TASK_SET_REF,
				taskManifestDigest: ROOT_EVAL_D145_HISTORICAL_HELD_OUT_SEAL_DIGEST,
				budgetPartition: "confirmatory-usd-6",
				providerReportedMicrousd: 303,
				unreportedSettledUpperBoundMicrousd: 0,
				accountedUpperBoundMicrousd: 303,
				admissionStatus: "admitted",
				developmentQualification: {
					kind: "eval-development-qualification-state",
					campaignPurpose: "confirmatory",
					generationRef: "confirmatory-1",
					status: "not-applicable",
					generationQualified: null,
					consecutiveQualifyingGenerations: 2,
					requiredConsecutiveGenerations: 2,
					heldOutEligible: true,
				},
				evidenceDigest: empiricalStrictJsonDigest("confirmatory-evidence"),
			});
			expect(confirmatory).toMatchObject({
				developmentSpentMicrousd: 303,
				confirmatorySpentMicrousd: 303,
				developmentQualificationStreak: 2,
				heldOutConsumed: true,
			});
			expect(() =>
				reconcileRootEvalD145ConsumedPreclaimFailure({
					ledger: confirmatory,
					generationRef: rootEvalD145DevelopmentGenerationRef(3),
					taskSetRef: rootEvalD145DevelopmentTaskSetRef(3),
					taskManifestDigest: empiricalStrictJsonDigest("post-held-out-manifest"),
					receiptDigest: empiricalStrictJsonDigest("post-held-out-receipt"),
				}),
			).toThrow(/not authorized/u);
			const { ledgerDigest: _confirmatoryDigest, ...confirmatoryMaterial } = confirmatory;
			const postHeldOutDevelopmentMaterial = Object.freeze({
				...confirmatoryMaterial,
				developmentQualificationStreak: 0,
				entries: Object.freeze([
					...confirmatory.entries,
					Object.freeze({
						generationRef: rootEvalD145DevelopmentGenerationRef(3),
						campaignPurpose: "development" as const,
						taskSetRef: rootEvalD145DevelopmentTaskSetRef(3),
						taskManifestDigest: empiricalStrictJsonDigest("post-held-out-ledger-manifest"),
						budgetPartition: "development-usd-36" as const,
						providerReportedMicrousd: 0,
						unreportedSettledUpperBoundMicrousd: 0,
						accountedUpperBoundMicrousd: 0,
						generationQualified: false,
						evidenceDigest: empiricalStrictJsonDigest("post-held-out-ledger-evidence"),
					}),
				]),
			});
			expect(() =>
				nextRootEvalD145DevelopmentOrdinal({
					...postHeldOutDevelopmentMaterial,
					ledgerDigest: empiricalStrictJsonDigest(postHeldOutDevelopmentMaterial),
				}),
			).toThrow(/conservation invalid/u);
			expect(() =>
				advanceRootEvalD145CharterLedger({
					ledger: second,
					generationRef: "confirmatory-over-cap",
					campaignPurpose: "confirmatory",
					taskSetRef: ROOT_EVAL_D145_HISTORICAL_CONFIRMATORY_TASK_SET_REF,
					taskManifestDigest: ROOT_EVAL_D145_HISTORICAL_HELD_OUT_SEAL_DIGEST,
					budgetPartition: "confirmatory-usd-6",
					providerReportedMicrousd: 6_000_001,
					unreportedSettledUpperBoundMicrousd: 0,
					accountedUpperBoundMicrousd: 6_000_001,
					admissionStatus: "admitted",
					developmentQualification: null,
					evidenceDigest: empiricalStrictJsonDigest("confirmatory-over-cap"),
				}),
			).toThrow(/hard cap/u);
			expect(() =>
				advanceRootEvalD145CharterLedger({
					ledger: confirmatory,
					generationRef: "confirmatory-2",
					campaignPurpose: "confirmatory",
					taskSetRef: ROOT_EVAL_D145_HISTORICAL_CONFIRMATORY_TASK_SET_REF,
					taskManifestDigest: ROOT_EVAL_D145_HISTORICAL_HELD_OUT_SEAL_DIGEST,
					budgetPartition: "confirmatory-usd-6",
					providerReportedMicrousd: 1,
					unreportedSettledUpperBoundMicrousd: 0,
					accountedUpperBoundMicrousd: 1,
					admissionStatus: "admitted",
					developmentQualification: null,
					evidenceDigest: empiricalStrictJsonDigest("confirmatory-2"),
				}),
			).toThrow(/not authorized/u);
		} finally {
			await rm(temporary, { recursive: true, force: true });
		}
	});

	it("preserves historical USD 6/12 development entries while admitting only the USD 36 partition", async () => {
		const historicalEntry = Object.freeze({
			generationRef: rootEvalD145DevelopmentGenerationRef(1),
			campaignPurpose: "development" as const,
			taskSetRef: "root-eval-d145-transfer-development-1-v1",
			taskManifestDigest: empiricalStrictJsonDigest("historical-development-manifest"),
			budgetPartition: "development-usd-6" as const,
			providerReportedMicrousd: 5_900_000,
			unreportedSettledUpperBoundMicrousd: 0,
			accountedUpperBoundMicrousd: 5_900_000,
			generationQualified: false,
			evidenceDigest: empiricalStrictJsonDigest("historical-development-evidence"),
		});
		const historicalUsd12Entry = Object.freeze({
			generationRef: rootEvalD145DevelopmentGenerationRef(2),
			campaignPurpose: "development" as const,
			taskSetRef: "root-eval-d145-transfer-development-2-v1",
			taskManifestDigest: empiricalStrictJsonDigest("historical-development-usd-12-manifest"),
			budgetPartition: "development-usd-12" as const,
			providerReportedMicrousd: 6_000_000,
			unreportedSettledUpperBoundMicrousd: 0,
			accountedUpperBoundMicrousd: 6_000_000,
			generationQualified: false,
			evidenceDigest: empiricalStrictJsonDigest("historical-development-usd-12-evidence"),
		});
		const historicalMaterial = Object.freeze({
			schemaVersion: ROOT_EVAL_D145_EMPTY_CHARTER_LEDGER.schemaVersion,
			decisionRef: ROOT_EVAL_D145_EMPTY_CHARTER_LEDGER.decisionRef,
			heldOutSealDigest: ROOT_EVAL_D145_EMPTY_CHARTER_LEDGER.heldOutSealDigest,
			supersededLedgerDigest: null,
			developmentSpentMicrousd: 11_900_000,
			confirmatorySpentMicrousd: 0,
			developmentQualificationStreak: 0,
			heldOutConsumed: false,
			entries: Object.freeze([historicalEntry, historicalUsd12Entry]),
		});
		const historicalLedger = Object.freeze({
			...historicalMaterial,
			ledgerDigest: empiricalStrictJsonDigest(historicalMaterial),
		});
		const extended = advanceRootEvalD145CharterLedger({
			ledger: historicalLedger,
			generationRef: rootEvalD145DevelopmentGenerationRef(3),
			campaignPurpose: "development",
			taskSetRef: rootEvalD145DevelopmentTaskSetRef(3),
			taskManifestDigest: empiricalStrictJsonDigest("development-3-usd-36-manifest"),
			budgetPartition: "development-usd-36",
			providerReportedMicrousd: 200_001,
			unreportedSettledUpperBoundMicrousd: 0,
			accountedUpperBoundMicrousd: 200_001,
			admissionStatus: "rejected",
			developmentQualification: null,
			evidenceDigest: empiricalStrictJsonDigest("development-3-usd-36-evidence"),
		});
		expect(extended).toMatchObject({
			developmentSpentMicrousd: 12_100_001,
			entries: [
				expect.objectContaining({ budgetPartition: "development-usd-6" }),
				expect.objectContaining({ budgetPartition: "development-usd-12" }),
				expect.objectContaining({ budgetPartition: "development-usd-36" }),
			],
		});
		expect(() =>
			advanceRootEvalD145CharterLedger({
				ledger: historicalLedger,
				generationRef: rootEvalD145DevelopmentGenerationRef(3),
				campaignPurpose: "development",
				taskSetRef: rootEvalD145DevelopmentTaskSetRef(3),
				taskManifestDigest: empiricalStrictJsonDigest("development-3-old-partition-manifest"),
				budgetPartition: "development-usd-12" as never,
				providerReportedMicrousd: 1,
				unreportedSettledUpperBoundMicrousd: 0,
				accountedUpperBoundMicrousd: 1,
				admissionStatus: "rejected",
				developmentQualification: null,
				evidenceDigest: empiricalStrictJsonDigest("development-3-old-partition-evidence"),
			}),
		).toThrow(/not authorized/u);
		expect(() =>
			advanceRootEvalD145CharterLedger({
				ledger: historicalLedger,
				generationRef: rootEvalD145DevelopmentGenerationRef(3),
				campaignPurpose: "development",
				taskSetRef: rootEvalDevelopmentTaskSetRef(3),
				taskManifestDigest: empiricalStrictJsonDigest("rebound-d145-manifest"),
				budgetPartition: "development-usd-36",
				providerReportedMicrousd: 0,
				unreportedSettledUpperBoundMicrousd: 0,
				accountedUpperBoundMicrousd: 0,
				admissionStatus: "rejected",
				developmentQualification: null,
				evidenceDigest: empiricalStrictJsonDigest("rebound-d145-evidence"),
			}),
		).toThrow(/task manifest transition was not authorized/u);
	});

	it("binds exact fresh D152 currentness and rejects synthetic live authority", async () => {
		expect(ROOT_EVAL_LIVE_DECISION_REF).toBe("graphrefly-ts:D152");
		expect(ROOT_EVAL_LIVE_CLAIM_SCHEMA).toBe("graphrefly-ts.root-eval-live-claim.v21");
		expect(ROOT_EVAL_LIVE_EVIDENCE_SCHEMA).toBe("graphrefly-ts.root-eval-live-evidence.v27");
		expect(ROOT_EVAL_LIVE_PRECLAIM_FAILURE_SCHEMA).toBe(
			"graphrefly-ts.root-eval-live-preclaim-failure.v21",
		);
		expect(ROOT_EVAL_LIVE_CLAIM_REF).toBe("root-eval-development-claim-2026-09-01-d152-v1");
		expect(ROOT_EVAL_LIVE_GENERATION_REF).toBe("root-eval-development-2026-09-01-d152-v1");
		expect(ROOT_EVAL_LIVE_BUDGET_PARTITION).toBe("development-usd-36");
		expect(ROOT_EVAL_LIVE_PARTITION_HARD_CAP_MICROUSD).toBe(36_000_000);
		expect(ROOT_EVAL_LIVE_CAMPAIGN_HARD_CAP_MICROUSD).toBe(12_000_000);
		const temporary = await mkdtemp(join(tmpdir(), "graphrefly-root-eval-d140-synthetic-live-"));
		const privateRoot = await realpath(temporary);
		await chmod(privateRoot, 0o700);
		try {
			await expect(acquireRootEvalLiveClaim(await currentClaimInput(privateRoot))).rejects.toThrow(
				/authority-provenance/u,
			);
			expect(await readdir(privateRoot)).toEqual([]);
		} finally {
			await rm(temporary, { recursive: true, force: true });
		}
	});

	it("keeps confirmatory authority on its sealed USD 6 partition", async () => {
		const moduleUrl = pathToFileURL(
			resolve(
				repositoryRoot,
				"packages/ts/evals/graph-native-rerun-avoidance/root-eval-live-authority.ts",
			),
		).href;
		const source = `
			const authority = await import(${JSON.stringify(moduleUrl)});
			process.stdout.write(JSON.stringify({
				purpose: authority.ROOT_EVAL_LIVE_CAMPAIGN_PURPOSE,
				partition: authority.ROOT_EVAL_LIVE_BUDGET_PARTITION,
				hardCapMicrousd: authority.ROOT_EVAL_LIVE_CAMPAIGN_HARD_CAP_MICROUSD,
			}));
		`;
		const result = await new Promise<
			Readonly<{ readonly code: number | null; readonly stdout: string; readonly stderr: string }>
		>((resolveResult, reject) => {
			const child = spawn(
				process.execPath,
				["--import", "tsx", "--input-type=module", "--eval", source],
				{
					cwd: repositoryRoot,
					env: { ...process.env, GRAPHREFLY_ROOT_EVAL_CAMPAIGN_SLOT: "confirmatory" },
					shell: false,
					stdio: ["ignore", "pipe", "pipe"],
				},
			);
			let stdout = "";
			let stderr = "";
			child.stdout.setEncoding("utf8");
			child.stderr.setEncoding("utf8");
			child.stdout.on("data", (chunk: string) => {
				stdout += chunk;
			});
			child.stderr.on("data", (chunk: string) => {
				stderr += chunk;
			});
			child.once("error", reject);
			child.once("close", (code) => resolveResult({ code, stdout, stderr }));
		});
		expect(result.code, result.stderr).toBe(0);
		expect(JSON.parse(result.stdout)).toEqual({
			purpose: "confirmatory",
			partition: "confirmatory-usd-6",
			hardCapMicrousd: 5_477_518,
		});
	});
	it("uses the exact shared private-input identity gate before preclaim", async () => {
		const temporary = await mkdtemp(join(tmpdir(), "graphrefly-root-eval-d116-private-inputs-"));
		const canonicalTemporary = await realpath(temporary);
		const inputRoot = join(canonicalTemporary, "inputs");
		const privateRoot = join(canonicalTemporary, "private");
		const credentialPath = join(inputRoot, "openrouter.env");
		const zeroByokPath = join(inputRoot, "fresh-zero-byok-d140.v15.json");
		const observedAtMs = Date.now();
		try {
			await mkdir(inputRoot, { mode: 0o700 });
			await mkdir(privateRoot, { mode: 0o700 });
			await persistRootEvalLivePrecredentialGateReceipt({
				privateRoot,
				currentness: boundedCurrentness,
				completedAtMs: observedAtMs - 1,
			});
			await writeFile(credentialPath, "OPENROUTER_API_KEY=sk-or-v1-a44-middle-credential-e06\n", {
				mode: 0o600,
			});
			await chmod(credentialPath, 0o600);
			await writeFile(zeroByokPath, operatorConfigurationBytes(observedAtMs), { mode: 0o644 });
			await chmod(zeroByokPath, 0o644);
			await expect(
				qualifyRootEvalLivePrivateInputs({
					credentialPath,
					zeroByokPath,
					precredentialPrivateRoot: privateRoot,
					currentness: boundedCurrentness,
					nowMs: observedAtMs,
				}),
			).rejects.toThrow(/private input identity/u);

			await chmod(zeroByokPath, 0o600);
			await expect(
				qualifyRootEvalLivePrivateInputs({
					credentialPath,
					zeroByokPath,
					precredentialPrivateRoot: privateRoot,
					currentness: boundedCurrentness,
					nowMs: observedAtMs,
				}),
			).resolves.toMatchObject({
				credential: {
					bindingRef: "openrouter.local-eval-2",
					bindingRevision: "2026-09-01.d152.v1",
				},
				zeroByok: {
					workspaceSlug: "graph-re-fly",
					keyName: "Local Eval 2",
					byokCredentialCount: 0,
					observationDigest: expect.stringMatching(/^sha256:[0-9a-f]{64}$/u),
				},
			});
		} finally {
			await rm(temporary, { force: true, recursive: true });
		}
	});
	it("installs an explicitly supplied operator configuration atomically and mode-0600", async () => {
		const temporary = await mkdtemp(join(tmpdir(), "graphrefly-root-eval-d149-config-update-"));
		const root = await realpath(temporary);
		const credentialPath = join(root, "openrouter.env");
		const candidatePath = join(root, "candidate.json");
		const targetPath = join(root, ROOT_EVAL_LIVE_OPERATOR_CONFIGURATION_NAME);
		const nowMs = Date.now();
		const candidateBytes = operatorConfigurationBytes(nowMs);
		try {
			await chmod(root, 0o700);
			await writeFile(credentialPath, "OPENROUTER_API_KEY=sk-or-v1-a44-middle-credential-e06\n", {
				mode: 0o600,
			});
			await writeFile(candidatePath, candidateBytes, { mode: 0o600 });
			await writeFile(targetPath, operatorConfigurationBytes(nowMs - 1), { mode: 0o600 });
			await expect(
				replaceRootEvalLiveOperatorConfiguration({
					credentialPath,
					candidatePath,
					targetPath,
					nowMs,
				}),
			).resolves.toMatchObject({
				configurationRevision: "2026-09-04.d158.v1",
				postCommitFailureDigest: null,
				sourceArtifactDigest: expect.stringMatching(/^sha256:[0-9a-f]{64}$/u),
			});
			expect(new Uint8Array(await readFile(targetPath))).toEqual(candidateBytes);
			expect((await stat(targetPath)).mode & 0o777).toBe(0o600);

			await chmod(candidatePath, 0o644);
			await expect(
				replaceRootEvalLiveOperatorConfiguration({
					credentialPath,
					candidatePath,
					targetPath,
					nowMs,
				}),
			).rejects.toThrow(/private input identity/u);
			expect(new Uint8Array(await readFile(targetPath))).toEqual(candidateBytes);

			const revokedBytes = new TextEncoder().encode(
				new TextDecoder().decode(candidateBytes).replace('"revoked":false', '"revoked":true'),
			);
			await chmod(candidatePath, 0o600);
			await writeFile(candidatePath, revokedBytes);
			await expect(
				replaceRootEvalLiveOperatorConfiguration({
					credentialPath,
					candidatePath,
					targetPath,
					nowMs,
				}),
			).resolves.toMatchObject({ revoked: true });
			const installedRevocation = new Uint8Array(await readFile(targetPath));
			expect(() =>
				admitRootEvalLiveOperatorConfiguration({
					credential: parseRootEvalLiveCredential(
						new TextEncoder().encode("OPENROUTER_API_KEY=sk-or-v1-a44-middle-credential-e06\n"),
					),
					bytes: installedRevocation,
					nowMs,
				}),
			).toThrow(/same-credential admission/u);
		} finally {
			await rm(temporary, { force: true, recursive: true });
		}
	});
	it("admits a stable operator configuration without consuming its live generation", async () => {
		const temporary = await mkdtemp(join(tmpdir(), "graphrefly-root-eval-d140-preflight-"));
		const canonicalTemporary = await realpath(temporary);
		const inputRoot = join(canonicalTemporary, "inputs");
		const privateRoot = join(canonicalTemporary, "private");
		const credentialPath = join(inputRoot, "openrouter.env");
		const zeroByokPath = join(inputRoot, "fresh-zero-byok-d140.v15.json");
		const observedAtMs = Date.now();
		try {
			await mkdir(inputRoot, { mode: 0o700 });
			await mkdir(privateRoot, { mode: 0o700 });
			const receipt = await persistRootEvalLivePrecredentialGateReceipt({
				privateRoot,
				currentness: boundedCurrentness,
				completedAtMs: observedAtMs - 1,
			});
			await writeFile(credentialPath, "OPENROUTER_API_KEY=sk-or-v1-a44-middle-credential-e06\n", {
				mode: 0o600,
			});
			await writeFile(zeroByokPath, operatorConfigurationBytes(observedAtMs), {
				mode: 0o600,
			});
			await expect(
				qualifyRootEvalLivePrivateInputs({
					credentialPath,
					zeroByokPath,
					precredentialPrivateRoot: privateRoot,
					currentness: boundedCurrentness,
					nowMs: observedAtMs,
				}),
			).resolves.toMatchObject({
				precredentialGateReceipt: { receiptDigest: receipt.receiptDigest },
				zeroByok: { workspaceSlug: "graph-re-fly" },
			});
			expect(await readdir(privateRoot)).toEqual([
				`.${ROOT_EVAL_LIVE_GENERATION_REF}.precredential-gates.v5.json`,
			]);

			const staleSchema = new TextDecoder()
				.decode(operatorConfigurationBytes(observedAtMs))
				.replace(
					ROOT_EVAL_LIVE_OPERATOR_CONFIGURATION_SCHEMA,
					"graphrefly-ts.d145.zero-byok-observation.v16",
				);
			await writeFile(zeroByokPath, staleSchema, { mode: 0o600 });
			await expect(
				qualifyRootEvalLivePrivateInputs({
					credentialPath,
					zeroByokPath,
					precredentialPrivateRoot: privateRoot,
					currentness: boundedCurrentness,
					nowMs: observedAtMs,
				}),
			).rejects.toThrow(/same-credential admission/u);
			expect(await readdir(privateRoot)).toEqual([
				`.${ROOT_EVAL_LIVE_GENERATION_REF}.precredential-gates.v5.json`,
			]);

			const unknownField = new TextDecoder()
				.decode(operatorConfigurationBytes(observedAtMs))
				.replace(/\}$/u, ',"unexpectedField":true}');
			await writeFile(zeroByokPath, unknownField, { mode: 0o600 });
			await expect(
				qualifyRootEvalLivePrivateInputs({
					credentialPath,
					zeroByokPath,
					precredentialPrivateRoot: privateRoot,
					currentness: boundedCurrentness,
					nowMs: observedAtMs,
				}),
			).rejects.toThrow(/unexpected keys/u);
			expect(await readdir(privateRoot)).toEqual([
				`.${ROOT_EVAL_LIVE_GENERATION_REF}.precredential-gates.v5.json`,
			]);
		} finally {
			await rm(temporary, { force: true, recursive: true });
		}
	});
	it("rejects a stale gate receipt before attempting to read credentials", async () => {
		const temporary = await mkdtemp(join(tmpdir(), "graphrefly-root-eval-d138-stale-receipt-"));
		const privateRoot = await realpath(temporary);
		const nowMs = Date.now();
		try {
			await persistRootEvalLivePrecredentialGateReceipt({
				privateRoot,
				currentness: boundedCurrentness,
				completedAtMs: nowMs - 3_600_001,
			});
			await expect(
				qualifyRootEvalLivePrivateInputs({
					credentialPath: join(privateRoot, "missing-credential.env"),
					zeroByokPath: join(privateRoot, "missing-zero-byok.json"),
					precredentialPrivateRoot: privateRoot,
					currentness: boundedCurrentness,
					nowMs,
				}),
			).rejects.toThrow(/receipt was not fresh/u);
		} finally {
			await rm(temporary, { force: true, recursive: true });
		}
	});
	it("atomically refreshes a stale unconsumed receipt for automatic retry", async () => {
		const temporary = await mkdtemp(join(tmpdir(), "graphrefly-root-eval-d149-receipt-refresh-"));
		const privateRoot = await realpath(temporary);
		const nowMs = Date.now();
		try {
			const stale = await persistRootEvalLivePrecredentialGateReceipt({
				privateRoot,
				currentness: boundedCurrentness,
				completedAtMs: nowMs - 3_600_001,
			});
			await expect(
				readRootEvalLivePrecredentialGateReceipt({ privateRoot, nowMs }),
			).rejects.toThrow(/receipt was not fresh/u);
			const refreshed = await replaceRootEvalLivePrecredentialGateReceipt({
				privateRoot,
				currentness: {
					...boundedCurrentness,
					repositoryStateDigest: empiricalStrictJsonDigest("repaired-currentness"),
				},
				completedAtMs: nowMs,
			});
			expect(refreshed.receiptDigest).not.toBe(stale.receiptDigest);
			await expect(
				readRootEvalLivePrecredentialGateReceipt({ privateRoot, nowMs }),
			).resolves.toMatchObject({
				repositoryStateDigest: empiricalStrictJsonDigest("repaired-currentness"),
				completedAtMs: nowMs,
			});
			expect(await readdir(privateRoot)).toEqual([
				`.${ROOT_EVAL_LIVE_GENERATION_REF}.precredential-gates.v5.json`,
			]);
		} finally {
			await rm(temporary, { force: true, recursive: true });
		}
	});
	it("admits an old self-consistent receipt closure only for atomic refresh", async () => {
		const temporary = await mkdtemp(join(tmpdir(), "graphrefly-root-eval-d149-closure-refresh-"));
		const privateRoot = await realpath(temporary);
		const nowMs = Date.now();
		const oldMaterial = {
			schemaVersion: ROOT_EVAL_LIVE_PRECREDENTIAL_GATE_RECEIPT_SCHEMA,
			decisionRef: ROOT_EVAL_LIVE_DECISION_REF,
			generationRef: ROOT_EVAL_LIVE_GENERATION_REF,
			implementationManifestDigest: empiricalStrictJsonDigest("old-implementation"),
			qualificationArtifactDigest: empiricalStrictJsonDigest("old-artifact"),
			qualificationDigest: empiricalStrictJsonDigest("old-qualification"),
			implementationCommit: "c".repeat(40),
			repositoryStateDigest: empiricalStrictJsonDigest("old-repository-state"),
			artifactSetDigest: empiricalStrictJsonDigest("old-artifact-set"),
			completedAtMs: nowMs - 1,
		};
		const oldBytes = new TextEncoder().encode(
			JSON.stringify({
				...oldMaterial,
				receiptDigest: empiricalStrictJsonDigest(oldMaterial),
			}),
		);
		try {
			await writeFile(join(privateRoot, ROOT_EVAL_LIVE_PRECREDENTIAL_GATE_RECEIPT_NAME), oldBytes, {
				mode: 0o600,
			});
			await expect(
				readRootEvalLivePrecredentialGateReceipt({ privateRoot, nowMs }),
			).rejects.toThrow(/implementationManifestDigest/u);
			await expect(
				readRootEvalLiveRefreshablePrecredentialGateReceipt({ privateRoot, nowMs }),
			).resolves.toMatchObject(oldMaterial);

			const tampered = new TextDecoder()
				.decode(oldBytes)
				.replace(oldMaterial.repositoryStateDigest, empiricalStrictJsonDigest("tampered"));
			await writeFile(join(privateRoot, ROOT_EVAL_LIVE_PRECREDENTIAL_GATE_RECEIPT_NAME), tampered, {
				mode: 0o600,
			});
			await expect(
				readRootEvalLiveRefreshablePrecredentialGateReceipt({ privateRoot, nowMs }),
			).rejects.toThrow(/digest drifted/u);

			await writeFile(join(privateRoot, ROOT_EVAL_LIVE_PRECREDENTIAL_GATE_RECEIPT_NAME), oldBytes, {
				mode: 0o600,
			});
			const refreshed = await replaceRootEvalLivePrecredentialGateReceipt({
				privateRoot,
				currentness: boundedCurrentness,
				completedAtMs: nowMs,
			});
			expect(refreshed.implementationManifestDigest).toBe(
				ROOT_EVAL_CURRENT_IMPLEMENTATION_MANIFEST_DIGEST,
			);
			expect(refreshed.receiptDigest).not.toBe(empiricalStrictJsonDigest(oldMaterial));
		} finally {
			await rm(temporary, { force: true, recursive: true });
		}
	});
	it("binds commit, worktree and generated-artifact currentness before credential access", async () => {
		for (const currentnessPatch of [
			{ implementationCommit: "b".repeat(40) },
			{ repositoryStateDigest: empiricalStrictJsonDigest("mutated-repository-state") },
			{ artifactSetDigest: empiricalStrictJsonDigest("mutated-artifact-set") },
		] as const) {
			const temporary = await mkdtemp(join(tmpdir(), "graphrefly-root-eval-d138-currentness-"));
			const privateRoot = await realpath(temporary);
			try {
				await persistRootEvalLivePrecredentialGateReceipt({
					privateRoot,
					currentness: boundedCurrentness,
				});
				await expect(
					qualifyRootEvalLivePrivateInputs({
						credentialPath: join(privateRoot, "missing-credential.env"),
						zeroByokPath: join(privateRoot, "missing-zero-byok.json"),
						precredentialPrivateRoot: privateRoot,
						currentness: { ...boundedCurrentness, ...currentnessPatch },
					}),
				).rejects.toThrow(/receipt currentness drifted/u);
			} finally {
				await rm(temporary, { force: true, recursive: true });
			}
		}
	});
	it("detects a generated-artifact byte mutation without executing the root Eval", async () => {
		const temporary = await mkdtemp(join(tmpdir(), "graphrefly-root-eval-d138-artifacts-"));
		const artifactDirectory = join(temporary, "artifacts");
		try {
			await cp(ROOT_EVAL_ARTIFACT_DIRECTORY, artifactDirectory, { recursive: true });
			await writeFile(join(artifactDirectory, "root-eval-run-summary.json"), "{}\n");
			await expect(checkRootEvalGeneratedArtifactSnapshot({ artifactDirectory })).rejects.toThrow(
				/snapshot drift/u,
			);
		} finally {
			await rm(temporary, { force: true, recursive: true });
		}
	});
	it("rejects unexpected private generation state before attempting to read credentials", async () => {
		const temporary = await mkdtemp(join(tmpdir(), "graphrefly-root-eval-d138-private-state-"));
		const privateRoot = await realpath(temporary);
		try {
			await persistRootEvalLivePrecredentialGateReceipt({
				privateRoot,
				currentness: boundedCurrentness,
			});
			await writeFile(join(privateRoot, "unexpected-artifact.json"), "{}\n", { mode: 0o600 });
			await expect(
				qualifyRootEvalLivePrivateInputs({
					credentialPath: join(privateRoot, "missing-credential.env"),
					zeroByokPath: join(privateRoot, "missing-zero-byok.json"),
					precredentialPrivateRoot: privateRoot,
					currentness: boundedCurrentness,
				}),
			).rejects.toThrow(/consumed generation state/u);
		} finally {
			await rm(temporary, { force: true, recursive: true });
		}
	});
	it("binds D159 live authority to a single-use private execution grant", () => {
		const liveEntry = readFileSync(
			resolve(
				repositoryRoot,
				"packages/ts/evals/graph-native-rerun-avoidance/run-live-campaign.ts",
			),
			"utf8",
		);
		expect(ROOT_EVAL_LIVE_EXECUTION_GRANT_SCHEMA).toBe(
			"graphrefly-ts.root-eval-execution-grant.v1",
		);
		expect(liveEntry).toContain("readRootEvalLiveExecutionGrant(executionGrantPath)");
		expect(liveEntry).toContain("ROOT_EVAL_D159_HORIZON_SLOTS.includes(");
		expect(liveEntry).toContain("await readRootEvalD159HorizonReceipt();");
		expect(liveEntry).toContain('join(operatorRoot, "execution-grants"');
		expect(liveEntry).toContain("providerQualificationGrantDigest");
		expect(liveEntry).not.toContain("ROOT_EVAL_LIVE_EXECUTION_AUTHORITY_OPEN");
		expect(liveEntry).not.toContain("GRAPHREFLY_ROOT_EVAL_EXECUTION_AUTHORITY");
		expect(liveEntry).not.toContain("user-authorized:d157-development-5");
		expect(liveEntry).toContain(
			"process.env.GRAPHREFLY_ROOT_EVAL_TASK_MANIFEST_DIRECTORY !== undefined",
		);
		expect(liveEntry).not.toContain("prepareRootEvalD159HorizonForNoNetworkQualification");
		expect(liveEntry).toContain("root eval D157 prior development manifest drifted from ledger");
		expect(liveEntry).not.toContain('ROOT_EVAL_LIVE_CAMPAIGN_SLOT !== "development-3"');
		expect(liveEntry).not.toContain(
			'"user-authorized:d152-development-2:usd-4.272834:development-usd-36"',
		);
		expect(liveEntry).not.toContain(
			'"user-authorized:d152-development-1:usd-12:development-usd-36"',
		);
		expect(liveEntry).toMatch(
			/join\(operatorRoot, `current-\$\{ROOT_EVAL_LIVE_GENERATION_REF\}`\)/u,
		);
		expect(liveEntry).not.toContain('join(operatorRoot, "current-live-d136")');
		const liveMain = liveEntry.slice(liveEntry.indexOf("async function main(): Promise<void>"));
		const liveHorizonSeal = liveMain.indexOf("await readRootEvalD159HorizonReceipt();");
		expect(liveHorizonSeal).toBeGreaterThan(0);
		expect(liveHorizonSeal).toBeLessThan(
			liveMain.indexOf("await runRootEvalPrecredentialStagePlan({"),
		);
		const qualificationEntry = readFileSync(
			resolve(
				repositoryRoot,
				"packages/ts/evals/graph-native-rerun-avoidance/run-provider-qualification.ts",
			),
			"utf8",
		);
		const horizonSeal = qualificationEntry.indexOf("await readRootEvalD159HorizonReceipt();");
		expect(horizonSeal).toBeGreaterThan(0);
		expect(qualificationEntry).toContain(
			"process.env.GRAPHREFLY_ROOT_EVAL_TASK_MANIFEST_DIRECTORY !== undefined",
		);
		expect(qualificationEntry).not.toContain("prepareRootEvalD159HorizonForNoNetworkQualification");
		expect(qualificationEntry).not.toContain("settings.executionRef !== approvalRef");
		expect(qualificationEntry).not.toContain("86_400_000");
		expect(qualificationEntry).toContain(
			"ledger.developmentSpentMicrousd + PROVIDER_QUALIFICATION_CAP > 45_000_000",
		);
		expect(horizonSeal).toBeLessThan(
			qualificationEntry.indexOf('"together-qualification-settings.json"'),
		);
		expect(horizonSeal).toBeLessThan(
			qualificationEntry.indexOf("const credential = parseRootEvalLiveCredential("),
		);
		for (const providerCapableAnchor of [
			"const pricing = await official(",
			"const zdr = await official(",
			"const currentKey = await readRootEvalLiveCurrentKey({",
			"const result = await runProviderQualificationWithTransport({",
		])
			expect(horizonSeal).toBeLessThan(qualificationEntry.indexOf(providerCapableAnchor));
		for (const recoveryName of [
			"recover-d145-source-failure.ts",
			"recover-d145-interrupted-campaign.ts",
		]) {
			const recoveryEntry = readFileSync(
				resolve(repositoryRoot, `packages/ts/evals/graph-native-rerun-avoidance/${recoveryName}`),
				"utf8",
			);
			const recoveryMain = recoveryEntry.slice(
				recoveryEntry.indexOf("async function main(): Promise<void>"),
			);
			expect(recoveryMain).toContain("D145 recovery is retired for the D157 finite horizon");
			expect(
				recoveryMain.indexOf("D145 recovery is retired for the D157 finite horizon"),
			).toBeLessThan(
				recoveryMain.indexOf("readRootEvalTaskManifest(ROOT_EVAL_LIVE_CAMPAIGN_SLOT)"),
			);
		}
	});
	it.each([
		{ ordinal: 2, cap: 4_272_834, partition: 36_000_000, partitionRef: "development-usd-36" },
		{ ordinal: 3, cap: 4_179_695, partition: 40_000_000, partitionRef: "development-usd-40" },
		{ ordinal: 4, cap: 4_164_201, partition: 40_000_000, partitionRef: "development-usd-40" },
		{ ordinal: 5, cap: 4_138_575, partition: 40_000_000, partitionRef: "development-usd-40" },
		{ ordinal: 6, cap: 4_138_575, partition: 45_000_000, partitionRef: "development-usd-45" },
		{ ordinal: 7, cap: 4_138_575, partition: 45_000_000, partitionRef: "development-usd-45" },
	])("binds development-$ordinal to its exact approved budget coordinates", ({
		ordinal,
		cap,
		partition,
		partitionRef,
	}) => {
		const moduleUrl = pathToFileURL(
			resolve(
				repositoryRoot,
				"packages/ts/evals/graph-native-rerun-avoidance/root-eval-live-authority.ts",
			),
		).href;
		const source = `
			const a = await import(${JSON.stringify(moduleUrl)});
			process.stdout.write(JSON.stringify({
				slot: a.ROOT_EVAL_LIVE_CAMPAIGN_SLOT,
				generation: a.ROOT_EVAL_LIVE_GENERATION_REF,
				cap: a.ROOT_EVAL_LIVE_CAMPAIGN_HARD_CAP_MICROUSD,
				partition: a.ROOT_EVAL_LIVE_PARTITION_HARD_CAP_MICROUSD,
				partitionRef: a.ROOT_EVAL_LIVE_BUDGET_PARTITION
			}));
		`;
		const result = execFileSync(
			process.execPath,
			["--import", "tsx", "--input-type=module", "--eval", source],
			{
				cwd: repositoryRoot,
				env: { ...process.env, GRAPHREFLY_ROOT_EVAL_CAMPAIGN_SLOT: `development-${ordinal}` },
				encoding: "utf8",
				timeout: 20_000,
			},
		);
		expect(JSON.parse(result)).toEqual({
			slot: `development-${ordinal}`,
			generation: `root-eval-development-2026-09-01-d152-v${ordinal}`,
			cap,
			partition,
			partitionRef,
		});
	});
	it("keeps an unsettled caller await alive and releases the lease after settlement", async () => {
		const moduleUrl = pathToFileURL(
			resolve(repositoryRoot, "packages/ts/evals/graph-native-rerun-avoidance/root-eval-live.ts"),
		).href;
		const source = `
			const { awaitRootEvalCallerSettlement } = await import(${JSON.stringify(moduleUrl)});
			const value = await awaitRootEvalCallerSettlement(() => new Promise((resolve) => {
				const timer = setTimeout(() => resolve("settled"), 25);
				timer.unref();
			}));
			process.stdout.write(value);
		`;
		const startedAt = Date.now();
		const result = await new Promise<
			Readonly<{ readonly code: number | null; readonly stdout: string; readonly stderr: string }>
		>((resolveResult, reject) => {
			const child = spawn(
				process.execPath,
				["--import", "tsx", "--input-type=module", "--eval", source],
				{ cwd: repositoryRoot, shell: false, stdio: ["ignore", "pipe", "pipe"] },
			);
			let stdout = "";
			let stderr = "";
			child.stdout.setEncoding("utf8");
			child.stderr.setEncoding("utf8");
			child.stdout.on("data", (chunk: string) => {
				stdout += chunk;
			});
			child.stderr.on("data", (chunk: string) => {
				stderr += chunk;
			});
			child.once("error", reject);
			child.once("close", (code) => resolveResult({ code, stdout, stderr }));
		});
		expect(result.code).toBe(0);
		expect(result.stdout).toBe("settled");
		expect(result.stderr).not.toMatch(/Error|unsettled top-level await/u);
		expect(Date.now() - startedAt).toBeLessThan(5_000);
	});

	it("derives the caller safety ceiling from the finite Graph schedule", () => {
		expect(ROOT_EVAL_MAX_POST_CUTOFF_CAUSAL_TAIL_MS).toBe(
			ROOT_EVAL_PROVIDER_SETTLEMENT_LEASE_MS +
				ROOT_EVAL_TOOL_SETTLEMENT_LEASE_MS +
				ROOT_EVAL_RETRY_SETTLEMENT_LEASE_MS +
				ROOT_EVAL_BILLING_SETTLEMENT_LEASE_MS * ROOT_EVAL_MAX_BILLING_OBSERVATIONS,
		);
		expect(ROOT_EVAL_MAX_POST_CUTOFF_CAUSAL_TAIL_MS).toBeLessThan(
			rootEvalScheduleFeasibility(5).maximumFinitePathMs,
		);
		expect(ROOT_EVAL_CALLER_SETTLEMENT_DEADLINE_MS).toBe(
			rootEvalScheduleFeasibility(5).maximumFinitePathMs,
		);
	});

	it("enforces retry and cleanup-finalizer settlement against non-cooperative adapters", async () => {
		const executor = createRootEvalLiveExecutor({
			graph: graph(),
			repositoryRoot,
			materializationRoot: join(repositoryRoot, ".never-created-root-eval-lease-test"),
			privateRoot: repositoryRoot,
			claimCommit: {} as never,
			bearerToken: "sk-or-v1-no-network-lease-fixture",
			pricing,
			wait: async () => await new Promise<never>(() => undefined),
			removeWorkspace: async () => await new Promise<never>(() => undefined),
		});
		vi.useFakeTimers();
		try {
			const retry = executor.execute({
				kind: "eval-admitted-retry-delay",
				executionId: "retry-lease-fixture",
				delayMs: 120_000,
			} as never);
			const retryResult = expect(retry).rejects.toMatchObject({
				name: "RootEvalSettlementLeaseExpired",
				effectClass: "retry-delay",
			});
			await vi.advanceTimersByTimeAsync(ROOT_EVAL_RETRY_SETTLEMENT_LEASE_MS);
			await retryResult;
			const disposal = expect(executor.dispose()).rejects.toThrow(
				"cleanup finalizer did not complete",
			);
			await vi.advanceTimersByTimeAsync(ROOT_EVAL_TOOL_SETTLEMENT_LEASE_MS);
			await disposal;
		} finally {
			vi.useRealTimers();
		}
	});

	it("bounds caller settlement with a closed technical code and no Graph mutation", async () => {
		await expect(
			awaitRootEvalCallerSettlement(() => new Promise<never>(() => undefined), { deadlineMs: 5 }),
		).rejects.toMatchObject({
			name: "RootEvalCallerSettlementDeadlineExpired",
			code: "caller-settlement-deadline-expired",
			deadlineMs: 5,
		});
	});

	it("cancels the root Graph runner and admitted executor work at the caller deadline", async () => {
		const cancellation = new AbortController();
		let active = 0;
		let settled = 0;
		const running = runRootEval(
			createRootEvalTopology({
				profileInput: createCurrentExactModelHarnessProfileInput(),
				currentKeyBefore: ROOT_EVAL_NO_NETWORK_CURRENT_KEY_BEFORE,
				providerPacingSetTimeout: (callback) => {
					callback();
					return 0 as unknown as ReturnType<typeof setTimeout>;
				},
			}),
			async () => {
				active += 1;
				try {
					await new Promise<never>((_resolve, reject) => {
						const onAbort = () => reject(cancellation.signal.reason);
						cancellation.signal.addEventListener("abort", onAbort, { once: true });
						if (cancellation.signal.aborted) onAbort();
					});
				} finally {
					active -= 1;
					settled += 1;
				}
			},
			{ signal: cancellation.signal },
		);
		for (let turn = 0; turn < 16 && active === 0; turn += 1)
			await new Promise<void>((resolve) => setTimeout(resolve, 0));
		expect(active).toBeGreaterThan(0);
		await expect(
			awaitRootEvalCallerSettlement(() => running, {
				deadlineMs: 5,
				onDeadline: (error) => cancellation.abort(error),
			}),
		).rejects.toMatchObject({ code: "caller-settlement-deadline-expired" });
		await expect(running).rejects.toMatchObject({ code: "caller-settlement-deadline-expired" });
		expect(active).toBe(0);
		expect(settled).toBeGreaterThan(0);
	});

	it("requires a committed D140 live claim before live provider dispatch", async () => {
		const temporary = await mkdtemp(join(tmpdir(), "graphrefly-root-eval-d94-wire-"));
		const privateRoot = await realpath(temporary);
		let admitted: EvalAdmittedEffect | undefined;
		try {
			await expect(
				runRootEval(
					createRootEvalTopology({
						profileInput: createCurrentExactModelHarnessProfileInput(),
						currentKeyBefore: ROOT_EVAL_NO_NETWORK_CURRENT_KEY_BEFORE,
						providerPacingSetTimeout: (callback) => {
							callback();
							return 0 as unknown as ReturnType<typeof setTimeout>;
						},
						campaignRef: ROOT_EVAL_LIVE_GENERATION_REF,
						taskSetRef: ROOT_EVAL_DEVELOPMENT_TASK.taskSetRef,
						maxCostMicrousd: 6_000_000,
						reservationMicrousd: 200_000,
					}),
					async (effect) => {
						if (effect.kind === "eval-admitted-effect") admitted = effect;
						throw new Error("captured first admitted effect");
					},
				),
			).rejects.toThrow(/captured first admitted effect/u);
			if (admitted === undefined) throw new TypeError("D116 admitted effect was not captured");
			const claimInput = await currentClaimInput(privateRoot);
			const claimAcquisition = await acquireRootEvalLiveClaimForNoNetworkQualification(claimInput);
			const copiedRootPath = join(temporary, "copied-private-root");
			await mkdir(copiedRootPath, { mode: 0o700 });
			const copiedRoot = await realpath(copiedRootPath);
			const dispositionName = (await readdir(privateRoot)).find((name) =>
				name.endsWith("disposition.v21.json"),
			);
			if (dispositionName === undefined) throw new TypeError("D140 disposition missing");
			const committedBytes = await readFile(join(privateRoot, dispositionName));
			await writeFile(join(copiedRoot, dispositionName), committedBytes, { mode: 0o600 });
			const copiedRootExecutor = createRootEvalLiveTransportQualificationExecutor({
				graph: graph(),
				repositoryRoot,
				materializationRoot: join(temporary, "copied-root-workspaces"),
				privateRoot: copiedRoot,
				claimCommit: claimAcquisition,
				bearerToken: claimInput.credential.bearerToken,
				pricing: claimInput.pricing,
				providerResponses: [{ status: 200, bytes: providerBytesForEffect(admitted) }],
			});
			try {
				await expect(copiedRootExecutor.execute(admitted)).resolves.toMatchObject({
					status: "failed",
					reason: "executor-failed",
					dispatchAttempted: false,
				});
				expect(copiedRootExecutor.providerRequestSummaries()).toEqual([]);
			} finally {
				await copiedRootExecutor.dispose();
			}
			const forgedCapabilityExecutor = createRootEvalLiveTransportQualificationExecutor({
				graph: graph(),
				repositoryRoot,
				materializationRoot: join(temporary, "forged-capability-workspaces"),
				privateRoot,
				claimCommit: {
					claim: claimAcquisition.claim,
					postCommitFailureDigest: null,
				} as never,
				bearerToken: claimInput.credential.bearerToken,
				pricing: claimInput.pricing,
				providerResponses: [{ status: 200, bytes: providerBytes() }],
			});
			try {
				await expect(forgedCapabilityExecutor.execute(admitted)).resolves.toMatchObject({
					status: "failed",
					reason: "executor-failed",
					dispatchAttempted: false,
				});
				expect(forgedCapabilityExecutor.providerRequestSummaries()).toEqual([]);
			} finally {
				await forgedCapabilityExecutor.dispose();
			}
			const liveExecutor = createRootEvalLiveExecutor({
				graph: graph(),
				repositoryRoot,
				materializationRoot: join(temporary, "strict-live-workspaces"),
				privateRoot,
				claimCommit: claimAcquisition,
				bearerToken: claimInput.credential.bearerToken,
				pricing: claimInput.pricing,
			});
			try {
				await expect(liveExecutor.execute(admitted)).resolves.toMatchObject({
					status: "failed",
					dispatchAttempted: false,
					reason: "executor-failed",
				});
			} finally {
				await liveExecutor.dispose();
			}
			const wrongCredentialExecutor = createRootEvalLiveTransportQualificationExecutor({
				graph: graph(),
				repositoryRoot,
				materializationRoot: join(temporary, "wrong-credential-workspaces"),
				privateRoot,
				claimCommit: claimAcquisition,
				bearerToken: "sk-or-v1-a44-different-credential-e06",
				pricing: claimInput.pricing,
				providerResponses: [{ status: 200, bytes: providerBytes() }],
			});
			try {
				await expect(wrongCredentialExecutor.execute(admitted)).resolves.toMatchObject({
					status: "failed",
					reason: "executor-failed",
					costMicrousd: 0,
					costEvidence: "provider-reported" as const,
				});
				expect(wrongCredentialExecutor.providerRequestSummaries()).toEqual([]);
			} finally {
				await wrongCredentialExecutor.dispose();
			}
			let capturedSystemPrompt: string | undefined;
			const executor = createRootEvalLiveTransportQualificationExecutor({
				graph: graph(),
				repositoryRoot,
				materializationRoot: join(temporary, "workspaces"),
				privateRoot,
				claimCommit: claimAcquisition,
				bearerToken: claimInput.credential.bearerToken,
				pricing: claimInput.pricing,
				providerResponses: [],
				providerResponseForRequest(request) {
					const messages = request.messages as readonly Readonly<Record<string, unknown>>[];
					capturedSystemPrompt = String(messages[0]?.content);
					return { status: 200, bytes: providerBytesForEffect(admitted) };
				},
			});
			try {
				const outcome = (await executor.execute(admitted)) as EvalProviderOutcome;
				expect(outcome).toMatchObject({
					status: "tool-proposed",
					reason: "tool-proposed",
					costMicrousd: 157,
				});
				const requestBody = executor.providerRequestSummaries()[0];
				expect(Object.isFrozen(requestBody)).toBe(true);
				expect(Object.isFrozen(requestBody?.provider)).toBe(true);
				expect(Object.isFrozen(requestBody?.response_format)).toBe(true);
				expect(requestBody).toMatchObject({
					model: "deepseek/deepseek-v4-flash-0731",
					max_tokens: 16_384,
					provider: {
						order: ["together"],
						only: ["together"],
						allow_fallbacks: false,
						require_parameters: true,
						data_collection: "deny",
						zdr: true,
					},
					response_format: {
						type: "json_schema",
						json_schema: { name: "occurrence_bound_candidate_selection", strict: true },
					},
					reasoning: { effort: "medium" },
				});
				expect(capturedSystemPrompt).toContain("Select only the candidateRef");
				expect(capturedSystemPrompt).toContain("Do not author patch text");
				expect(requestBody?.reasoning).not.toHaveProperty("max_tokens");
				expect(requestBody).not.toHaveProperty("tools");
				expect(requestBody).not.toHaveProperty("tool_choice");
				expect(requestBody).not.toHaveProperty("parallel_tool_calls");
				await executor.dispose();
				const replayExecutor = createRootEvalLiveTransportQualificationExecutor({
					graph: graph(),
					repositoryRoot,
					materializationRoot: join(temporary, "replay-workspaces"),
					privateRoot,
					claimCommit: claimAcquisition,
					bearerToken: claimInput.credential.bearerToken,
					pricing: claimInput.pricing,
					providerResponses: [{ status: 200, bytes: providerBytes() }],
				});
				try {
					await expect(replayExecutor.execute(admitted)).resolves.toMatchObject({
						status: "failed",
						reason: "executor-failed",
						costMicrousd: 0,
					});
					expect(replayExecutor.providerRequestSummaries()).toEqual([]);
				} finally {
					await replayExecutor.dispose();
				}
			} finally {
				await executor.dispose();
			}
			const { claimDigest: _currentDigest, ...currentClaimMaterial } = JSON.parse(
				committedBytes.toString("utf8"),
			) as RootEvalLiveClaim;
			const staleD121Material = {
				...currentClaimMaterial,
				schemaVersion: "graphrefly-ts.root-eval-live-claim.v14",
				claimRef: "root-eval-live-claim-2026-08-25-d121-v1",
				decisionRef: "graphrefly-ts:D121",
				generationRef: "root-eval-live-2026-08-25-d121-v1",
				implementationManifestDigest:
					"sha256:2bf1f7b4fa15262f09fdadc491af567d455d4dea81e28478db7223fb22556e0e",
				qualificationArtifactDigest:
					"sha256:90fdba7d97a6cd4e353cefe6f762ea114d92b2f1b6cdc23e4451f44656cefcfa",
				qualificationDigest:
					"sha256:b6d49961927d36d18153d32c673414bf9488edaa3fe8f96d9294f2e9efacc3a4",
				credentialBindingDigest: empiricalStrictJsonDigest({
					bindingRef: "openrouter.local-eval-2",
					bindingRevision: "2026-08-25.d121.v1",
				}),
			};
			await writeFile(
				join(privateRoot, dispositionName),
				JSON.stringify({
					...staleD121Material,
					claimDigest: empiricalStrictJsonDigest(staleD121Material),
				}),
				{ mode: 0o600 },
			);
			const staleD121Executor = createRootEvalLiveTransportQualificationExecutor({
				graph: graph(),
				repositoryRoot,
				materializationRoot: join(temporary, "stale-d121-workspaces"),
				privateRoot,
				claimCommit: claimAcquisition,
				bearerToken: claimInput.credential.bearerToken,
				pricing: claimInput.pricing,
				providerResponses: [{ status: 200, bytes: providerBytes() }],
			});
			try {
				await expect(staleD121Executor.execute(admitted)).resolves.toMatchObject({
					status: "failed",
					reason: "executor-failed",
					dispatchAttempted: false,
				});
				expect(staleD121Executor.providerRequestSummaries()).toEqual([]);
			} finally {
				await staleD121Executor.dispose();
			}
		} finally {
			await rm(temporary, { recursive: true, force: true });
		}
	}, 120_000);

	it("keeps consumed dispatch accounting when stage cleanup fails after receipt link", async () => {
		const temporary = await mkdtemp(join(tmpdir(), "graphrefly-root-eval-d140-dispatch-cleanup-"));
		const privateRoot = await realpath(temporary);
		let admitted: EvalAdmittedEffect | undefined;
		const httpTopology = createRootEvalTopology({
			profileInput: createCurrentExactModelHarnessProfileInput(),
			currentKeyBefore: ROOT_EVAL_NO_NETWORK_CURRENT_KEY_BEFORE,
			providerPacingSetTimeout: (callback) => {
				callback();
				return 0 as unknown as ReturnType<typeof setTimeout>;
			},
			campaignRef: ROOT_EVAL_LIVE_GENERATION_REF,
			taskSetRef: ROOT_EVAL_DEVELOPMENT_TASK.taskSetRef,
			maxCostMicrousd: 6_000_000,
			reservationMicrousd: 200_000,
		});
		try {
			await expect(
				runRootEval(httpTopology, async (effect) => {
					if (effect.kind === "eval-admitted-effect") admitted = effect;
					throw new Error("captured dispatch-cleanup effect");
				}),
			).rejects.toThrow(/captured dispatch-cleanup effect/u);
			if (admitted === undefined)
				throw new TypeError("D140 dispatch-cleanup effect was not captured");
			const claimInput = await currentClaimInput(privateRoot);
			const claimAcquisition = await acquireRootEvalLiveClaimForNoNetworkQualification(claimInput);
			let providerCalls = 0;
			const executor = createRootEvalLiveTransportQualificationExecutor({
				graph: httpTopology.graph,
				repositoryRoot,
				materializationRoot: join(temporary, "workspaces"),
				privateRoot,
				claimCommit: claimAcquisition,
				bearerToken: claimInput.credential.bearerToken,
				pricing: claimInput.pricing,
				providerResponses: [{ status: 200, bytes: providerBytes() }],
				onProviderCall: () => {
					providerCalls += 1;
				},
				removeDispatchStage: async () => {
					throw new Error("injected dispatch stage cleanup failure");
				},
			});
			try {
				await expect(executor.execute(admitted)).resolves.toMatchObject({
					status: "failed",
					reason: "executor-failed",
					dispatchAttempted: true,
					costMicrousd: 200_000,
					costEvidence: "reservation-upper-bound",
				});
				expect(providerCalls).toBe(1);
				expect(
					(await readdir(join(privateRoot, ".d152-provider-dispatches"))).some((name) =>
						name.endsWith(".json"),
					),
				).toBe(true);
			} finally {
				await executor.dispose();
			}
		} finally {
			await rm(temporary, { force: true, recursive: true });
		}
	}, 15_000);

	it("drains the response and preserves reported cost when the dispatch observer throws", async () => {
		const temporary = await mkdtemp(join(tmpdir(), "graphrefly-root-eval-d140-dispatch-observer-"));
		const privateRoot = await realpath(temporary);
		let admitted: EvalAdmittedEffect | undefined;
		const httpTopology = createRootEvalTopology({
			profileInput: createCurrentExactModelHarnessProfileInput(),
			currentKeyBefore: ROOT_EVAL_NO_NETWORK_CURRENT_KEY_BEFORE,
			providerPacingSetTimeout: (callback) => {
				callback();
				return 0 as unknown as ReturnType<typeof setTimeout>;
			},
			campaignRef: ROOT_EVAL_LIVE_GENERATION_REF,
			taskSetRef: ROOT_EVAL_DEVELOPMENT_TASK.taskSetRef,
			maxCostMicrousd: 6_000_000,
			reservationMicrousd: 200_000,
		});
		try {
			await expect(
				runRootEval(httpTopology, async (effect) => {
					if (effect.kind === "eval-admitted-effect") admitted = effect;
					throw new Error("captured dispatch-observer effect");
				}),
			).rejects.toThrow(/captured dispatch-observer effect/u);
			if (admitted === undefined)
				throw new TypeError("D140 dispatch-observer effect was not captured");
			const claimInput = await currentClaimInput(privateRoot);
			const claimAcquisition = await acquireRootEvalLiveClaimForNoNetworkQualification(claimInput);
			let providerCalls = 0;
			const executor = createRootEvalLiveTransportQualificationExecutor({
				graph: httpTopology.graph,
				repositoryRoot,
				materializationRoot: join(temporary, "workspaces"),
				privateRoot,
				claimCommit: claimAcquisition,
				bearerToken: claimInput.credential.bearerToken,
				pricing: claimInput.pricing,
				providerResponses: [{ status: 200, bytes: providerBytesForEffect(admitted) }],
				onProviderCall: () => {
					providerCalls += 1;
					throw new Error("injected observer failure");
				},
			});
			try {
				await expect(executor.execute(admitted)).resolves.toMatchObject({
					status: "failed",
					reason: "executor-failed",
					dispatchAttempted: true,
					costMicrousd: 157,
					costEvidence: "provider-reported",
				});
				expect(providerCalls).toBe(1);
				expect(executor.providerRequestSummaries()).toHaveLength(1);
				expect(
					(await readdir(join(privateRoot, ".d152-provider-dispatches"))).some((name) =>
						name.endsWith(".json"),
					),
				).toBe(true);
			} finally {
				await executor.dispose();
			}
		} finally {
			await rm(temporary, { force: true, recursive: true });
		}
	}, 15_000);

	it("settles a pre-dispatch stall through the Graph-admitted Work Item timeout", async () => {
		const temporary = await mkdtemp(join(tmpdir(), "graphrefly-root-eval-effect-lease-"));
		const privateRoot = await realpath(temporary);
		const claimInput = await currentClaimInput(privateRoot);
		const claimAcquisition = await acquireRootEvalLiveClaimForNoNetworkQualification(claimInput);
		const httpTopology = createRootEvalTopology({
			profileInput: createCurrentExactModelHarnessProfileInput(),
			currentKeyBefore: ROOT_EVAL_NO_NETWORK_CURRENT_KEY_BEFORE,
			providerPacingSetTimeout: (callback) => {
				callback();
				return 0 as unknown as ReturnType<typeof setTimeout>;
			},
			maxCostMicrousd: 6_000_000,
			reservationMicrousd: 200_000,
			effectTimeoutMs: 500,
			sourceEffectTimeoutMs: 300_000,
		});
		const executor = createRootEvalLiveTransportQualificationExecutor({
			graph: httpTopology.graph,
			repositoryRoot,
			materializationRoot: join(temporary, "workspaces"),
			privateRoot,
			claimCommit: claimAcquisition,
			bearerToken: claimInput.credential.bearerToken,
			pricing: claimInput.pricing,
			providerResponses: [],
			beforeProviderDispatch: async (effect, signal) => {
				if (effect.workItemRole !== "target") return;
				await new Promise<void>((_resolve, reject) => {
					const abort = () => reject(signal.reason);
					if (signal.aborted) abort();
					else signal.addEventListener("abort", abort, { once: true });
				});
			},
			providerResponseForRequest(request) {
				const encoded = JSON.stringify(request);
				const targetTask = ROOT_EVAL_DEVELOPMENT_TASKS.find((task) =>
					encoded.includes(JSON.stringify(task.taskStatement).slice(1, -1)),
				);
				if (targetTask !== undefined)
					return { status: 200, bytes: providerBytes(), stallUntilAbort: true };
				const sourceTask = ROOT_EVAL_DEVELOPMENT_TASKS.find((task) =>
					encoded.includes(JSON.stringify(task.sourceTaskStatement).slice(1, -1)),
				);
				return sourceTask === undefined
					? { status: 200, bytes: providerBytes(), stallUntilAbort: true }
					: { status: 200, bytes: providerBytesForSourceTask(sourceTask) };
			},
		});
		try {
			const result = await runRootEval(httpTopology, (effect) => executor.execute(effect));
			expect(result.finding).toMatchObject({
				completedWorkItems: 30,
				admittedAttempts: 35,
				stoppingReason: "campaign-complete",
				providerOutcomeReasonCounts: { "executor-failed": 30, "tool-proposed": 5 },
			});
			expect(result.peakConcurrentEffects).toBe(1);
			// The explicit pre-dispatch barrier proves the Work Item lease covers
			// the full pre-dispatch path independently of checkout speed.
			expect(executor.providerRequestSummaries()).toHaveLength(5);
			expect(await readdir(join(temporary, "workspaces"))).toEqual([]);
		} finally {
			await executor.dispose();
			await rm(temporary, { recursive: true, force: true });
		}
	}, 120_000);

	it("aborts active transport leases and removes every workspace on caller cancellation", async () => {
		const temporary = await mkdtemp(join(tmpdir(), "graphrefly-root-eval-caller-cancel-"));
		const privateRoot = await realpath(temporary);
		const materializationRoot = join(temporary, "workspaces");
		const claimInput = await currentClaimInput(privateRoot);
		const claimAcquisition = await acquireRootEvalLiveClaimForNoNetworkQualification(claimInput);
		const httpTopology = createRootEvalTopology({
			profileInput: createCurrentExactModelHarnessProfileInput(),
			currentKeyBefore: ROOT_EVAL_NO_NETWORK_CURRENT_KEY_BEFORE,
			providerPacingSetTimeout: (callback) => {
				callback();
				return 0 as unknown as ReturnType<typeof setTimeout>;
			},
			taskSetRef: ROOT_EVAL_DEVELOPMENT_TASK.taskSetRef,
			effectTimeoutMs: 300_000,
		});
		const executor = createRootEvalLiveTransportQualificationExecutor({
			graph: httpTopology.graph,
			repositoryRoot,
			materializationRoot,
			privateRoot,
			claimCommit: claimAcquisition,
			bearerToken: claimInput.credential.bearerToken,
			pricing: claimInput.pricing,
			providerResponses: Array.from({ length: 6 }, () => ({
				status: 200,
				bytes: providerBytes(),
				stallUntilAbort: true,
			})),
		});
		const cancellation = new AbortController();
		try {
			const running = runRootEval(httpTopology, executor.execute, { signal: cancellation.signal });
			const settledRun = running.then(
				() => null,
				(error: unknown) => error,
			);
			while (executor.providerRequestSummaries().length < 1)
				await new Promise<void>((resolve) => setTimeout(resolve, 5));
			const reason = new RootEvalCallerSettlementDeadlineExpired(5);
			cancellation.abort(reason);
			await executor.dispose(reason);
			expect(await settledRun).toBe(reason);
			await expect(readdir(materializationRoot)).rejects.toMatchObject({ code: "ENOENT" });
		} finally {
			await executor.dispose();
			await rm(temporary, { recursive: true, force: true });
		}
	}, 120_000);

	it("settles thirty output-truncated Together responses through the root Graph", async () => {
		const temporary = await mkdtemp(join(tmpdir(), "graphrefly-root-eval-truncated-response-"));
		const privateRoot = await realpath(temporary);
		const capturedTargetTaskStatements: string[] = [];
		const claimInput = await currentClaimInput(privateRoot);
		const claimAcquisition = await acquireRootEvalLiveClaimForNoNetworkQualification(claimInput);
		const httpTopology = createRootEvalTopology({
			profileInput: createCurrentExactModelHarnessProfileInput(),
			currentKeyBefore: ROOT_EVAL_NO_NETWORK_CURRENT_KEY_BEFORE,
			providerPacingSetTimeout: (callback) => {
				callback();
				return 0 as unknown as ReturnType<typeof setTimeout>;
			},
			taskSetRef: ROOT_EVAL_DEVELOPMENT_TASK.taskSetRef,
			maxCostMicrousd: 6_000_000,
			reservationMicrousd: 200_000,
		});
		const executor = createRootEvalLiveTransportQualificationExecutor({
			graph: httpTopology.graph,
			repositoryRoot,
			materializationRoot: join(temporary, "workspaces"),
			privateRoot,
			claimCommit: claimAcquisition,
			bearerToken: claimInput.credential.bearerToken,
			pricing: claimInput.pricing,
			providerResponses: [],
			providerResponseForRequest(request) {
				const encoded = JSON.stringify(request);
				const targetTask = ROOT_EVAL_DEVELOPMENT_TASKS.find((task) =>
					encoded.includes(JSON.stringify(task.taskStatement).slice(1, -1)),
				);
				if (targetTask !== undefined) {
					const messages = request.messages as readonly Readonly<Record<string, unknown>>[];
					const userContent = String(messages[1]?.content ?? "");
					capturedTargetTaskStatements.push(
						userContent.split("\n\n### Admitted memory context\n", 1)[0]!,
					);
					return { status: 200, bytes: truncatedProviderBytes() };
				}
				const sourceTask = ROOT_EVAL_DEVELOPMENT_TASKS.find((task) =>
					encoded.includes(JSON.stringify(task.sourceTaskStatement).slice(1, -1)),
				);
				return sourceTask === undefined
					? { status: 200, bytes: truncatedProviderBytes() }
					: { status: 200, bytes: providerBytesForSourceTask(sourceTask) };
			},
		});
		try {
			const result = await runRootEval(httpTopology, (effect) => executor.execute(effect));
			expect(result.finding).toMatchObject({
				completedWorkItems: 30,
				admittedAttempts: 35,
				stoppingReason: "campaign-complete",
				providerOutcomeReasonCounts: {
					"response-output-truncated": 30,
					"tool-proposed": 5,
				},
			});
			expect(result.peakConcurrentEffects).toBe(1);
			const requests = executor.providerRequestSummaries();
			expect(requests).toHaveLength(35);
			expect(capturedTargetTaskStatements).toHaveLength(30);
			for (const task of ROOT_EVAL_DEVELOPMENT_TASKS) {
				const sixArmStatements = capturedTargetTaskStatements.filter(
					(statement) => statement === task.taskStatement,
				);
				expect(sixArmStatements).toHaveLength(6);
				expect(new Set(sixArmStatements)).toEqual(new Set([task.taskStatement]));
			}
			expect(await readdir(join(temporary, "workspaces"))).toEqual([]);
		} finally {
			await executor.dispose();
			await rm(temporary, { recursive: true, force: true });
		}
	}, 120_000);

	it("classifies a post-header body abort as the Graph-admitted transport timeout", async () => {
		const temporary = await mkdtemp(join(tmpdir(), "graphrefly-root-eval-body-lease-"));
		const privateRoot = await realpath(temporary);
		const claimInput = await currentClaimInput(privateRoot);
		const claimAcquisition = await acquireRootEvalLiveClaimForNoNetworkQualification(claimInput);
		let admitted: EvalAdmittedEffect | undefined;
		const httpTopology = createRootEvalTopology({
			profileInput: createCurrentExactModelHarnessProfileInput(),
			currentKeyBefore: ROOT_EVAL_NO_NETWORK_CURRENT_KEY_BEFORE,
			providerPacingSetTimeout: (callback) => {
				callback();
				return 0 as unknown as ReturnType<typeof setTimeout>;
			},
			campaignRef: ROOT_EVAL_LIVE_GENERATION_REF,
			taskSetRef: ROOT_EVAL_DEVELOPMENT_TASK.taskSetRef,
			maxCostMicrousd: 6_000_000,
			reservationMicrousd: 200_000,
			effectTimeoutMs: 5_000,
		});
		await expect(
			runRootEval(httpTopology, async (effect) => {
				if (admitted === undefined && effect.kind === "eval-admitted-effect") admitted = effect;
				throw new Error("captured body-stall admission");
			}),
		).rejects.toThrow(/captured body-stall admission/u);
		if (admitted === undefined) throw new Error("missing admitted provider effect fixture");
		const materializationRoot = join(temporary, "body-workspaces");
		const executor = createRootEvalLiveTransportQualificationExecutor({
			graph: httpTopology.graph,
			repositoryRoot,
			materializationRoot,
			privateRoot,
			claimCommit: claimAcquisition,
			bearerToken: claimInput.credential.bearerToken,
			pricing: claimInput.pricing,
			providerResponses: [{ status: 200, bytes: providerBytes(), stallBodyUntilAbort: true }],
		});
		try {
			await expect(executor.execute(admitted)).resolves.toMatchObject({
				status: "retryable",
				reason: "transport-availability-retryable",
				recoveryClass: "availability",
				retryAfterMs: 0,
				providerResponseKind: "transport",
				httpStatus: null,
				transportNoToolSideEffect: true,
				costMicrousd: 200_000,
				cleanupCompleted: true,
			});
			expect(executor.providerRequestSummaries()).toHaveLength(1);
			expect(await readdir(materializationRoot)).toEqual([]);
		} finally {
			await executor.dispose();
			await rm(temporary, { recursive: true, force: true });
		}
	}, 120_000);

	it("retains HTTP 429 capacity identity when its optional body aborts", async () => {
		const temporary = await mkdtemp(join(tmpdir(), "graphrefly-root-eval-429-body-lease-"));
		const privateRoot = await realpath(temporary);
		const claimInput = await currentClaimInput(privateRoot);
		const claimAcquisition = await acquireRootEvalLiveClaimForNoNetworkQualification(claimInput);
		let admitted: EvalAdmittedEffect | undefined;
		const httpTopology = createRootEvalTopology({
			profileInput: createCurrentExactModelHarnessProfileInput(),
			currentKeyBefore: ROOT_EVAL_NO_NETWORK_CURRENT_KEY_BEFORE,
			providerPacingSetTimeout: (callback) => {
				callback();
				return 0 as unknown as ReturnType<typeof setTimeout>;
			},
			campaignRef: ROOT_EVAL_LIVE_GENERATION_REF,
			taskSetRef: ROOT_EVAL_DEVELOPMENT_TASK.taskSetRef,
			maxCostMicrousd: 6_000_000,
			reservationMicrousd: 200_000,
			effectTimeoutMs: 5_000,
		});
		await expect(
			runRootEval(httpTopology, async (effect) => {
				if (admitted === undefined && effect.kind === "eval-admitted-effect") admitted = effect;
				throw new Error("captured 429 body-stall admission");
			}),
		).rejects.toThrow(/captured 429 body-stall admission/u);
		if (admitted === undefined) throw new Error("missing admitted 429 provider effect fixture");
		const materializationRoot = join(temporary, "body-workspaces");
		const executor = createRootEvalLiveTransportQualificationExecutor({
			graph: httpTopology.graph,
			repositoryRoot,
			materializationRoot,
			privateRoot,
			claimCommit: claimAcquisition,
			bearerToken: claimInput.credential.bearerToken,
			pricing: claimInput.pricing,
			providerResponses: [
				{
					status: 429,
					bytes: new TextEncoder().encode("{}"),
					retryAfter: null,
					stallBodyUntilAbort: true,
				},
			],
		});
		try {
			await expect(executor.execute(admitted)).resolves.toMatchObject({
				status: "retryable",
				reason: "http-capacity-retryable",
				recoveryClass: "capacity",
				retryAfterMs: 0,
				costMicrousd: 200_000,
				cleanupCompleted: true,
			});
			expect(executor.providerRequestSummaries()).toHaveLength(1);
			expect(await readdir(materializationRoot)).toEqual([]);
		} finally {
			await executor.dispose();
			await rm(temporary, { recursive: true, force: true });
		}
	}, 120_000);

	it("does not turn a dispatch observer failure into availability retry after a 429 body abort", async () => {
		const temporary = await mkdtemp(join(tmpdir(), "graphrefly-root-eval-429-body-lease-"));
		const privateRoot = await realpath(temporary);
		const claimInput = await currentClaimInput(privateRoot);
		const claimAcquisition = await acquireRootEvalLiveClaimForNoNetworkQualification(claimInput);
		let admitted: EvalAdmittedEffect | undefined;
		const httpTopology = createRootEvalTopology({
			profileInput: createCurrentExactModelHarnessProfileInput(),
			currentKeyBefore: ROOT_EVAL_NO_NETWORK_CURRENT_KEY_BEFORE,
			providerPacingSetTimeout: (callback) => {
				callback();
				return 0 as unknown as ReturnType<typeof setTimeout>;
			},
			campaignRef: ROOT_EVAL_LIVE_GENERATION_REF,
			taskSetRef: ROOT_EVAL_DEVELOPMENT_TASK.taskSetRef,
			maxCostMicrousd: 6_000_000,
			reservationMicrousd: 200_000,
			effectTimeoutMs: 5_000,
		});
		await expect(
			runRootEval(httpTopology, async (effect) => {
				if (admitted === undefined && effect.kind === "eval-admitted-effect") admitted = effect;
				throw new Error("captured 429 body-stall admission");
			}),
		).rejects.toThrow(/captured 429 body-stall admission/u);
		if (admitted === undefined) throw new Error("missing admitted 429 provider effect fixture");
		const materializationRoot = join(temporary, "body-workspaces");
		const executor = createRootEvalLiveTransportQualificationExecutor({
			graph: httpTopology.graph,
			repositoryRoot,
			materializationRoot,
			privateRoot,
			claimCommit: claimAcquisition,
			bearerToken: claimInput.credential.bearerToken,
			pricing: claimInput.pricing,
			onProviderCall: () => {
				throw new Error("dispatch observer failed");
			},
			providerResponses: [
				{
					status: 429,
					bytes: new TextEncoder().encode("{}"),
					retryAfter: null,
					stallBodyUntilAbort: true,
				},
			],
		});
		try {
			await expect(executor.execute(admitted)).resolves.toMatchObject({
				status: "failed",
				reason: "executor-failed",
				recoveryClass: null,
				httpStatus: 429,
				providerResponseKind: "http",
				transportNoToolSideEffect: false,
				retryAfterMs: 0,
				costMicrousd: 200_000,
				cleanupCompleted: true,
			});
			expect(executor.providerRequestSummaries()).toHaveLength(1);
			expect(await readdir(materializationRoot)).toEqual([]);
		} finally {
			await executor.dispose();
			await rm(temporary, { recursive: true, force: true });
		}
	}, 120_000);

	it("qualifies fresh Together pricing and the exact route through the ZDR registry", async () => {
		const pricingEnvelope = {
			data: {
				id: "deepseek/deepseek-v4-flash-0731",
				endpoints: [
					{
						provider_name: "Together",
						tag: "together",
						quantization: "unknown",
						model_id: "deepseek/deepseek-v4-flash-0731",
						name: "Together | deepseek/deepseek-v4-flash-20260731",
						supported_parameters: [
							"max_tokens",
							"reasoning",
							"response_format",
							"structured_outputs",
						],
						pricing: {
							prompt: "0.00000014",
							completion: "0.00000028",
							input_cache_read: "0.00000003",
						},
					},
				],
			},
		};
		const zdrEndpoint = {
			provider_name: "Together",
			tag: "together",
			model_id: "deepseek/deepseek-v4-flash-0731",
			name: "Together | deepseek/deepseek-v4-flash-20260731",
		};
		const fetchWithZdr = async (url: string | URL | Request): Promise<Response> => {
			const target = String(url);
			const response = new Response(
				JSON.stringify(
					target === ROOT_EVAL_LIVE_PRICING_SOURCE ? pricingEnvelope : { data: [zdrEndpoint] },
				),
				{ status: 200 },
			);
			Object.defineProperty(response, "url", { value: target });
			return response;
		};
		await expect(
			readRootEvalLivePricing({ fetchImpl: fetchWithZdr as typeof fetch, nowMs: 123 }),
		).resolves.toMatchObject({
			providerName: "Together",
			providerRef: "together",
			zeroDataRetention: true,
			promptTraining: false,
			zdrSourceUrl: ROOT_EVAL_LIVE_ZDR_SOURCE,
		});
		const fetchWithoutZdr = async (url: string | URL | Request): Promise<Response> => {
			const target = String(url);
			const response = new Response(
				JSON.stringify(target === ROOT_EVAL_LIVE_PRICING_SOURCE ? pricingEnvelope : { data: [] }),
				{ status: 200 },
			);
			Object.defineProperty(response, "url", { value: target });
			return response;
		};
		await expect(
			readRootEvalLivePricing({ fetchImpl: fetchWithoutZdr as typeof fetch, nowMs: 123 }),
		).rejects.toThrow(/not uniquely ZDR-qualified/u);
	});

	it("bounds external response bodies while streaming", async () => {
		let declaredOversizeCancelled = false;
		const declaredOversize = new Response(
			new ReadableStream<Uint8Array>({
				cancel() {
					declaredOversizeCancelled = true;
				},
			}),
			{ headers: { "content-length": "1025" } },
		);
		await expect(
			readRootEvalBoundedResponseBytes(declaredOversize, 1024, "test response"),
		).rejects.toThrow(/content-length bound/u);
		expect(declaredOversizeCancelled).toBe(true);
		const response = new Response(
			new ReadableStream<Uint8Array>({
				start(controller) {
					controller.enqueue(new Uint8Array(700));
					controller.enqueue(new Uint8Array(700));
					controller.close();
				},
			}),
		);
		await expect(readRootEvalBoundedResponseBytes(response, 1024, "test response")).rejects.toThrow(
			/streaming byte bound/u,
		);
	});

	it("rejects duplicate keys in every external JSON authority", async () => {
		const exactEndpoint = {
			provider_name: "Together",
			tag: "together",
			quantization: "unknown",
			model_id: "deepseek/deepseek-v4-flash-0731",
			name: "Together | deepseek/deepseek-v4-flash-20260731",
			supported_parameters: ["max_tokens", "reasoning", "response_format", "structured_outputs"],
			pricing: {
				prompt: "0.00000014",
				completion: "0.00000028",
				input_cache_read: "0.00000003",
			},
		};
		const exactPricing = JSON.stringify({
			data: { id: "deepseek/deepseek-v4-flash-0731", endpoints: [exactEndpoint] },
		});
		const exactZdr = JSON.stringify({ data: [exactEndpoint] });
		const responseAt = (target: string, body: string): Response => {
			const response = new Response(body, { status: 200 });
			Object.defineProperty(response, "url", { value: target });
			return response;
		};
		await expect(
			readRootEvalLivePricing({
				nowMs: 1,
				fetchImpl: (async (url: string | URL | Request) => {
					const target = String(url);
					return responseAt(
						target,
						exactPricing.replace(
							'"id":"deepseek/deepseek-v4-flash-0731"',
							'"id":"other","id":"deepseek/deepseek-v4-flash-0731"',
						),
					);
				}) as typeof fetch,
			}),
		).rejects.toThrow(/unique-key UTF-8 JSON/u);
		await expect(
			readRootEvalLivePricing({
				nowMs: 1,
				fetchImpl: (async (url: string | URL | Request) => {
					const target = String(url);
					return responseAt(
						target,
						target === ROOT_EVAL_LIVE_PRICING_SOURCE
							? exactPricing
							: exactZdr.replace('"data":', '"data":[],"data":'),
					);
				}) as typeof fetch,
			}),
		).rejects.toThrow(/unique-key UTF-8 JSON/u);
		const credential = parseRootEvalLiveCredential(
			new TextEncoder().encode("OPENROUTER_API_KEY=sk-or-v1-a44-middle-credential-e06\n"),
		);
		const receipt = precredentialGateReceipt(0);
		expect(() =>
			admitRootEvalLiveZeroByok({
				credential,
				precredentialGateReceipt: receipt,
				nowMs: 1,
				bytes: operatorConfigurationBytes(1, true),
			}),
		).toThrow(/unique-key UTF-8 JSON/u);
		await expect(
			readRootEvalLiveCurrentKey({
				credential,
				fetchImpl: (async () =>
					new Response(
						'{"data":{"limit":32,"limit_remaining":7,"usage":24,"usage":25,"limit_reset":null,"is_management_key":false}}',
						{ status: 200 },
					)) as typeof fetch,
			}),
		).rejects.toThrow(/unique-key UTF-8 JSON/u);
	});

	it("parses exactly one bounded structured proposal and accounts conservatively", () => {
		const parsed = parseRootEvalLiveProviderResponse({
			route: { providerRef: "fireworks", providerModelRef: "deepseek/deepseek-v4-flash-0731" },
			status: 200,
			bytes: historicalFireworksProviderBytes(),
			retryAfter: null,
			pricing: historicalFireworksPricing,
			reservationMicrousd: 200_000,
		});
		expect(parsed.disposition).toBe("tool");
		expect(parsed.reason).toBe("tool-proposed");
		expect(parsed.costMicrousd).toBe(265);
		expect(parsed.pricingRoundingAllowanceMicrousd).toBe(1);
		const catalog = rootEvalToolCandidateCatalog(
			ROOT_EVAL_DEVELOPMENT_TASK,
			"target",
			DEFAULT_TEST_WORK_ITEM_ID,
		);
		expect(parsed.tool).toEqual({
			candidateRef: catalog.candidates[0].candidateRef,
			candidateCatalogDigest: catalog.catalogDigest,
		});
		expect(
			parseRootEvalLiveProviderResponse({
				route: { providerRef: "fireworks", providerModelRef: "deepseek/deepseek-v4-flash-0731" },
				status: 429,
				bytes: new TextEncoder().encode("{}"),
				retryAfter: "61",
				pricing,
				reservationMicrousd: 200_000,
			}),
		).toMatchObject({ disposition: "retryable", retryAfterMs: 61_000, costMicrousd: 200_000 });
		expect(
			parseRootEvalLiveProviderResponse({
				route: { providerRef: "fireworks", providerModelRef: "deepseek/deepseek-v4-flash-0731" },
				status: 429,
				bytes: historicalFireworksProviderBytes(),
				retryAfter: "61",
				pricing: historicalFireworksPricing,
				reservationMicrousd: 100,
			}),
		).toMatchObject({
			disposition: "retryable",
			costEvidence: "provider-reported",
			costMicrousd: 265,
		});
		expect(
			parseRootEvalLiveProviderResponse({
				route: { providerRef: "fireworks", providerModelRef: "deepseek/deepseek-v4-flash-0731" },
				status: 429,
				bytes: new TextEncoder().encode('{"usage":{"cost":0.000265}}'),
				retryAfter: "61",
				pricing: historicalFireworksPricing,
				reservationMicrousd: 100,
			}),
		).toMatchObject({
			disposition: "retryable",
			costEvidence: "provider-reported",
			costMicrousd: 265,
		});
		const incompleteUsage = JSON.parse(
			new TextDecoder().decode(historicalFireworksProviderBytes()),
		) as Record<string, unknown>;
		incompleteUsage.usage = { cost: 0.000265 };
		try {
			parseRootEvalLiveProviderResponse({
				route: { providerRef: "fireworks", providerModelRef: "deepseek/deepseek-v4-flash-0731" },
				status: 200,
				bytes: new TextEncoder().encode(JSON.stringify(incompleteUsage)),
				retryAfter: null,
				pricing: historicalFireworksPricing,
				reservationMicrousd: 100,
			});
			throw new TypeError("incomplete usage unexpectedly passed");
		} catch (error) {
			expect(error).toMatchObject({
				reason: "response-usage-invalid",
				costMicrousd: 265,
				costEvidence: "provider-reported",
			});
		}
		for (const [retryAfter, expectedMs] of [
			[null, 0],
			["malformed", 0],
			["1", 1_000],
			["121", 121_000],
			["Wed, 21 Oct 2015 07:28:00 GMT", 0],
		] as const)
			expect(
				parseRootEvalLiveProviderResponse({
					route: { providerRef: "fireworks", providerModelRef: "deepseek/deepseek-v4-flash-0731" },
					status: 429,
					bytes: new TextEncoder().encode("{}"),
					retryAfter,
					pricing: historicalFireworksPricing,
					reservationMicrousd: 200_000,
				}),
				retryAfter ?? "missing Retry-After",
			).toMatchObject({ disposition: "retryable", retryAfterMs: expectedMs });
		expect(
			parseRootEvalLiveProviderResponse({
				route: { providerRef: "fireworks", providerModelRef: "deepseek/deepseek-v4-flash-0731" },
				status: 503,
				bytes: new TextEncoder().encode("{}"),
				retryAfter: "5",
				pricing: historicalFireworksPricing,
				reservationMicrousd: 200_000,
			}),
		).toMatchObject({
			disposition: "retryable",
			reason: "http-availability-retryable",
			recoveryClass: "availability",
			retryAfterMs: 5_000,
			costMicrousd: 200_000,
		});
		expect(
			parseRootEvalLiveProviderResponse({
				route: { providerRef: "fireworks", providerModelRef: "deepseek/deepseek-v4-flash-0731" },
				status: 429,
				bytes: new TextEncoder().encode("{}"),
				retryAfter: "241",
				pricing: historicalFireworksPricing,
				reservationMicrousd: 200_000,
			}),
		).toMatchObject({
			disposition: "retryable",
			retryAfterMs: 240_001,
			recoveryClass: "capacity",
		});
		for (const status of [408, 425, 502, 503, 504, 520])
			expect(
				parseRootEvalLiveProviderResponse({
					route: { providerRef: "fireworks", providerModelRef: "deepseek/deepseek-v4-flash-0731" },
					status,
					bytes: new TextEncoder().encode("{}"),
					retryAfter: null,
					pricing: historicalFireworksPricing,
					reservationMicrousd: 200_000,
				}),
			).toMatchObject({
				disposition: "retryable",
				reason: "http-availability-retryable",
				recoveryClass: "availability",
			});
		expect(
			parseRootEvalLiveProviderResponse({
				route: { providerRef: "fireworks", providerModelRef: "deepseek/deepseek-v4-flash-0731" },
				status: 500,
				bytes: new TextEncoder().encode(
					JSON.stringify({ error: { metadata: { provider_error_code: "provider_overloaded" } } }),
				),
				retryAfter: null,
				pricing: historicalFireworksPricing,
				reservationMicrousd: 200_000,
			}),
		).toMatchObject({ disposition: "retryable", reason: "http-availability-retryable" });
		for (const status of [400, 401, 402, 403, 404, 405, 413, 415, 422, 500, 501, 505])
			expect(
				parseRootEvalLiveProviderResponse({
					route: { providerRef: "fireworks", providerModelRef: "deepseek/deepseek-v4-flash-0731" },
					status,
					bytes: new TextEncoder().encode("{}"),
					retryAfter: null,
					pricing: historicalFireworksPricing,
					reservationMicrousd: 200_000,
				}),
			).toMatchObject({
				disposition: "failed",
				reason: "http-terminal",
				recoveryClass: null,
			});
		for (const status of [429, 503, 400] as const)
			for (const bytes of [
				new Uint8Array(),
				new TextEncoder().encode("not-json"),
				new Uint8Array(2 * 1_048_576 + 1),
			]) {
				const result = parseRootEvalLiveProviderResponse({
					route: { providerRef: "fireworks", providerModelRef: "deepseek/deepseek-v4-flash-0731" },
					status,
					bytes,
					retryAfter: null,
					pricing: historicalFireworksPricing,
					reservationMicrousd: 200_000,
				});
				expect(result).toMatchObject(
					status === 429
						? { disposition: "retryable", recoveryClass: "capacity" }
						: status === 503
							? { disposition: "retryable", recoveryClass: "availability" }
							: { disposition: "failed", reason: "http-terminal", recoveryClass: null },
				);
			}
		const documentedUsage = JSON.parse(
			new TextDecoder().decode(historicalFireworksProviderBytes()),
		) as Record<string, unknown>;
		const usage = { ...(documentedUsage.usage as Record<string, unknown>) };
		delete usage.prompt_tokens_details;
		usage.cost = 0.000286;
		const withoutCacheDetails = parseRootEvalLiveProviderResponse({
			route: { providerRef: "fireworks", providerModelRef: "deepseek/deepseek-v4-flash-0731" },
			status: 200,
			bytes: new TextEncoder().encode(JSON.stringify({ ...documentedUsage, usage })),
			retryAfter: null,
			pricing: historicalFireworksPricing,
			reservationMicrousd: 200_000,
		});
		expect(withoutCacheDetails).toMatchObject({
			disposition: "tool",
			reason: "tool-proposed",
			costMicrousd: 286,
			pricingRoundingAllowanceMicrousd: 0,
		});
		const oneMicrousd = JSON.parse(
			new TextDecoder().decode(historicalFireworksProviderBytes()),
		) as Record<string, unknown>;
		oneMicrousd.usage = {
			prompt_tokens: 2,
			completion_tokens: 1,
			total_tokens: 3,
			cost: 0.000000887,
			prompt_tokens_details: { cached_tokens: 1 },
		};
		expect(
			parseRootEvalLiveProviderResponse({
				route: { providerRef: "fireworks", providerModelRef: "deepseek/deepseek-v4-flash-0731" },
				status: 200,
				bytes: new TextEncoder().encode(JSON.stringify(oneMicrousd)),
				retryAfter: null,
				pricing: historicalFireworksPricing,
				reservationMicrousd: 200_000,
			}),
		).toMatchObject({
			costMicrousd: 1,
			pricingRoundingAllowanceMicrousd: 1,
		});
	}, 15_000);

	it("accepts only the admitted Together identity, model revision and structured proposal", () => {
		const base = JSON.parse(new TextDecoder().decode(providerBytes()));
		const route = { providerRef: "together", providerModelRef: "deepseek/deepseek-v4-flash-0731" };
		const parse = (response: unknown, admittedRoute = route) =>
			parseRootEvalLiveProviderResponse({
				route: admittedRoute,
				status: 200,
				bytes: new TextEncoder().encode(JSON.stringify(response)),
				retryAfter: null,
				pricing,
				reservationMicrousd: 200_000,
			});
		for (const model of [route.providerModelRef, "deepseek/deepseek-v4-flash-20260731"])
			expect(parse({ ...base, provider: "Together", model })).toMatchObject({
				disposition: "tool",
				costEvidence: "provider-reported",
				costMicrousd: 157,
			});
		for (const provider of ["Fireworks", "DeepInfra", "together", null])
			expect(() => parse({ ...base, provider })).toThrow(/route identity/);
		expect(() =>
			parse({ ...base, provider: "Together", model: "deepseek/deepseek-v4-flash" }),
		).toThrow(/route identity/);
		expect(() =>
			parse({ ...base, provider: "Together" }, { ...route, providerRef: "fireworks" }),
		).toThrow(/route identity/);
		expect(() =>
			parse({
				...base,
				provider: "Together",
				choices: [{ message: { content: null, tool_calls: [] } }],
			}),
		).toThrow();
	});

	it("classifies malformed provider responses with closed material-free reasons", () => {
		const catalog = rootEvalToolCandidateCatalog(
			ROOT_EVAL_DEVELOPMENT_TASK,
			"target",
			DEFAULT_TEST_WORK_ITEM_ID,
		);
		const providerText = new TextDecoder().decode(historicalFireworksProviderBytes());
		const base = JSON.parse(providerText) as Record<string, unknown>;
		const reasonFor = (value: unknown | Uint8Array): string => {
			const bytes =
				value instanceof Uint8Array ? value : new TextEncoder().encode(JSON.stringify(value));
			try {
				parseRootEvalLiveProviderResponse({
					route: { providerRef: "fireworks", providerModelRef: "deepseek/deepseek-v4-flash-0731" },
					status: 200,
					bytes,
					retryAfter: null,
					pricing: historicalFireworksPricing,
					reservationMicrousd: 200_000,
				});
				return "not-rejected";
			} catch (error) {
				return String((error as { readonly reason?: unknown }).reason);
			}
		};
		const cases = [
			["response-bounds-invalid", new Uint8Array(2 * 1_048_576 + 1)],
			["response-json-invalid", new TextEncoder().encode("{")],
			[
				"response-json-invalid",
				new TextEncoder().encode(
					providerText.replace(
						'"provider":"Fireworks"',
						'"provider":"Other","provider":"Fireworks"',
					),
				),
			],
			[
				"response-json-invalid",
				new TextEncoder().encode(providerText.replace('"usage":{', '"usage":null,"usage":{')),
			],
			[
				"response-json-invalid",
				new TextEncoder().encode(providerText.replace('"choices":[', '"choices":[],"choices":[')),
			],
			["response-route-invalid", { ...base, provider: "Other" }],
			[
				"response-usage-invalid",
				{ ...base, usage: { ...(base.usage as Record<string, unknown>), total_tokens: 0 } },
			],
			[
				"response-usage-invalid",
				{
					...base,
					usage: Object.fromEntries(
						Object.entries(base.usage as Record<string, unknown>).filter(([key]) => key !== "cost"),
					),
				},
			],
			[
				"response-usage-invalid",
				{
					...base,
					usage: { ...(base.usage as Record<string, unknown>), cost: 0.000001 },
				},
			],
			[
				"response-usage-invalid",
				{
					...base,
					usage: {
						prompt_tokens: Number.MAX_SAFE_INTEGER,
						completion_tokens: 0,
						total_tokens: Number.MAX_SAFE_INTEGER,
					},
				},
			],
			["response-choice-invalid", { ...base, choices: [] }],
			[
				"response-output-truncated",
				{
					...base,
					choices: [
						{
							...(base.choices as readonly Record<string, unknown>[])[0],
							finish_reason: "length",
						},
					],
				},
			],
			[
				"response-proposal-invalid",
				{
					...base,
					choices: [
						{
							...(base.choices as readonly Record<string, unknown>[])[0],
							native_finish_reason: "content_filter",
						},
					],
				},
			],
			["response-proposal-missing", { ...base, choices: [{ message: { role: "assistant" } }] }],
			[
				"response-proposal-legacy-shape",
				{
					...base,
					choices: [
						{
							message: {
								content: "{}",
								tool_calls: [],
							},
						},
					],
				},
			],
			[
				"response-proposal-legacy-shape",
				{
					...base,
					choices: [
						{
							index: 0,
							finish_reason: "stop",
							native_finish_reason: "stop",
							message: {
								role: "assistant",
								content: JSON.stringify({ candidateRef: catalog.candidates[0].candidateRef }),
								function_call: { name: "replace_exact", arguments: "{}" },
							},
						},
					],
				},
			],
			[
				"not-rejected",
				{
					...base,
					choices: [
						{
							index: 0,
							finish_reason: "stop",
							native_finish_reason: null,
							message: {
								role: "assistant",
								content: JSON.stringify({ candidateRef: catalog.candidates[0].candidateRef }),
								tool_calls: null,
								function_call: null,
								refusal: null,
							},
						},
					],
				},
			],
			[
				"response-proposal-invalid",
				{
					...base,
					choices: [{ message: { content: "{" } }],
				},
			],
			[
				"response-proposal-invalid",
				{
					...base,
					choices: [
						{
							index: 0,
							finish_reason: "stop",
							native_finish_reason: "stop",
							message: {
								role: "assistant",
								content: `{"candidateRef":"${catalog.candidates[0].candidateRef}","candidateRef":"wrong"}`,
							},
						},
					],
				},
			],
			[
				"response-proposal-invalid",
				{
					...base,
					choices: [
						{ message: { content: JSON.stringify({ path: ROOT_EVAL_LIVE_WRITABLE_PATH }) } },
					],
				},
			],
			[
				"response-proposal-invalid",
				{
					...base,
					choices: [
						{
							message: {
								content: JSON.stringify({
									candidateRef: catalog.candidates[0].candidateRef,
									extra: true,
								}),
							},
						},
					],
				},
			],
			[
				"response-proposal-arguments-invalid",
				{
					...base,
					choices: [
						{
							message: {
								content: JSON.stringify({ candidateRef: "wrong" }),
							},
						},
					],
				},
			],
			[
				"response-proposal-arguments-invalid",
				{
					...base,
					choices: [
						{
							index: 0,
							finish_reason: "stop",
							native_finish_reason: "stop",
							message: {
								role: "assistant",
								content: JSON.stringify({ candidateRef: "\ud800" }),
							},
						},
					],
				},
			],
		] as const;
		for (const [expected, input] of cases) expect(reasonFor(input), expected).toBe(expected);

		const legacyToolCalls = {
			...base,
			choices: [
				{
					message: {
						content: null,
						tool_calls: [{ function: { name: "replace_exact", arguments: "{}" } }],
					},
				},
			],
		};
		try {
			parseRootEvalLiveProviderResponse({
				route: { providerRef: "fireworks", providerModelRef: "deepseek/deepseek-v4-flash-0731" },
				status: 200,
				bytes: new TextEncoder().encode(JSON.stringify(legacyToolCalls)),
				retryAfter: null,
				pricing: historicalFireworksPricing,
				reservationMicrousd: 200_000,
			});
			throw new Error("legacy tool calls were not rejected");
		} catch (error) {
			expect(error).toMatchObject({
				reason: "response-proposal-legacy-shape",
				costMicrousd: 265,
			});
		}
	});

	it("retains every success invariant as a stable material-free rejection code", () => {
		const base = liveEvidenceInput();
		const workItemCount = ROOT_EVAL_LIVE_REPLICATE_COUNT * arms.length;
		expect(evaluateRootEvalLiveAdmission(base).admissionReport).toEqual({
			status: "admitted",
			violationCodes: [],
			rejectedGraphSummary: null,
		});
		const ids = base.graphResult?.executedAdmissionIds ?? [];
		const cases: ReadonlyArray<
			readonly [(typeof ROOT_EVAL_LIVE_SUCCESS_VIOLATION_CODES)[number], RootEvalLiveEvidenceInput]
		> = [
			["success.graph-shape-invalid", withGraphResult(base, { peakConcurrentEffects: -1 })],
			["success.current-key-before-missing", { ...base, currentKeyBefore: null }],
			["success.failure-present", { ...base, failure: new Error("private-marker") }],
			["success.cleanup-incomplete", { ...base, cleanupDisposition: "failed" }],
			["success.campaign-ref-mismatch", withGraphResult(base, {}, { campaignRef: "wrong" })],
			["success.replicate-count-mismatch", withGraphResult(base, {}, { replicateCount: 4 })],
			[
				"success.completed-work-items-mismatch",
				withGraphResult(base, {}, { completedWorkItems: workItemCount - 1 }),
			],
			[
				"success.finding-mismatch",
				withGraphResult(base, {}, { finding: "no-positive-differential" }),
			],
			[
				"success.pass-counts-invalid",
				withGraphResult(
					base,
					{},
					{
						passCounts: {
							...base.graphResult!.finding.passCounts,
							"relevant-applied": ROOT_EVAL_LIVE_REPLICATE_COUNT + 1,
						},
					},
				),
			],
			["success.observations-empty", withGraphResult(base, { observations: [] })],
			[
				"success.terminal-observation-missing",
				withTerminalObservation(base, { finding: "pending" }),
			],
			[
				"success.terminal-finding-mismatch",
				withTerminalObservation(base, { finding: "no-positive-differential" }),
			],
			[
				"success.terminal-stopping-reason-mismatch",
				withTerminalObservation(base, { stoppingReason: "budget-exhausted" }),
			],
			[
				"success.terminal-observation-order-invalid",
				withGraphResult(base, {
					observations: [
						...base.graphResult!.observations,
						withTerminalObservation(base, { finding: "pending" }).graphResult!.observations.at(-1)!,
					],
				}),
			],
			[
				"success.terminal-observation-state-mismatch",
				withTerminalObservation(base, {
					activeProviderEffects: 1,
					activeAdmittedEffects: 1,
					admittedAttempts: workItemCount + 1,
					providerCapacity: {
						kind: "eval-provider-capacity-state",
						pacingRevision: workItemCount,
						providerStartIntervalMs: 30_000,
						consecutiveUsableResponses: workItemCount % 3,
						mode: "paced-serial",
						initialMaxConcurrentEffects: 1,
						maxConcurrentEffects: 1,
						activeEffects: 1,
						proposalCount: workItemCount + 1,
						pendingProposalCount: 0,
						pendingFirstAttemptProposalCount: 0,
						pendingRetryProposalCount: 0,
						retryProposalCount: 0,
						admittedProposalCount: workItemCount + 1,
						admittedRetryProposalCount: 0,
						settledProposalCount: workItemCount,
						settledRetryProposalCount: 0,
						rejectedProposalCount: 0,
						rejectedRetryProposalCount: 0,
						cooldownOutstandingReadinessCount: 0,
						rateLimitFeedbackCount: 0,
					},
				}),
			],
			["success.peak-concurrency-below-one", withGraphResult(base, { peakConcurrentEffects: 0 })],
			[
				"success.peak-provider-concurrency-above-one",
				withGraphResult(base, { peakConcurrentEffects: 3 }),
			],
			[
				"success.admission-count-below-thirty",
				withGraphResult(base, { executedAdmissionIds: ids.slice(0, -1) }),
			],
			[
				"success.admission-identities-duplicate",
				withGraphResult(base, { executedAdmissionIds: [...ids.slice(0, -1), ids[0]!] }),
			],
			[
				"success.finding-admitted-attempts-mismatch",
				withGraphResult(base, {}, { admittedAttempts: workItemCount - 1 }),
			],
			[
				"success.provider-outcome-reason-count-mismatch",
				withGraphResult(
					base,
					{},
					{
						providerOutcomeReasonCounts: {
							...providerOutcomeReasonCounts,
							"tool-proposed": workItemCount - 1,
						},
					},
				),
			],
			[
				"success.accounted-budget-above-cap",
				withGraphResult(
					base,
					{},
					{
						accountedUpperBoundMicrousd: ROOT_EVAL_LIVE_CAMPAIGN_HARD_CAP_MICROUSD + 1,
					},
				),
			],
			["success.provider-call-count-mismatch", { ...base, providerCalls: workItemCount - 1 }],
		];
		expect(cases.map(([code]) => code)).toEqual(ROOT_EVAL_LIVE_SUCCESS_VIOLATION_CODES);
		for (const [code, input] of cases) {
			const evaluation = evaluateRootEvalLiveAdmission(input);
			const report = evaluation.admissionReport;
			expect(report.status, code).toBe("rejected");
			expect(report.violationCodes, code).toContain(code);
			const indexes = report.violationCodes.map((item) =>
				ROOT_EVAL_LIVE_SUCCESS_VIOLATION_CODES.indexOf(item),
			);
			expect(indexes, code).toEqual([...indexes].sort((left, right) => left - right));
			expect(JSON.stringify(report), code).not.toMatch(
				/private-marker|authorization|bearer|admission-0/iu,
			);
			const callerDispositionOnly = [
				"success.current-key-before-missing",
				"success.failure-present",
				"success.cleanup-incomplete",
				"success.provider-call-count-mismatch",
			].includes(code);
			expect(evaluation.projectedGraph !== null, code).toBe(callerDispositionOnly);
		}
	});

	it("admits a development generation that correctly resets a prior qualification streak", () => {
		let input = withRehashedClaim(liveEvidenceInput(), {
			developmentQualificationStreakBefore: 1,
		});
		input = withGraphResult(
			input,
			{},
			{
				evaluableReplicates: 3,
				excludedTechnicalReplicates: [2, 5],
				matchedRelevantOverColdWins: 3,
				passCounts: {
					...input.graphResult!.finding.passCounts,
					"relevant-applied": 3,
				},
				finding: "operationally-inconclusive",
			},
		);
		input = withTerminalObservation(input, {
			evaluableReplicates: 3,
			excludedTechnicalReplicates: [2, 5],
			matchedRelevantOverColdWins: 3,
			developmentQualification: {
				kind: "eval-development-qualification-state",
				campaignPurpose: ROOT_EVAL_LIVE_CAMPAIGN_PURPOSE,
				generationRef: ROOT_EVAL_LIVE_GENERATION_REF,
				status: "reset",
				generationQualified: false,
				consecutiveQualifyingGenerations: 0,
				requiredConsecutiveGenerations: 2,
				heldOutEligible: false,
			},
			finding: "operationally-inconclusive",
		});

		expect(evaluateRootEvalLiveAdmission(input).admissionReport).toEqual({
			status: "admitted",
			violationCodes: [],
			rejectedGraphSummary: null,
		});
	});

	it("admits only the closed source-and-target Work Item admission identity space", () => {
		const base = liveEvidenceInput();
		const targetIds = base.graphResult?.executedAdmissionIds ?? [];
		const withSource = withGraphResult(base, {
			executedAdmissionIds: [sourceAdmissionId(1), ...targetIds.slice(1)],
		});
		expect(evaluateRootEvalLiveAdmission(withSource).admissionReport).toEqual({
			status: "admitted",
			violationCodes: [],
			rejectedGraphSummary: null,
		});

		for (const invalidId of [
			sourceAdmissionId(1).replace("/dispatch-1/", "/dispatch-6/"),
			sourceAdmissionId(1).replace(ROOT_EVAL_LIVE_TASK_SET_REF, "unbound-task-set"),
		]) {
			const invalid = withGraphResult(base, {
				executedAdmissionIds: [invalidId, ...targetIds.slice(1)],
			});
			expect(evaluateRootEvalLiveAdmission(invalid).admissionReport).toEqual({
				status: "rejected",
				violationCodes: ["success.graph-shape-invalid"],
				rejectedGraphSummary: null,
			});
		}
	});

	it("fails closed on verification-diagnostics shape, conservation, binding, and progress drift", () => {
		const base = liveEvidenceInput();
		const baseDiagnostics = base.graphResult!.finding.verificationDiagnostics;
		const missingStage = structuredClone(baseDiagnostics) as Record<string, unknown>;
		delete (missingStage.stageCounts as Record<string, Record<string, unknown>>).cold
			.cleanupCompleted;
		expect(
			evaluateRootEvalLiveAdmission(
				withGraphResult(base, {}, { verificationDiagnostics: missingStage as never }),
			).admissionReport,
		).toMatchObject({ status: "rejected", violationCodes: ["success.graph-shape-invalid"] });

		const reasonDrift = structuredClone(baseDiagnostics);
		reasonDrift.terminalReasonCounts.cold["no-change"] = 4;
		const reasonDriftInput = withTerminalObservation(
			withGraphResult(base, {}, { verificationDiagnostics: reasonDrift }),
			{ verificationDiagnostics: reasonDrift },
		);
		expect(evaluateRootEvalLiveAdmission(reasonDriftInput).admissionReport).toMatchObject({
			status: "rejected",
			violationCodes: ["success.graph-shape-invalid"],
		});

		const unreachableReason = structuredClone(baseDiagnostics);
		unreachableReason.stageCounts.cold.exactToolAdmitted = 0;
		unreachableReason.stageCounts.cold.scopedChange = 0;
		unreachableReason.stageCounts.cold.publicSemanticPassed = 0;
		unreachableReason.stageCounts.cold.hiddenVerifierPassed = 0;
		unreachableReason.terminalReasonCounts.cold["no-change"] = 0;
		unreachableReason.terminalReasonCounts.cold["hidden-verifier-failed"] = 5;
		const unreachableReasonInput = withTerminalObservation(
			withGraphResult(base, {}, { verificationDiagnostics: unreachableReason }),
			{ verificationDiagnostics: unreachableReason },
		);
		expect(evaluateRootEvalLiveAdmission(unreachableReasonInput).admissionReport).toMatchObject({
			status: "rejected",
			violationCodes: ["success.graph-shape-invalid"],
		});

		const impossibleCleanupObscuring = structuredClone(baseDiagnostics);
		impossibleCleanupObscuring.stageCounts.cold.exactToolAdmitted = 4;
		impossibleCleanupObscuring.stageCounts.cold.scopedChange = 1;
		impossibleCleanupObscuring.stageCounts.cold.publicSemanticPassed = 0;
		impossibleCleanupObscuring.stageCounts.cold.hiddenVerifierPassed = 0;
		impossibleCleanupObscuring.stageCounts.cold.cleanupCompleted = 4;
		impossibleCleanupObscuring.terminalReasonCounts.cold["cleanup-incomplete"] = 1;
		impossibleCleanupObscuring.terminalReasonCounts.cold["exact-tool-failed"] = 4;
		impossibleCleanupObscuring.terminalReasonCounts.cold["no-change"] = 0;
		const impossibleCleanupInput = withTerminalObservation(
			withGraphResult(base, {}, { verificationDiagnostics: impossibleCleanupObscuring }),
			{ verificationDiagnostics: impossibleCleanupObscuring },
		);
		expect(evaluateRootEvalLiveAdmission(impossibleCleanupInput).admissionReport).toMatchObject({
			status: "rejected",
			violationCodes: ["success.graph-shape-invalid"],
		});

		const bindingDrift = structuredClone(baseDiagnostics);
		bindingDrift.stageCounts["relevant-applied"].hiddenVerifierPassed = 0;
		bindingDrift.stageCounts["relevant-applied"].passed = 0;
		bindingDrift.terminalReasonCounts["relevant-applied"].passed = 0;
		bindingDrift.terminalReasonCounts["relevant-applied"]["hidden-verifier-failed"] =
			ROOT_EVAL_LIVE_REPLICATE_COUNT;
		const bindingDriftInput = withTerminalObservation(
			withGraphResult(base, {}, { verificationDiagnostics: bindingDrift }),
			{ verificationDiagnostics: bindingDrift },
		);
		expect(evaluateRootEvalLiveAdmission(bindingDriftInput).admissionReport).toMatchObject({
			status: "rejected",
			violationCodes: ["success.pass-counts-invalid", "success.terminal-observation-order-invalid"],
		});

		const terminal = base.graphResult!.observations.at(-1)!;
		for (const invalidSequence of [
			[terminal],
			base.graphResult!.observations.slice(2),
			[
				base.graphResult!.observations[0]!,
				base.graphResult!.observations[2]!,
				...base.graphResult!.observations.slice(3),
			],
		])
			expect(
				evaluateRootEvalLiveAdmission(withGraphResult(base, { observations: invalidSequence }))
					.admissionReport,
			).toMatchObject({
				status: "rejected",
				violationCodes: expect.arrayContaining(["success.terminal-observation-order-invalid"]),
			});

		const terminalValue = terminal.msg[1] as unknown as Record<string, unknown>;
		const pendingValue = {
			...terminalValue,
			finding: "pending",
			evaluableReplicates: null,
			excludedTechnicalReplicates: [],
			sourceTechnicalExcludedReplicates: [],
			matchedRelevantOverColdWins: null,
			observedBilledMicrousd: null,
			billingObservationCount: 0,
			billingStableIntervals: 0,
			reconciledBilledMicrousd: null,
			billingDisposition: "pending",
		};
		const regressed = structuredClone(baseDiagnostics);
		regressed.stageCounts.cold.completedWorkItems = 0;
		regressed.stageCounts.cold.exactToolAdmitted = 0;
		regressed.stageCounts.cold.cleanupCompleted = 0;
		regressed.terminalReasonCounts.cold["no-change"] = 0;
		regressed.completedWorkItems =
			baseDiagnostics.completedWorkItems - ROOT_EVAL_LIVE_REPLICATE_COUNT;
		const progressDrift = withGraphResult(base, {
			observations: [
				{ ...terminal, seq: 1, msg: ["DATA", pendingValue] as never },
				{
					...terminal,
					seq: 2,
					msg: ["DATA", { ...pendingValue, verificationDiagnostics: regressed }] as never,
				},
				{ ...terminal, seq: 3 },
			],
		});
		expect(evaluateRootEvalLiveAdmission(progressDrift).admissionReport).toMatchObject({
			status: "rejected",
			violationCodes: ["success.terminal-observation-order-invalid"],
		});

		const higherScopedProgress = structuredClone(baseDiagnostics);
		higherScopedProgress.stageCounts.cold.scopedChange = 1;
		higherScopedProgress.terminalReasonCounts.cold["no-change"] =
			ROOT_EVAL_LIVE_REPLICATE_COUNT - 1;
		higherScopedProgress.terminalReasonCounts.cold["public-semantic-failed"] = 1;
		const equalCompletionStageRegression = withGraphResult(base, {
			observations: [
				{
					...terminal,
					seq: 1,
					msg: [
						"DATA",
						{
							...pendingValue,
							verificationDiagnostics: higherScopedProgress,
						},
					] as never,
				},
				{ ...terminal, seq: 2 },
			],
		});
		expect(
			evaluateRootEvalLiveAdmission(equalCompletionStageRegression).admissionReport,
		).toMatchObject({
			status: "rejected",
			violationCodes: ["success.terminal-observation-order-invalid"],
		});

		const priorReasonProgress = structuredClone(baseDiagnostics);
		priorReasonProgress.terminalReasonCounts.cold["no-change"] = ROOT_EVAL_LIVE_REPLICATE_COUNT - 1;
		priorReasonProgress.terminalReasonCounts.cold["exact-tool-failed"] = 1;
		const equalCompletionReasonRegression = withGraphResult(base, {
			observations: [
				{
					...terminal,
					seq: 1,
					msg: [
						"DATA",
						{
							...pendingValue,
							verificationDiagnostics: priorReasonProgress,
						},
					] as never,
				},
				{ ...terminal, seq: 2 },
			],
		});
		expect(
			evaluateRootEvalLiveAdmission(equalCompletionReasonRegression).admissionReport,
		).toMatchObject({
			status: "rejected",
			violationCodes: ["success.terminal-observation-order-invalid"],
		});

		const duplicateProgress = withGraphResult(base, {
			observations: [
				{ ...terminal, seq: 1, msg: ["DATA", pendingValue] as never },
				{ ...terminal, seq: 2, msg: ["DATA", pendingValue] as never },
				{ ...terminal, seq: 3 },
			],
		});
		expect(evaluateRootEvalLiveAdmission(duplicateProgress).admissionReport).toMatchObject({
			status: "rejected",
			violationCodes: ["success.terminal-observation-order-invalid"],
		});

		for (const regressedCampaign of [
			[
				{ ...pendingValue, replicate: 1, completedArms: 6 },
				{ ...pendingValue, replicate: 1, completedArms: 5 },
			],
		] as const) {
			const drift = withGraphResult(base, {
				observations: [
					{ ...terminal, seq: 1, msg: ["DATA", regressedCampaign[0]] as never },
					{ ...terminal, seq: 2, msg: ["DATA", regressedCampaign[1]] as never },
					{ ...terminal, seq: 3 },
				],
			});
			expect(evaluateRootEvalLiveAdmission(drift).admissionReport).toMatchObject({
				status: "rejected",
				violationCodes: ["success.terminal-observation-order-invalid"],
			});
		}

		for (const impossibleIntermediate of [
			{ ...pendingValue, accountedUpperBoundMicrousd: 101 },
			{
				...pendingValue,
				providerOutcomeReasonCounts: { ...providerOutcomeReasonCounts, "tool-proposed": 31 },
			},
		]) {
			const drift = withGraphResult(base, {
				observations: [
					{ ...terminal, seq: 1, msg: ["DATA", impossibleIntermediate] as never },
					{ ...terminal, seq: 2 },
				],
			});
			expect(evaluateRootEvalLiveAdmission(drift).admissionReport).toMatchObject({
				status: "rejected",
				violationCodes: ["success.graph-shape-invalid"],
			});
		}
	});

	it("admits semantic evidence when the key-ledger audit is rejected or post-campaign delta is missing", () => {
		const rejectedAudit = withRejectedBillingTerminal(liveEvidenceInput());
		for (const candidate of [rejectedAudit, { ...rejectedAudit, currentKeyAfter: null }]) {
			const evaluation = evaluateRootEvalLiveAdmission(candidate);
			expect(evaluation.admissionReport).toEqual({
				status: "admitted",
				violationCodes: [],
				rejectedGraphSummary: null,
			});
			expect(evaluation.projectedGraph?.finding).toMatchObject({
				finding: "positive-differential",
				stoppingReason: "campaign-complete",
				billingDisposition: "rejected",
			});
		}

		const allZero = {
			cold: 0,
			"relevant-applied": 0,
			"proposal-only": 0,
			"admission-rejected": 0,
			"irrelevant-applied": 0,
			"wrong-scope-applied": 0,
		};
		const base = liveEvidenceInput();
		const baseDiagnostics = base.graphResult!.finding.verificationDiagnostics;
		const negativeDiagnostics = {
			...baseDiagnostics,
			stageCounts: {
				...baseDiagnostics.stageCounts,
				"relevant-applied": {
					...baseDiagnostics.stageCounts["relevant-applied"],
					hiddenVerifierPassed: 0,
					passed: 0,
				},
			},
			terminalReasonCounts: {
				...baseDiagnostics.terminalReasonCounts,
				"relevant-applied": {
					...baseDiagnostics.terminalReasonCounts["relevant-applied"],
					"hidden-verifier-failed": ROOT_EVAL_LIVE_REPLICATE_COUNT,
					passed: 0,
				},
			},
		};
		const negativeObservations = base.graphResult!.observations.map((event, index, events) => {
			const value = event.msg[1] as unknown as Record<string, unknown>;
			const diagnostics = structuredClone(value.verificationDiagnostics) as typeof baseDiagnostics;
			const relevantCompleted = diagnostics.stageCounts["relevant-applied"].completedWorkItems;
			diagnostics.stageCounts["relevant-applied"].hiddenVerifierPassed = 0;
			diagnostics.stageCounts["relevant-applied"].passed = 0;
			diagnostics.terminalReasonCounts["relevant-applied"]["hidden-verifier-failed"] =
				relevantCompleted;
			diagnostics.terminalReasonCounts["relevant-applied"].passed = 0;
			return {
				...event,
				msg: [
					"DATA",
					{
						...value,
						verificationDiagnostics: diagnostics,
						finding: index === events.length - 1 ? "no-positive-differential" : "pending",
						developmentQualification: value.developmentQualification,
					},
				] as never,
			};
		});
		const negative = withRejectedBillingTerminal(
			withGraphResult(
				base,
				{ observations: negativeObservations },
				{
					passCounts: allZero,
					verificationDiagnostics: negativeDiagnostics,
					finding: "no-positive-differential",
				},
			),
		);
		const evidence = constructRootEvalLiveEvidence(negative);
		expect(evidence).toMatchObject({
			disposition: "success",
			efficacyClaim: "none",
			causalAttribution: "undetermined",
			admissionReport: { status: "admitted", violationCodes: [] },
			graphResult: {
				finding: {
					finding: "no-positive-differential",
					billingDisposition: "rejected",
				},
			},
		});
	});

	it("fails closed with stable authority-envelope violation codes", () => {
		const base = liveEvidenceInput();
		const authorityCases: ReadonlyArray<
			readonly [
				(typeof ROOT_EVAL_LIVE_AUTHORITY_VIOLATION_CODES)[number],
				RootEvalLiveEvidenceInput,
			]
		> = [
			[
				"authority.claim-shape-invalid",
				{ ...base, claim: { ...base.claim, extra: "forbidden" } as never },
			],
			["authority.claim-digest-invalid", { ...base, claim: { ...base.claim, claimDigest: "bad" } }],
			[
				"authority.pricing-shape-invalid",
				{ ...base, pricing: { ...base.pricing, extra: "forbidden" } as never },
			],
			[
				"authority.pricing-digest-invalid",
				{ ...base, pricing: { ...base.pricing, observationDigest: "bad" } },
			],
			[
				"authority.pricing-semantics-mismatch",
				withRehashedPricing(base, { providerName: "forged-provider" }),
			],
			[
				"authority.zero-byok-shape-invalid",
				{ ...base, zeroByok: { ...base.zeroByok, extra: "forbidden" } as never },
			],
			[
				"authority.zero-byok-digest-invalid",
				{ ...base, zeroByok: { ...base.zeroByok, observationDigest: "bad" } },
			],
			[
				"authority.zero-byok-semantics-mismatch",
				withRehashedZeroByok(base, { byokCredentialCount: 1 }),
			],
			[
				"authority.current-key-before-shape-invalid",
				{ ...base, currentKeyBefore: { ...base.currentKeyBefore!, extra: "forbidden" } as never },
			],
			[
				"authority.current-key-before-digest-invalid",
				{ ...base, currentKeyBefore: { ...base.currentKeyBefore!, admissionDigest: "bad" } },
			],
			[
				"authority.current-key-before-semantics-mismatch",
				withRehashedCurrentKey(base, "before", { usageMicrousd: -1 }),
			],
			[
				"authority.current-key-after-shape-invalid",
				{ ...base, currentKeyAfter: { ...base.currentKeyAfter!, extra: "forbidden" } as never },
			],
			[
				"authority.current-key-after-digest-invalid",
				{ ...base, currentKeyAfter: { ...base.currentKeyAfter!, admissionDigest: "bad" } },
			],
			[
				"authority.current-key-after-semantics-mismatch",
				withRehashedCurrentKey(base, "after", { usageMicrousd: 25_000_100.5 }),
			],
			[
				"authority.claim-pricing-binding-mismatch",
				{ ...base, claim: { ...base.claim, pricingObservationDigest: "wrong" } },
			],
			[
				"authority.claim-zero-byok-binding-mismatch",
				{ ...base, claim: { ...base.claim, zeroByokObservationDigest: "wrong" } },
			],
			[
				"authority.claim-schema-mismatch",
				{ ...base, claim: { ...base.claim, schemaVersion: "wrong" } as never },
			],
			[
				"authority.claim-execution-mode-invalid",
				{ ...base, claim: { ...base.claim, executionMode: "network-wrapper" } as never },
			],
			[
				"authority.claim-ref-mismatch",
				{ ...base, claim: { ...base.claim, claimRef: "wrong" } as never },
			],
			[
				"authority.claim-decision-mismatch",
				{ ...base, claim: { ...base.claim, decisionRef: "wrong" } as never },
			],
			[
				"authority.claim-generation-mismatch",
				{ ...base, claim: { ...base.claim, generationRef: "wrong" } as never },
			],
			[
				"authority.claim-task-binding-mismatch",
				{ ...base, claim: { ...base.claim, taskBindingDigest: "wrong" } },
			],
			[
				"authority.claim-task-manifest-mismatch",
				{ ...base, claim: { ...base.claim, taskManifestDigest: "wrong" } },
			],
			[
				"authority.claim-campaign-cap-mismatch",
				{ ...base, claim: { ...base.claim, campaignHardCapMicrousd: 1 } as never },
			],
			[
				"authority.claim-key-limit-mismatch",
				{ ...base, claim: { ...base.claim, localEvalNoResetLimitMicrousd: 1 } as never },
			],
			[
				"authority.claim-implementation-coordinate-invalid",
				{ ...base, claim: { ...base.claim, implementationCoordinate: "wrong" } },
			],
			[
				"authority.claim-implementation-coordinate-binding-mismatch",
				withRehashedClaim(base, {
					implementationCoordinate: `worktree:${"a".repeat(40)}:${empiricalStrictJsonDigest("other-manifest")}`,
				}),
			],
			[
				"authority.claim-implementation-manifest-mismatch",
				withRehashedClaim(base, {
					implementationManifestDigest: empiricalStrictJsonDigest("other-manifest"),
				}),
			],
			[
				"authority.claim-qualification-artifact-mismatch",
				withRehashedClaim(base, {
					qualificationArtifactDigest: empiricalStrictJsonDigest("other-artifact"),
				}),
			],
			[
				"authority.claim-qualification-mismatch",
				withRehashedClaim(base, {
					qualificationDigest: empiricalStrictJsonDigest("other-qualification"),
				}),
			],
			[
				"authority.claim-credential-binding-mismatch",
				withRehashedClaim(base, {
					credentialBindingDigest: empiricalStrictJsonDigest("other-credential"),
				}),
			],
			[
				"authority.claim-current-key-before-binding-mismatch",
				withRehashedClaim(base, {
					currentKeyBeforeDigest: empiricalStrictJsonDigest("other-current-key"),
				}),
			],
			[
				"authority.claim-recovery-envelope-mismatch",
				withRehashedClaim(base, {
					recoveryEnvelope: {
						...base.claim.recoveryEnvelope,
						pricing: { ...base.claim.recoveryEnvelope.pricing, observedAtMs: 2 },
					},
				}),
			],
			[
				"authority.current-key-limit-mismatch",
				{ ...base, currentKeyBefore: { ...base.currentKeyBefore!, limitMicrousd: 1 } as never },
			],
			[
				"authority.current-key-remaining-below-cap",
				{ ...base, currentKeyBefore: { ...base.currentKeyBefore!, remainingMicrousd: 1 } },
			],
			[
				"authority.current-key-reconciliation-nonmonotonic",
				refreshedCurrentKeys({
					...base,
					currentKeyAfter: {
						...base.currentKeyAfter!,
						usageMicrousd: base.currentKeyBefore!.usageMicrousd - 1,
					},
				}),
			],
			["authority.provider-call-count-invalid", { ...base, providerCalls: -1 }],
			[
				"authority.result-and-failure-missing",
				{ ...base, graphResult: null, partialGraphObservations: [], failure: null },
			],
		];
		expect(authorityCases.map(([code]) => code)).toEqual(ROOT_EVAL_LIVE_AUTHORITY_VIOLATION_CODES);
		for (const [code, input] of authorityCases) {
			try {
				evaluateRootEvalLiveAdmission(input);
				throw new TypeError(`authority mutation ${code} was admitted`);
			} catch (error) {
				expect(error).toMatchObject({ violationCodes: expect.arrayContaining([code]) });
				expect(String(error), code).not.toMatch(/private-marker|authorization|bearer/iu);
			}
		}
	});

	it("persists a rejected candidate as current partial evidence with no raw admission identities", () => {
		const evidence = constructRootEvalLiveEvidence(
			withGraphResult(liveEvidenceInput(), { peakConcurrentEffects: 3 }),
		);
		expect(evidence).toMatchObject({
			disposition: "partial-failure",
			observationProvenance: "live-run",
			graphResult: null,
			efficacyClaim: "none",
			causalAttribution: "undetermined",
			admissionReport: {
				status: "rejected",
				violationCodes: ["success.peak-provider-concurrency-above-one"],
				rejectedGraphSummary: { peakConcurrentEffects: 3, executedAdmissionCount: 30 },
			},
		});
		expect(JSON.stringify(evidence)).not.toMatch(
			/admission-0|private-marker|authorization|bearer/iu,
		);
		const callerPartial = constructRootEvalLiveEvidence({
			...liveEvidenceInput(),
			currentKeyAfter: null,
			providerCalls: 29,
			failure: new Error("post-Graph caller failure"),
			cleanupDisposition: "failed",
		});
		expect(callerPartial).toMatchObject({
			disposition: "partial-failure",
			graphResult: expect.objectContaining({
				finding: expect.objectContaining({ finding: "positive-differential" }),
			}),
			efficacyClaim: "none",
			causalAttribution: "undetermined",
			admissionReport: {
				status: "rejected",
				violationCodes: [
					"success.failure-present",
					"success.cleanup-incomplete",
					"success.provider-call-count-mismatch",
				],
			},
		});
		const deadlinePartial = constructRootEvalLiveEvidence({
			...liveEvidenceInput(),
			graphResult: null,
			currentKeyAfter: null,
			providerCalls: 1,
			failure: new RootEvalCallerSettlementDeadlineExpired(5),
			cleanupDisposition: "complete",
		});
		expect(deadlinePartial).toMatchObject({
			disposition: "partial-failure",
			technicalFailureCode: "caller-settlement-deadline-expired",
			latestGraphObservation: expect.objectContaining({ path: "eval/observation" }),
		});
		const recoveredPartial = constructRootEvalLiveEvidence({
			...liveEvidenceInput(),
			observationProvenance: "exact-response-no-network-recovery",
			graphResult: null,
			currentKeyAfter: null,
			providerCalls: 5,
			failure: new Error("source Work Item verification failed closed"),
			cleanupDisposition: "complete",
		});
		expect(recoveredPartial).toMatchObject({
			disposition: "partial-failure",
			observationProvenance: "exact-response-no-network-recovery",
			graphResult: null,
			efficacyClaim: "none",
			causalAttribution: "undetermined",
			admissionReport: { status: "not-candidate" },
		});
		const base = liveEvidenceInput();
		const spendMismatch = constructRootEvalLiveEvidence(
			refreshedCurrentKeys({
				...base,
				currentKeyAfter: {
					...base.currentKeyAfter!,
					remainingMicrousd: base.currentKeyBefore!.remainingMicrousd - 200,
					usageMicrousd: base.currentKeyBefore!.usageMicrousd + 200,
				},
			}),
		);
		expect(spendMismatch).toMatchObject({
			disposition: "success",
			graphResult: expect.objectContaining({
				finding: expect.objectContaining({ billingDisposition: "reconciled" }),
			}),
			efficacyClaim: "none",
			admissionReport: {
				status: "admitted",
				violationCodes: [],
				rejectedGraphSummary: null,
			},
		});
		const event = liveEvidenceInput().graphResult!.observations.at(-1)!;
		const forged = constructRootEvalLiveEvidence(
			withGraphResult(liveEvidenceInput(), {
				observations: [
					{
						...event,
						msg: [
							"DATA",
							{ ...(event.msg[1] as object), privateMarker: "do-not-persist" },
						] as never,
					},
				],
			}),
		);
		expect(forged.admissionReport).toEqual({
			status: "rejected",
			violationCodes: ["success.graph-shape-invalid"],
			rejectedGraphSummary: null,
		});
		expect(forged.partialGraphObservations).toEqual([]);
		expect(JSON.stringify(forged)).not.toContain("do-not-persist");
	});

	it("requires a committed D152 claim before evidence persistence", async () => {
		const temporary = await mkdtemp(join(tmpdir(), "graphrefly-root-eval-no-claim-"));
		const privateRoot = await realpath(temporary);
		await chmod(privateRoot, 0o700);
		try {
			const evidence = constructRootEvalLiveEvidence(liveEvidenceInput());
			await expect(persistRootEvalLiveEvidence({ privateRoot, evidence })).rejects.toThrow(
				/committed D152 claim/u,
			);
			expect(await readdir(privateRoot)).toEqual([]);
		} finally {
			await rm(temporary, { recursive: true, force: true });
		}
	});

	it("requires fresh runtime-issued admissions with the full campaign balance before claim", async () => {
		const temporary = await mkdtemp(join(tmpdir(), "graphrefly-root-eval-d94-capability-"));
		const privateRoot = await realpath(temporary);
		await chmod(privateRoot, 0o700);
		try {
			const input = await currentClaimInput(privateRoot);
			await expect(
				acquireRootEvalLiveClaimForNoNetworkQualification({
					...input,
					pricing: { ...input.pricing },
				} as never),
			).rejects.toThrow(/pricing-admission/u);
			await expect(
				acquireRootEvalLiveClaimForNoNetworkQualification({
					...input,
					zeroByok: { ...input.zeroByok },
				} as never),
			).rejects.toThrow(/zero-byok-admission/u);
			await expect(
				acquireRootEvalLiveClaimForNoNetworkQualification({
					...input,
					currentKeyBefore: { ...input.currentKeyBefore },
				} as never),
			).rejects.toThrow(/current-key-admission/u);
			await expect(
				acquireRootEvalLiveClaimForNoNetworkQualification({
					...input,
					nowMs: input.nowMs + 3_600_001,
				}),
			).rejects.toThrow(/freshness/u);
			const staleCurrentKey = await readRootEvalLiveCurrentKey({
				credential: input.credential,
				nowMs: input.nowMs - 60_001,
				fetchImpl: (async () =>
					new Response(
						JSON.stringify({
							data: {
								limit: 32,
								limit_remaining: 13,
								usage: 19,
								limit_reset: null,
								is_management_key: false,
							},
						}),
						{ status: 200 },
					)) as typeof fetch,
			});
			await expect(
				acquireRootEvalLiveClaimForNoNetworkQualification({
					...input,
					currentKeyBefore: staleCurrentKey,
				}),
			).rejects.toThrow(/freshness/u);
			const insufficientKey = await readRootEvalLiveCurrentKey({
				credential: input.credential,
				minimumRemainingMicrousd: 0,
				fetchImpl: (async () =>
					new Response(
						JSON.stringify({
							data: {
								limit: 32,
								limit_remaining: 11.999999,
								usage: 20.000001,
								limit_reset: null,
								is_management_key: false,
							},
						}),
						{ status: 200 },
					)) as typeof fetch,
			});
			await expect(
				acquireRootEvalLiveClaimForNoNetworkQualification({
					...input,
					currentKeyBefore: insufficientKey,
				}),
			).rejects.toThrow(/current-key-admission/u);
			const otherCredential = parseRootEvalLiveCredential(
				new TextEncoder().encode("OPENROUTER_API_KEY=sk-or-v1-a44-other-middle-credential-e06\n"),
			);
			await expect(
				acquireRootEvalLiveClaim({
					...input,
					credential: otherCredential,
					nowMs: undefined,
				}),
			).rejects.toThrow(/authority-provenance|same-credential-provenance/u);
			expect(await readdir(privateRoot)).toEqual([]);
		} finally {
			await rm(temporary, { recursive: true, force: true });
		}
	});

	it("rejects a synthetic D140 live claim without runtime authority provenance", async () => {
		const temporary = await mkdtemp(join(tmpdir(), "graphrefly-root-eval-d94-stale-d92-"));
		const privateRoot = await realpath(temporary);
		await chmod(privateRoot, 0o700);
		try {
			const input = await currentClaimInput(privateRoot);
			await expect(
				acquireRootEvalLiveClaim({
					...input,
					credential: {
						...input.credential,
						bindingRevision: "2026-08-24.d92.v1",
					} as never,
				}),
			).rejects.toThrow(/authority-provenance|credential-binding/u);
			expect(await readdir(privateRoot)).toEqual([]);
		} finally {
			await rm(temporary, { recursive: true, force: true });
		}
	});

	it("commits one D140 qualification claim and persists identical canonical evidence idempotently", async () => {
		const temporary = await mkdtemp(join(tmpdir(), "graphrefly-root-eval-d94-claim-"));
		const privateRoot = await realpath(temporary);
		await chmod(privateRoot, 0o700);
		try {
			const claimInput = await currentClaimInput(privateRoot);
			const claimAcquisition = await acquireRootEvalLiveClaimForNoNetworkQualification(claimInput);
			expect(claimAcquisition.postCommitFailureDigest).toBeNull();
			const recovered = recoverRootEvalLiveClaimAuthority(claimAcquisition.claim);
			expect(recovered).toEqual({
				pricing: { ...claimInput.pricing },
				zeroByok: { ...claimInput.zeroByok },
				currentKeyBefore: { ...claimInput.currentKeyBefore },
			});
			expect(Object.isFrozen(recovered)).toBe(true);
			expect(Object.isFrozen(recovered.pricing)).toBe(true);
			const dispositionName = (await readdir(privateRoot)).find((name) =>
				name.endsWith("disposition.v21.json"),
			);
			if (dispositionName === undefined) throw new TypeError("D140 disposition missing");
			const dispositionText = await readFile(join(privateRoot, dispositionName), "utf8");
			expect(dispositionText).not.toContain(claimInput.credential.bearerToken);
			await expect(
				acquireRootEvalLiveClaimForNoNetworkQualification(claimInput),
			).rejects.toMatchObject({ code: "EEXIST" });
			const base = liveEvidenceInput();
			const currentKeyAfterMaterial = {
				...claimInput.currentKeyBefore,
				remainingMicrousd: claimInput.currentKeyBefore.remainingMicrousd - 100,
				usageMicrousd: claimInput.currentKeyBefore.usageMicrousd + 100,
			};
			delete (currentKeyAfterMaterial as { admissionDigest?: string }).admissionDigest;
			const currentKeyAfter = {
				...currentKeyAfterMaterial,
				admissionDigest: empiricalStrictJsonDigest(currentKeyAfterMaterial),
			};
			const evidence = constructRootEvalLiveEvidence({
				...base,
				claim: claimAcquisition.claim,
				pricing: claimInput.pricing,
				zeroByok: claimInput.zeroByok,
				currentKeyBefore: claimInput.currentKeyBefore,
				currentKeyAfter,
			});
			const { evidenceDigest: _d118Digest, ...d118Material } = evidence;
			const d116Material = {
				...d118Material,
				generationRef: "root-eval-live-2026-08-24-d116-v1" as never,
			};
			await expect(
				persistRootEvalLiveEvidence({
					privateRoot,
					evidence: {
						...d116Material,
						evidenceDigest: empiricalStrictJsonDigest(d116Material),
					},
				}),
			).rejects.toThrow(/generation/u);
			const rejected = constructRootEvalLiveEvidence({
				...base,
				claim: claimAcquisition.claim,
				pricing: claimInput.pricing,
				zeroByok: claimInput.zeroByok,
				currentKeyBefore: claimInput.currentKeyBefore,
				currentKeyAfter,
				failure: new Error("caller partial after positive Graph result"),
				cleanupDisposition: "failed",
			});
			const { evidenceDigest: _rejectedDigest, ...rejectedMaterial } = rejected;
			const forgedRejectedMaterial = {
				...rejectedMaterial,
				efficacyClaim: "transfer-task-family-positive-differential" as const,
				causalAttribution: "verified-prior-work-item-memory-transfer" as const,
			};
			await expect(
				persistRootEvalLiveEvidence({
					privateRoot,
					evidence: {
						...forgedRejectedMaterial,
						evidenceDigest: empiricalStrictJsonDigest(forgedRejectedMaterial),
					},
				}),
			).rejects.toThrow(/partial Graph conclusion relationship invalid/u);
			const first = await persistRootEvalLiveEvidence({ privateRoot, evidence });
			const second = await persistRootEvalLiveEvidence({ privateRoot, evidence });
			expect(second).toEqual(first);
			expect(first.postCommitFailureDigest).toBeNull();
			expect(await readdir(join(privateRoot, ROOT_EVAL_LIVE_GENERATION_REF))).toEqual([
				"evidence.v27.json",
			]);
			await expect(
				persistRootEvalLiveEvidence({
					privateRoot,
					evidence: { ...evidence, disposition: "partial-failure" },
				}),
			).rejects.toThrow(/evidence.*invalid|digest/u);
		} finally {
			await rm(temporary, { recursive: true, force: true });
		}
	});

	it("D154 persists a real budget-stopped Graph terminal without efficacy and rejects terminal drift", async () => {
		const temporary = await mkdtemp(join(tmpdir(), "graphrefly-root-eval-d154-stopped-"));
		const privateRoot = await realpath(temporary);
		let stopBudget = () => undefined;
		try {
			const claimInput = await currentClaimInput(privateRoot);
			const acquisition = await acquireRootEvalLiveClaimForNoNetworkQualification(claimInput);
			const manifest = createRootEvalTaskManifest({
				slot: "development-1",
				variantOrder: [0, 1, 2, 3, 4],
				coordinateSuffix: "d154-budget-stopped-case",
			});
			const topology = createRootEvalTopology({
				profileInput: createCurrentExactModelHarnessProfileInput(),
				currentKeyBefore: ROOT_EVAL_NO_NETWORK_CURRENT_KEY_BEFORE,
				campaignRef: ROOT_EVAL_LIVE_GENERATION_REF,
				campaignPurpose: ROOT_EVAL_LIVE_CAMPAIGN_PURPOSE,
				taskSetRef: ROOT_EVAL_LIVE_TASK_SET_REF,
				taskManifestDigest: acquisition.claim.taskManifestDigest,
				taskDefinitions: manifest.tasks,
				taskBindings: rootEvalTaskBindings(manifest.tasks, ROOT_EVAL_LIVE_GENERATION_REF),
				generationRef: ROOT_EVAL_LIVE_GENERATION_REF,
				heldOutSealDigest: ROOT_EVAL_LIVE_HELD_OUT_SEAL_DIGEST,
				budgetPartition: ROOT_EVAL_LIVE_BUDGET_PARTITION,
				partitionHardCapMicrousd: ROOT_EVAL_LIVE_PARTITION_HARD_CAP_MICROUSD,
				partitionLedgerDigest: acquisition.claim.partitionLedgerDigest,
				maxCostMicrousd: ROOT_EVAL_LIVE_CAMPAIGN_HARD_CAP_MICROUSD,
				reservationMicrousd: ROOT_EVAL_LIVE_CAMPAIGN_HARD_CAP_MICROUSD + 1,
			});
			let budgetReceipt: EvalBudgetState | null = null;
			stopBudget = topology.nodes.budgets.subscribe((message) => {
				if (message[0] === "DATA") budgetReceipt = message[1] as EvalBudgetState;
			});
			const execute = vi.fn(async () => {
				throw new Error("stopped Graph must not execute effects");
			});
			const outcome = await runRootEval(topology, execute);
			expect(execute).not.toHaveBeenCalled();
			if (outcome.finding !== null) throw new Error("expected real Graph budget stop");
			expect(outcome.terminal).toMatchObject({
				status: "stopped",
				finding: null,
				stoppingReason: "budget-exhausted",
			});
			const input: RootEvalLiveEvidenceInput = {
				...liveEvidenceInput(),
				claim: acquisition.claim,
				pricing: claimInput.pricing,
				zeroByok: claimInput.zeroByok,
				currentKeyBefore: claimInput.currentKeyBefore,
				currentKeyAfter: claimInput.currentKeyBefore,
				providerCalls: 0,
				budgetReceipt,
				graphResult: null,
				stoppedTerminal: outcome.terminal,
				partialGraphObservations: outcome.observations,
				failure: null,
				cleanupDisposition: "complete",
			};
			const evidence = constructRootEvalLiveEvidence(input);
			expect(evidence).toMatchObject({
				disposition: "stopped",
				graphResult: null,
				failureDigest: null,
				efficacyClaim: "none",
				causalAttribution: "undetermined",
				admissionReport: { status: "not-candidate", violationCodes: [] },
			});
			expect(
				(evidence.latestGraphObservation!.msg[1] as { developmentQualification: unknown })
					.developmentQualification,
			).toMatchObject({ generationQualified: null, heldOutEligible: false });
			for (const terminalPatch of [
				{ observationDigest: empiricalStrictJsonDigest("other-observation") },
				{ budgetDigest: empiricalStrictJsonDigest("other-budget") },
				{ activityDigest: "invalid" },
				{ observationRevision: 0 },
				{ completedTargetWorkItems: 1 },
				{ cleanupComplete: false },
				{ stoppingReason: "progress-stalled" },
				{ unexpected: true },
			])
				expect(() =>
					constructRootEvalLiveEvidence({
						...input,
						stoppedTerminal: { ...outcome.terminal, ...terminalPatch } as never,
					}),
				).toThrow();
			expect(() => constructRootEvalLiveEvidence({ ...input, budgetReceipt: null })).toThrow();
			expect(() =>
				constructRootEvalLiveEvidence({
					...input,
					budgetReceipt: {
						...evidence.budgetReceipt!,
						maxCostMicrousd: ROOT_EVAL_LIVE_CAMPAIGN_HARD_CAP_MICROUSD - 1,
					},
				}),
			).toThrow(/budget/u);
			expect(() =>
				constructRootEvalLiveEvidence({ ...input, partialGraphObservations: [] }),
			).toThrow();
			const lastObservation = outcome.observations.at(-1)!;
			expect(() =>
				constructRootEvalLiveEvidence({
					...input,
					partialGraphObservations: [
						...outcome.observations.slice(0, -1),
						{
							...lastObservation,
							msg: [
								"DATA",
								{ ...(lastObservation.msg[1] as Record<string, unknown>), finding: "pending" },
							],
						},
					],
				}),
			).toThrow(/terminal/u);
			const failure = constructRootEvalLiveEvidence({
				...input,
				failure: new Error("cleanup failed after terminal"),
				cleanupDisposition: "failed",
			});
			expect(failure).toMatchObject({ disposition: "partial-failure", efficacyClaim: "none" });
			expect(failure.failureDigest).not.toBeNull();
			const { evidenceDigest: _digest, ...material } = evidence;
			const mutated = {
				...material,
				stoppedTerminal: { ...outcome.terminal, completedTargetWorkItems: 1 },
			};
			await expect(
				persistRootEvalLiveEvidence({
					privateRoot,
					evidence: { ...mutated, evidenceDigest: empiricalStrictJsonDigest(mutated) },
				}),
			).rejects.toThrow(/terminal/u);
			const forgedClaim = {
				...material,
				efficacyClaim: "transfer-task-family-positive-differential" as const,
			};
			await expect(
				persistRootEvalLiveEvidence({
					privateRoot,
					evidence: { ...forgedClaim, evidenceDigest: empiricalStrictJsonDigest(forgedClaim) },
				}),
			).rejects.toThrow(/normal-stop/u);
			const first = await persistRootEvalLiveEvidence({ privateRoot, evidence });
			expect(await persistRootEvalLiveEvidence({ privateRoot, evidence })).toEqual(first);
			expect(
				JSON.parse(
					await readFile(
						join(privateRoot, ROOT_EVAL_LIVE_GENERATION_REF, "evidence.v27.json"),
						"utf8",
					),
				),
			).toEqual(evidence);
		} finally {
			stopBudget();
			await rm(temporary, { recursive: true, force: true });
		}
	}, 15_000);

	it("atomically commits D152 evidence and its carried-spend ledger", async () => {
		const temporary = await mkdtemp(join(tmpdir(), "graphrefly-root-eval-d152-transaction-"));
		const operatorRoot = await realpath(temporary);
		const privateRoot = join(operatorRoot, "current-d152-development-1");
		const historicalLedgerPath = join(operatorRoot, "d145-charter-ledger.v4.json");
		const ledgerPath = join(operatorRoot, "d152-charter-ledger.v1.json");
		const journalPath = join(operatorRoot, "d152-charter-transaction.v1.json");
		await mkdir(privateRoot, { mode: 0o700 });
		await writeRootEvalD145CharterLedger(historicalLedgerPath, ROOT_EVAL_D145_EMPTY_CHARTER_LEDGER);
		try {
			const ledger = await readRootEvalD152Ledger({
				path: ledgerPath,
				historicalLedger: ROOT_EVAL_D145_EMPTY_CHARTER_LEDGER,
			});
			const claimInput = await currentClaimInput(privateRoot);
			const acquisition = await acquireRootEvalLiveClaimForNoNetworkQualification(claimInput);
			const evidence = constructRootEvalLiveEvidence({
				...liveEvidenceInput(),
				claim: acquisition.claim,
				pricing: claimInput.pricing,
				zeroByok: claimInput.zeroByok,
				currentKeyBefore: claimInput.currentKeyBefore,
			});
			const nextLedger = advanceRootEvalD152Ledger({
				ledger,
				generationRef: ROOT_EVAL_LIVE_GENERATION_REF,
				taskSetRef: ROOT_EVAL_LIVE_TASK_SET_REF,
				taskManifestDigest: claimInput.taskManifestDigest,
				providerReportedMicrousd: 0,
				unreportedSettledUpperBoundMicrousd: 0,
				accountedUpperBoundMicrousd: 0,
				admissionStatus: evidence.admissionReport.status,
				developmentQualification: null,
				evidenceDigest: evidence.evidenceDigest,
			});
			const committed = await commitRootEvalD152Transaction({
				journalPath,
				privateRoot,
				ledgerPath,
				previousLedgerDigest: ledger.ledgerDigest,
				evidence,
				nextLedger,
			});
			expect(committed.nextLedger).toEqual(nextLedger);
			expect(committed.persistence.postCommitFailureDigest).toBeNull();
			expect(
				await readRootEvalD152Ledger({
					path: ledgerPath,
					historicalLedger: ROOT_EVAL_D145_EMPTY_CHARTER_LEDGER,
				}),
			).toEqual(nextLedger);
			expect(await readdir(join(privateRoot, ROOT_EVAL_LIVE_GENERATION_REF))).toEqual([
				"evidence.v27.json",
			]);
			await expect(stat(journalPath)).rejects.toMatchObject({ code: "ENOENT" });
		} finally {
			await rm(temporary, { recursive: true, force: true });
		}
	});

	it.each([
		false,
		true,
	])("atomically retains budget receipts and spend when canonical evidence is rejected (stale=%s)", async (stale) => {
		const temporary = await mkdtemp(join(tmpdir(), "graphrefly-root-eval-d152-transaction-"));
		const operatorRoot = await realpath(temporary);
		const privateRoot = join(operatorRoot, "current-d152-development-1");
		const historicalLedgerPath = join(operatorRoot, "d145-charter-ledger.v4.json");
		const ledgerPath = join(operatorRoot, "d152-charter-ledger.v1.json");
		const journalPath = join(operatorRoot, "d152-charter-transaction.v1.json");
		await mkdir(privateRoot, { mode: 0o700 });
		await writeRootEvalD145CharterLedger(historicalLedgerPath, ROOT_EVAL_D145_EMPTY_CHARTER_LEDGER);
		try {
			const ledger = await readRootEvalD152Ledger({
				path: ledgerPath,
				historicalLedger: ROOT_EVAL_D145_EMPTY_CHARTER_LEDGER,
			});
			const claimInput = await currentClaimInput(privateRoot);
			const acquisition = await acquireRootEvalLiveClaimForNoNetworkQualification(claimInput);
			const budgetReceipt = {
				kind: "eval-budget-state" as const,
				executionGrantDigest: empiricalStrictJsonDigest({
					kind: "root-eval-no-network-execution-grant",
				}),
				policyQualifiedNonbillableCount: 0,
				admittedAttempts: stale ? 1 : 2,
				activeEffects: stale ? 0 : 1,
				admittedRetryAttempts: 0,
				retryProposalCount: 0,
				pendingRetryProposalCount: 0,
				rejectedRetryProposalCount: 0,
				settledRetryAttemptCount: 0,
				providerCallCount: 1,
				providerReportedMicrousd: 10,
				unreportedSettledUpperBoundMicrousd: 0,
				activeReservedMicrousd: stale ? 0 : 100,
				accountedUpperBoundMicrousd: stale ? 10 : 110,
				pricingRoundingAllowanceMicrousd: 0,
				maxAttempts: 175,
				maxCostMicrousd: 12_000_000,
				stoppingReason: "none" as const,
				providerOutcomeReasonCounts: {
					...emptyEvalProviderOutcomeReasonCounts(),
					"tool-proposed": 1,
				},
			};
			const spend = settledRootEvalSpend({
				budget: budgetReceipt,
				providerCalls: 2,
				authorizedMaximumMicrousd: 12_000_000,
			});
			const evidence = constructRootEvalLiveEvidence({
				...withGraphResult(liveEvidenceInput(), { peakConcurrentEffects: 3 }),
				budgetReceipt,
				providerCalls: 2,
				failure: new Error("rejected canonical observation"),
				claim: acquisition.claim,
				pricing: claimInput.pricing,
				zeroByok: claimInput.zeroByok,
				currentKeyBefore: claimInput.currentKeyBefore,
			});
			const nextLedger = advanceRootEvalD152Ledger({
				ledger,
				generationRef: ROOT_EVAL_LIVE_GENERATION_REF,
				taskSetRef: ROOT_EVAL_LIVE_TASK_SET_REF,
				taskManifestDigest: claimInput.taskManifestDigest,
				providerReportedMicrousd: spend.providerReportedMicrousd,
				unreportedSettledUpperBoundMicrousd: spend.unreportedSettledUpperBoundMicrousd,
				accountedUpperBoundMicrousd: spend.accountedUpperBoundMicrousd,
				admissionStatus: evidence.admissionReport.status,
				developmentQualification: null,
				evidenceDigest: evidence.evidenceDigest,
			});
			const committed = await commitRootEvalD152Transaction({
				journalPath,
				privateRoot,
				ledgerPath,
				previousLedgerDigest: ledger.ledgerDigest,
				evidence,
				nextLedger,
			});
			expect(committed.nextLedger).toEqual(nextLedger);
			expect(evidence.admissionReport.status).toBe("rejected");
			expect(evidence.graphResult).toBeNull();
			expect(nextLedger.developmentSpentMicrousd).toBe(stale ? 12_000_000 : 110);
			const persisted = JSON.parse(
				await readFile(
					join(privateRoot, ROOT_EVAL_LIVE_GENERATION_REF, "evidence.v27.json"),
					"utf8",
				),
			);
			expect(persisted.budgetReceipt).toEqual(stale ? null : budgetReceipt);
			expect(persisted.efficacyClaim).toBe("none");
			expect(committed.persistence.postCommitFailureDigest).toBeNull();
			expect(
				await readRootEvalD152Ledger({
					path: ledgerPath,
					historicalLedger: ROOT_EVAL_D145_EMPTY_CHARTER_LEDGER,
				}),
			).toEqual(nextLedger);
			expect(await readdir(join(privateRoot, ROOT_EVAL_LIVE_GENERATION_REF))).toEqual([
				"evidence.v27.json",
			]);
			await expect(stat(journalPath)).rejects.toMatchObject({ code: "ENOENT" });
		} finally {
			await rm(temporary, { recursive: true, force: true });
		}
	});

	it("persists success when an earlier independent observer has a prefix and different envelope sequences", async () => {
		const temporary = await mkdtemp(join(tmpdir(), "graphrefly-root-eval-observer-prefix-"));
		const privateRoot = await realpath(temporary);
		await chmod(privateRoot, 0o700);
		try {
			const claimInput = await currentClaimInput(privateRoot);
			const claimAcquisition = await acquireRootEvalLiveClaimForNoNetworkQualification(claimInput);
			const base = liveEvidenceInput();
			const first = base.graphResult!.observations[0]!;
			const diagnostic = [
				{ ...first, seq: 0 },
				...base.graphResult!.observations.map((event) => ({ ...event, seq: event.seq + 10_000 })),
			];
			const evidence = constructRootEvalLiveEvidence({
				...base,
				claim: claimAcquisition.claim,
				pricing: claimInput.pricing,
				zeroByok: claimInput.zeroByok,
				currentKeyBefore: claimInput.currentKeyBefore,
				partialGraphObservations: diagnostic,
			});

			await expect(persistRootEvalLiveEvidence({ privateRoot, evidence })).resolves.toMatchObject({
				postCommitFailureDigest: null,
			});
		} finally {
			await rm(temporary, { recursive: true, force: true });
		}
	});

	it("persists success when the canonical observer has a prefix and diagnostics retain the exact semantic suffix", async () => {
		const temporary = await mkdtemp(join(tmpdir(), "graphrefly-root-eval-canonical-prefix-"));
		const privateRoot = await realpath(temporary);
		await chmod(privateRoot, 0o700);
		try {
			const claimInput = await currentClaimInput(privateRoot);
			const claimAcquisition = await acquireRootEvalLiveClaimForNoNetworkQualification(claimInput);
			const base = liveEvidenceInput();
			const diagnostic = base
				.graphResult!.observations.slice(1)
				.map((event) => ({ ...event, seq: event.seq + 10_000 }));
			const evidence = constructRootEvalLiveEvidence({
				...base,
				claim: claimAcquisition.claim,
				pricing: claimInput.pricing,
				zeroByok: claimInput.zeroByok,
				currentKeyBefore: claimInput.currentKeyBefore,
				partialGraphObservations: diagnostic,
			});

			await expect(persistRootEvalLiveEvidence({ privateRoot, evidence })).resolves.toMatchObject({
				postCommitFailureDigest: null,
			});
		} finally {
			await rm(temporary, { recursive: true, force: true });
		}
	});

	it("persists the caller deadline code and latest bounded Graph observation", async () => {
		const temporary = await mkdtemp(join(tmpdir(), "graphrefly-root-eval-deadline-evidence-"));
		const privateRoot = await realpath(temporary);
		await chmod(privateRoot, 0o700);
		try {
			const claimInput = await currentClaimInput(privateRoot);
			const claimAcquisition = await acquireRootEvalLiveClaimForNoNetworkQualification(claimInput);
			const base = liveEvidenceInput();
			const evidence = constructRootEvalLiveEvidence({
				...base,
				claim: claimAcquisition.claim,
				pricing: claimInput.pricing,
				zeroByok: claimInput.zeroByok,
				currentKeyBefore: claimInput.currentKeyBefore,
				currentKeyAfter: null,
				graphResult: null,
				providerCalls: 1,
				failure: new RootEvalCallerSettlementDeadlineExpired(5),
				cleanupDisposition: "complete",
			});
			const persisted = await persistRootEvalLiveEvidence({ privateRoot, evidence });
			expect(persisted.postCommitFailureDigest).toBeNull();
			const bytes = await readFile(
				join(privateRoot, ROOT_EVAL_LIVE_GENERATION_REF, "evidence.v27.json"),
				"utf8",
			);
			const durable = JSON.parse(bytes) as Record<string, unknown>;
			expect(durable).toMatchObject({
				technicalFailureCode: "caller-settlement-deadline-expired",
				latestGraphObservation: expect.objectContaining({ path: "eval/observation" }),
			});
		} finally {
			await rm(temporary, { recursive: true, force: true });
		}
	});

	it("atomically persists D113 semantic success with a rejected billing audit", async () => {
		const temporary = await mkdtemp(join(tmpdir(), "graphrefly-root-eval-d105-rejected-"));
		const privateRoot = await realpath(temporary);
		await chmod(privateRoot, 0o700);
		try {
			const claimInput = await currentClaimInput(privateRoot);
			const claimAcquisition = await acquireRootEvalLiveClaimForNoNetworkQualification(claimInput);
			const currentKeyAfterMaterial = {
				...claimInput.currentKeyBefore,
				remainingMicrousd: claimInput.currentKeyBefore.remainingMicrousd - 85_261,
				usageMicrousd: claimInput.currentKeyBefore.usageMicrousd + 85_261,
			};
			delete (currentKeyAfterMaterial as { admissionDigest?: string }).admissionDigest;
			const currentKeyAfter = {
				...currentKeyAfterMaterial,
				admissionDigest: empiricalStrictJsonDigest(currentKeyAfterMaterial),
			};
			const candidate = withRejectedBillingTerminal({
				...liveEvidenceInput(),
				claim: claimAcquisition.claim,
				pricing: claimInput.pricing,
				zeroByok: claimInput.zeroByok,
				currentKeyBefore: claimInput.currentKeyBefore,
				currentKeyAfter,
			});
			const evidence = constructRootEvalLiveEvidence(candidate);
			expect(evidence).toMatchObject({
				disposition: "success",
				efficacyClaim: "none",
				causalAttribution: "undetermined",
				admissionReport: {
					status: "admitted",
					violationCodes: [],
					rejectedGraphSummary: null,
				},
				graphResult: {
					finding: {
						stoppingReason: "campaign-complete",
						finding: "positive-differential",
						providerReportedMicrousd: 85_284,
						pricingRoundingAllowanceMicrousd: 22,
						providerReportedLowerBoundMicrousd: 85_262,
						observedBilledMicrousd: 85_261,
						billingDisposition: "rejected",
					},
				},
			});
			const receipt = await persistRootEvalLiveEvidence({ privateRoot, evidence });
			expect(receipt.postCommitFailureDigest).toBeNull();
			const persisted = await readFile(
				join(privateRoot, ROOT_EVAL_LIVE_GENERATION_REF, "evidence.v27.json"),
				"utf8",
			);
			expect(JSON.parse(persisted)).toEqual(evidence);
			expect(persisted).not.toMatch(/authorization|bearer|admission-0|private-marker/iu);
		} finally {
			await rm(temporary, { recursive: true, force: true });
		}
	});

	it("commits one D140 no-charge preclaim disposition and blocks a later qualification claim", async () => {
		const temporary = await mkdtemp(join(tmpdir(), "graphrefly-root-eval-d94-preclaim-"));
		const privateRoot = await realpath(temporary);
		await chmod(privateRoot, 0o700);
		const input = {
			privateRoot,
			implementationManifestDigest: ROOT_EVAL_CURRENT_IMPLEMENTATION_MANIFEST_DIGEST,
			qualificationArtifactDigest: ROOT_EVAL_CURRENT_QUALIFICATION_ARTIFACT_DIGEST,
			qualificationDigest: ROOT_EVAL_CURRENT_QUALIFICATION_DIGEST,
			taskBindingDigest: ROOT_EVAL_CURRENT_TASK_BINDING_DIGEST,
			failure: new Error("preclaim gate failed without provider dispatch"),
		};
		try {
			await expect(persistRootEvalLivePreclaimFailure(input)).resolves.toMatchObject({
				receiptDigest: expect.stringMatching(/^sha256:[0-9a-f]{64}$/u),
				postCommitFailureDigest: null,
			});
			await expect(persistRootEvalLivePreclaimFailure(input)).rejects.toMatchObject({
				code: "EEXIST",
			});
			await expect(
				acquireRootEvalLiveClaimForNoNetworkQualification(await currentClaimInput(privateRoot)),
			).rejects.toMatchObject({ code: "EEXIST" });
			const entries = await readdir(privateRoot);
			expect(entries).toHaveLength(1);
			expect(entries[0]).toContain("disposition.v21.json");
		} finally {
			await rm(temporary, { recursive: true, force: true });
		}
	});

	it("advances past only contiguous self-consistent consumed preclaim dispositions", async () => {
		const temporary = await mkdtemp(join(tmpdir(), "graphrefly-root-eval-consumed-preclaim-"));
		const operatorRoot = await realpath(temporary);
		const generationRef = rootEvalD152DevelopmentGenerationRef(15);
		const generationRoot = join(operatorRoot, `current-${generationRef}`);
		const dispositionPath = join(generationRoot, `.${generationRef}.disposition.v21.json`);
		const material = {
			schemaVersion: ROOT_EVAL_LIVE_PRECLAIM_FAILURE_SCHEMA,
			decisionRef: ROOT_EVAL_LIVE_DECISION_REF,
			generationRef,
			implementationManifestDigest: empiricalStrictJsonDigest("old-implementation"),
			qualificationArtifactDigest: empiricalStrictJsonDigest("old-artifact"),
			qualificationDigest: empiricalStrictJsonDigest("old-qualification"),
			taskBindingDigest: empiricalStrictJsonDigest("old-task-binding"),
			providerCalls: 0,
			chargedCallExecuted: false,
			failureDigest: empiricalStrictJsonDigest("old-preclaim-failure"),
		};
		const bytes = new TextEncoder().encode(
			JSON.stringify({ ...material, receiptDigest: empiricalStrictJsonDigest(material) }),
		);
		try {
			await chmod(operatorRoot, 0o700);
			await mkdir(generationRoot, { mode: 0o700 });
			await writeFile(dispositionPath, bytes, { mode: 0o600 });
			expect(
				admitRootEvalLiveConsumedPreclaimFailure({
					bytes,
					expectedGenerationRef: generationRef,
				}),
			).toMatchObject(material);
			await expect(
				readRootEvalLiveConsumedDevelopmentPreclaimFailures({
					operatorRoot,
					firstMissingOrdinal: 15,
					currentOrdinal: 16,
				}),
			).resolves.toEqual([
				expect.objectContaining({
					generationRef,
					providerCalls: 0,
					chargedCallExecuted: false,
					receiptDigest: empiricalStrictJsonDigest(material),
				}),
			]);
			await expect(
				readRootEvalLiveConsumedDevelopmentPreclaimFailures({
					operatorRoot,
					firstMissingOrdinal: 14,
					currentOrdinal: 16,
				}),
			).rejects.toThrow(/range was invalid/u);
			await expect(
				readRootEvalLiveConsumedDevelopmentPreclaimFailures({
					operatorRoot: join(operatorRoot, "not-read-for-empty-range"),
					firstMissingOrdinal: 1,
					currentOrdinal: 1,
				}),
			).resolves.toEqual([]);

			const chargedMaterial = { ...material, chargedCallExecuted: true };
			await writeFile(
				dispositionPath,
				JSON.stringify({
					...chargedMaterial,
					receiptDigest: empiricalStrictJsonDigest(chargedMaterial),
				}),
				{ mode: 0o600 },
			);
			await expect(
				readRootEvalLiveConsumedDevelopmentPreclaimFailures({
					operatorRoot,
					firstMissingOrdinal: 15,
					currentOrdinal: 16,
				}),
			).rejects.toThrow(/chargedCallExecuted/u);
		} finally {
			await rm(temporary, { recursive: true, force: true });
		}
	});

	it("durably resets the qualification streak for a consumed zero-cost preclaim failure", () => {
		const first = advanceRootEvalD145CharterLedger({
			ledger: ROOT_EVAL_D145_EMPTY_CHARTER_LEDGER,
			generationRef: rootEvalD145DevelopmentGenerationRef(1),
			campaignPurpose: "development",
			taskSetRef: rootEvalD145DevelopmentTaskSetRef(1),
			taskManifestDigest: empiricalStrictJsonDigest("development-1-manifest"),
			budgetPartition: "development-usd-36",
			providerReportedMicrousd: 1,
			unreportedSettledUpperBoundMicrousd: 0,
			accountedUpperBoundMicrousd: 1,
			admissionStatus: "admitted",
			developmentQualification: {
				kind: "eval-development-qualification-state",
				campaignPurpose: "development",
				generationRef: rootEvalD145DevelopmentGenerationRef(1),
				status: "qualified",
				generationQualified: true,
				consecutiveQualifyingGenerations: 1,
				requiredConsecutiveGenerations: 2,
				heldOutEligible: false,
			},
			evidenceDigest: empiricalStrictJsonDigest("development-1-evidence"),
		});
		const receiptDigest = empiricalStrictJsonDigest("development-2-preclaim-receipt");
		const reconciliationInput = {
			generationRef: rootEvalD145DevelopmentGenerationRef(2),
			taskSetRef: rootEvalD145DevelopmentTaskSetRef(2),
			taskManifestDigest: empiricalStrictJsonDigest("development-2-manifest"),
			receiptDigest,
		};
		const reconciliationDigest =
			rootEvalD145ConsumedPreclaimReconciliationDigest(reconciliationInput);
		const reconciled = reconcileRootEvalD145ConsumedPreclaimFailure({
			ledger: first,
			...reconciliationInput,
		});
		expect(reconciled).toMatchObject({
			developmentSpentMicrousd: 1,
			developmentQualificationStreak: 0,
			entries: [
				expect.objectContaining({ generationQualified: true }),
				expect.objectContaining({
					generationRef: rootEvalD145DevelopmentGenerationRef(2),
					providerReportedMicrousd: 0,
					unreportedSettledUpperBoundMicrousd: 0,
					accountedUpperBoundMicrousd: 0,
					generationQualified: false,
					evidenceDigest: reconciliationDigest,
				}),
			],
		});
		expect(
			rootEvalD145ConsumedPreclaimReconciliationDigest({
				...reconciliationInput,
				taskManifestDigest: empiricalStrictJsonDigest("different-development-2-manifest"),
			}),
		).not.toBe(reconciliationDigest);
		expect(nextRootEvalD145DevelopmentOrdinal(reconciled)).toBe(3);

		const third = advanceRootEvalD145CharterLedger({
			ledger: reconciled,
			generationRef: rootEvalD145DevelopmentGenerationRef(3),
			campaignPurpose: "development",
			taskSetRef: rootEvalD145DevelopmentTaskSetRef(3),
			taskManifestDigest: empiricalStrictJsonDigest("development-3-manifest"),
			budgetPartition: "development-usd-36",
			providerReportedMicrousd: 1,
			unreportedSettledUpperBoundMicrousd: 0,
			accountedUpperBoundMicrousd: 1,
			admissionStatus: "admitted",
			developmentQualification: {
				kind: "eval-development-qualification-state",
				campaignPurpose: "development",
				generationRef: rootEvalD145DevelopmentGenerationRef(3),
				status: "qualified",
				generationQualified: true,
				consecutiveQualifyingGenerations: 1,
				requiredConsecutiveGenerations: 2,
				heldOutEligible: false,
			},
			evidenceDigest: empiricalStrictJsonDigest("development-3-evidence"),
		});
		expect(third.developmentQualificationStreak).toBe(1);
	});

	it("serializes consumed preclaim reconciliation through the durable charter journal", async () => {
		const temporary = await mkdtemp(join(tmpdir(), "graphrefly-root-eval-charter-reconcile-"));
		const ledgerPath = join(temporary, "ledger.json");
		const journalPath = join(temporary, "journal.json");
		const firstInput = {
			generationRef: rootEvalD145DevelopmentGenerationRef(1),
			taskSetRef: rootEvalD145DevelopmentTaskSetRef(1),
			taskManifestDigest: empiricalStrictJsonDigest("reconciliation-development-1-manifest"),
			receiptDigest: empiricalStrictJsonDigest("reconciliation-development-1-receipt"),
		};
		const first = reconcileRootEvalD145ConsumedPreclaimFailure({
			ledger: ROOT_EVAL_D145_EMPTY_CHARTER_LEDGER,
			...firstInput,
		});
		try {
			await commitRootEvalD145CharterReconciliation({
				journalPath,
				charterLedgerPath: ledgerPath,
				previousLedgerDigest: ROOT_EVAL_D145_EMPTY_CHARTER_LEDGER.ledgerDigest,
				reconciliationDigest: rootEvalD145ConsumedPreclaimReconciliationDigest(firstInput),
				nextLedger: first,
			});
			expect(await readRootEvalD145CharterLedger(ledgerPath)).toEqual(first);
			await expect(recoverRootEvalD145CharterTransaction(journalPath)).resolves.toBeNull();

			const staleInput = {
				generationRef: rootEvalD145DevelopmentGenerationRef(2),
				taskSetRef: rootEvalD145DevelopmentTaskSetRef(2),
				taskManifestDigest: empiricalStrictJsonDigest("stale-development-2-manifest"),
				receiptDigest: empiricalStrictJsonDigest("stale-development-2-receipt"),
			};
			const competingInput = {
				...staleInput,
				taskManifestDigest: empiricalStrictJsonDigest("competing-development-2-manifest"),
				receiptDigest: empiricalStrictJsonDigest("competing-development-2-receipt"),
			};
			const staleNext = reconcileRootEvalD145ConsumedPreclaimFailure({
				ledger: first,
				...staleInput,
			});
			const competingNext = reconcileRootEvalD145ConsumedPreclaimFailure({
				ledger: first,
				...competingInput,
			});
			await writeRootEvalD145CharterLedger(ledgerPath, competingNext);
			await expect(
				commitRootEvalD145CharterReconciliation({
					journalPath,
					charterLedgerPath: ledgerPath,
					previousLedgerDigest: first.ledgerDigest,
					reconciliationDigest: rootEvalD145ConsumedPreclaimReconciliationDigest(staleInput),
					nextLedger: staleNext,
				}),
			).rejects.toThrow(/source ledger changed/u);
			expect(await readRootEvalD145CharterLedger(ledgerPath)).toEqual(competingNext);
		} finally {
			await rm(temporary, { recursive: true, force: true });
		}
	});

	it("permits exactly one concurrent finalizer for a recoverable charter journal", async () => {
		const temporary = await mkdtemp(join(tmpdir(), "graphrefly-root-eval-charter-finalizer-"));
		const ledgerPath = resolve(join(temporary, "ledger.json"));
		const journalPath = resolve(join(temporary, "journal.json"));
		const reconciliationInput = {
			generationRef: rootEvalD145DevelopmentGenerationRef(1),
			taskSetRef: rootEvalD145DevelopmentTaskSetRef(1),
			taskManifestDigest: empiricalStrictJsonDigest("finalizer-development-1-manifest"),
			receiptDigest: empiricalStrictJsonDigest("finalizer-development-1-receipt"),
		};
		const reconciliationDigest =
			rootEvalD145ConsumedPreclaimReconciliationDigest(reconciliationInput);
		const nextLedger = reconcileRootEvalD145ConsumedPreclaimFailure({
			ledger: ROOT_EVAL_D145_EMPTY_CHARTER_LEDGER,
			...reconciliationInput,
		});
		const journalMaterial = Object.freeze({
			schemaVersion: ROOT_EVAL_D145_CHARTER_RECONCILIATION_SCHEMA,
			charterLedgerPath: ledgerPath,
			previousLedgerDigest: ROOT_EVAL_D145_EMPTY_CHARTER_LEDGER.ledgerDigest,
			reconciliationDigest,
			nextLedger,
		});
		const journalBytes = strictJsonCodec.encode({
			...journalMaterial,
			transactionDigest: empiricalStrictJsonDigest(journalMaterial),
		});
		try {
			await writeFile(journalPath, journalBytes, { mode: 0o600 });
			const recoveries = await Promise.allSettled([
				recoverRootEvalD145CharterTransaction(journalPath),
				recoverRootEvalD145CharterTransaction(journalPath),
			]);
			expect(
				recoveries.filter((result) => result.status === "fulfilled" && result.value !== null),
			).toHaveLength(1);
			expect(await readRootEvalD145CharterLedger(ledgerPath)).toEqual(nextLedger);
			await expect(stat(journalPath)).rejects.toMatchObject({ code: "ENOENT" });
			expect((await stat(`${journalPath}.lock.sqlite`)).mode & 0o777).toBe(0o600);

			// Crash after ledger persistence but before journal deletion remains idempotently recoverable.
			await writeFile(journalPath, journalBytes, { mode: 0o600 });
			await expect(recoverRootEvalD145CharterTransaction(journalPath)).resolves.toMatchObject({
				transactionDigest: empiricalStrictJsonDigest(journalMaterial),
			});
			expect(await readRootEvalD145CharterLedger(ledgerPath)).toEqual(nextLedger);
			// Crash after journal deletion leaves no stale process-owned lock state.
			await expect(recoverRootEvalD145CharterTransaction(journalPath)).resolves.toBeNull();

			const secondInput = {
				generationRef: rootEvalD145DevelopmentGenerationRef(2),
				taskSetRef: rootEvalD145DevelopmentTaskSetRef(2),
				taskManifestDigest: empiricalStrictJsonDigest("finalizer-development-2-manifest"),
				receiptDigest: empiricalStrictJsonDigest("finalizer-development-2-receipt"),
			};
			const secondLedger = reconcileRootEvalD145ConsumedPreclaimFailure({
				ledger: nextLedger,
				...secondInput,
			});
			await commitRootEvalD145CharterReconciliation({
				journalPath,
				charterLedgerPath: ledgerPath,
				previousLedgerDigest: nextLedger.ledgerDigest,
				reconciliationDigest: rootEvalD145ConsumedPreclaimReconciliationDigest(secondInput),
				nextLedger: secondLedger,
			});
			expect(await readRootEvalD145CharterLedger(ledgerPath)).toEqual(secondLedger);
		} finally {
			await rm(temporary, { recursive: true, force: true });
		}
	});

	it("settles a version-stale charged journal as spend-only without efficacy evidence", async () => {
		const temporary = await mkdtemp(join(tmpdir(), "graphrefly-root-eval-stale-journal-"));
		const canonicalTemporary = await realpath(temporary);
		const generationRef = rootEvalD145DevelopmentGenerationRef(1);
		const privateRoot = resolve(join(canonicalTemporary, `current-${generationRef}`));
		const ledgerPath = resolve(join(canonicalTemporary, "ledger.json"));
		const journalPath = resolve(join(canonicalTemporary, "journal.json"));
		const taskSetRef = rootEvalD145DevelopmentTaskSetRef(1);
		const taskManifestDigest = empiricalStrictJsonDigest("stale-development-1-manifest");
		const oldImplementationDigest = empiricalStrictJsonDigest("stale-implementation");
		const partial = constructRootEvalLiveEvidence({
			...liveEvidenceInput(),
			graphResult: null,
			providerCalls: 1,
			failure: new Error("old projector rejected its terminal observation"),
			cleanupDisposition: "complete",
		});
		const { evidenceDigest: _currentEvidenceDigest, ...partialMaterial } = partial;
		const staleEvidenceMaterial = {
			...partialMaterial,
			schemaVersion: "graphrefly-ts.root-eval-live-evidence.v24" as const,
			generationRef,
			implementationCoordinate: `worktree:${"b".repeat(40)}:${oldImplementationDigest}`,
			implementationManifestDigest: oldImplementationDigest,
			taskManifestDigest,
		};
		const staleEvidence = Object.freeze({
			...staleEvidenceMaterial,
			evidenceDigest: empiricalStrictJsonDigest(staleEvidenceMaterial),
		});
		const intendedOldLedger = advanceRootEvalD145CharterLedger({
			ledger: ROOT_EVAL_D145_EMPTY_CHARTER_LEDGER,
			generationRef,
			campaignPurpose: "development",
			taskSetRef,
			taskManifestDigest,
			budgetPartition: "development-usd-36",
			providerReportedMicrousd: 90_000,
			unreportedSettledUpperBoundMicrousd: 5_800_000,
			accountedUpperBoundMicrousd: 5_890_000,
			admissionStatus: "rejected",
			developmentQualification: null,
			evidenceDigest: staleEvidence.evidenceDigest,
		});
		const journalMaterial = Object.freeze({
			schemaVersion: ROOT_EVAL_D145_CHARTER_TRANSACTION_SCHEMA,
			privateRoot,
			charterLedgerPath: ledgerPath,
			previousLedgerDigest: ROOT_EVAL_D145_EMPTY_CHARTER_LEDGER.ledgerDigest,
			evidence: staleEvidence,
			nextLedger: intendedOldLedger,
		});
		try {
			await mkdir(privateRoot, { mode: 0o700 });
			const completedEvidenceRoot = join(privateRoot, generationRef);
			await mkdir(completedEvidenceRoot, { mode: 0o700 });
			await writeFile(
				join(completedEvidenceRoot, "evidence.v24.json"),
				strictJsonCodec.encode(staleEvidence),
				{ mode: 0o600 },
			);
			await writeRootEvalD145CharterLedger(ledgerPath, intendedOldLedger);
			await writeFile(
				journalPath,
				strictJsonCodec.encode({
					...journalMaterial,
					transactionDigest: empiricalStrictJsonDigest(journalMaterial),
				}),
				{ mode: 0o600 },
			);
			await expect(recoverRootEvalD145CharterTransaction(journalPath)).resolves.toMatchObject({
				transactionDigest: empiricalStrictJsonDigest(journalMaterial),
				historicalEvidencePreserved: true,
			});
			expect(await readRootEvalD145CharterLedger(ledgerPath)).toEqual(intendedOldLedger);
			await rm(completedEvidenceRoot, { recursive: true });
			await rm(ledgerPath);

			const forgedEvidenceMaterial = {
				...staleEvidenceMaterial,
				efficacyClaim: "transfer-task-family-positive-differential" as const,
				causalAttribution: "verified-prior-work-item-memory-transfer" as const,
			};
			const forgedEvidence = {
				...forgedEvidenceMaterial,
				evidenceDigest: empiricalStrictJsonDigest(forgedEvidenceMaterial),
			};
			const forgedLedger = advanceRootEvalD145CharterLedger({
				ledger: ROOT_EVAL_D145_EMPTY_CHARTER_LEDGER,
				generationRef,
				campaignPurpose: "development",
				taskSetRef,
				taskManifestDigest,
				budgetPartition: "development-usd-36",
				providerReportedMicrousd: 90_000,
				unreportedSettledUpperBoundMicrousd: 5_800_000,
				accountedUpperBoundMicrousd: 5_890_000,
				admissionStatus: "rejected",
				developmentQualification: null,
				evidenceDigest: forgedEvidence.evidenceDigest,
			});
			const forgedJournalMaterial = {
				...journalMaterial,
				evidence: forgedEvidence,
				nextLedger: forgedLedger,
			};
			await writeFile(
				journalPath,
				strictJsonCodec.encode({
					...forgedJournalMaterial,
					transactionDigest: empiricalStrictJsonDigest(forgedJournalMaterial),
				}),
				{ mode: 0o600 },
			);
			await expect(recoverRootEvalD145CharterTransaction(journalPath)).rejects.toThrow(
				/fail-closed.*efficacy/u,
			);
			expect(await readRootEvalD145CharterLedger(ledgerPath)).toEqual(
				ROOT_EVAL_D145_EMPTY_CHARTER_LEDGER,
			);

			await writeFile(
				journalPath,
				strictJsonCodec.encode({
					...journalMaterial,
					transactionDigest: empiricalStrictJsonDigest(journalMaterial),
				}),
				{ mode: 0o600 },
			);
			const recovered = await recoverRootEvalD145CharterTransaction(journalPath);
			expect(recovered).toMatchObject({
				persistence: null,
				transactionDigest: empiricalStrictJsonDigest(journalMaterial),
				reconciliationReceiptDigest: expect.stringMatching(/^sha256:[0-9a-f]{64}$/u),
			});
			const ledger = await readRootEvalD145CharterLedger(ledgerPath);
			expect(ledger).toMatchObject({
				developmentSpentMicrousd: 5_890_000,
				developmentQualificationStreak: 0,
				entries: [
					expect.objectContaining({
						generationRef,
						generationQualified: false,
						providerReportedMicrousd: 90_000,
						unreportedSettledUpperBoundMicrousd: 5_800_000,
						accountedUpperBoundMicrousd: 5_890_000,
						evidenceDigest: recovered?.reconciliationReceiptDigest,
					}),
				],
			});
			const receiptPath = join(
				privateRoot,
				`.${generationRef}.stale-transaction-reconciliation.v1.json`,
			);
			expect(JSON.parse(await readFile(receiptPath, "utf8"))).toMatchObject({
				schemaVersion: ROOT_EVAL_D145_STALE_TRANSACTION_RECONCILIATION_SCHEMA,
				generationRef,
				classification: "consumed-unqualified-stale-transaction",
				accountedUpperBoundMicrousd: 5_890_000,
				receiptDigest: recovered?.reconciliationReceiptDigest,
			});
			await expect(stat(journalPath)).rejects.toMatchObject({ code: "ENOENT" });
			await expect(stat(join(privateRoot, generationRef))).rejects.toMatchObject({
				code: "ENOENT",
			});

			// A crash after the recovered ledger write but before journal deletion is idempotent.
			await writeFile(
				journalPath,
				strictJsonCodec.encode({
					...journalMaterial,
					transactionDigest: empiricalStrictJsonDigest(journalMaterial),
				}),
				{ mode: 0o600 },
			);
			await expect(recoverRootEvalD145CharterTransaction(journalPath)).resolves.toEqual(recovered);
			expect(await readRootEvalD145CharterLedger(ledgerPath)).toEqual(ledger);
		} finally {
			await rm(temporary, { recursive: true, force: true });
		}
	});

	it("reconciles rejected post-usage response shapes at their independently validated cost", async () => {
		const temporary = await mkdtemp(join(tmpdir(), "graphrefly-root-eval-live-proposal-shape-"));
		const base = JSON.parse(new TextDecoder().decode(providerBytes())) as Record<string, unknown>;
		const legacyToolCall = new TextEncoder().encode(
			JSON.stringify({
				...base,
				choices: [
					{
						message: {
							content: null,
							tool_calls: [{ function: { name: "replace_exact", arguments: "{}" } }],
						},
					},
				],
			}),
		);
		const malformedProposal = new TextEncoder().encode(
			JSON.stringify({
				...base,
				choices: [{ message: { content: "{" } }],
			}),
		);
		const executor = createRootEvalNoNetworkQualificationExecutor({
			repositoryRoot,
			materializationRoot: join(temporary, "workspaces"),
			pricing,
			providerResponses: [],
			providerResponseForEffect(effect) {
				if (effect.workItemRole === "source")
					return {
						status: 200,
						bytes: providerBytesForSourceTask(
							ROOT_EVAL_DEVELOPMENT_TASKS[effect.replicate - 1]!,
							effect.workItemId,
						),
					};
				return { status: 200, bytes: effect.replicate === 1 ? legacyToolCall : malformedProposal };
			},
		});
		try {
			const graphResult = await runRootEval(
				createRootEvalTopology({
					profileInput: createCurrentExactModelHarnessProfileInput(),
					currentKeyBefore: ROOT_EVAL_NO_NETWORK_CURRENT_KEY_BEFORE,
					providerPacingSetTimeout: (callback) => {
						callback();
						return 0 as unknown as ReturnType<typeof setTimeout>;
					},
					campaignRef: ROOT_EVAL_LIVE_GENERATION_REF,
					taskSetRef: ROOT_EVAL_DEVELOPMENT_TASK.taskSetRef,
					maxCostMicrousd: 6_000_000,
					reservationMicrousd: 200_000,
				}),
				async (effect) => {
					if (effect.kind === "eval-admitted-billing-observation")
						return await executor.execute(effect);
					if (effect.kind === "eval-admitted-tool-effect" && effect.workItemRole === "source")
						return await executor.execute(effect);
					if (
						effect.kind === "eval-admitted-effect" &&
						(effect.workItemRole === "source" ||
							(effect.replicate <= 2 && effect.arm === "relevant-applied"))
					)
						return await executor.execute(effect);
					if (effect.kind !== "eval-admitted-effect")
						throw new Error("unexpected non-provider effect after proposal rejection");
					const resultDigest = empiricalStrictJsonDigest({
						kind: "injected-control-provider-failure",
						executionId: effect.executionId,
					});
					return Object.freeze({
						kind: "eval-provider-outcome" as const,
						admission: effect,
						admissionId: effect.admissionId,
						executionId: effect.executionId,
						operationId: effect.operationId,
						effectRunId: effect.effectRunId,
						workItemId: effect.workItemId,
						workItemRole: effect.workItemRole,
						replicate: effect.replicate,
						arm: effect.arm,
						providerLogicalAttempt: effect.providerLogicalAttempt,
						dispatchOrdinal: effect.dispatchOrdinal,
						capacityRetryOrdinal: effect.capacityRetryOrdinal,
						availabilityRetryOrdinal: effect.availabilityRetryOrdinal,
						status: "failed" as const,
						reason: "executor-failed" as const,
						recoveryClass: null,
						dispatchAttempted: false,
						dispatchElapsedMs: 0,
						providerResponseKind: "none" as const,
						httpStatus: null,
						providerErrorCode: null,
						transportNoToolSideEffect: false,
						costMicrousd: 0,
						costEvidence: "provider-reported" as const,
						pricingRoundingAllowanceMicrousd: 0,
						elapsedMs: 0,
						resultDigest,
						retryAfterMs: 0,
						cleanupCompleted: true,
						toolProposal: null,
					} satisfies EvalProviderOutcome);
				},
			);
			expect(executor.providerRequestSummaries()).toHaveLength(7);
			expect(graphResult.finding.providerReportedMicrousd).toBe(1_099);
			expect(graphResult.finding.providerOutcomeReasonCounts).toMatchObject({
				"tool-proposed": 5,
				"response-proposal-legacy-shape": 1,
				"response-proposal-invalid": 1,
				"executor-failed": 28,
			});
		} finally {
			await executor.dispose();
			await rm(temporary, { recursive: true, force: true });
		}
	}, 120_000);

	it.each([
		"development-1",
		"development-3",
	] as const)("completes an all-Work-Item 429 lifecycle beyond the old projection bounds for %s", async (slot) => {
		const temporary = await mkdtemp(join(tmpdir(), "graphrefly-root-eval-live-six-429-"));
		const materializationRoot = join(temporary, "workspaces");
		const taskManifest = createRootEvalTaskManifest({
			slot,
			variantOrder: [0, 1, 2, 3, 4],
			coordinateSuffix: "no-network-shape",
		});
		const tasks = taskManifest.tasks;
		const generationRef = rootEvalD152DevelopmentGenerationRef(slot === "development-3" ? 3 : 1);
		expect(
			rootEvalWorkspaceForAdmission(materializationRoot, {
				replicate: 1,
				workItemRole: "source",
				arm: "cold",
				dispatchOrdinal: 1,
			}),
		).not.toBe(
			rootEvalWorkspaceForAdmission(materializationRoot, {
				replicate: 1,
				workItemRole: "target",
				arm: "cold",
				dispatchOrdinal: 1,
			}),
		);
		const retryable = Object.freeze({
			status: 429,
			bytes: new TextEncoder().encode("{}"),
			retryAfter: "0",
		});
		const executor = createRootEvalNoNetworkQualificationExecutor({
			repositoryRoot,
			materializationRoot,
			pricing,
			taskManifestSlot: slot,
			taskManifest,
			providerResponses: [],
			providerResponseForEffect(effect) {
				const task = tasks[effect.replicate - 1]!;
				if (effect.dispatchOrdinal === 1) return retryable;
				return {
					status: 200,
					bytes:
						effect.workItemRole === "source"
							? providerBytesForSourceTask(task, effect.workItemId)
							: providerBytesForTask(task, effect.workItemId),
				};
			},
		});
		try {
			const graphResult = await runRootEval(
				createRootEvalTopology({
					profileInput: createCurrentExactModelHarnessProfileInput(),
					currentKeyBefore: ROOT_EVAL_NO_NETWORK_CURRENT_KEY_BEFORE,
					providerPacingSetTimeout: (callback) => {
						callback();
						return 0 as unknown as ReturnType<typeof setTimeout>;
					},
					campaignRef: generationRef,
					campaignPurpose: ROOT_EVAL_LIVE_CAMPAIGN_PURPOSE,
					taskSetRef: taskManifest.taskSetRef,
					taskManifestDigest: taskManifest.manifestDigest,
					taskDefinitions: tasks,
					taskBindings: rootEvalTaskBindings(tasks, generationRef),
					generationRef,
					heldOutSealDigest: ROOT_EVAL_LIVE_HELD_OUT_SEAL_DIGEST,
					budgetPartition:
						slot === "development-3" ? "development-usd-40" : ROOT_EVAL_LIVE_BUDGET_PARTITION,
					partitionHardCapMicrousd:
						slot === "development-3" ? 40_000_000 : ROOT_EVAL_LIVE_PARTITION_HARD_CAP_MICROUSD,
					partitionLedgerDigest: testPartitionLedgerDigest,
					developmentQualificationStreakBefore: 0,
					maxCostMicrousd:
						slot === "development-3" ? 4_179_695 : ROOT_EVAL_LIVE_CAMPAIGN_HARD_CAP_MICROUSD,
					// The synthetic body lacks qualified zero-cost evidence; retain all
					// 35 holds. This offline reserve fits both generation-specific caps.
					reservationMicrousd: slot === "development-3" ? 100_000 : 200_000,
				}),
				async (effect) => {
					if (effect.kind !== "eval-admitted-retry-delay") return await executor.execute(effect);
					return Object.freeze({
						kind: "eval-retry-delay-outcome" as const,
						admission: effect,
						executionId: effect.executionId,
						elapsedMs: effect.delayMs,
						status: "completed" as const,
						resultDigest: empiricalStrictJsonDigest({
							kind: "no-network-immediate-retry-delay",
							executionId: effect.executionId,
						}),
					});
				},
			);
			expect(executor.providerRequestSummaries()).toHaveLength(70);
			expect(graphResult.executedAdmissionIds).toHaveLength(70);
			if (slot === "development-1") assertRootEvalRunResultAdmissionShape(graphResult);
			else {
				// Evidence authority is intentionally generation-scoped at module load.
				// The default generation-1 boundary must reject this generation-3 run.
				expect(() => assertRootEvalRunResultAdmissionShape(graphResult)).toThrow(
					/admission identity/u,
				);
				const moduleUrl = pathToFileURL(
					resolve(
						repositoryRoot,
						"packages/ts/evals/graph-native-rerun-avoidance/root-eval-live-authority.ts",
					),
				).href;
				const source = `
					import { readFileSync } from "node:fs";
					const authority = await import(${JSON.stringify(moduleUrl)});
					authority.assertRootEvalRunResultAdmissionShape(JSON.parse(readFileSync(0, "utf8")));
					process.stdout.write("accepted");
				`;
				expect(
					execFileSync(
						process.execPath,
						["--import", "tsx", "--input-type=module", "--eval", source],
						{
							cwd: repositoryRoot,
							env: { ...process.env, GRAPHREFLY_ROOT_EVAL_CAMPAIGN_SLOT: slot },
							input: JSON.stringify(graphResult),
							encoding: "utf8",
							timeout: 20_000,
						},
					),
				).toBe("accepted");
			}
			expect(graphResult.finding).toMatchObject({
				completedWorkItems: 30,
				admittedAttempts: 70,
				providerCallCount: 70,
				stoppingReason: "campaign-complete",
				providerOutcomeReasonCounts: {
					"http-capacity-retryable": 35,
					"tool-proposed": 35,
				},
			});
			const terminal = [...graphResult.observations]
				.reverse()
				.flatMap((event) =>
					event.msg[0] === "DATA" ? [event.msg[1] as Record<string, unknown>] : [],
				)
				.find((value) => value.finding !== "pending");
			expect(terminal).toMatchObject({
				retryProposalCount: 35,
				pendingRetryProposalCount: 0,
				admittedRetryAttempts: 35,
				rejectedRetryProposalCount: 0,
				settledRetryAttemptCount: 35,
			});
			expect(await readdir(materializationRoot)).toEqual([]);
		} finally {
			await executor.dispose();
			await rm(temporary, { recursive: true, force: true });
		}
	}, 300_000);

	it("derives and enforces the exact 175-provider/140-retry topology boundary offline", () => {
		const input = liveEvidenceInput();
		const graphResult = input.graphResult!;
		const terminal = graphResult.observations.at(-1)!;
		if (terminal.msg[0] !== "DATA") throw new TypeError("test terminal observation missing");
		const terminalValue = terminal.msg[1] as Readonly<Record<string, unknown>>;
		const providerCapacity = terminalValue.providerCapacity as Readonly<Record<string, unknown>>;
		const maxProviderAttempts = rootEvalMaximumProviderAttempts(ROOT_EVAL_LIVE_REPLICATE_COUNT);
		const maxRetryAttempts = rootEvalMaximumRetryAttempts(ROOT_EVAL_LIVE_REPLICATE_COUNT);
		const maxWorkItems = ROOT_EVAL_LIVE_REPLICATE_COUNT * (arms.length + 1);
		const maxCapacityRetries = maxWorkItems * ROOT_EVAL_MAX_CAPACITY_RETRIES;
		const maxAvailabilityRetries = maxWorkItems * ROOT_EVAL_MAX_AVAILABILITY_RETRIES;
		const maximalReasonCounts = Object.freeze({
			...emptyEvalProviderOutcomeReasonCounts(),
			"tool-proposed": maxWorkItems,
			"http-capacity-retryable": maxCapacityRetries,
			"http-availability-retryable": maxAvailabilityRetries,
		});
		expect(maxProviderAttempts).toBe(175);
		expect(maxRetryAttempts).toBe(140);
		expect(maxCapacityRetries + maxAvailabilityRetries).toBe(maxRetryAttempts);
		const maximalObservation = {
			...terminalValue,
			providerCapacity: {
				...providerCapacity,
				mode: "cooldown",
				proposalCount: maxProviderAttempts,
				pendingProposalCount: 0,
				pendingFirstAttemptProposalCount: 0,
				pendingRetryProposalCount: 0,
				retryProposalCount: maxRetryAttempts,
				admittedProposalCount: maxProviderAttempts,
				admittedRetryProposalCount: maxRetryAttempts,
				settledProposalCount: maxProviderAttempts,
				settledRetryProposalCount: maxRetryAttempts,
				rejectedProposalCount: 0,
				rejectedRetryProposalCount: 0,
				cooldownOutstandingReadinessCount: 1,
				rateLimitFeedbackCount: maxCapacityRetries,
			},
			admittedAttempts: maxProviderAttempts,
			admittedRetryAttempts: maxRetryAttempts,
			retryProposalCount: maxRetryAttempts,
			pendingRetryProposalCount: 0,
			rejectedRetryProposalCount: 0,
			settledRetryAttemptCount: maxRetryAttempts,
			providerCallCount: maxProviderAttempts,
			providerOutcomeReasonCounts: maximalReasonCounts,
		} as never;
		assertRootEvalObservationRuntimeShape(maximalObservation, "maximal offline observation");
		const maximalEvent = {
			...terminal,
			msg: ["DATA", maximalObservation] as never,
		};
		const maximalGraphResult: RootEvalRunResult = {
			...graphResult,
			finding: {
				...graphResult.finding,
				admittedAttempts: maxProviderAttempts,
				providerCallCount: maxProviderAttempts,
				providerOutcomeReasonCounts: maximalReasonCounts,
			},
			observations: [...graphResult.observations.slice(0, -1), maximalEvent],
			executedAdmissionIds: allProviderAdmissionIds(),
		};
		expect(maximalGraphResult.executedAdmissionIds).toHaveLength(maxProviderAttempts);
		assertRootEvalRunResultAdmissionShape(maximalGraphResult);
		expect(() =>
			assertRootEvalRunResultAdmissionShape({
				...maximalGraphResult,
				observations: Array.from(
					{ length: rootEvalMaximumObservationOccurrences(5) + 1 },
					() => maximalEvent,
				),
			}),
		).toThrow(/retention|bound|observations/u);
		const oversizedDiagnosticStream = [
			...Array.from({ length: 513 }, () => maximalGraphResult.observations[0]!),
			...maximalGraphResult.observations,
		];
		const evidence = constructRootEvalLiveEvidence({
			...input,
			providerCalls: maxProviderAttempts,
			graphResult: maximalGraphResult,
			partialGraphObservations: oversizedDiagnosticStream,
		});
		expect(evidence).toMatchObject({
			disposition: "success",
			providerCalls: maxProviderAttempts,
			admissionReport: { status: "admitted" },
			latestGraphObservation: {
				msg: [
					"DATA",
					expect.objectContaining({
						admittedAttempts: maxProviderAttempts,
						admittedRetryAttempts: maxRetryAttempts,
						providerCallCount: maxProviderAttempts,
					}),
				],
			},
		});
		expect(evidence.partialGraphObservations).toHaveLength(oversizedDiagnosticStream.length);
		expect(evidence.latestGraphObservation).toEqual(evidence.partialGraphObservations.at(-1));

		for (const overflow of [
			{ admittedAttempts: maxProviderAttempts + 1 },
			{ providerCallCount: maxProviderAttempts + 1 },
			{ admittedRetryAttempts: maxRetryAttempts + 1 },
			{ retryProposalCount: maxRetryAttempts + 1 },
			{ settledRetryAttemptCount: maxRetryAttempts + 1 },
		])
			expect(() =>
				assertRootEvalObservationRuntimeShape(
					{ ...maximalObservation, ...overflow } as never,
					"overflow offline observation",
				),
			).toThrow(/expected safe integer in/u);

		expect(() =>
			evaluateRootEvalLiveAdmission({ ...input, providerCalls: maxProviderAttempts + 1 }),
		).toThrow(/authority\.provider-call-count-invalid/u);
		const overflowEvent = {
			...maximalEvent,
			seq: maximalEvent.seq + 1,
			msg: ["DATA", { ...maximalObservation, providerCallCount: maxProviderAttempts + 1 }] as never,
		};
		const projected = constructRootEvalLiveEvidence({
			...input,
			providerCalls: maxProviderAttempts,
			graphResult: maximalGraphResult,
			partialGraphObservations: [...maximalGraphResult.observations, overflowEvent],
		});
		expect(projected.latestGraphObservation).toEqual(maximalEvent);
		expect(projected.partialGraphObservations).not.toContainEqual(overflowEvent);
	});

	it("qualifies Together through five sources and all thirty target Work Items without network", async () => {
		const temporary = await mkdtemp(join(tmpdir(), "graphrefly-together-candidate-"));
		const privateRoot = await realpath(temporary);
		const claimInput = await currentClaimInput(privateRoot);
		const claimCommit = await acquireRootEvalLiveClaimForNoNetworkQualification(claimInput);
		const current = createCurrentExactModelHarnessProfileInput();
		const definition = createDeepSeekV4Flash0731TogetherStructuredProfileDefinition();
		const qualification = createInjectedNoNetworkProfileQualification({
			definition,
			implementationManifestDigest: current.currentImplementationManifestDigest,
			qualificationArtifactDigest: MODEL_HARNESS_PROFILE_NO_NETWORK_QA_ARTIFACT_DIGEST,
		});
		const topology = createRootEvalTopology({
			profileInput: exactQualifiedProfileCatalogInput(
				{ ...definition, qualification },
				current.currentImplementationManifestDigest,
			),
			currentKeyBefore: ROOT_EVAL_NO_NETWORK_CURRENT_KEY_BEFORE,
			campaignRef: "together-injected-qualification",
			campaignPurpose: "qualification",
			maxCostMicrousd: 6_000_000,
			reservationMicrousd: 200_000,
			providerPacingSetTimeout: (callback) => {
				callback();
				return 0 as unknown as ReturnType<typeof setTimeout>;
			},
		});
		const executor = createRootEvalNoNetworkQualificationExecutor({
			repositoryRoot,
			materializationRoot: join(temporary, "workspaces"),
			pricing: {
				inputMicrousdPerMillionTokens: 140_000,
				outputMicrousdPerMillionTokens: 280_000,
				cacheReadMicrousdPerMillionTokens: 140_000,
			},
			providerResponses: [],
			providerResponseForEffect(effect) {
				expect(effect.providerRef).toBe("together");
				const response = JSON.parse(new TextDecoder().decode(providerBytesForEffect(effect)));
				response.provider = "Together";
				response.usage.cost = 0.000168;
				return { status: 200, bytes: new TextEncoder().encode(JSON.stringify(response)) };
			},
		});
		const wrongRouteExecutor = createRootEvalLiveTransportQualificationExecutor({
			graph: topology.graph,
			repositoryRoot,
			materializationRoot: join(temporary, "wrong-route-workspaces"),
			privateRoot,
			claimCommit,
			bearerToken: claimInput.credential.bearerToken,
			pricing: claimInput.pricing,
			providerResponses: [],
		});
		let routeRejectionChecked = false;
		try {
			const result = await runRootEval(topology, async (effect) => {
				if (!routeRejectionChecked && effect.kind === "eval-admitted-effect") {
					routeRejectionChecked = true;
					expect(effect.providerRef).toBe("together");
					await expect(
						wrongRouteExecutor.execute({ ...effect, providerRef: "fireworks" } as never),
					).resolves.toMatchObject({
						status: "failed",
						reason: "executor-failed",
						dispatchAttempted: false,
						costMicrousd: 0,
					});
					expect(wrongRouteExecutor.providerRequestSummaries()).toEqual([]);
					await expect(stat(join(privateRoot, ".d152-provider-dispatches"))).rejects.toMatchObject({
						code: "ENOENT",
					});
					await expect(stat(join(temporary, "wrong-route-workspaces"))).rejects.toMatchObject({
						code: "ENOENT",
					});
				}
				return executor.execute(effect);
			});
			expect(routeRejectionChecked).toBe(true);
			const requests = executor.providerRequestSummaries();
			expect(requests).toHaveLength(35);
			for (const request of requests)
				expect(request).toMatchObject({
					model: "deepseek/deepseek-v4-flash-0731",
					provider: {
						order: ["together"],
						only: ["together"],
						allow_fallbacks: false,
						require_parameters: true,
						data_collection: "deny",
						zdr: true,
					},
					responseFormat: { type: "json_schema", json_schema: { strict: true } },
					forbiddenFieldPresence: {
						parallelToolCalls: false,
						tools: false,
						toolChoice: false,
						plugins: false,
					},
				});
			expect(result.finding.providerOutcomeReasonCounts["tool-proposed"]).toBe(35);
			expect(result.finding.providerReportedMicrousd).toBe(35 * 168);
			expect(result.finding.unreportedSettledUpperBoundMicrousd).toBe(0);
			expect(result.finding.armOrder).toHaveLength(6);
			expect(result.finding.finding).toBe("no-positive-differential");
			for (const arm of Object.values(result.finding.verificationDiagnostics.stageCounts))
				expect(arm).toMatchObject({
					completedWorkItems: 5,
					exactToolAdmitted: 5,
					hiddenVerifierPassed: 5,
					cleanupCompleted: 5,
				});
			expect(await readdir(join(temporary, "workspaces"))).toEqual([]);
		} finally {
			await wrongRouteExecutor.dispose();
			await executor.dispose();
			await rm(temporary, { recursive: true, force: true });
		}
	}, 180_000);

	it.each([
		"development-6",
		"development-7",
	] as const)("runs the full five-replicate six-arm %s bank through no-network Graph integration", async (slot) => {
		const temporary = await realpath(
			await mkdtemp(join(tmpdir(), `graphrefly-root-eval-${slot}-integration-`)),
		);
		const manifest = readRootEvalTaskManifest(slot);
		const topology = createRootEvalTopology({
			profileInput: createCurrentExactModelHarnessProfileInput(),
			currentKeyBefore: ROOT_EVAL_NO_NETWORK_CURRENT_KEY_BEFORE,
			campaignRef: `root-eval-${slot}-no-network-integration`,
			campaignPurpose: "qualification",
			taskSetRef: manifest.taskSetRef,
			taskManifestDigest: manifest.manifestDigest,
			taskDefinitions: manifest.tasks,
			maxCostMicrousd: 6_000_000,
			reservationMicrousd: 200_000,
			providerPacingSetTimeout: (callback) => {
				callback();
				return 0 as unknown as ReturnType<typeof setTimeout>;
			},
		});
		const executor = createRootEvalNoNetworkQualificationExecutor({
			repositoryRoot,
			materializationRoot: join(temporary, "workspaces"),
			taskManifestSlot: slot,
			taskManifest: manifest,
			pricing: {
				inputMicrousdPerMillionTokens: 140_000,
				outputMicrousdPerMillionTokens: 280_000,
				cacheReadMicrousdPerMillionTokens: 30_000,
			},
			providerResponses: [],
			providerResponseForEffect: (effect) => ({
				status: 200,
				bytes: providerBytesForEffect(effect, manifest.tasks),
			}),
		});
		try {
			const result = await runRootEval(topology, executor.execute);
			expect(executor.providerRequestSummaries()).toHaveLength(35);
			expect(result.finding.providerOutcomeReasonCounts["tool-proposed"]).toBe(35);
			expect(result.finding.armOrder).toHaveLength(6);
			for (const arm of Object.values(result.finding.verificationDiagnostics.stageCounts))
				expect(arm).toMatchObject({
					completedWorkItems: 5,
					exactToolAdmitted: 5,
					hiddenVerifierPassed: 5,
					cleanupCompleted: 5,
				});
			expect(await readdir(join(temporary, "workspaces"))).toEqual([]);
		} finally {
			await executor.dispose();
			await rm(temporary, { recursive: true, force: true });
		}
	}, 180_000);

	it("executes one admitted effect against a frozen isolated workspace and behavioral verifiers", async () => {
		const temporary = await mkdtemp(join(tmpdir(), "graphrefly-root-eval-live-"));
		const privateRoot = await realpath(temporary);
		const claimInput = await currentClaimInput(privateRoot);
		const claimCommit = await acquireRootEvalLiveClaimForNoNetworkQualification(claimInput);
		const sourceExecutor = createRootEvalNoNetworkQualificationExecutor({
			repositoryRoot,
			materializationRoot: join(temporary, "workspaces"),
			pricing: claimInput.pricing,
			providerResponses: [],
			providerResponseForEffect(effect) {
				const task = ROOT_EVAL_DEVELOPMENT_TASKS[effect.replicate - 1]!;
				return { status: 200, bytes: providerBytesForSourceTask(task, effect.workItemId) };
			},
		});
		const httpTopology = createRootEvalTopology({
			profileInput: createCurrentExactModelHarnessProfileInput(),
			currentKeyBefore: ROOT_EVAL_NO_NETWORK_CURRENT_KEY_BEFORE,
			providerPacingSetTimeout: (callback) => {
				callback();
				return 0 as unknown as ReturnType<typeof setTimeout>;
			},
			campaignRef: ROOT_EVAL_LIVE_GENERATION_REF,
			campaignPurpose: "qualification",
			taskSetRef: ROOT_EVAL_DEVELOPMENT_TASK.taskSetRef,
			generationRef: ROOT_EVAL_LIVE_GENERATION_REF,
			heldOutSealDigest: ROOT_EVAL_LIVE_HELD_OUT_SEAL_DIGEST,
			budgetPartition: "no-network",
			partitionHardCapMicrousd: 6_000_000,
			partitionLedgerDigest: testPartitionLedgerDigest,
			developmentQualificationStreakBefore: 0,
			maxCostMicrousd: 6_000_000,
			reservationMicrousd: 200_000,
		});
		const executor = createRootEvalLiveTransportQualificationExecutor({
			graph: httpTopology.graph,
			repositoryRoot,
			materializationRoot: join(temporary, "workspaces"),
			privateRoot,
			claimCommit,
			bearerToken: claimInput.credential.bearerToken,
			pricing: claimInput.pricing,
			diagnosticMode: "development-private",
			providerResponses: [
				{
					status: 200,
					bytes: providerBytesForTask(
						ROOT_EVAL_DEVELOPMENT_TASK,
						`${ROOT_EVAL_LIVE_GENERATION_REF}/replicate-1/relevant-applied`,
					),
				},
			],
		});
		try {
			let verified: EvalEffectOutcome | undefined;
			const graphResult = await runRootEval(httpTopology, async (effect) => {
				if (
					(effect.kind === "eval-admitted-effect" || effect.kind === "eval-admitted-tool-effect") &&
					effect.workItemRole === "source"
				)
					return await sourceExecutor.execute(effect);
				if (
					effect.kind === "eval-admitted-effect" &&
					effect.replicate === 1 &&
					effect.arm === "relevant-applied"
				)
					return await executor.execute(effect);
				if (
					effect.kind === "eval-admitted-tool-effect" &&
					effect.workItemRole === "target" &&
					effect.replicate === 1 &&
					effect.arm === "relevant-applied"
				) {
					await expect(
						executor.execute({
							...effect,
							executionId: `${effect.executionId}/forged-unadmitted`,
						}),
					).rejects.toThrow(/complete Graph admission receipt/u);
					verified = (await executor.execute(effect)) as EvalEffectOutcome;
					return verified;
				}
				if (effect.kind === "eval-admitted-retry-delay")
					throw new Error("unexpected retry delay in exact-tool integration test");
				if (effect.kind === "eval-admitted-billing-observation")
					return await executor.execute(effect);
				const digest = empiricalStrictJsonDigest({
					kind: "injected-control-provider-failure",
					executionId: effect.executionId,
				});
				return Object.freeze({
					kind: "eval-provider-outcome" as const,
					admission: effect,
					admissionId: effect.admissionId,
					executionId: effect.executionId,
					operationId: effect.operationId,
					effectRunId: effect.effectRunId,
					workItemId: effect.workItemId,
					workItemRole: effect.workItemRole,
					replicate: effect.replicate,
					arm: effect.arm,
					providerLogicalAttempt: effect.providerLogicalAttempt,
					dispatchOrdinal: effect.dispatchOrdinal,
					capacityRetryOrdinal: effect.capacityRetryOrdinal,
					availabilityRetryOrdinal: effect.availabilityRetryOrdinal,
					status: "failed" as const,
					reason: "executor-failed" as const,
					recoveryClass: null,
					dispatchAttempted: false,
					dispatchElapsedMs: 0,
					providerResponseKind: "none" as const,
					httpStatus: null,
					providerErrorCode: null,
					transportNoToolSideEffect: false,
					costMicrousd: 0,
					costEvidence: "provider-reported" as const,
					pricingRoundingAllowanceMicrousd: 0,
					elapsedMs: 0,
					resultDigest: digest,
					retryAfterMs: 0,
					cleanupCompleted: true,
					toolProposal: null,
				} satisfies EvalProviderOutcome);
			});
			expect(
				Object.entries(graphResult.finding.providerOutcomeReasonCounts).filter(
					([, count]) => count > 0,
				),
			).toEqual([
				["tool-proposed", 6],
				["executor-failed", 29],
			]);
			const requests = executor.providerRequestSummaries();
			expect(requests).toHaveLength(1);
			const request = requests[0]!;
			expect(request).toMatchObject({
				model: "deepseek/deepseek-v4-flash-0731",
				response_format: {
					type: "json_schema",
					json_schema: {
						name: "occurrence_bound_candidate_selection",
						strict: true,
						schema: {
							additionalProperties: false,
							required: ["candidateRef"],
						},
					},
				},
				provider: {
					order: ["together"],
					only: ["together"],
					allow_fallbacks: false,
					require_parameters: true,
					data_collection: "deny",
					zdr: true,
				},
			});
			for (const forbidden of ["parallel_tool_calls", "tools", "tool_choice", "plugins"])
				expect(Object.hasOwn(request, forbidden)).toBe(false);
			expect(JSON.stringify(request)).not.toContain(ROOT_EVAL_LIVE_BUGGY_REPLACEMENT);
			expect(JSON.stringify(request)).not.toContain("Managed cloud PostgreSQL must admit");
			expect(graphResult.observations.length).toBeGreaterThan(0);
			expect(
				graphResult.observations.every((event) => event.msg[0] === "DATA" && event.tier === 3),
			).toBe(true);
			expect(graphResult.finding.providerOutcomeReasonCounts).toMatchObject({
				"tool-proposed": 6,
				"executor-failed": 29,
			});
			expect(verified?.status).toBe("completed");
			expect(verified?.evidence.diff).toBe("scoped-change");
			expect(verified?.evidence.expectedDigest).not.toBe(verified?.evidence.actualDigest);
			expect(verified?.evidence.publicSemantic).toBe("equivalent");
			expect(verified?.evidence.hiddenVerifier).toBe("pass");
			expect(executor.providerRequestSummaries()).toHaveLength(1);
			const diagnosticRoot = join(privateRoot, ".d152-development-diagnostics");
			const diagnosticNames = await readdir(diagnosticRoot);
			expect(diagnosticNames).toHaveLength(3);
			for (const name of diagnosticNames)
				expect((await stat(join(diagnosticRoot, name))).mode & 0o777).toBe(0o600);
			const diagnostics = await Promise.all(
				diagnosticNames.map((name) => readFile(join(diagnosticRoot, name), "utf8")),
			);
			expect(diagnostics.join("\n")).toContain("responseBase64");
			expect(diagnostics.join("\n")).toContain("public-verifier");
			expect(diagnostics.join("\n")).toContain("hidden-verifier");
			expect(JSON.stringify(graphResult.observations)).not.toContain("responseBase64");
		} finally {
			await sourceExecutor.dispose();
			await executor.dispose();
			await rm(temporary, { recursive: true, force: true });
		}
	}, 420_000);

	it.each([
		{ slot: "development-1", workItemRole: "target" },
		{ slot: "development-3", workItemRole: "source" },
		{ slot: "development-3", workItemRole: "target" },
		{ slot: "development-4", workItemRole: "source" },
		{ slot: "development-4", workItemRole: "target" },
		{ slot: "development-5", workItemRole: "source" },
		{ slot: "development-5", workItemRole: "target" },
		{ slot: "development-6", workItemRole: "source" },
		{ slot: "development-6", workItemRole: "target" },
		{ slot: "development-7", workItemRole: "source" },
		{ slot: "development-7", workItemRole: "target" },
	] as const)("qualifies five orthogonal mechanisms with ambiguous public and discriminating private verifiers: $slot/$workItemRole", async ({
		slot,
		workItemRole,
	}) => {
		const temporary = await mkdtemp(join(tmpdir(), "graphrefly-root-eval-transfer-family-"));
		const tasks =
			slot === "development-1"
				? ROOT_EVAL_DEVELOPMENT_TASKS
				: createRootEvalTaskManifest({
						slot,
						variantOrder: [0, 1, 2, 3, 4],
						coordinateSuffix: `${slot}-offline-qualification`,
					}).tasks;
		try {
			for (const task of tasks) {
				expect(task.sourceTaskStatement).toContain(task.mechanismId);
				expect(task.sourceTaskStatement).toContain("verified expression");
				expect(task.taskStatement).not.toMatch(
					/compare|reject|return selected|acceptedCoordinate/u,
				);
				expect(task.fixtureCorrectText).not.toBe(task.fixtureBuggyText);
				expect(task.fixtureAlternativeText).not.toBe(task.fixtureBuggyText);
				expect(task.fixtureAlternativeText).not.toBe(task.fixtureCorrectText);
				if (task.replicate === 1) {
					expect(task.fixtureCorrectText).toContain("\r\n\treturn ");
					expect(task.fixtureCorrectText).not.toMatch(/(?<!\r)\n/u);
					expect(task.fixtureAlternativeText).toContain("\r\n\treturn ");
				}
			}
			expect(new Set(tasks.map((task) => task.mechanismId)).size).toBe(5);
			expect(
				await qualifyRootEvalMechanismTaskFamily({
					repositoryRoot,
					materializationRoot: join(temporary, "workspaces"),
					tasks,
					workItemRole,
				}),
			).toEqual(
				tasks.map((task) => ({
					replicate: task.replicate,
					publicAllowsAmbiguousBug: true,
					hiddenRejectsAmbiguousBug: true,
					exactScopedChange: true,
					correctPassesPublicAndHidden: true,
				})),
			);
			expect(await readdir(join(temporary, "workspaces"))).toEqual([]);
		} finally {
			await rm(temporary, { recursive: true, force: true });
		}
	}, 420_000);

	it("audits frozen pre-D156 manifests without reopening them as executable task material", async () => {
		const temporary = await mkdtemp(join(tmpdir(), "graphrefly-root-eval-frozen-manifest-"));
		const previous = process.env.GRAPHREFLY_ROOT_EVAL_TASK_MANIFEST_DIRECTORY;
		process.env.GRAPHREFLY_ROOT_EVAL_TASK_MANIFEST_DIRECTORY = temporary;
		try {
			const current = createRootEvalTaskManifest({
				slot: "development-1",
				variantOrder: [0, 1, 2, 3, 4],
				coordinateSuffix: "frozen-history-seed",
			});
			const historicalTasks = current.tasks.map((task) => {
				const {
					fixtureAlternativeText: _fixtureAlternativeText,
					sourceFixtureAlternativeText: _sourceFixtureAlternativeText,
					...historicalTask
				} = task;
				return historicalTask;
			});
			const historicalMaterial = {
				schemaVersion: "graphrefly-ts.root-eval-d152-mechanism-manifest.v7",
				slot: current.slot,
				taskSetRef: current.taskSetRef,
				tasks: historicalTasks,
			};
			const historical = {
				...historicalMaterial,
				manifestDigest: empiricalStrictJsonDigest(historicalMaterial),
			};
			await writeFile(join(temporary, "development-1.json"), strictJsonCodec.encode(historical), {
				mode: 0o600,
			});
			expect(() => readRootEvalTaskManifest("development-1")).toThrow(/audit-only/u);
			await expect(
				readRootEvalFrozenDevelopmentManifestAudit("development-1"),
			).resolves.toMatchObject({
				schemaVersion: historical.schemaVersion,
				slot: historical.slot,
				taskSetRef: historical.taskSetRef,
				manifestDigest: historical.manifestDigest,
			});
		} finally {
			if (previous === undefined) delete process.env.GRAPHREFLY_ROOT_EVAL_TASK_MANIFEST_DIRECTORY;
			else process.env.GRAPHREFLY_ROOT_EVAL_TASK_MANIFEST_DIRECTORY = previous;
			await rm(temporary, { recursive: true, force: true });
		}
	});

	it("atomically seals the D157 two-bank horizon and fails closed outside it", async () => {
		const temporary = await mkdtemp(join(tmpdir(), "graphrefly-root-eval-task-manifests-"));
		const previous = process.env.GRAPHREFLY_ROOT_EVAL_TASK_MANIFEST_DIRECTORY;
		process.env.GRAPHREFLY_ROOT_EVAL_TASK_MANIFEST_DIRECTORY = temporary;
		const development1 = createRootEvalTaskManifest({
			slot: "development-1",
			variantOrder: [0, 1, 2, 3, 4],
			coordinateSuffix: "development-one-seed",
		});
		const development2 = createRootEvalTaskManifest({
			slot: "development-2",
			variantOrder: [0, 1, 2, 3, 4],
			coordinateSuffix: "development-two-seed",
		});
		const development3 = createRootEvalTaskManifest({
			slot: "development-3",
			variantOrder: [0, 1, 2, 3, 4],
			coordinateSuffix: "development-three-seed",
		});
		try {
			for (const slot of ["development-1", "development-2", "development-3"] as const)
				await writeFile(
					join(temporary, `${slot}.json`),
					await readFile(
						resolve(
							repositoryRoot,
							`packages/ts/evals/.private/empirical-memory-rerun-avoidance/d152-mechanism-manifests/${slot}.json`,
						),
					),
					{ mode: 0o600 },
				);
			const frozenManifests = await Promise.all(
				(["development-1", "development-2", "development-3"] as const).map(
					readRootEvalFrozenDevelopmentManifestAudit,
				),
			);
			await expect(ensureRootEvalDevelopmentTaskManifest("development-2")).rejects.toThrow(
				/audit-only/u,
			);
			expect((await stat(join(temporary, "development-2.json"))).mode & 0o777).toBe(0o600);
			const generated3Bytes = await readFile(join(temporary, "development-3.json"));
			await expect(ensureRootEvalDevelopmentTaskManifest("development-3")).rejects.toThrow(
				/audit-only/u,
			);
			expect(await readFile(join(temporary, "development-3.json"))).toEqual(generated3Bytes);
			expect((await stat(join(temporary, "development-3.json"))).mode & 0o777).toBe(0o600);
			expect(() => rootEvalTask("development-transfer", 5, "development-3")).toThrow(/audit-only/u);
			for (const previousManifest of [development1, development2]) {
				expect(rootEvalTaskManifestDisjointAudit(previousManifest, development3).disjoint).toBe(
					true,
				);
			}
			expect(rootEvalMechanismDiscriminationOracle(development3.tasks)).toHaveLength(5);
			expect(development3.taskSetRef).toBe(ROOT_EVAL_DEVELOPMENT_TASK_SET_REFS["development-3"]);
			const preparationState = {
				developmentEntryCount: 3,
				developmentQualificationStreak: 0,
				ledgerPath: join(temporary, "qualification-ledger.json"),
				outcomeStatePaths: [join(temporary, "qualification-outcome")],
				priorManifestBindings: frozenManifests.map((manifest) => ({
					taskSetRef: manifest.taskSetRef,
					manifestDigest: manifest.manifestDigest,
				})),
			};
			const horizon = await prepareRootEvalD157HorizonForNoNetworkQualification({
				state: preparationState,
			});
			process.env.GRAPHREFLY_ROOT_EVAL_TASK_MANIFEST_DIRECTORY = resolve(
				repositoryRoot,
				"packages/ts/evals/.private/empirical-memory-rerun-avoidance/d152-mechanism-manifests",
			);
			await expect(
				prepareRootEvalD157HorizonForNoNetworkQualification({ state: preparationState }),
			).rejects.toThrow(/isolated temp root/u);
			process.env.GRAPHREFLY_ROOT_EVAL_TASK_MANIFEST_DIRECTORY = temporary;
			const horizonBytes = await readFile(
				join(temporary, ROOT_EVAL_D157_HORIZON_DIRECTORY_NAME, ROOT_EVAL_D157_HORIZON_RECEIPT_NAME),
			);
			expect(await readRootEvalD157HorizonReceipt()).toEqual(horizon);
			expect(horizon.slots).toEqual(ROOT_EVAL_D157_HORIZON_SLOTS);
			expect(horizon.manifests).toHaveLength(2);
			expect(
				(await stat(join(temporary, ROOT_EVAL_D157_HORIZON_DIRECTORY_NAME))).mode & 0o777,
			).toBe(0o700);
			const development4 = await ensureRootEvalDevelopmentTaskManifest("development-4");
			const development5 = await ensureRootEvalDevelopmentTaskManifest("development-5");
			for (const manifest of [development4, development5]) {
				const path = join(
					temporary,
					ROOT_EVAL_D157_HORIZON_DIRECTORY_NAME,
					`${manifest.slot}.json`,
				);
				expect((await stat(path)).mode & 0o777).toBe(0o600);
				expect(rootEvalMechanismDiscriminationOracle(manifest.tasks)).toHaveLength(5);
			}
			const all = [development1, development2, development3, development4, development5];
			expect(ROOT_EVAL_SUPPORTED_DEVELOPMENT_SLOTS).toEqual([
				"development-1",
				"development-2",
				"development-3",
				"development-4",
				"development-5",
				"development-6",
				"development-7",
			]);
			const registryTasks = [
				...frozenManifests.flatMap((manifest) => manifest.tasks),
				...development4.tasks,
				...development5.tasks,
			];
			expect(rootEvalDevelopmentRegistryPairwiseAudit(registryTasks)).toHaveLength(195);
			const semanticCloneSource = registryTasks[0]!;
			const semanticCloneTarget = registryTasks.at(-1)!;
			const renamedRewordedClone = {
				...semanticCloneSource,
				replicate: semanticCloneTarget.replicate,
				taskSetRef: semanticCloneTarget.taskSetRef,
				mechanismId: "renamed-reworded-semantic-clone",
				sourceInsightContent: "mechanism-invariant.v2;rule=renamed-reworded-clone".padEnd(96, " "),
				fixtureCorrectText: semanticCloneSource.fixtureCorrectText.replace(
					"export function ",
					"export function renamed",
				),
				readonlyFixtureFiles: Object.freeze([
					Object.freeze({
						...semanticCloneSource.readonlyFixtureFiles[0]!,
						text: `${semanticCloneSource.readonlyFixtureFiles[0]!.text}\n// reworded`,
					}),
				]),
				hiddenVerifierSource: `${semanticCloneSource.hiddenVerifierSource}\n// reworded`,
			};
			expect(() =>
				rootEvalDevelopmentRegistryPairwiseAudit([
					...registryTasks.slice(0, -1),
					renamedRewordedClone,
				]),
			).toThrow(/pairwise isolation audit/u);
			const copiedActorContract = {
				...semanticCloneTarget,
				sourceReadonlyFixtureFiles: semanticCloneSource.sourceReadonlyFixtureFiles,
				readonlyFixtureFiles: semanticCloneSource.readonlyFixtureFiles,
			};
			expect(() =>
				rootEvalDevelopmentRegistryPairwiseAudit([
					...registryTasks.slice(0, -1),
					copiedActorContract,
				]),
			).toThrow(/pairwise isolation audit/u);
			for (let left = 0; left < all.length; left += 1) {
				for (let right = left + 1; right < all.length; right += 1)
					expect(rootEvalTaskManifestDisjointAudit(all[left]!, all[right]!).disjoint).toBe(true);
			}
			expect(
				new Set(all.flatMap((manifest) => manifest.tasks.map((task) => task.mechanismId))).size,
			).toBe(25);
			expect(
				await prepareRootEvalD157HorizonForNoNetworkQualification({
					state: {
						developmentEntryCount: 3,
						developmentQualificationStreak: 0,
						ledgerPath: join(temporary, "qualification-ledger.json"),
						outcomeStatePaths: [join(temporary, "qualification-outcome")],
						priorManifestBindings: frozenManifests.map((manifest) => ({
							taskSetRef: manifest.taskSetRef,
							manifestDigest: manifest.manifestDigest,
						})),
					},
				}),
			).toEqual(horizon);
			expect(
				await readFile(
					join(
						temporary,
						ROOT_EVAL_D157_HORIZON_DIRECTORY_NAME,
						ROOT_EVAL_D157_HORIZON_RECEIPT_NAME,
					),
				),
			).toEqual(horizonBytes);
			const development5Path = join(
				temporary,
				ROOT_EVAL_D157_HORIZON_DIRECTORY_NAME,
				"development-5.json",
			);
			const development5Bytes = await readFile(development5Path);
			const driftedTasks = development5.tasks.map((task, index) =>
				index === 0 ? { ...task, baselineCommit: "self-consistent-registry-forgery" } : task,
			);
			const driftedMaterial = {
				schemaVersion: development5.schemaVersion,
				slot: development5.slot,
				taskSetRef: development5.taskSetRef,
				tasks: driftedTasks,
			};
			await writeFile(
				development5Path,
				strictJsonCodec.encode({
					...driftedMaterial,
					manifestDigest: empiricalStrictJsonDigest(driftedMaterial),
				}),
			);
			expect(() => readRootEvalTaskManifest("development-5")).toThrow(/finite registry/u);
			await writeFile(development5Path, development5Bytes);
			const linkedManifest = join(temporary, "linked-development-5.json");
			await writeFile(linkedManifest, development5Bytes, { mode: 0o600 });
			await rm(development5Path);
			await link(linkedManifest, development5Path);
			expect(() => readRootEvalTaskManifest("development-5")).toThrow(/mode-0600/u);
			await rm(development5Path);
			await writeFile(development5Path, development5Bytes, { mode: 0o600 });
			await rm(development5Path);
			await symlink(linkedManifest, development5Path);
			expect(() => readRootEvalTaskManifest("development-5")).toThrow();
			await rm(development5Path);
			await writeFile(development5Path, development5Bytes, { mode: 0o600 });

			const replacement5 = createRootEvalTaskManifest({
				slot: "development-5",
				variantOrder: [0, 1, 2, 3, 4],
				coordinateSuffix: "replacement-five-must-not-rebind",
			});
			await writeFile(development5Path, strictJsonCodec.encode(replacement5));
			const replacementReceiptMaterial = {
				schemaVersion: horizon.schemaVersion,
				decisionRef: horizon.decisionRef,
				slots: horizon.slots,
				manifests: [
					horizon.manifests[0]!,
					{
						slot: replacement5.slot,
						taskSetRef: replacement5.taskSetRef,
						manifestDigest: replacement5.manifestDigest,
					},
				],
			};
			await writeFile(
				join(temporary, ROOT_EVAL_D157_HORIZON_DIRECTORY_NAME, ROOT_EVAL_D157_HORIZON_RECEIPT_NAME),
				strictJsonCodec.encode({
					...replacementReceiptMaterial,
					receiptDigest: empiricalStrictJsonDigest(replacementReceiptMaterial),
				}),
			);
			await expect(readRootEvalD157HorizonReceipt()).rejects.toThrow(
				/development-4 ledger binding lost development-5/u,
			);
			await writeFile(development5Path, development5Bytes);
			await writeFile(
				join(temporary, ROOT_EVAL_D157_HORIZON_DIRECTORY_NAME, ROOT_EVAL_D157_HORIZON_RECEIPT_NAME),
				horizonBytes,
			);
			const receiptPath = join(
				temporary,
				ROOT_EVAL_D157_HORIZON_DIRECTORY_NAME,
				ROOT_EVAL_D157_HORIZON_RECEIPT_NAME,
			);
			await writeFile(
				receiptPath,
				strictJsonCodec.encode({
					...horizon,
					receiptDigest: empiricalStrictJsonDigest("tampered"),
				}),
			);
			await expect(readRootEvalD157HorizonReceipt()).rejects.toThrow(/lost manifest binding/u);
			await writeFile(receiptPath, horizonBytes);
			const historicalOnePath = join(temporary, "development-1.json");
			const historicalOneBytes = await readFile(historicalOnePath);
			const historicalOne = strictJsonCodec.decode(historicalOneBytes) as {
				readonly schemaVersion: string;
				readonly slot: string;
				readonly taskSetRef: string;
				readonly tasks: readonly Readonly<Record<string, unknown>>[];
			};
			const historicalSemanticCloneTasks = historicalOne.tasks.map((task, index) =>
				index === 0
					? {
							...task,
							mechanismId: "historical-reworded-semantic-clone",
							sourceInsightContent:
								"mechanism-invariant.v2;rule=historical-reworded-semantic-clone".padEnd(96, " "),
							fixtureCorrectText: development4.tasks[0]!.fixtureCorrectText.replace(
								/export function [A-Za-z0-9_]+/u,
								"export function historicalSemanticClone",
							),
							sourceFixtureCorrectText: development4.tasks[0]!.sourceFixtureCorrectText.replace(
								/export function [A-Za-z0-9_]+/u,
								"export function historicalSemanticCloneAtSource",
							),
						}
					: task,
			);
			const historicalSemanticCloneMaterial = {
				schemaVersion: historicalOne.schemaVersion,
				slot: historicalOne.slot,
				taskSetRef: historicalOne.taskSetRef,
				tasks: historicalSemanticCloneTasks,
			};
			await writeFile(
				historicalOnePath,
				strictJsonCodec.encode({
					...historicalSemanticCloneMaterial,
					manifestDigest: empiricalStrictJsonDigest(historicalSemanticCloneMaterial),
				}),
			);
			await expect(readRootEvalD157HorizonReceipt()).rejects.toThrow(/pairwise isolation audit/u);
			await writeFile(historicalOnePath, historicalOneBytes);
			await expect(ensureRootEvalDevelopmentTaskManifest("development-6")).rejects.toThrow(
				/horizon|ENOENT/u,
			);
			expect(await readdir(temporary)).not.toContain("development-6.json");
			await expect(ensureRootEvalDevelopmentTaskManifest("confirmatory")).rejects.toThrow();
			expect(rootEvalTaskManifestDisjointAudit(development1, development2)).toEqual({
				leftSlot: "development-1",
				rightSlot: "development-2",
				sharedMechanismIds: [],
				sharedFixtureDigests: [],
				sharedVerifierDigests: [],
				disjoint: true,
			});
			expect(development1.manifestDigest).not.toBe(development2.manifestDigest);
			expect(
				new Set([
					...development1.tasks.map((task) => task.mechanismId),
					...development2.tasks.map((task) => task.mechanismId),
				]).size,
			).toBe(10);
			expect(
				development1.tasks.some((left) =>
					development2.tasks.some(
						(right) =>
							left.fixtureCorrectText === right.fixtureCorrectText ||
							left.hiddenVerifierSource === right.hiddenVerifierSource,
					),
				),
			).toBe(false);
			expect(development1.taskSetRef).toBe(ROOT_EVAL_DEVELOPMENT_TASK_SET_REFS["development-1"]);
			expect(development2.taskSetRef).toBe(ROOT_EVAL_DEVELOPMENT_TASK_SET_REFS["development-2"]);
			expect(() =>
				createRootEvalTaskManifest({
					slot: "confirmatory",
					variantOrder: [0, 1, 2, 3, 4],
					coordinateSuffix: "confirmatory-unmaterialized",
				}),
			).toThrow(/unmaterialized/u);
			expect(() =>
				rootEvalTaskManifestDisjointAudit(development1, {
					...development2,
					tasks: development2.tasks.map((task, index) =>
						index === 0 ? { ...task, mechanismId: development1.tasks[0]!.mechanismId } : task,
					),
				}),
			).toThrow();
			expect(() => readRootEvalTaskManifest("development-1")).toThrow(/audit-only/u);
			expect(() => rootEvalTask("development-transfer", 5, "development-1")).toThrow(/audit-only/u);
			expect(() => rootEvalTask("confirmatory-transfer", 1, "confirmatory")).toThrow();
			await chmod(development5Path, 0o644);
			expect(() => readRootEvalTaskManifest("development-5")).toThrow(/mode-0600/u);
			await chmod(development5Path, 0o600);
			const oldSchemaManifest = {
				...development5,
				schemaVersion: "graphrefly-ts.root-eval-d145-task-manifest.v4",
				manifestDigest: empiricalStrictJsonDigest({
					schemaVersion: "graphrefly-ts.root-eval-d145-task-manifest.v4",
					slot: development5.slot,
					taskSetRef: development5.taskSetRef,
					tasks: development5.tasks,
				}),
			};
			await writeFile(development5Path, JSON.stringify(oldSchemaManifest));
			expect(() => readRootEvalTaskManifest("development-5")).toThrow(/failed closed/u);
			const tasksWithoutSourceInsightDigest = development5.tasks.map((task, index) => {
				if (index !== 0) return task;
				const { sourceInsightDigest: _sourceInsightDigest, ...legacyTask } = task;
				return legacyTask;
			});
			const legacyShapedManifest = {
				...development5,
				tasks: tasksWithoutSourceInsightDigest,
				manifestDigest: empiricalStrictJsonDigest({
					schemaVersion: development5.schemaVersion,
					slot: development5.slot,
					taskSetRef: development5.taskSetRef,
					tasks: tasksWithoutSourceInsightDigest,
				}),
			};
			await writeFile(development5Path, JSON.stringify(legacyShapedManifest));
			expect(() => readRootEvalTaskManifest("development-5")).toThrow(/failed closed/u);
			await writeFile(
				development5Path,
				JSON.stringify({ ...development5, taskSetRef: "tampered-task-set" }),
			);
			expect(() => readRootEvalTaskManifest("development-5")).toThrow(/failed closed/u);
			await writeFile(development5Path, development5Bytes);
			await writeFile(join(temporary, "confirmatory.json"), JSON.stringify(development1), {
				mode: 0o600,
			});
			expect(() => readRootEvalTaskManifest("confirmatory")).toThrow(/failed closed/u);
			await rm(join(temporary, ROOT_EVAL_D157_HORIZON_DIRECTORY_NAME), {
				recursive: true,
				force: true,
			});
			expect(() =>
				assertRootEvalD157PrecommitEligibility({
					developmentEntryCount: 4,
					developmentQualificationStreak: 0,
					outcomeStatePresent: false,
					priorManifestBindingsMatch: true,
				}),
			).toThrow(/precommit authority invalid/u);
			expect(() =>
				assertRootEvalD157PrecommitEligibility({
					developmentEntryCount: 3,
					developmentQualificationStreak: 0,
					outcomeStatePresent: true,
					priorManifestBindingsMatch: true,
				}),
			).toThrow(/precommit authority invalid/u);
			await expect(ensureRootEvalDevelopmentTaskManifest("development-4")).rejects.toThrow();
			expect(await readdir(temporary)).not.toContain(ROOT_EVAL_D157_HORIZON_DIRECTORY_NAME);
		} finally {
			if (previous === undefined) delete process.env.GRAPHREFLY_ROOT_EVAL_TASK_MANIFEST_DIRECTORY;
			else process.env.GRAPHREFLY_ROOT_EVAL_TASK_MANIFEST_DIRECTORY = previous;
			await rm(temporary, { recursive: true, force: true });
		}
	});

	it("atomically precommits the D159 development-6/7 horizon and all-pairs isolation", async () => {
		const temporary = await mkdtemp(join(tmpdir(), "graphrefly-root-eval-d159-horizon-"));
		const previous = process.env.GRAPHREFLY_ROOT_EVAL_TASK_MANIFEST_DIRECTORY;
		process.env.GRAPHREFLY_ROOT_EVAL_TASK_MANIFEST_DIRECTORY = temporary;
		try {
			const production = resolve(
				repositoryRoot,
				"packages/ts/evals/.private/empirical-memory-rerun-avoidance/d152-mechanism-manifests",
			);
			for (const slot of ["development-1", "development-2", "development-3"] as const)
				await cp(join(production, `${slot}.json`), join(temporary, `${slot}.json`));
			await cp(
				join(production, ROOT_EVAL_D157_HORIZON_DIRECTORY_NAME),
				join(temporary, ROOT_EVAL_D157_HORIZON_DIRECTORY_NAME),
				{ recursive: true },
			);
			const prior = await Promise.all(
				ROOT_EVAL_SUPPORTED_DEVELOPMENT_SLOTS.slice(0, 5).map(
					readRootEvalFrozenDevelopmentManifestAudit,
				),
			);
			const state = {
				developmentEntryCount: 5,
				developmentQualificationStreak: 0,
				ledgerPath: join(temporary, "d159-ledger.json"),
				outcomeStatePaths: [join(temporary, "d159-outcome")],
				priorManifestBindings: prior.map((manifest) => ({
					taskSetRef: manifest.taskSetRef,
					manifestDigest: manifest.manifestDigest,
				})),
			};
			const receipt = await prepareRootEvalD159HorizonForNoNetworkQualification({ state });
			expect(receipt.slots).toEqual(ROOT_EVAL_D159_HORIZON_SLOTS);
			expect(await readRootEvalD159HorizonReceipt()).toEqual(receipt);
			await expect(prepareRootEvalD159HorizonForNoNetworkQualification({ state })).rejects.toThrow(
				/preparation replay rejected/u,
			);
			const unexpectedPath = join(
				temporary,
				ROOT_EVAL_D159_HORIZON_DIRECTORY_NAME,
				"unexpected.json",
			);
			await writeFile(unexpectedPath, strictJsonCodec.encode({ unexpected: true }), {
				mode: 0o600,
			});
			await expect(readRootEvalD159HorizonReceipt()).rejects.toThrow(/directory membership/u);
			await rm(unexpectedPath);
			expect(await readRootEvalD159HorizonReceipt()).toEqual(receipt);
			const development6 = await ensureRootEvalDevelopmentTaskManifest("development-6");
			const development7 = await ensureRootEvalDevelopmentTaskManifest("development-7");
			const allTasks = [...prior, development6, development7].flatMap((manifest) => manifest.tasks);
			expect(allTasks).toHaveLength(35);
			expect(rootEvalD159DevelopmentRegistryPairwiseAudit(allTasks)).toHaveLength(295);
			expect(new Set(allTasks.map((task) => task.mechanismId)).size).toBe(35);
			expect(
				(await stat(join(temporary, ROOT_EVAL_D159_HORIZON_DIRECTORY_NAME))).mode & 0o777,
			).toBe(0o700);
			for (const slot of ROOT_EVAL_D159_HORIZON_SLOTS)
				expect(
					(await stat(join(temporary, ROOT_EVAL_D159_HORIZON_DIRECTORY_NAME, `${slot}.json`)))
						.mode & 0o777,
				).toBe(0o600);
			await expect(ensureRootEvalDevelopmentTaskManifest("development-8")).rejects.toThrow(
				/finite horizon/u,
			);
			const receiptPath = join(
				temporary,
				ROOT_EVAL_D159_HORIZON_DIRECTORY_NAME,
				ROOT_EVAL_D159_HORIZON_RECEIPT_NAME,
			);
			const receiptBytes = await readFile(receiptPath);
			await writeFile(
				receiptPath,
				strictJsonCodec.encode({
					...receipt,
					receiptDigest: empiricalStrictJsonDigest("tampered"),
				}),
			);
			await expect(readRootEvalD159HorizonReceipt()).rejects.toThrow(/manifest binding/u);
			await writeFile(receiptPath, receiptBytes);
		} finally {
			if (previous === undefined) delete process.env.GRAPHREFLY_ROOT_EVAL_TASK_MANIFEST_DIRECTORY;
			else process.env.GRAPHREFLY_ROOT_EVAL_TASK_MANIFEST_DIRECTORY = previous;
			await rm(temporary, { recursive: true, force: true });
		}
	});

	it("persists one exact D159 execution grant and rejects replay or closure drift", async () => {
		const previousSlot = process.env.GRAPHREFLY_ROOT_EVAL_CAMPAIGN_SLOT;
		process.env.GRAPHREFLY_ROOT_EVAL_CAMPAIGN_SLOT = "development-6";
		const temporary = await realpath(
			await mkdtemp(join(tmpdir(), "graphrefly-root-eval-d159-grant-")),
		);
		try {
			const moduleUrl = `${
				pathToFileURL(
					resolve(
						repositoryRoot,
						"packages/ts/evals/graph-native-rerun-avoidance/root-eval-live-authority.ts",
					),
				).href
			}?d159-grant=${Date.now()}`;
			const authority = await import(moduleUrl);
			const grant = authority.createRootEvalLiveExecutionGrant({
				executionRef: "root-eval-development-6-together-2026-09-05-1",
				providerQualificationExecutionRef: "provider-qualification-together-2026-09-05-2",
				providerQualificationGrantDigest: empiricalStrictJsonDigest("qualification-grant"),
			});
			expect(() =>
				authority.createRootEvalLiveExecutionGrant({
					executionRef: "root-eval-development-7-together-2026-09-05-1",
					providerQualificationExecutionRef: "provider-qualification-together-2026-09-05-2",
					providerQualificationGrantDigest: empiricalStrictJsonDigest("qualification-grant"),
				}),
			).toThrow(/current closure/u);
			expect(grant).toMatchObject({
				schemaVersion: ROOT_EVAL_LIVE_EXECUTION_GRANT_SCHEMA,
				decisionRef: "graphrefly-ts:D159",
				slot: "development-6",
				budgetPartition: "development-usd-45",
				partitionHardCapMicrousd: 45_000_000,
				totalHardCapMicrousd: 51_000_000,
				campaignHardCapMicrousd: 4_138_575,
			});
			const path = join(temporary, `${authority.ROOT_EVAL_LIVE_GENERATION_REF}.json`);
			await authority.persistRootEvalLiveExecutionGrant(path, grant);
			expect((await stat(path)).mode & 0o777).toBe(0o600);
			expect(await authority.readRootEvalLiveExecutionGrant(path)).toEqual(grant);
			await expect(authority.persistRootEvalLiveExecutionGrant(path, grant)).rejects.toMatchObject({
				code: "EEXIST",
			});
			const claimRoot = join(temporary, "claim");
			await mkdir(claimRoot, { mode: 0o700 });
			const nowMs = Date.now();
			const credential = authority.parseRootEvalLiveCredential(
				new TextEncoder().encode("OPENROUTER_API_KEY=sk-or-v1-a44-middle-credential-e06\n"),
			);
			const precredentialMaterial = {
				schemaVersion: authority.ROOT_EVAL_LIVE_PRECREDENTIAL_GATE_RECEIPT_SCHEMA,
				decisionRef: ROOT_EVAL_LIVE_DECISION_REF,
				generationRef: authority.ROOT_EVAL_LIVE_GENERATION_REF,
				implementationManifestDigest: authority.ROOT_EVAL_CURRENT_IMPLEMENTATION_MANIFEST_DIGEST,
				qualificationArtifactDigest: authority.ROOT_EVAL_CURRENT_QUALIFICATION_ARTIFACT_DIGEST,
				qualificationDigest: authority.ROOT_EVAL_CURRENT_QUALIFICATION_DIGEST,
				implementationCommit: "a".repeat(40),
				repositoryStateDigest: empiricalStrictJsonDigest("d159-claim-repository"),
				artifactSetDigest: empiricalStrictJsonDigest("d159-claim-artifacts"),
				completedAtMs: nowMs,
			};
			const precredentialGateReceipt = authority.admitRootEvalLivePrecredentialGateReceipt({
				bytes: strictJsonCodec.encode({
					...precredentialMaterial,
					receiptDigest: empiricalStrictJsonDigest(precredentialMaterial),
				}),
				nowMs,
			});
			const pricingAdmission = await authority.readRootEvalLivePricing({
				nowMs,
				fetchImpl: (async (url: string | URL | Request) => {
					const target = String(url);
					const body =
						target === authority.ROOT_EVAL_LIVE_PRICING_SOURCE
							? {
									data: {
										id: "deepseek/deepseek-v4-flash-0731",
										endpoints: [
											{
												provider_name: "Together",
												tag: "together",
												quantization: "unknown",
												model_id: "deepseek/deepseek-v4-flash-0731",
												name: "Together | deepseek/deepseek-v4-flash-20260731",
												supported_parameters: [
													"max_tokens",
													"reasoning",
													"response_format",
													"structured_outputs",
												],
												pricing: {
													prompt: "0.00000014",
													completion: "0.00000028",
													input_cache_read: "0.00000003",
												},
											},
										],
									},
								}
							: {
									data: [
										{
											provider_name: "Together",
											tag: "together",
											model_id: "deepseek/deepseek-v4-flash-0731",
											name: "Together | deepseek/deepseek-v4-flash-20260731",
										},
									],
								};
					const response = new Response(JSON.stringify(body), { status: 200 });
					Object.defineProperty(response, "url", { value: target });
					return response;
				}) as typeof fetch,
			});
			const zeroByok = authority.admitRootEvalLiveZeroByok({
				credential,
				nowMs,
				precredentialGateReceipt,
				bytes: operatorConfigurationBytes(nowMs),
			});
			const currentKeyBefore = await authority.readRootEvalLiveCurrentKey({
				credential,
				fetchImpl: (async () =>
					new Response(
						JSON.stringify({
							data: {
								limit: 32,
								limit_remaining: 13,
								usage: 19,
								limit_reset: null,
								is_management_key: false,
							},
						}),
						{ status: 200 },
					)) as typeof fetch,
			});
			const claimInput = {
				privateRoot: claimRoot,
				executionGrant: grant,
				executionGrantPath: path,
				implementationCoordinate: `worktree:${"a".repeat(40)}:${authority.ROOT_EVAL_CURRENT_IMPLEMENTATION_MANIFEST_DIGEST}`,
				implementationManifestDigest: authority.ROOT_EVAL_CURRENT_IMPLEMENTATION_MANIFEST_DIGEST,
				qualificationArtifactDigest: authority.ROOT_EVAL_CURRENT_QUALIFICATION_ARTIFACT_DIGEST,
				qualificationDigest: authority.ROOT_EVAL_CURRENT_QUALIFICATION_DIGEST,
				taskBindingDigest: authority.ROOT_EVAL_CURRENT_TASK_BINDING_DIGEST,
				taskManifestDigest: readRootEvalTaskManifest("development-6").manifestDigest,
				pricing: pricingAdmission,
				zeroByok,
				credential,
				currentKeyBefore,
				partitionSpentBeforeMicrousd: 0,
				partitionLedgerDigest: empiricalStrictJsonDigest("d159-claim-ledger"),
				developmentQualificationStreakBefore: 0,
				nowMs,
			};
			const acquisition =
				await authority.acquireRootEvalLiveExecutionClaimForNoNetworkQualification(claimInput);
			expect(acquisition.postCommitFailureDigest).toBeNull();
			expect(acquisition.claim).toMatchObject({
				schemaVersion: authority.ROOT_EVAL_LIVE_EXECUTION_CLAIM_SCHEMA,
				executionMode: "live",
				executionRef: grant.executionRef,
				executionGrantDigest: grant.grantDigest,
			});
			const consumedEntries = (await readdir(temporary)).filter((name) =>
				name.includes(".consumed-"),
			);
			expect(await readdir(temporary)).not.toContain(basename(path));
			expect(consumedEntries).toHaveLength(1);
			expect((await stat(join(temporary, consumedEntries[0]!))).nlink).toBe(1);
			await expect(
				authority.acquireRootEvalLiveExecutionClaimForNoNetworkQualification(claimInput),
			).rejects.toThrow();
			const topology = createRootEvalTopology({
				profileInput: createCurrentExactModelHarnessProfileInput(),
				currentKeyBefore: ROOT_EVAL_NO_NETWORK_CURRENT_KEY_BEFORE,
				executionGrantDigest: acquisition.claim.executionGrantDigest,
			});
			const budgetDigests: string[] = [];
			const stopBudget = topology.nodes.budgets.subscribe((message) => {
				if (message[0] === "DATA")
					budgetDigests.push((message[1] as EvalBudgetState).executionGrantDigest);
			});
			expect(topology.campaignContract.executionGrantDigest).toBe(grant.grantDigest);
			expect(budgetDigests).toEqual([grant.grantDigest]);
			stopBudget();
			expect(() =>
				authority.parseRootEvalLiveExecutionGrant(
					strictJsonCodec.encode({ ...grant, campaignHardCapMicrousd: 4_138_574 }),
				),
			).toThrow(/current closure/u);
		} finally {
			if (previousSlot === undefined) delete process.env.GRAPHREFLY_ROOT_EVAL_CAMPAIGN_SLOT;
			else process.env.GRAPHREFLY_ROOT_EVAL_CAMPAIGN_SLOT = previousSlot;
			await rm(temporary, { recursive: true, force: true });
		}
	});

	const developmentThreeOrders = (() => {
		const permutations = (remaining: readonly number[]): number[][] =>
			remaining.length === 0
				? [[]]
				: remaining.flatMap((head) =>
						permutations(remaining.filter((value) => value !== head)).map((tail) => [
							head,
							...tail,
						]),
					);
		return permutations([0, 1, 2, 3, 4]);
	})();

	it("enumerates all 120 supported development-3 shuffles and retains bank support controls", () => {
		expect(developmentThreeOrders).toHaveLength(120);
		expect(new Set(developmentThreeOrders.map((order) => order.join(","))).size).toBe(120);
		for (const order of developmentThreeOrders)
			expect(rootEvalVariantOrderSupportsIrrelevantControls(order, "development-3")).toBe(true);
		expect(rootEvalVariantOrderSupportsIrrelevantControls([0, 1, 2, 3, 4], "development-4")).toBe(
			true,
		);
		expect(rootEvalVariantOrderSupportsIrrelevantControls([0, 1, 2, 3, 4], "development-5")).toBe(
			true,
		);
		expect(rootEvalVariantOrderSupportsIrrelevantControls([0, 1, 2, 3, 4], "development-6")).toBe(
			true,
		);
		expect(rootEvalVariantOrderSupportsIrrelevantControls([0, 1, 2, 3, 4], "confirmatory")).toBe(
			false,
		);
	});

	it.each(developmentThreeOrders.map((variantOrder) => ({ variantOrder, label: variantOrder.join(",") })))(
		"qualifies development-3 shuffle $label against its own bank and rejects rebinding or bank reuse",
		({ variantOrder }) => {
			const create = () =>
				createRootEvalTaskManifest({
					slot: "development-3",
					variantOrder,
					coordinateSuffix: "development-three-permutations",
				});
			if (!rootEvalVariantOrderSupportsIrrelevantControls(variantOrder, "development-3")) {
				expect(create).toThrow(/generation input invalid/u);
				return;
			}
			const manifest = create();
			expect(rootEvalMechanismDiscriminationOracle(manifest.tasks)).toHaveLength(5);
			const bindings = rootEvalTaskBindings(manifest.tasks);
			for (const [index, task] of manifest.tasks.entries()) {
				const rotated = manifest.tasks[ROOT_EVAL_IRRELEVANT_SOURCE_REPLICATES[index]! - 1]!;
				expect(bindings[index]!.sourceInsightDigest).toBe(task.sourceInsightDigest);
				expect(bindings[index]!.irrelevantSourceInsightDigest).toBe(rotated.sourceInsightDigest);
				expect(task.mechanismAction).not.toBe(rotated.mechanismAction);
				// Execute only this test's generated, trusted candidate expressions. Check
				// all three, not only the correct/rotated pair or their policy labels.
				const candidates = [
					...task.readonlyFixtureFiles[0]!.text.matchAll(/^\/\/ (first|second|third): (.+)$/gmu),
				];
				expect(candidates).toHaveLength(3);
				for (const verifierKind of ["publicVerifierSource", "hiddenVerifierSource"] as const) {
					const example = task[verifierKind].match(/expect\(\w+\((.+)\)\)\.toBe\((.+)\);/u);
					if (example === null) throw new Error("generated fixture example missing");
					const input = runInNewContext(`(${example[1]})`);
					const expected = runInNewContext(example[2]!);
					const passing = candidates
						.filter(
							(candidate) => runInNewContext(candidate[2]!, { input, TextEncoder }) === expected,
						)
						.map((candidate) => candidate[1]);
					const correctExpression = task.fixtureCorrectText.match(
						/\r?\n\treturn (.+);\r?\n\}/u,
					)?.[1];
					const correctSlot = candidates.find(
						(candidate) => candidate[2] === correctExpression,
					)?.[1];
					expect(passing).toEqual(
						verifierKind === "publicVerifierSource" ? ["first", "second", "third"] : [correctSlot],
					);
				}
			}
			const rebound = manifest.tasks.map((task, index) =>
				index === 0
					? { ...task, sourceInsightContent: manifest.tasks[1]!.sourceInsightContent }
					: task,
			);
			expect(() => assertRootEvalTaskStimulusContract(rebound)).toThrow();
			const previous = createRootEvalTaskManifest({
				slot: "development-2",
				variantOrder: [0, 1, 2, 3, 4],
				coordinateSuffix: "development-two-disjoint",
			});
			expect(() =>
				rootEvalTaskManifestDisjointAudit(previous, {
					...manifest,
					tasks: manifest.tasks.map((task, index) =>
						index === 0 ? { ...task, mechanismId: previous.tasks[0]!.mechanismId } : task,
					),
				}),
			).toThrow();
		},
	);

	it("binds discriminant-only relevant and incompatible irrelevant source Work Items", () => {
		assertRootEvalTaskStimulusContract(ROOT_EVAL_DEVELOPMENT_TASKS);
		const bindings = rootEvalTaskBindings(ROOT_EVAL_DEVELOPMENT_TASKS);
		const oracle = rootEvalMechanismDiscriminationOracle(ROOT_EVAL_DEVELOPMENT_TASKS);
		const pairwiseAudit = rootEvalMechanismPairwiseAudit(ROOT_EVAL_DEVELOPMENT_TASKS);
		const targetOccurrences = bindings.flatMap((binding) =>
			Object.values(binding.targetCandidateCatalogs),
		);
		expect(bindings).toHaveLength(5);
		expect(targetOccurrences).toHaveLength(30);
		expect(new Set(targetOccurrences.map((entry) => entry.workItemId)).size).toBe(30);
		expect(new Set(targetOccurrences.map((entry) => entry.candidateCatalogDigest)).size).toBe(30);
		expect(new Set(targetOccurrences.flatMap((entry) => entry.candidateRefs)).size).toBe(60);
		expect(oracle).toHaveLength(5);
		expect(pairwiseAudit).toHaveLength(10);
		expect(
			pairwiseAudit.every(
				(audit) =>
					!audit.semanticInterchangeable &&
					audit.actionTokenOverlap <= 0.2 &&
					audit.executableTokenOverlap <= 0.2,
			),
		).toBe(true);
		expect(new Set(bindings.map((binding) => binding.irrelevantTaskInstanceRef)).size).toBe(5);
		expect(new Set(ROOT_EVAL_DEVELOPMENT_TASKS.map((task) => task.mechanismId)).size).toBe(5);
		expect(new Set(ROOT_EVAL_DEVELOPMENT_TASKS.map((task) => task.mechanismAction)).size).toBe(5);
		expect(
			new Set(ROOT_EVAL_DEVELOPMENT_TASKS.map((task) => task.sourceInsightContent.length)),
		).toEqual(new Set([96]));
		for (const [index, binding] of bindings.entries()) {
			const target = ROOT_EVAL_DEVELOPMENT_TASKS[index]!;
			const irrelevant =
				ROOT_EVAL_DEVELOPMENT_TASKS[ROOT_EVAL_IRRELEVANT_SOURCE_REPLICATES[index]! - 1]!;
			for (const workItemRole of ["source", "target"] as const) {
				const targetOccurrence = binding.targetCandidateCatalogs.cold;
				const workItemId =
					workItemRole === "source" ? binding.sourceWorkItemId : targetOccurrence.workItemId;
				const catalog = rootEvalToolCandidateCatalog(target, workItemRole, workItemId);
				const correctReplacement =
					workItemRole === "source" ? target.sourceFixtureCorrectText : target.fixtureCorrectText;
				const alternativeReplacement =
					workItemRole === "source"
						? target.sourceFixtureAlternativeText
						: target.fixtureAlternativeText;
				const correctIndex = catalog.candidates.findIndex(
					(candidate) =>
						candidate.replacementDigest === empiricalStrictJsonDigest(correctReplacement),
				);
				expect(catalog.candidates).toHaveLength(2);
				expect(catalog.candidates.map((candidate) => candidate.candidateRef)).toEqual(
					workItemRole === "source" ? binding.sourceCandidateRefs : targetOccurrence.candidateRefs,
				);
				expect(catalog.catalogDigest).toBe(
					workItemRole === "source"
						? binding.sourceCandidateCatalogDigest
						: targetOccurrence.candidateCatalogDigest,
				);
				expect(correctIndex).toBe(target.replicate % 2 === 1 ? 0 : 1);
				expect(new Set(catalog.candidates.map((candidate) => candidate.action)).size).toBe(2);
				expect(
					catalog.candidates.every(
						(candidate) => !/candidate-[ab]|first|second|third/iu.test(candidate.action),
					),
				).toBe(true);
				expect(
					catalog.candidates.find(
						(candidate) =>
							candidate.replacementDigest === empiricalStrictJsonDigest(alternativeReplacement),
					)?.replacementText,
				).toBe(alternativeReplacement);
				expect(target.sourceInsightContent).not.toContain(
					catalog.candidates[correctIndex]!.candidateRef,
				);
			}
			expect(target.taskStatement).toContain(
				"Public examples intentionally permit more than one plausible rule",
			);
			expect(target.sourceInsightContent.trim()).toMatch(/^mechanism-invariant\.v2;rule=[a-z-]+$/u);
			expect(target.sourceInsightContent).not.toMatch(
				/compare|reject|return|patch|verifier|fixture|packages\//iu,
			);
			expect(binding.irrelevantTaskInstanceRef).toBe(irrelevant.instanceRef);
			expect(binding.irrelevantSourceInsightDigest).toBe(irrelevant.sourceInsightDigest);
			expect(target.mechanismAction).not.toBe(irrelevant.mechanismAction);
			expect(oracle[index]).toEqual({
				replicate: target.replicate,
				relevantSelected: "verified",
				irrelevantSelected: "alternative",
				controlsSelected: ["alternative", "alternative", "alternative", "alternative"],
			});
			expect(
				rootEvalScriptedMechanismReplacement(target, {
					sourceInsightContent: target.sourceInsightContent,
					admitted: true,
					applied: true,
					scopeMatches: true,
				}).replacement,
			).toBe(target.fixtureCorrectText);
			expect(
				rootEvalScriptedMechanismReplacement(target, {
					sourceInsightContent: irrelevant.sourceInsightContent,
					admitted: true,
					applied: true,
					scopeMatches: true,
				}).replacement,
			).toBe(target.fixtureAlternativeText);
		}
		const duplicateMechanism = ROOT_EVAL_DEVELOPMENT_TASKS.map((task, index) =>
			index === 1 ? { ...task, mechanismId: ROOT_EVAL_DEVELOPMENT_TASKS[0]!.mechanismId } : task,
		);
		expect(() => assertRootEvalTaskStimulusContract(duplicateMechanism)).toThrow(
			/orthogonal mechanisms/u,
		);
		const target = ROOT_EVAL_DEVELOPMENT_TASKS[0]!;
		const sourceInsightContent = `${target.sourceInsightContent.trim()};${target.writablePath}`;
		const leakedTasks = ROOT_EVAL_DEVELOPMENT_TASKS.map((task, index) =>
			index === 0
				? {
						...task,
						sourceInsightContent,
						sourceInsightDigest: empiricalStrictJsonDigest({
							kind: "eval-source-causal-insight-bytes",
							taskInstanceRef: task.instanceRef,
							sourceWorkItemId: task.sourceWorkItemRef,
							content: sourceInsightContent,
						}),
					}
				: task,
		);
		expect(() => assertRootEvalTaskStimulusContract(leakedTasks)).toThrow();
		const rebound = ROOT_EVAL_DEVELOPMENT_TASKS.map((task, index) => {
			if (index !== 1) return task;
			const content = ROOT_EVAL_DEVELOPMENT_TASKS[0]!.sourceInsightContent;
			return {
				...task,
				sourceInsightContent: content,
				sourceInsightDigest: empiricalStrictJsonDigest({
					kind: "eval-source-causal-insight-bytes",
					taskInstanceRef: task.instanceRef,
					sourceWorkItemId: task.sourceWorkItemRef,
					content,
				}),
			};
		});
		expect(() => rootEvalTaskBindings(rebound)).toThrow();
		expect(() =>
			createRootEvalTaskManifest({
				slot: "development-1",
				variantOrder: [0, 0, 1, 2, 3],
				coordinateSuffix: "duplicate-mechanism-seed",
			}),
		).toThrow(/generation input invalid/u);
	});

	it("binds every actor-visible fixture into the exact-tool workspace snapshot", () => {
		const task = ROOT_EVAL_DEVELOPMENT_TASKS[0]!;
		const baseline = rootEvalCandidateWorkspaceSnapshotDigest(task, "target");
		const drifted = Object.freeze({
			...task,
			readonlyFixtureFiles: Object.freeze(
				task.readonlyFixtureFiles.map((fixture, index) =>
					index === 0 ? Object.freeze({ ...fixture, text: `${fixture.text}\n// drift` }) : fixture,
				),
			),
		});
		expect(rootEvalCandidateWorkspaceSnapshotDigest(drifted, "target")).not.toBe(baseline);
		const catalog = rootEvalToolCandidateCatalog(task, "target", DEFAULT_TEST_WORK_ITEM_ID);
		expect(
			catalog.candidates.every((candidate) => candidate.workspaceSnapshotDigest === baseline),
		).toBe(true);
	});

	it("binds private manifest salts without leaking them into hidden mechanism fixtures", () => {
		const manifest = createRootEvalTaskManifest({
			slot: "development-1",
			variantOrder: [0, 1, 2, 3, 4],
			coordinateSuffix: "manifest-suffix-1234",
		});
		expect(manifest.tasks[0]!.readonlyFixtureFiles[0]!.text).toContain(
			"sealed-manifest-coordinate: :manifest-suffix-1234",
		);
		expect(manifest.tasks[0]!.hiddenVerifierSource).not.toContain("manifest-suffix-1234");
	});

	it("binds the stable D149 operator declaration and fresh current-key admission to Local Eval 2", async () => {
		const credential = parseRootEvalLiveCredential(
			new TextEncoder().encode("OPENROUTER_API_KEY=sk-or-v1-a44-middle-credential-e06\n"),
		);
		const nowMs = Date.now();
		const gateReceipt = precredentialGateReceipt(nowMs - 1);
		const declarationBytes = operatorConfigurationBytes(nowMs);
		expect(JSON.parse(new TextDecoder().decode(declarationBytes))).toMatchObject({
			schemaVersion: ROOT_EVAL_LIVE_OPERATOR_CONFIGURATION_SCHEMA,
			decisionRef: ROOT_EVAL_LIVE_OPERATOR_CONFIGURATION_DECISION_REF,
			credentialFingerprintDigest: empiricalSha256(
				new TextEncoder().encode("sk-or-v1-a44-middle-credential-e06"),
			),
		});
		const zeroByok = admitRootEvalLiveZeroByok({
			credential,
			precredentialGateReceipt: gateReceipt,
			nowMs,
			bytes: declarationBytes,
		});
		expect(zeroByok.byokCredentialCount).toBe(0);
		const oldDeclarationBytes = operatorConfigurationBytes(nowMs - 31 * 24 * 60 * 60 * 1_000);
		const oldDeclaration = admitRootEvalLiveOperatorConfiguration({
			credential,
			nowMs,
			bytes: oldDeclarationBytes,
		});
		expect(oldDeclaration.declaredAtMs).toBe(nowMs - 31 * 24 * 60 * 60 * 1_000);
		const laterReceiptObservation = admitRootEvalLiveZeroByok({
			credential,
			precredentialGateReceipt: precredentialGateReceipt(nowMs + 1),
			nowMs: nowMs + 1,
			bytes: declarationBytes,
		});
		expect(laterReceiptObservation.sourceArtifactDigest).toBe(zeroByok.sourceArtifactDigest);
		expect(laterReceiptObservation.observationDigest).not.toBe(zeroByok.observationDigest);
		const rotatedSameFragments = parseRootEvalLiveCredential(
			new TextEncoder().encode("OPENROUTER_API_KEY=sk-or-v1-a44-rotated-credential-e06\n"),
		);
		expect(() =>
			admitRootEvalLiveOperatorConfiguration({
				credential: rotatedSameFragments,
				nowMs,
				bytes: declarationBytes,
			}),
		).toThrow(/same-credential admission/u);
		const revoked = new TextDecoder()
			.decode(declarationBytes)
			.replace('"revoked":false', '"revoked":true');
		expect(() =>
			admitRootEvalLiveOperatorConfiguration({
				credential,
				nowMs,
				bytes: new TextEncoder().encode(revoked),
			}),
		).toThrow(/same-credential admission/u);
		expect(() =>
			admitRootEvalLiveZeroByok({
				credential,
				precredentialGateReceipt: gateReceipt,
				nowMs,
				bytes: new TextEncoder().encode(
					JSON.stringify({
						schemaVersion: ROOT_EVAL_LIVE_OPERATOR_CONFIGURATION_SCHEMA,
						decisionRef: "graphrefly-ts:D94",
						workspaceName: "GraphReFly",
						workspaceSlug: "graph-re-fly",
						keyName: "Local Eval 2",
						byokCredentialCount: 0,
						providerObservation: "Fireworks Not configured",
						source: "maintainer-declared-openrouter-settings",
						declaredAt: new Date(nowMs).toISOString(),
						configurationRevision: "2026-08-29.d149.v1",
						revoked: false,
						credentialFingerprintDigest: empiricalSha256(
							new TextEncoder().encode("sk-or-v1-a44-middle-credential-e06"),
						),
						guardrailId: "2c97d3e1-b4cc-4246-95d7-33eb27fb65ab",
						guardrailName: "B112 DeepSeek V4 Flash",
						guardrailDescription:
							"Dedicated Local Eval 2 guardrail for the B112 DeepSeek V4 Flash 0731 Fireworks-only structured-proposal route.",
						keyAssigned: true,
						restrictionMode: "only-allow",
						paidEndpointTrainingAllowed: false,
						providerEligible: true,
						requestDataCollection: "deny",
						requestZdrRequired: true,
						keyVisiblePrefix: "",
						keyVisibleSuffix: "",
						allowedModels: ["deepseek/deepseek-v4-flash-0731"],
						allowedProviders: ["Fireworks"],
					}),
				),
			}),
		).toThrow(/same-credential/u);
		let reads = 0;
		const fetchImpl = async (): Promise<Response> => {
			reads += 1;
			return new Response(
				JSON.stringify({
					data: {
						limit: 32,
						limit_remaining: 12.25,
						usage: 19.75,
						limit_reset: null,
						is_management_key: false,
						rate_limit: { requests: 0, interval: "deprecated-not-budget-authority" },
					},
				}),
				{ status: 200 },
			);
		};
		const admittedKey = await readRootEvalLiveCurrentKey({ credential, fetchImpl });
		expect(admittedKey).toMatchObject({
			limitMicrousd: 32_000_000,
			remainingMicrousd: 12_250_000,
			usageMicrousd: 19_750_000,
			limitReset: "none",
			isManagementKey: false,
		});
		expect(reads).toBe(1);
	});

	it("keeps historical D85 coordinates inspectable but rejects their reuse by D140", async () => {
		const temporary = await mkdtemp(join(tmpdir(), "graphrefly-root-eval-claim-"));
		const privateRoot = await realpath(temporary);
		await chmod(privateRoot, 0o700);
		const credential = Object.freeze({
			bearerToken: "test-openrouter-token-not-secret",
			bindingRef: "openrouter.local-eval-2" as const,
			bindingRevision: "2026-08-24.d94.v1" as const,
		});
		const pricingMaterial = Object.freeze({
			sourceUrl:
				"https://openrouter.ai/api/v1/models/deepseek/deepseek-v4-flash-0731/endpoints" as const,
			modelRef: "deepseek/deepseek-v4-flash-0731" as const,
			endpointModelRef: "deepseek/deepseek-v4-flash-20260731" as const,
			providerName: "Fireworks" as const,
			providerRef: "fireworks" as const,
			quantization: "unknown" as const,
			inputMicrousdPerMillionTokens: 220_000 as const,
			outputMicrousdPerMillionTokens: 660_000 as const,
			cacheReadMicrousdPerMillionTokens: 7_000 as const,
			zeroDataRetention: true as const,
			promptTraining: false as const,
			zdrSourceUrl: ROOT_EVAL_LIVE_ZDR_SOURCE,
			zdrResponseDigest: empiricalStrictJsonDigest("zdr"),
			observedAtMs: 1,
			officialResponseDigest: empiricalStrictJsonDigest("pricing"),
		});
		const pricingObservation = Object.freeze({
			...pricingMaterial,
			observationDigest: empiricalStrictJsonDigest(pricingMaterial),
		});
		const zeroMaterial = Object.freeze({
			workspaceSlug: "graph-re-fly" as const,
			keyName: "Local Eval 2" as const,
			byokCredentialCount: 0 as const,
			providerObservation: "Fireworks Not configured" as const,
			observedAtMs: 1,
			precredentialGateCompletedAtMs: 0,
			precredentialGateReceiptDigest: empiricalStrictJsonDigest("precredential-gates"),
			sourceArtifactDigest: empiricalStrictJsonDigest("zero-source"),
		});
		const zeroByok = Object.freeze({
			...zeroMaterial,
			observationDigest: empiricalStrictJsonDigest(zeroMaterial),
		});
		try {
			const claimInput = {
				privateRoot,
				implementationCoordinate: `worktree:${"a".repeat(40)}:${ROOT_EVAL_HISTORICAL_D85_IMPLEMENTATION_MANIFEST_DIGEST}`,
				implementationManifestDigest: ROOT_EVAL_HISTORICAL_D85_IMPLEMENTATION_MANIFEST_DIGEST,
				qualificationArtifactDigest: ROOT_EVAL_HISTORICAL_D85_QUALIFICATION_ARTIFACT_DIGEST,
				qualificationDigest: ROOT_EVAL_HISTORICAL_D85_QUALIFICATION_DIGEST,
				taskBindingDigest: ROOT_EVAL_HISTORICAL_D85_TASK_BINDING_DIGEST,
				taskManifestDigest: testTaskManifestDigest,
				pricing: pricingObservation,
				zeroByok,
				credential,
			};
			await expect(acquireRootEvalLiveClaim(claimInput)).rejects.toThrow(/current closure/u);
			const currentEvidence = liveEvidenceInput();
			const originalClaim = currentEvidence.claim!;
			await expect(
				persistRootEvalLivePreclaimFailure({
					privateRoot,
					implementationManifestDigest: claimInput.implementationManifestDigest,
					qualificationArtifactDigest: claimInput.qualificationArtifactDigest,
					qualificationDigest: claimInput.qualificationDigest,
					taskBindingDigest: claimInput.taskBindingDigest,
					failure: new Error("must not coexist with claim"),
				}),
			).rejects.toThrow(/current closure/u);
			const currentKeyBeforeMaterial = Object.freeze({
				limitMicrousd: 32_000_000 as const,
				remainingMicrousd: 13_500_000,
				usageMicrousd: 18_500_000,
				limitReset: "none" as const,
				isManagementKey: false as const,
			});
			const currentKeyBefore = Object.freeze({
				...currentKeyBeforeMaterial,
				admissionDigest: empiricalStrictJsonDigest(currentKeyBeforeMaterial),
			});
			const currentKeyAfterMaterial = Object.freeze({
				...currentKeyBeforeMaterial,
				remainingMicrousd: 13_499_900,
				usageMicrousd: 18_500_100,
			});
			const currentKeyAfter = Object.freeze({
				...currentKeyAfterMaterial,
				admissionDigest: empiricalStrictJsonDigest(currentKeyAfterMaterial),
			});
			const { claimDigest: _historicalClaimDigest, ...originalClaimMaterial } = originalClaim;
			const claimMaterial = {
				...originalClaimMaterial,
				currentKeyBeforeDigest: currentKeyBefore.admissionDigest,
				recoveryEnvelope: {
					pricing: currentEvidence.pricing,
					zeroByok: currentEvidence.zeroByok,
					currentKeyBefore,
				},
			};
			const claim = {
				...claimMaterial,
				claimDigest: empiricalStrictJsonDigest(claimMaterial),
			};
			const verificationDiagnostics =
				liveEvidenceInput().graphResult!.finding.verificationDiagnostics;
			const currentWorkItemCount = ROOT_EVAL_LIVE_REPLICATE_COUNT * arms.length;
			const graphResult: RootEvalRunResult = Object.freeze({
				finding: Object.freeze({
					kind: "eval-efficacy-finding" as const,
					campaignRef: ROOT_EVAL_LIVE_GENERATION_REF,
					replicateCount: ROOT_EVAL_LIVE_REPLICATE_COUNT,
					armOrder: Object.freeze([
						"cold",
						"relevant-applied",
						"proposal-only",
						"admission-rejected",
						"irrelevant-applied",
						"wrong-scope-applied",
					] as const),
					passCounts: Object.freeze({
						cold: 0,
						"relevant-applied": ROOT_EVAL_LIVE_REPLICATE_COUNT,
						"proposal-only": 0,
						"admission-rejected": 0,
						"irrelevant-applied": 0,
						"wrong-scope-applied": 0,
					}),
					evaluableReplicates: ROOT_EVAL_LIVE_REPLICATE_COUNT,
					excludedTechnicalReplicates: Object.freeze([]),
					sourceTechnicalExcludedReplicates: Object.freeze([]),
					matchedRelevantOverColdWins: ROOT_EVAL_LIVE_REPLICATE_COUNT,
					verificationDiagnostics,
					completedWorkItems: currentWorkItemCount,
					admittedAttempts: currentWorkItemCount,
					providerCallCount: currentWorkItemCount,
					activeReservedMicrousd: 0,
					providerReportedMicrousd: 100,
					pricingRoundingAllowanceMicrousd: 1,
					providerReportedLowerBoundMicrousd: 99,
					unreportedSettledUpperBoundMicrousd: 0,
					accountedUpperBoundMicrousd: 100,
					observedBilledMicrousd: 100,
					billingObservationCount: 4,
					billingStableIntervals: 3,
					reconciledBilledMicrousd: 100,
					billingDisposition: "reconciled" as const,
					providerOutcomeReasonCounts,
					finding: "positive-differential" as const,
					stoppingReason: "campaign-complete" as const,
				}),
				observations: currentEvidence.graphResult!.observations,
				peakConcurrentEffects: 1,
				executedAdmissionIds: admissionIds(),
			});
			const oversizedDiagnosticStream = [
				...Array.from({ length: 513 }, () => graphResult.observations[0]!),
				...graphResult.observations,
			];
			const evidence = constructRootEvalLiveEvidence({
				claim,
				currentKeyBefore,
				currentKeyAfter,
				pricing: currentEvidence.pricing,
				zeroByok: currentEvidence.zeroByok,
				providerCalls: currentWorkItemCount,
				graphResult,
				partialGraphObservations: oversizedDiagnosticStream,
				failure: null,
				cleanupDisposition: "complete",
			});
			expect(evidence.efficacyClaim).toBe("none");
			expect(evidence.partialGraphObservations).toHaveLength(oversizedDiagnosticStream.length);
			expect(evidence.latestGraphObservation).toEqual(evidence.partialGraphObservations.at(-1));
			const { evidenceDigest: _digest, ...forgedMaterial } = evidence;
			const forgedDiagnosticMaterial = {
				...forgedMaterial,
				graphResult: {
					...evidence.graphResult!,
					finding: {
						...evidence.graphResult!.finding,
						passCounts: {
							...evidence.graphResult!.finding.passCounts,
							"relevant-applied": 0,
						},
						finding: "no-positive-differential" as const,
					},
					observations: evidence.graphResult!.observations.map((event, index, events) => ({
						...event,
						msg: [
							"DATA" as const,
							{
								...(event.msg[1] as Record<string, unknown>),
								finding:
									index === events.length - 1
										? ("no-positive-differential" as const)
										: ("pending" as const),
							},
						] as const,
					})),
				},
				efficacyClaim: "none" as const,
				causalAttribution: "undetermined" as const,
			};
			await expect(
				persistRootEvalLiveEvidence({
					privateRoot,
					evidence: {
						...forgedDiagnosticMaterial,
						evidenceDigest: empiricalStrictJsonDigest(forgedDiagnosticMaterial),
					},
				}),
			).rejects.toThrow(/pass counts drifted/u);
			const forgedMaterialWithDisposition = {
				...forgedMaterial,
				disposition: "partial-failure" as const,
			};
			const forgedEvidence = {
				...forgedMaterialWithDisposition,
				evidenceDigest: empiricalStrictJsonDigest(forgedMaterialWithDisposition),
			};
			await expect(
				persistRootEvalLiveEvidence({ privateRoot, evidence: forgedEvidence }),
			).rejects.toThrow(/partial evidence relationship invalid/u);
			const { evidenceDigest: _partialDigest, ...partialMaterial } = evidence;
			const partialDriftMaterial = {
				...partialMaterial,
				partialGraphObservations: evidence.partialGraphObservations.slice(0, -1),
			};
			await expect(
				persistRootEvalLiveEvidence({
					privateRoot,
					evidence: {
						...partialDriftMaterial,
						evidenceDigest: empiricalStrictJsonDigest(partialDriftMaterial),
					},
				}),
			).rejects.toThrow(/latest observation drifted|partial observations drifted/u);
			const { evidenceDigest: _claimDigestEvidence, ...unboundMaterial } = evidence;
			const unboundClaimMaterial = {
				...unboundMaterial,
				claimDigest: empiricalStrictJsonDigest("uncommitted-claim"),
			};
			await expect(
				persistRootEvalLiveEvidence({
					privateRoot,
					evidence: {
						...unboundClaimMaterial,
						evidenceDigest: empiricalStrictJsonDigest(unboundClaimMaterial),
					},
				}),
			).rejects.toThrow(/committed D152 claim/u);
			await expect(
				Promise.all([
					persistRootEvalLiveEvidence({ privateRoot, evidence }),
					persistRootEvalLiveEvidence({ privateRoot, evidence }),
				]),
			).rejects.toThrow(/committed D152 claim/u);
			await expect(
				persistRootEvalLiveEvidence({
					privateRoot,
					evidence: { ...evidence, disposition: "partial-failure" },
				}),
			).rejects.toThrow(/evidence.*invalid|committed D152 claim/u);
			expect(await readdir(privateRoot)).toEqual([]);
		} finally {
			await rm(temporary, { recursive: true, force: true });
		}
	}, 30_000);

	it("rejects stale preclaim coordinates before creating a D140 disposition", async () => {
		const temporary = await mkdtemp(join(tmpdir(), "graphrefly-root-eval-preclaim-"));
		const privateRoot = await realpath(temporary);
		await chmod(privateRoot, 0o700);
		const input = {
			privateRoot,
			implementationManifestDigest: `sha256:${"1".repeat(64)}`,
			qualificationArtifactDigest: `sha256:${"2".repeat(64)}`,
			qualificationDigest: `sha256:${"3".repeat(64)}`,
			taskBindingDigest: ROOT_EVAL_HISTORICAL_D85_TASK_BINDING_DIGEST,
			failure: new Error("precredential frozen task gate failed"),
		};
		try {
			await expect(persistRootEvalLivePreclaimFailure(input)).rejects.toThrow(/current closure/u);
			const pricingMaterial = Object.freeze({
				sourceUrl:
					"https://openrouter.ai/api/v1/models/deepseek/deepseek-v4-flash-0731/endpoints" as const,
				modelRef: "deepseek/deepseek-v4-flash-0731" as const,
				endpointModelRef: "deepseek/deepseek-v4-flash-20260731" as const,
				providerName: "Fireworks" as const,
				providerRef: "fireworks" as const,
				quantization: "unknown" as const,
				inputMicrousdPerMillionTokens: 220_000 as const,
				outputMicrousdPerMillionTokens: 660_000 as const,
				cacheReadMicrousdPerMillionTokens: 7_000 as const,
				zeroDataRetention: true as const,
				promptTraining: false as const,
				zdrSourceUrl: ROOT_EVAL_LIVE_ZDR_SOURCE,
				zdrResponseDigest: empiricalStrictJsonDigest("zdr"),
				observedAtMs: 1,
				officialResponseDigest: empiricalStrictJsonDigest("pricing"),
			});
			const zeroMaterial = Object.freeze({
				workspaceSlug: "graph-re-fly" as const,
				keyName: "Local Eval 2" as const,
				byokCredentialCount: 0 as const,
				providerObservation: "Fireworks Not configured" as const,
				observedAtMs: 1,
				precredentialGateCompletedAtMs: 0,
				precredentialGateReceiptDigest: empiricalStrictJsonDigest("precredential-gates"),
				sourceArtifactDigest: empiricalStrictJsonDigest("zero-source"),
			});
			await expect(
				acquireRootEvalLiveClaim({
					privateRoot,
					implementationCoordinate: `worktree:${"a".repeat(40)}:${input.implementationManifestDigest}`,
					implementationManifestDigest: input.implementationManifestDigest,
					qualificationArtifactDigest: input.qualificationArtifactDigest,
					qualificationDigest: input.qualificationDigest,
					taskBindingDigest: input.taskBindingDigest,
					taskManifestDigest: testTaskManifestDigest,
					pricing: Object.freeze({
						...pricingMaterial,
						observationDigest: empiricalStrictJsonDigest(pricingMaterial),
					}),
					zeroByok: Object.freeze({
						...zeroMaterial,
						observationDigest: empiricalStrictJsonDigest(zeroMaterial),
					}),
					credential: Object.freeze({
						bearerToken: "test-openrouter-token-not-secret",
						bindingRef: "openrouter.local-eval-2" as const,
						bindingRevision: "2026-08-24.d94.v1" as const,
					}),
				}),
			).rejects.toThrow(/current closure/u);
			expect(await readdir(privateRoot)).toEqual([]);
		} finally {
			await rm(temporary, { recursive: true, force: true });
		}
	});

	it("rejects a suffix-only current implementation coordinate before claim commit", async () => {
		const temporary = await mkdtemp(join(tmpdir(), "graphrefly-root-eval-coordinate-shape-"));
		const privateRoot = await realpath(temporary);
		await chmod(privateRoot, 0o700);
		try {
			const input = await currentClaimInput(privateRoot);
			await expect(
				acquireRootEvalLiveClaimForNoNetworkQualification({
					...input,
					implementationCoordinate: `anything:${ROOT_EVAL_CURRENT_IMPLEMENTATION_MANIFEST_DIGEST}`,
				}),
			).rejects.toThrow(/implementation-coordinate/u);
			expect(await readdir(privateRoot)).toEqual([]);
		} finally {
			await rm(temporary, { recursive: true, force: true });
		}
	});
});
