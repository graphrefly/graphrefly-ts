from pathlib import Path
import json,hashlib,tarfile,subprocess
root=Path('/Users/davidchenallio/src/graphrefly-ts');out=Path(__file__).parent
q=root/'packages/ts/qualification/causal-occurrence'
sha=lambda b:'sha256:'+hashlib.sha256(b).hexdigest()
read=lambda n:json.loads((out/n).read_text())
verification=read('evidence-verification.json')
assert verification['passed']
assert read('evidence-verification.check.json')['exitCode']==0
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()=='861a9a468c5d767997a4bec70df159f327faa512'
receiptPath=q/'committed-v2-receipt.json';reviewPath=q/'committed-v2-review.md';archivePath=q/'committed-v2-evidence.tar.gz'
assert all(not p.exists() for p in [receiptPath,reviewPath,archivePath]),'fresh immutable revision required'
checks=[read(i+'.check.json') for i in verification['checkIds']+['evidence-verification']]
for c in checks:assert c['exitCode']==0 and c['sourceUnchanged']
soak=read('root-soak.check.json')
review=(out/'review-draft.md').read_text()
review=review.replace('审阅草稿：2257 默认测试、四组 mutation、独立对照和构建检查已通过；显式 101 项离线 soak 尚在运行。只有该检查完成并通过，才会封存 complete 收据和更新 work。',f'已完成已批准切片的源码离线资格。默认 2257 项测试和显式 101 项离线 soak 均通过；soak 用时 {soak["elapsedSeconds"]:.1f} 秒。新收据 committed-v2 关闭同一个 CAUSAL-COMMITTED-VIEW-TS，保留 committed-v1 及所有中间尝试原状。')
review=review.replace('最终封存将包括','本收据与无损证据包包括')
review=review.replace('，以及 owner/workspace/dashboard gate。','，以及 owner/workspace/dashboard 预检查。封存后的最终 owner gate 另见 committed-v2-closeout.json。')
review += '\n描述性时长的中位数沿用既有 runner 的 upper-middle（偶数样本取中间较大值）定义；p95 仍按 nearest rank。两位静态审阅者发现并修正了新封存验证器的中位数口径及报告身份核对缺口，未改原始测量、测试、runtime 或预算。结果报告的 runner/test/source/oracle/closure 与两组固定基线都经过独立身份核对；收据逐文件绑定其内容。\n\n完整机器记录：[committed-v2-receipt.json](committed-v2-receipt.json)；无损原始日志与报告：[committed-v2-evidence.tar.gz](committed-v2-evidence.tar.gz)。上一轮性能是哈希绑定的复用证据，当前轮不是一次新的性能运行。新资格不改写此前失败结论，也不授予后续实施或外部执行权限。\n'
reviewPath.write_text(review)
qa={'mode':'two independent static reviewers; no reviewer test runs','initialFindings':[{'finding':'Result reports were not bound to their embedded runner/source/test/oracle/baseline identities','resolution':'New verify-report-identities.py verifies identities, exact git archive frozen digest and all closures; verify-evidence.py rechecks exact report content digests.'},{'finding':'Descriptive median independent recomputation used lower nearest-rank rather than existing upper-middle','resolution':'New verifier matches unchanged runner upper-middle convention. Raw reports, production code, measurement harness and original budgets unchanged.'}],'finalReviewers':{'offline_binding_review':'No findings in fixes; source/identity and distinct baseline checks resolved. Final receipt separately reviewed after assembly.','offline_scope_review':'No findings; median fix correct and private offline scope/downstream exclusions preserved.'},'runtimeChangesFromReview':False}
(out/'qa-review.json').write_text(json.dumps(qa,indent=2)+'\n')
members={}
for p in sorted(out.rglob('*')):
 if p.is_file() and '__pycache__' not in p.parts:
  name=str(p.relative_to(out));members[name]={'digest':sha(p.read_bytes()),'bytes':p.stat().st_size}
with tarfile.open(archivePath,'w:gz') as tar:
 for name in members:tar.add(out/name,arcname=name,recursive=False)
with tarfile.open(archivePath) as tar:
 assert set(tar.getnames())==set(members)
 for name,entry in members.items():assert sha(tar.extractfile(name).read())==entry['digest'],name
paths=read('scope-verification.json')['currentBindingAndArtifactPaths']
source=read('full-test.bindings.json')['after']
coverage=verification['coverage']
coverage['liveOptInSkips']=['3 local-untrusted-js-compute-node Podman live cases','1 rootless local-container-postgresql Podman live case']
receipt={'schema':'graphrefly-ts/causal-committed-view-evidence/v1','artifactRef':'graphrefly-ts:causal-committed-view-evidence','revision':'committed-v2','workRef':'graphrefly-ts:CAUSAL-COMMITTED-VIEW-TS','owner':'graphrefly-ts','date':'2026-09-08','status':'complete','statusReason':'Stable source passes all applicable offline checks, independent finite V1–V10 evidence, preserved original performance budgets and current no-network artifact binding; final owner validation is linked separately.','governingRefs':['graphrefly-ts:D160','graphrefly-ts:D161','graphrefly-ts:D162','graphrefly-ts:D163'],'authorization':read('authorization.json'),'authorizationDigest':sha((out/'authorization.json').read_bytes()),'provenance':{'actor':'Codex','task':'01a077c7-55e6-7f11-9d4f-e7c51944afb4','runtimeSourceCommit':'861a9a468c5d767997a4bec70df159f327faa512','originalImplementationReceipt':{'path':'packages/ts/qualification/causal-occurrence/committed-v1-receipt.json','digest':sha((q/'committed-v1-receipt.json').read_bytes())},'retainedMaterialReceipt':{'path':'packages/ts/qualification/causal-occurrence/committed-v1-material-receipt.json','digest':sha((q/'committed-v1-material-receipt.json').read_bytes())}},'productionFilesChangedThisRevision':[],'sourceFiles':source,'currentQualification':read('closure.json'),'refreshedFiles':{p:sha((root/p).read_bytes()) for p in paths},'currentness':read('scope-verification.json'),'resultReportDigests':read('report-identities-verification.json')['reportDigests'],'checks':checks,'coverage':coverage,'verification':verification,'performance':read('retained-performance-verification.json'),'review':{'path':str(reviewPath.relative_to(root)),'digest':sha(reviewPath.read_bytes()),'qa':qa},'evidenceBundle':{'path':str(archivePath.relative_to(root)),'digest':sha(archivePath.read_bytes()),'format':'gzip tar; lossless exact logs, result arrays, inputs, runner snapshots, source bindings and independent verifiers','members':members},'postSealValidationPath':'packages/ts/qualification/causal-occurrence/committed-v2-closeout.json','nonClaims':['No new performance rerun or generalized zero-cost claim','No resolution of historical 1.839833 anomaly cause','No mutation of frozen scientific method, historical receipts or consumed live grants','No external credential, provider, live or spend execution; only fixture credentials and injected responses','No public API, C/core or wave protocol change','No preset/graded audience hiding or all-five-port on-demand qualification','No request materializer, current-at-dispatch guard, actual inbox, B121 proof or external effect authorization','No automatic downstream implementation']}
receiptPath.write_text(json.dumps(receipt,ensure_ascii=False,indent='\t')+'\n')
readme=q/'README.md'
readme.write_text(readme.read_text()+'''
## committed-v2 — private committed-effects source qualification (2026-09-08)

[Review](committed-v2-review.md), [immutable receipt](committed-v2-receipt.json) and [closeout](committed-v2-closeout.json) qualify the stable private D163 implementation at 861a9a46. Default 2,257 passed (4 existing Podman live opt-in skips), explicit no-network root soak 101 passed, original 73 + 25 + 16 categorized mutations and 11 view detections passed. Independent finite plain/oracle, original-port comparisons, browser/lint/typecheck/build/export and regenerated artifact checks passed. Exact unchanged source/harness bindings permit reuse of the previously successful original construction/steady gate; all old failed receipts remain historical evidence.

This refresh changes only three current qualification digests and five digest-derived artifacts. It completes CAUSAL-COMMITTED-VIEW-TS, not graded audience hiding, a full preset, a materializer/current dispatch guard, the actual inbox, B121 or live authorization. Graph-owned lifecycle and active obligations remain independent of UI subscriptions.
''')
work=root/'plan/work.jsonl';lines=work.read_text().splitlines()
for i,line in enumerate(lines):
 d=json.loads(line)
 if d['id']!='CAUSAL-COMMITTED-VIEW-TS':continue
 assert d['status']=='planned'
 d['status']='complete'
 d['produces'][0]['revision']='committed-v2'
 for path in [receiptPath,reviewPath]:
  d['evidence_refs'].append({'ref':str(path.relative_to(root)),'digest':sha(path.read_bytes())})
 d['note']+=' 2026-09-08 latest 好的，继续 authorized stable-source offline requalification, existing three current digest bindings, generated artifacts and commit. committed-v2 qualifies unchanged 861a9a46 runtime source: default2257pass/4existing live opt-in skips, explicit no-network soak101, original73+25+16 and view11 categorized mutations, independent plain/oracle/workload and two standalone baselines, helpers168/incoming144/resources12+2, browser/lint/typecheck/build/export/artifact gates pass. Independent verification binds all report identities and both original material gate source snapshots to the same431 current files; original four construction/steady budgets are reused without rerun or threshold change. All historical receipts, failures, scientific inputs and consumed live grants preserved. Current three digest constants and five generated artifacts refreshed only after candidate generation and successful offline qualification. Same work complete with produced evidence revision committed-v2; no new decision, no provider/live/spend, no graded-hiding/preset/materializer/current-dispatch/inbox/B121 claim or downstream dispatch.'
 lines[i]=json.dumps(d,ensure_ascii=False,separators=(',',':'));break
else:raise AssertionError('work missing')
work.write_text('\n'.join(lines)+'\n')
print('RECEIPT_ASSEMBLED',str(receiptPath),len(members),'archive members',archivePath.stat().st_size,'bytes')
