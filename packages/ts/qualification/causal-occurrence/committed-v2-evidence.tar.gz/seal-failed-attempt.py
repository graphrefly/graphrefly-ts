from pathlib import Path
import json,hashlib,tarfile,shutil,subprocess
root=Path('/Users/davidchenallio/src/graphrefly-ts');out=Path(__file__).parent;q=root/'packages/ts/qualification/causal-occurrence'
sha=lambda b:'sha256:'+hashlib.sha256(b).hexdigest()
read=lambda n:json.loads((out/n).read_text())
verification=read('attempt-verification.json')
assert verification['verified'] and not verification['qualificationPassed']
assert read('attempt-verification.check.json')['exitCode']==0
receiptPath=q/'committed-v2-receipt.json';reviewPath=q/'committed-v2-review.md';archivePath=q/'committed-v2-evidence.tar.gz';proposalPath=q/'committed-v2-shuffle-proposal.patch'
assert all(not p.exists() for p in [receiptPath,reviewPath,archivePath,proposalPath])
assert subprocess.check_output(['git','status','--porcelain'],cwd=root,text=True)==''
shutil.copy2(out/'failed-review.md',reviewPath)
shutil.copy2(out/'shuffle-parameterization-proposal.patch',proposalPath)
qa={'mode':'two independent static reviewers; no reviewer test runs','verificationFindingsResolved':['Verify embedded runner/test/source/oracle/closure and exact distinct baseline identities, then bind report digests.','Use unchanged runner upper-middle descriptive median; raw data/harness unchanged.'],'finalVerificationReview':'No findings in the new identity and median fixes.','failureScopeReview':'Timeout-global-manifest cleanup cascade is plausible but unproven; isolated runs do not prove the original incident cause.','proposalReview':'No findings: all120 orders, per-order assertions, VM isolation and bank support controls preserved;221 resulting soak cases.5s-per-case replaces5s-aggregate and requires explicit approval.','proposalStatus':'Unapplied and not test-executed; TypeScript syntax checked only.'}
(out/'qa-review.json').write_text(json.dumps(qa,indent=2)+'\n')
incident=read('soak-incident.json')
incident['finalDiagnostic']={'fiveCasePassed':4,'fiveCaseFailed':1,'remaining':'development-3 shuffle7767ms exceeds5000ms; all other original failures pass in this diagnostic','fullConfirmationExecuted':False,'noFurtherUnchangedRerun':True}
incident['qualificationStatus']='failed;candidate binding withdrawn;work incomplete'
(out/'soak-incident.json').write_text(json.dumps(incident,indent=2)+'\n')
members={}
for p in sorted(out.rglob('*')):
 if p.is_file() and '__pycache__' not in p.parts:
  members[str(p.relative_to(out))]={'digest':sha(p.read_bytes()),'bytes':p.stat().st_size}
with tarfile.open(archivePath,'w:gz') as t:
 for n in members:t.add(out/n,arcname=n,recursive=False)
with tarfile.open(archivePath) as t:
 assert set(t.getnames())==set(members)
 for n,v in members.items():assert sha(t.extractfile(n).read())==v['digest'],n
checks=verification['checks']+[read('attempt-verification.check.json')]
receipt={'schema':'graphrefly-ts/causal-committed-view-evidence/v1','artifactRef':'graphrefly-ts:causal-committed-view-evidence','revision':'committed-v2','workRef':'graphrefly-ts:CAUSAL-COMMITTED-VIEW-TS','owner':'graphrefly-ts','date':'2026-09-08','status':'qualification-failed','statusReason':'Full explicit offline soak fails96/5;isolated original five fails4/1 with shuffle7767ms exceeding unchanged5000ms deadline. Candidate current qualification bindings withdrawn. Work remains incomplete.','governingRefs':['graphrefly-ts:D160','graphrefly-ts:D161','graphrefly-ts:D162','graphrefly-ts:D163'],'authorization':read('authorization.json'),'authorizationDigest':sha((out/'authorization.json').read_bytes()),'provenance':{'actor':'Codex','task':'01a077c7-55e6-7f11-9d4f-e7c51944afb4','runtimeSourceCommit':'861a9a468c5d767997a4bec70df159f327faa512','priorReceipts':{n:sha((q/n).read_bytes()) for n in ['committed-v1-receipt.json','committed-v1-material-receipt.json']}},'productionFilesChangedThisRevision':[],'sourceFiles':read('full-test.bindings.json')['after'],'testedCandidateQualification':read('closure.json'),'candidateWithdrawn':read('candidate-binding-withdrawal.json'),'finalCheckoutQualification':'Historical current binding restored;known drift still rejects new runtime. Candidate2257-pass suite is not a final-checkout all-green claim.','resultReportDigests':read('report-identities-verification.json')['reportDigests'],'checks':checks,'coverage':{'candidateDefault':{'passed':2257,'failed':0,'skipped':4,'skips':'Existing3 local-untrusted-JS Podman live and1 PostgreSQL Podman live opt-ins'},'fullSoak':{'passed':96,'failed':5},'isolatedFive':{'passed':4,'failed':1,'filteredOut':96},'isolatedGrant':{'passed':1,'filteredOut':100},'mutations':{'causal':73,'construction':25,'coldCategorized':16,'view':11,'deferredAdjacencyOnly':2},'plainComparisonsPerArm':12,'hotOrdersPerArm':2,'workloadRowsPerArm':33,'requiredEdges':168,'incoming':144,'resourceSnapshots':12,'resourceNegativeControls':2,'standaloneBaselines':2,'standaloneTracesPerBaseline':6},'performance':read('retained-performance-verification.json'),'failureDiagnosis':{'incident':incident,'directPath':read('shuffle-path-bindings.json'),'cpuSampling':read('shuffle-profile-summary.json')},'verification':{'integrityVerified':True,'qualificationPassed':False,'check':'attempt-verification.json','same431SourceFilesAcrossAllCommands':True},'proposal':{**read('shuffle-proposal.json'),'canonicalPatch':str(proposalPath.relative_to(root)),'canonicalPatchDigest':sha(proposalPath.read_bytes())},'review':{'path':str(reviewPath.relative_to(root)),'digest':sha(reviewPath.read_bytes()),'staticQA':qa},'evidenceBundle':{'path':str(archivePath.relative_to(root)),'digest':sha(archivePath.read_bytes()),'format':'gzip tar;lossless exact reports,logs,profiles,source bindings,runner snapshots and proposed/withdrawn bytes','members':members},'unexecutedCompletionDrafts':['assemble-receipt.py','verify-evidence.py','review-draft.md'],'postSealValidationPath':'packages/ts/qualification/causal-occurrence/committed-v2-closeout.json','nonClaims':['No complete offline qualification or final-checkout all-green status','No new performance-gate run or generalized zero-cost guarantee','No proven cause of initial timeout/grant cascade or historical1.839833 anomaly','No change to frozen scientific method,test deadlines,historical receipts or actual consumed grants','No public API,C/core,protocol,preset,graded audience hiding,materializer,current-at-dispatch guard,inbox or B121 completion','No external credential/provider/live/spend execution or downstream authorization']}
receiptPath.write_text(json.dumps(receipt,ensure_ascii=False,indent='\t')+'\n')
readme=q/'README.md'
readme.write_text(readme.read_text()+'''
## committed-v2 — failed stable-source offline refresh (2026-09-08)

[Review](committed-v2-review.md), [receipt](committed-v2-receipt.json) and [unapplied proposal](committed-v2-shuffle-proposal.patch) retain the stable-source refresh attempt at 861a9a46. Candidate bindings passed 2,257 default tests (4 existing live opt-in skips), all 73 + 25 + 16 + 11 categorized mutations, independent comparisons and other offline gates. The explicit full soak failed 96/5; isolated original failures recovered to 4/1, with the 120-shuffle test still exceeding its unchanged 5-second deadline. Original source-bound performance evidence remains valid.

The three candidate qualification digests and five derived artifacts were withdrawn and restored byte-for-byte. Final checkout still has the known qualification drift; CAUSAL-COMMITTED-VIEW-TS remains incomplete. The proposed parameterization changes watchdog granularity and requires approval. No production code, scientific input, actual grant, public API or downstream work changed.
''')
work=root/'plan/work.jsonl';lines=work.read_text().splitlines()
for i,line in enumerate(lines):
 d=json.loads(line)
 if d['id']!='CAUSAL-COMMITTED-VIEW-TS':continue
 assert d['status']=='planned'
 for p in [receiptPath,reviewPath,proposalPath]:
  d['evidence_refs'].append({'ref':str(p.relative_to(root)),'digest':sha(p.read_bytes())})
 d['note']+=' 2026-09-08 latest 好的，继续 authorized stable-source offline qualification and existing current-binding refresh. committed-v2 preserves failed attempt: candidate binding default2257pass/4existing skips,all73+25+16+11 mutations,independent oracle/helper/resource/two-baseline comparisons,browser/lint/typecheck/build/export/artifact and owner prechecks pass. Explicit full soak96pass/5fail;isolated grant passes;original five isolated4pass/1fail with120-shuffle7767ms above unchanged5000ms. No full rerun after failed diagnostic. Direct shuffle test/task/canonical/codec match qualifiedd9c868dc;diagnostic CPU samples concentrate in VM context creation but do not prove incident cause. Initial timeout-induced test-global manifest cleanup cascade remains plausible/unproven. All431 runtime source bytes still match retained successful material performance gate;no performance rerun. Failed candidate three digest/five artifact files restored exactly;final checkout still correctly rejects stale qualification. No production,fixture,deadline,scientific input,actual grant or downstream changes. Work remains planned/incomplete. New immutable failure receipt and unapplied121-test parameterization proposal retained;proposal preserves120orders/VM isolation/assertions but changes5s aggregate watchdog to5s per case and requires user approval. No new D# or provider/live/spend permission.'
 lines[i]=json.dumps(d,ensure_ascii=False,separators=(',',':'));break
else:raise AssertionError('missing work')
work.write_text('\n'.join(lines)+'\n')
print('FAILED_ATTEMPT_SEALED',len(members),'members',archivePath.stat().st_size,'archive bytes')
