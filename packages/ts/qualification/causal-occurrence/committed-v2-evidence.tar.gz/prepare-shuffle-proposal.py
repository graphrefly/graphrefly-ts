from pathlib import Path
import difflib,json,hashlib
root=Path('/Users/davidchenallio/src/graphrefly-ts');out=Path(__file__).parent
name='packages/ts/src/__tests__/solutions-agentic-memory-work-item-root-eval-live.test.ts'
s=(root/name).read_text()
start=s.index('\tit("qualifies every development-3 shuffle against its own bank and rejects rebinding or bank reuse"')
end=s.index('\n\tit("binds discriminant-only relevant and incompatible irrelevant source Work Items"',start)
old=s[start:end]
helper=old[old.index('\t\tconst permutations ='):old.index('\t\tlet qualified =')]
body=old[old.index('\t\t\tconst create ='):old.index('\n\t\t}\n\t\texpect(qualified)')]
body=body.replace('\t\t\tqualified += 1;\n','').replace('\t\t\t\tcontinue;','\t\t\t\treturn;')
body='\n'.join(line[1:] if line.startswith('\t') else line for line in body.splitlines())
tail=old[old.index('\t\texpect(rootEvalVariantOrderSupportsIrrelevantControls'):old.rfind('\n\t});')]
new='\tconst developmentThreeOrders = (() => {\n'+helper+'\t\treturn permutations([0, 1, 2, 3, 4]);\n\t})();\n\n'
new+='\tit("enumerates all 120 supported development-3 shuffles and retains bank support controls", () => {\n'
new+='\t\texpect(developmentThreeOrders).toHaveLength(120);\n\t\texpect(new Set(developmentThreeOrders.map((order) => order.join(","))).size).toBe(120);\n'
new+='\t\tfor (const order of developmentThreeOrders)\n\t\t\texpect(rootEvalVariantOrderSupportsIrrelevantControls(order, "development-3")).toBe(true);\n'
new+=tail+'\n\t});\n\n'
new+='\tit.each(developmentThreeOrders.map((variantOrder) => ({ variantOrder, label: variantOrder.join(",") })))(\n'
new+='\t\t"qualifies development-3 shuffle $label against its own bank and rejects rebinding or bank reuse",\n'
new+='\t\t({ variantOrder }) => {\n'
new+='\n'.join('\t'+line for line in body.splitlines())+'\n\t\t},\n\t);\n'
candidate=s[:start]+new+s[end:]
(out/'shuffle-parameterization-proposal.test.ts').write_text(candidate)
patch=''.join(difflib.unified_diff(s.splitlines(True),candidate.splitlines(True),fromfile='a/'+name,tofile='b/'+name))
(out/'shuffle-parameterization-proposal.patch').write_text(patch)
sha=lambda b:'sha256:'+hashlib.sha256(b).hexdigest()
(out/'shuffle-proposal.json').write_text(json.dumps({'status':'unapplied proposal for review; not implementation or qualification','file':name,'sourceDigest':sha(s.encode()),'candidateDigest':sha(candidate.encode()),'patchDigest':sha(patch.encode()),'scope':'One existing offline test reorganized into one enumeration/support control plus120 serial parameterized cases. No fixture/verifier/runtime/provider/seed/bank changes.','preserved':'All120 orders, fresh VM isolation, original per-manifest candidate/public/hidden/rebinding/disjointness assertions, negative bank-support checks. Existing default per-test5000ms remains.','changedAcceptanceBoundary':'Original5000ms watchdog for all120 orders becomes5000ms for each order and the enumeration case. Explicit user review required; this does NOT reduce total verification work or qualify the old aggregate watchdog.','expectedSoakCaseCount':221,'notExecuted':True,'noCheckoutWrite':True},indent=2)+'\n')
print('UNAPPLIED_PROPOSAL_PREPARED')
