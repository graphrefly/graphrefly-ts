from pathlib import Path
import json,hashlib,re,subprocess
root=Path('/Users/davidchenallio/src/graphrefly-ts');out=Path(__file__).parent
sha=lambda b:'sha256:'+hashlib.sha256(b).hexdigest()
old=json.loads((out/'initial-tracked-bindings.json').read_text())
base='packages/ts/evals/graph-native-rerun-avoidance/'
artifacts=['root-eval-artifact-set.json','root-eval-describe.json','root-eval-live-qualification.json','root-eval-observe-events.jsonl','root-eval-topology-qualification.json']
expected={base+'implementation-manifest.ts',*(base+'artifacts/'+x for x in artifacts)}
allowed=expected|{'plan/work.jsonl','packages/ts/qualification/causal-occurrence/README.md'}
changed={p for p,h in old.items() if not (root/p).is_file() or sha((root/p).read_bytes())!=h}
assert expected<=changed and changed<=allowed,changed
path=base+'implementation-manifest.ts'
before=subprocess.check_output(['git','show','HEAD:'+path]);after=(root/path).read_bytes()
normalize=lambda b:re.sub(rb'sha256:[0-9a-f]{64}',b'sha256:DIGEST',b)
assert normalize(before)==normalize(after)
assert len(re.findall(rb'^[+-].*sha256:',subprocess.check_output(['git','diff','--',path]),re.M))==6
for name in artifacts:
 path=base+'artifacts/'+name
 assert normalize(subprocess.check_output(['git','show','HEAD:'+path]))==normalize((root/path).read_bytes()),name
marker=json.loads((root/base/'artifacts/root-eval-artifact-set.json').read_text())
assert marker['implementationManifestDigest']==json.loads((out/'closure.json').read_text())['implementation']
for name,h in marker['files'].items():assert sha((root/base/'artifacts'/name).read_bytes())==h,name
result={'passed':True,'changedTrackedPaths':sorted(changed),'currentBindingAndArtifactPaths':sorted(expected),'productionSourceUnchanged':True,'existingQualificationEvidenceUnchanged':True,'scientificAndGrantTrackedInputsUnchanged':True,'currentArtifactChangesAreDigestOnly':True,'artifactMembersVerified':len(marker['files']),'manifestFileOnlyThreeDigestSubstitutions':True,'protectedTrackedFilesVerified':len(old)-len(allowed),'currentFiles':{p:sha((root/p).read_bytes()) for p in sorted(expected)}}
(out/'scope-verification.json').write_text(json.dumps(result,indent=2)+'\n')
print('SCOPE_VERIFICATION_DONE',len(marker['files']),'artifacts',len(old)-len(allowed),'protected tracked files')
