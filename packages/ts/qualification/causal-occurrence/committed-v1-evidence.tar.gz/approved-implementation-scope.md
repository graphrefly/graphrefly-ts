# 下一批实施范围：单 authority 的按需 committed effects 视图

2026-09-07。状态：供审阅的具体实施切片，尚未批准或执行。依据 graphrefly-ts:D163 / view-v1；C 仍由 D161 治理，普通用户五端口仍由 D162 治理。新运行代码基线为 `d9c868dc8c2cec395f96a5ae327f692cc37c6df7`。

本批建议完成一个可独立验收的结果：**调用方的同一 cold graph 中，私有只读 Node 能从正常 DATA 得到 authority 当前保留的逐 effect 记录，且无关事实不会反复构造该视图。** 将它接入后续 publication 的输入侧；本批不同时实现请求摘要编码、materializer、完整 preset、final dispatch guard 或 inbox。

这不是只加类型：实施与资格必须包括真实 cold/late subscription、退订期间入账/结果、乱序/replay/回收、原 ports 对照、运行 mutation 与完整离线检查。没有新增公开入口。

## 1. 冻结的数据边界

以下为拟实施的私有类型形状；字段只用于被动事实，不能作为可调用权限。

```ts
type RetainedEffect = Readonly<{
  proposal: CausalEffectProposal;
  admission?: CausalEffectAdmission;
  outcome?: CausalEffectOutcome;
}>;

type CommittedEffectsView = Readonly<{
  kind: "causal-committed-effects";
  authorityId: string;               // 现有 `${name}/authority` 的节点 ID
  binding: CausalBinding;             // 原四字段：contract / implementationRevision / scope / epoch
  effects: readonly RetainedEffect[];
  retention: readonly Readonly<{
    revisionDomain: string;
    floor: number;
    gapThrough: number;
  }>[];
}>;

type AuthorityEmission<T> =
  | Readonly<{ kind: "fact"; fact: AuthorityFact<T>; committedEffects: CommittedEffectsView }>
  | Readonly<{ kind: "view-change"; committedEffects: CommittedEffectsView }>;
```

本切片建议不增加 generation 计数器：同进程跳过重复投影只需同一不可变对象引用；跨序列化证据以实际内容与 exact refs 比较。view-v1 的 generation 是可选草图；省略它避免额外溢出/复位契约。记录次序沿用当前 effects Map 插入次序；retention 按 floor Map 次序，再附加仅存在于 gap Map 的 domain，不额外排序或全量求摘要。独立语义比较另按 key 归一，绝不把列表位置当身份。

`floor` 和 `gapThrough` 是现有两个状态表的数字，保留其既有含义；零作为该表的既有默认值。只列两个表实际保留的 domain，并以 union 去重。没有 `complete=true`、高水位或当前许可字段。缺少某条 effect/domain 不证明它从未出现、已取消、没有 pending 或可以重试；该视图只是当前保留记录和已知回收边界。当前性、coverage、pending conservation 仍需各自证据。

`authorityId + binding` 是定位坐标，同名跨 Graph 不因此成为同一 authority。生产消费必须由同一 cold builder 返回的真实 Node/依赖接线取得；沿用 Graph 和 exact capability 的现有检查，不能接受一个结构相同的对象来替代同图连接。无新 WeakMap 权限系统、全局 registry 或 DATA 中的 Graph 对象。

canonical proposal/admission/outcome 的深层不可变值可以直接共享；为输出新建并冻结外壳、数组与 retention 行，不能把内部 EffectRecord 或 Map 直接公开。后续写入不能修改旧视图。`EffectRecord.key` 是内部去重材料，不进入新视图。`unknown`/`reconcile-required` 原样保留，不能被映射成成功或“可再试”。

E≤maxEffects，domain 数≤maxOccurrences；原 contract 没有为每个任意 outcome.result 增加新的字节上限。因此这里只能承诺记录数量有界，不能伪称整个快照字节固定有界。本切片不私自限制原合法结果；测量需报告实际字节和较大 payload 情况。

## 2. 状态推进与发布顺序

候选唯一推进顺序：

```text
真实 arrival batch
  → transition 的同一 context（identity / lifecycle / evidence）
  → 得到最终 state、原 outputs、一次性 changed 标记
  → 在 authority 内准备/复用 CommittedEffectsView，放入该最终 state
  → authority 唯一一次 ctx.state.set
  → 原 outputs 逐条包装成 fact emission，各自按原单波方式输出
  → 仅 changed 且原 outputs 为空时输出一个 view-change emission
```

不在各个 helper 里新增 ctx.state.set，也不让投影节点决定 admission/终态。视图准备仍是 authority fn 内的固定纯投影步骤，与现有 transition helper 一样受该节点 dispatcher 调用约束；没有用户替换的回调。

`RuntimeState` 只增加一个可选的已发布视图引用；cloneState 复用该引用。`TransitionContext` 增加本次调用的一个 boolean 标记，初始 false；它不进入公共 DATA 或跨 transition 变化日志。transition 可在私有返回结构中带出该标记。

首次有实际 authority fact 或真实相关变化时准备一个视图。完全无输入、没有原 outputs 且没有改变时，不创建快照或初始化假的 empty DATA。已创建视图的纯 replay/无关事实复用原引用。一次 transition 内多个写入至多构造一份最终视图；同批 admission 与 outcome 的视图直接包含最终结果。若准备投影抛错，不能先提交或输出成功事实，旧已提交义务仍保留，沿用既有协议错误路径；不新增自动恢复。

## 3. 必须覆盖的实际变化点

基线源码锚点如下，实施时按最终 source 重新绑定。标记必须紧邻真实成功改变，不按 lane、outputs.length、Map 引用或 Map.size 猜测。

| 锚点 | 真正改变 | 标记条件 |
|---|---|---|
| lifecycle.ts:139 retainEffectProposal | 新记录 | set 实际执行；相同/冲突 replay、容量拒绝都不标记 |
| lifecycle.ts:186 flushEffectsAndTerminals | deferred admission 入账 | record.admission 原先缺失并发生替换 |
| lifecycle.ts:225 flushEffectsAndTerminals | deferred outcome 入账 | record.outcome 原先缺失且 exact 校验已通过 |
| lifecycle.ts:513 receiveEffectAdmissions | direct admission 入账 | 首次 exact admission；已有相同事实不标记 |
| lifecycle.ts:613 receiveOutcomes | direct outcome 入账 | 首次 exact outcome；错误关联不标记 |
| transition.ts:115–143 acceptOccurrence | 合法回收删除 effect、更新 floor/gap | 任一真实删除或声明的数字改变；即使无 effect 被删，范围改变也算变化 |

本切片不编辑 identity.ts/evidence.ts 的语义。对所有 effects 与两张 retention 表写入的完整清单做一次机械核对，避免上述表遗漏其他可达路径；如果发现额外路径，在同一职责内补标记并保留审计，不发明新的业务规则。pending input 的到达、删除和所有普通 evidence 改变不直接表示 effect 视图改变；它们间接引发的 deferred 接纳/回收仍由上述真实写点捕获。

## 4. 节点与文件范围

新增同图节点 `${name}/committed-effects`，factory 名建议 `causalCommittedEffectsProjection`。dep 只有该 authority；通过 depBatch 取 emission，按顺序仅对不同 view 引用发出 DATA。多 commit 不可简单压成最后一个。去重状态是该 projection 自己的派生状态，遵守 RAM 断连重建；不是业务账本。无需 replay 历史队列，正常缓存足够交付一个当前值。

private buildCausalNodes 返回值增加 committedEffects Node；原 `ports`、FullCausalCapability 的字段和两个现有 outer 返回对象不变。cold manifest、required edge 与 describe 加这一条真实依赖。增加一个 owned Node，**不为保存历史新增 root**。按基线计数，原 standalone 23 nodes 变成 24，既有组合 29 owned nodes 变成 30；测试最终按实际 describe 核对，不沿用旧收据的拓扑数字。

| 生产文件（packages/ts/src/solutions/causal-occurrence/ 下） | 有限改动 |
|---|---|
| contracts.ts | 私有 view/emission 类型、state 引用和 context 标记；不改变 contract-v2 输入/原输出类型 |
| lifecycle.ts | 五类成功接纳点标记；原判断与记录规则不变 |
| transition.ts | 初始化标记、回收标记及返回标记；原有限推进/clone 语义不改 |
| 新 committed-view.ts | 只读视图准备/复用的固定函数；无 Graph、订阅、I/O 或第二账本 |
| construction.ts | commit 前准备视图、commit 后包装、旧 projection 解包、新 Node/manifest/required-edge/private builder 返回 |

不改 ConstructionScope、node/core、wave protocol、dispatcher、capabilities.ts、公开 barrel/package exports。若这些成为必需改动，说明本切片前提已变化，应带具体冲突回到审阅，而不是扩大 C。

测试/资格范围：新增 focused test、独立 oracle/plain runner、新视图 mutations 与性能 runner；仅为最终源绑定更新既有 causal/construction/cold harness 的源码锚点和新增 Node 预期。旧 fixtures/收据/失败尝试不覆盖；生成新的 receipt 修订。现有通用 helper 性能算法、原门槛、root 业务 fixtures/许可和测试超时不修改。调用点审计须指出测试或资格脚本对 private transition 返回值与原 authority DATA 的依赖。

## 5. 验收向量

| 组 | 固定输入/操作 | 断言 |
|---|---|---|
| V1 精确记录 | 两 occurrence、两个 effect，仅一条 admitted | 逐 key proposal/admission/outcome 与独立 oracle 相同；聚合数不能替代 exact 记录 |
| V2 deferred | admission/outcome 先到，随后 occurrence/proposal/许可齐备 | pending 阶段无虚假接纳；真正 drain 后一次最终视图 |
| V3 单批终态 | 同 transition 接纳 proposal/admission/outcome | 同一提交所有 emissions 引用相同最终对象；不出现临时 admitted-only 视图 |
| V4 恢复 | 不订阅新 Node 先处理输入，最后 fact 分别为 issue/coverage/quiescence，再订阅 | 正常 DATA 给出当前记录，不窥读 cache，不依赖 kind 收尾 |
| V5 两种启动顺序 | 既有 release root 先启动；新 view consumer 先启动；热缓存和晚到输入 | 结果一致，原 root 不丢业务释放，未输入时无假值 |
| V6 UI lifecycle | 最后一位 UI 退订期间送 wrong/exact outcome，再订阅；startup fault | 错 outcome 不结算；正确只结算一次；faulted 不能变 end lifecycle/可重试 |
| V7 replay/回收 | 相同事实、冲突事实、满容量、合法回收含零 effect 情况 | 无关/重复不重建；真删除或范围变化更新；不能驱逐 active obligation |
| V8 不可变/隔离 | 持有旧视图再更新；尝试写嵌套字段；错 graph/epoch Node 接线 | 旧字节稳定；无法污染 state；真实同图/绑定边界拒绝错接 |
| V9 原行为/负对照 | 冻结基线的原八 ports、fan-out/fan-in、未触发 effect 的真实输入 | 原 ports 值与顺序等价；新增内部 emission 单列；无记录不能被宣传为 consumer no-publish |
| V10 成本 | E=1/16/64，相关变化比例 0%/1%/100%，批内多 facts、反复挂载和观测 | 重建次数符合变化，clone/hash 与控制/调度成本分别记录，所有原 gate 不放宽 |

无关更新并非随意给旧 policy 数据：必须构造能够真实进入 authority、产生不同 facts、但既不接纳 effect 又不推进声明保留边界的输入。1%/100% 工作负载须报告在容量和单调接纳限制下怎样持续推进，不得把实际未接纳的饱和 replay 算成相关变化压力。

独立 oracle 不 import transition/lifecycle/committed-view；固定接纳、exact ref、回收规则由 fixture 预期和独立归约给出。plain-code 对照必须同样承担容量、乱序、replay、记录保留与订阅恢复义务；无需模拟 Graph 的内部引用优化。mutation 分业务结果、资源、结构、不可变和工作量检测：漏任一标记；相同 replay 重建；只在某种 fact 携带 view；commit 前发送；借最新对象串 key；UI 清 state；旧版本被改写；实际断掉 authority→view。结构 bypass-only 与依赖切断分别运行，程序可运行的输出失败才计 runtime 行为检测。

本切片不含 materializer，因此不声称验证了精确 payload join 或实际授权路径；wrong source/payload 的完整 consumer 检验保留为后续义务。人/agent 包仍需要相同有限输入、真实图/源码版本、独立结果、mutation 分类与原始性能；没有可运行 preset 时不做假普通用户成功评分。

## 6. 性能与全量离线资格

保留原 ts-v4 matched construction ≤1.20、steady ≤1.10 的四行 gate；另与当前 `d9c868dc` 同物理资源口径对照，两个基线分别报告。当前基线没有新增 view 功能，不能将原端口性能对照称为同功能实现竞争；新功能与等价 plain-code 的语义/资源比较另列。

新增确定性预算：初始化后无相关改变，视图构造次数=0、视图深 clone/hash=0、专用收尾 wave=0；每个相关 commit 构造次数≤1；一个提交的所有 facts 共用 view 引用；不因 UI 数量多建 authority。新增 Node 在活跃时仍会计算及产生控制波，不能承诺零额外 dispatcher 次数。相关更新浅投影 O(E+D)；较大 canonical payload 共享引用，但观测/JSON 序列化按实际 B bytes 测量。至少加入代表性小结果、4 KiB 和64 KiB 结果的描述性测量，不把未来 inbox 单条 4 KiB 限制误套到所有 contract-v2 outcome 上。

原有所有适用离线测试必须运行：focused + default 全量、显式 root soak、browser、lint/typecheck、build/export、离线 artifact、原 causal/construction/cold mutations、冻结原 runtime 对照、资源和预算检查，以及 owner/workspace/dashboard。保留失败尝试、所有批次、超时和原始 ns/bytes；不得挑选最好一次。资格证据绑定最终输入闭包和源码，不改历史收据的含义。

新增功能不合格时不得通过换基线、静默关闭必要观测、改门槛、丢 active 记录、借旧 C 通过结论或继续扩张存储层解决。回报具体失败与可比较的下一方案。

## 7. 本轮 Q5–Q9 与批准边界

- Q5：一个私有 solution 投影，消费者得到的仍是 Node；无新 kernel 抽象，类型字段只描述现有已提交记录。
- Q6：成功写点标记、旧版本不可变和先提交后输出是长期维护不变量；省略可选 generation，保留真实字节成本限制。
- Q7：真实 lanes → authority → view → sink；同图冷构造、无 collector-first 顺序、无 cache 偷读或外部 imperative 回灌。
- Q8：沿用已批准的共享视图方案；相较仅增量事件，不需要连续日志/ack/pull 机制；相较每次 full snapshot，避免无关输入重建。此次不再重开已选择的三方案比较。
- Q9：建议采用上列五个生产文件的有限实施与完整离线资格。设计覆盖恢复/保留/低额外工作目标；实际性能、所有写点覆盖和原端口等价仍需跑出来。普通用户完整输入准备、materializer、真实 inbox 和五端口展示继续保持未完成。

拟实施 work outcome：实现并验收一个从正常 DATA 恢复当前保留记录、只在相关改变时重建的私有 committed effects Node。唯一 owner graphrefly-ts；依赖已完成 CAUSAL-COMMITTED-VIEW-DESIGN-TS/view-v1 与 CAUSAL-COLD-ASSEMBLY-TS/cold-v1。此处只定义 outcome 与范围，不预先创建实施记录或执行授权。

若用户批准此精确范围，登记一个 implementation-slice 并执行上述无网络开发/离线资格；沿用当前任务的非决策批准记录，不为执行批准制造 D#。既有“记得 commit”授权继续适用，经检查后提交本批结果。不自动运行 provider/live/spend、实际 inbox，不改 wave protocol，不启动下一批 consumer 工作。
