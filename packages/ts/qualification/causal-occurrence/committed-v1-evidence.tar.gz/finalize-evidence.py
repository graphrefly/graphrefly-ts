import pathlib,hashlib,json,subprocess,tarfile,gzip,io
r=pathlib.Path('/Users/davidchenallio/src/graphrefly-ts')
b=pathlib.Path('/Users/davidchenallio/.codex/visualizations/2026/09/06/01a077c7-55e6-7f11-9d4f-e7c51944afb4/committed-view-implementation')
q=r/'packages/ts/qualification/causal-occurrence'
def sha(p): return 'sha256:'+hashlib.sha256(p.read_bytes()).hexdigest()
def read(n): return json.loads((b/n).read_text())
required=['root-soak','default-tests','final-lint','build-exports','browser','artifacts','view-observe-comparison','view-mutations-first','original-causal-mutations-third','old-construction-mutations','cold-mutations-final','matched-perf-final','frozen-standalone','current-standalone','helper','incoming','resources','resource-verifier']
for n in required: assert (b/(n+'.check.json')).exists(),n
prod=['packages/ts/src/solutions/causal-occurrence/'+n+'.ts' for n in ['contracts','lifecycle','transition','committed-view','construction']]
changed=subprocess.check_output(['git','diff','--name-only'],cwd=r,text=True).splitlines()
actual=[p for p in changed if p.startswith('packages/ts/src/') and '/__tests__/' not in p]
assert set(actual)==set(prod)-{'packages/ts/src/solutions/causal-occurrence/committed-view.ts'},actual
perfBinding=read('matched-perf-final.bindings.json')
assert all(perfBinding['after'][p]==sha(r/p) for p in prod)
scope=pathlib.Path(read('authorization.json')['scopePath'])
assert sha(scope)==read('authorization.json')['scopeDigest']
(b/'approved-implementation-scope.md').write_bytes(scope.read_bytes())
diff=subprocess.check_output(['git','diff','--',*prod],cwd=r)
diff+=b'\nNEW FILE committed-view.ts\n'+(r/prod[3]).read_bytes()
(b/'production.diff').write_bytes(diff)
checks=[]
for p in sorted(b.glob('*.check.json')):
 d=json.loads(p.read_text());name=d['id'];binding=b/(name+'.bindings.json')
 d['bindingFile']=binding.name;d['bindingDigest']=sha(binding);checks.append(d)
# Preserve every development failure, interrupted attempt, raw sample, binding and exact qualified runner.
members=[p for p in b.iterdir() if p.is_file() and p.suffix in ['.json','.log','.mjs','.mts','.md','.diff','.py']]
archive=q/'committed-v1-evidence.tar.gz'
index={p.name:{'digest':sha(p),'bytes':p.stat().st_size} for p in sorted(members)}
with archive.open('wb') as out:
 with gzip.GzipFile(filename='',mode='wb',fileobj=out,mtime=0,compresslevel=6) as compressed:
  with tarfile.open(fileobj=compressed,mode='w') as tar:
   for p in sorted(members):
    data=p.read_bytes();info=tarfile.TarInfo(p.name);info.size=len(data);info.mtime=0;info.mode=0o644;tar.addfile(info,io.BytesIO(data))
scripts=[p.as_posix() for p in pathlib.Path('scripts').glob('*.mjs') if p.name in ['compare-causal-cold-standalone.mjs','compare-causal-construction.mjs','compare-causal-required-edges.mjs','qualify-causal-cold-assembly.mjs','qualify-causal-occurrence.mjs','compare-causal-committed-view.mjs','qualify-causal-committed-view.mjs']]
extra=['scripts/fixtures/causal-committed-oracle.mjs','package.json','pnpm-lock.yaml','packages/ts/package.json','docs/design/causal-committed-view-v1.md','docs/design/causal-committed-view-v1.json']
files={p.relative_to(r).as_posix():sha(p) for p in sorted((r/'packages/ts/src').rglob('*')) if p.is_file()}
for name in scripts+extra:files[name]=sha(r/name)
review=q/'committed-v1-review.md';files[review.relative_to(r).as_posix()]=sha(review)
files[archive.relative_to(r).as_posix()]=sha(archive)
receipt={
 'schema':'graphrefly-ts/causal-committed-view-evidence/v1','artifactRef':'graphrefly-ts:causal-committed-view-evidence','revision':'committed-v1','workRef':'graphrefly-ts:CAUSAL-COMMITTED-VIEW-TS','owner':'graphrefly-ts','date':'2026-09-07','status':'qualification-failed',
 'statusReason':'Original construction/steady budgets failed; current source also invalidates the prior D159 qualification, causing two default tests and the artifact gate to fail. Work remains incomplete.',
 'governingRefs':['graphrefly-ts:D160','graphrefly-ts:D161','graphrefly-ts:D162','graphrefly-ts:D163'],
 'authorization':read('authorization.json'),'authorizationDigest':sha(b/'authorization.json'),
 'provenance':{'implementationActor':'Codex assistant','humanApproval':'user explicitly 批准 the exact attached implementation scope; earlier 记得 commit remains applicable','baselineCommit':'1bf11e6cdd2c66dbc8907685c25aeca0b6068ba5','runtimeBaselineCommit':'d9c868dc8c2cec395f96a5ae327f692cc37c6df7','candidateBranch':'codex/causal-committed-view','bindingMeaning':'File hashes bind the candidate content before its containing commit; neither CausalBinding nor this receipt grants effect execution.'},
 'productionFiles':prod,'productionDiff':index['production.diff'],'files':files,
 'evidenceBundle':{'path':archive.relative_to(r).as_posix(),'digest':sha(archive),'format':'gzip tar; lossless raw UTF-8 reports/logs and exact runner snapshots','members':index},
 'checks':checks,
 'coverage':{'newFocusedTests':18,'default':{'passed':2255,'failed':2,'skipped':4},'offlineRootSoak':{'passed':101},'mutations':{'new':11,'newDeferredWriteAdjacencyAudits':2,'causal':73,'construction':25,'coldCategorized':16},'plainComparisons':12,'hotInputOrders':2,'measurementRowsPerArm':33,'arms':['temporary work counters/profile','unmodified runtime timings'],'helperCases':168,'incomingCases':144,'resourceSnapshots':12,'resourceNegativeControls':2},
 'performance':read('matched-performance-gate.json'),
 'sourceQualificationDrift':read('root-manifest-drift.json'),
 'qualificationRunnerSnapshots':{'causal-mutations-qualified-third.mjs':'Exact pre-format runner digest matches successful 73-mutation report; final source differs only in formatting.','comparison-qualified-third.mjs':'Prior successful raw authority subscription workload retained separately from the final real graph.observe matrix.','oracle-qualified-third.mjs':'Exact oracle bytes for that prior successful report.','matched-perf-first-interrupted-bundle.mjs':'Interrupted before performance sampling; retained solely as an attempt.'},
 'review':read('static-review.json'),
 'postSealValidationPath':'packages/ts/qualification/causal-occurrence/committed-v1-validation.json',
 'nonClaims':['Complete qualification or readiness for downstream work','Performance regression root cause or a noise excuse','Per-effect O(1) runtime or byte-bounded arbitrary outcome payloads','Every deferred marker individually load-bearing in the exercised graph paths','Full malformed-input plain-code equivalence','Ordinary user five-port/preset usability or human understanding verified','Exact materializer/join, actual host/inbox authorization, provider/live/spend or B121 completion','A renewed D159 source qualification or changed execution permission']
}
receiptPath=q/'committed-v1-receipt.json';receiptPath.write_text(json.dumps(receipt,ensure_ascii=False,indent='\t')+'\n')
p=r/'plan/work.jsonl';lines=p.read_text().splitlines()
for number,line in enumerate(lines):
 row=json.loads(line)
 if row['id']=='CAUSAL-COMMITTED-VIEW-TS':
  row['status']='planned'
  row['evidence_refs']=[{'ref':receiptPath.relative_to(r).as_posix(),'digest':sha(receiptPath)},{'ref':review.relative_to(r).as_posix(),'digest':sha(review)}]
  row['note']+=' Implementation and all applicable offline checks executed under the exact approval. Qualification failed: construction ratios 1.201307/1.200487 exceed 1.20 and 1000-background steady ratio 1.839833 exceeds 1.10. Default 2255 pass/2 fail/4 opt-in skips and artifact rejection correctly reflect D159 prior-source qualification drift; baseline src matches old digest and exactly eight changed source/test files invalidate it. D159 qualification/permission records were preserved. 101 offline soak, 73+25+16 original mutations, 11 new categorized mutations, finite plain/oracle recovery and work-count/observation measurements, browser, lint/typecheck and build/export pass. committed-v1 retains the failed budgets and all attempts; planned is not complete or downstream authorization. Candidate commit authorized by earlier 记得 commit; branch codex/causal-committed-view preserves main baseline. Next bounded review must address performance failure and current offline qualification binding without silently expanding C, changing budgets, public API or wave protocol.'
  lines[number]=json.dumps(row,ensure_ascii=False,separators=(',',':'))
p.write_text('\n'.join(lines)+'\n')
print(json.dumps({'receipt':str(receiptPath),'digest':sha(receiptPath),'bundleBytes':archive.stat().st_size,'sourceBindings':len(files),'checks':len(checks),'status':receipt['status']}))
