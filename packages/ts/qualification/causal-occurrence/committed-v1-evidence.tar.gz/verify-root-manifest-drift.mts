import { readFileSync, readdirSync, existsSync, writeFileSync } from 'node:fs';
import { join } from 'node:path';
import { measureCurrentImplementationInputs, CURRENT_IMPLEMENTATION_RUNTIME, CURRENT_IMPLEMENTATION_MANIFEST_DIGEST } from '/Users/davidchenallio/src/graphrefly-ts/packages/ts/evals/graph-native-rerun-avoidance/implementation-manifest.ts';
import { empiricalSha256, empiricalStrictJsonDigest } from '/Users/davidchenallio/src/graphrefly-ts/packages/ts/evals/graph-native-rerun-avoidance/canonical.ts';
const base='/Users/davidchenallio/.codex/visualizations/2026/09/06/01a077c7-55e6-7f11-9d4f-e7c51944afb4/committed-view-implementation';
const current=await measureCurrentImplementationInputs();const before={...current};
const prefix='runtime/packages/ts/src/';for(const k of Object.keys(before))if(k.startsWith(prefix))delete before[k];
function walk(dir,rel=''){for(const entry of readdirSync(dir,{withFileTypes:true})){const name=rel+entry.name;if(entry.isDirectory())walk(join(dir,entry.name),name+'/');else if(name.endsWith('.ts'))before[prefix+name]=empiricalSha256(readFileSync(join(dir,entry.name)));}}
walk(base+'/baseline-src');
const digest=sources=>empiricalStrictJsonDigest({revision:'graphrefly-ts.d159.current-implementation-manifest.v78',runtime:CURRENT_IMPLEMENTATION_RUNTIME,sources});
const result={expected:CURRENT_IMPLEMENTATION_MANIFEST_DIGEST,baseline:digest(before),candidate:digest(current),baselineMatched: digest(before)===CURRENT_IMPLEMENTATION_MANIFEST_DIGEST,changed:Object.keys({...before,...current}).filter(k=>before[k]!==current[k]).map(k=>({path:k,before:before[k]??null,after:current[k]??null})),meaning:'Same current eval/toolchain inputs with baseline src bytes substituted; eval and toolchain files were untouched by this slice. No manifest or qualification constant changed.'};
writeFileSync(base+'/root-manifest-drift.json',JSON.stringify(result,null,2)+'\n');console.log(JSON.stringify({expected:result.expected,baseline:result.baseline,candidate:result.candidate,baselineMatched:result.baselineMatched,changed:result.changed.length}));
