import { evaluationWithAmounts,evaluationPack,presetRun,presetBinding } from '/Users/davidchenallio/src/graphrefly-ts/scripts/fixtures/spending-preset-harness.ts';
import { oracleBusiness,verifyBusiness } from '/Users/davidchenallio/src/graphrefly-ts/scripts/fixtures/spending-preset-oracle.ts';
import { plainBusiness } from '/Users/davidchenallio/src/graphrefly-ts/scripts/fixtures/spending-preset-plain.ts';
const cases = [[999999999.9999999,1e9,999999999.9999999],[999999999.9999999,999999999.9999999,1e9],[100,140]];
const result=[];
for(const amounts of cases){const e=evaluationWithAmounts(amounts),r=presetRun();try{r.send('pack',evaluationPack([e]));r.send('arrivals',{packRef:presetBinding.packRef,evaluationRefs:[e.evaluationRef]}); const observed=r.events.assessment.flatMap((f:any)=>f.rows).at(-1).value; result.push({amounts,evaluation:e,observed,plain:plainBusiness(e),oracle:oracleBusiness(e),verified:verifyBusiness(e,observed),plainVerified:verifyBusiness(e,plainBusiness(e)),effects:[...r.state().effects.values()],effectExecuted:false});}finally{r.cleanup()}}
console.log(JSON.stringify({kind:'numeric-semantic-preflight',qualified:false,result},null,2));
