"""Account for every attributed sample; never subtract stalls from the qualification score."""
import json,math,statistics,hashlib,sys,collections
from pathlib import Path
b=Path(__file__).parent
smoke='--smoke' in sys.argv
intervalFile=b/('smoke-intervals.json' if smoke else 'full/intervals.json')
traceFile=b/('smoke-v8.json' if smoke else 'full/v8-trace.json')
reportFile=b/('smoke-result.json' if smoke else 'full-report.json')
output=b/('smoke-analysis.json' if smoke else 'analysis.json')
a=json.loads(intervalFile.read_text());v=json.loads(traceFile.read_text());r=json.loads(reportFile.read_text())
q=lambda xs,p=.5:sorted(xs)[max(0,math.ceil(len(xs)*p)-1)]
anchors=[]
for x in a['traceAnchors']:
 lo=int(x['monotonicBeforeNs'])/1e6-x['performanceMs'];hi=int(x['monotonicAfterNs'])/1e6-x['performanceMs']
 anchors.append({'offsetLowMs':lo,'offsetHighMs':hi,'uncertaintyUs':(hi-lo)*1000})
offsetLow=max(x['offsetLowMs'] for x in anchors);offsetHigh=min(x['offsetHighMs'] for x in anchors)
assert offsetLow<=offsetHigh,'clock anchor bounds do not intersect'
offset=(offsetLow+offsetHigh)/2;clockUncertaintyMs=(offsetHigh-offsetLow)/2
assert abs(statistics.mean([anchors[0]['offsetLowMs'],anchors[0]['offsetHighMs']])-statistics.mean([anchors[1]['offsetLowMs'],anchors[1]['offsetHighMs']]))<1,'clock offset changed over 1ms'
threadIds={e['tid'] for e in v['traceEvents'] if e['name']=='thread_name' and e.get('args',{}).get('name')=='JavaScriptMainThread'}
if not threadIds:threadIds={e['tid'] for e in v['traceEvents'] if e['name']=='thread_name' and e.get('args',{}).get('name') in ['MainThread','main','NodeMainThread']}
assert len(threadIds)==1,threadIds
thread=next(iter(threadIds));stacks=collections.defaultdict(list);gc=[];deopt=[]
for e in v['traceEvents']:
 if e['tid']!=thread:continue
 if e['name'] in ['MinorGC','MajorGC']:
  if e['ph']=='B':stacks[e['name']].append(e)
  if e['ph']=='E':
   assert stacks[e['name']],e
   start=stacks[e['name']].pop();gc.append({'name':e['name'],'start':start['ts']/1000-offset,'end':e['ts']/1000-offset,'durationMs':(e['ts']-start['ts'])/1000})
 elif e['name']=='V8.DeoptimizeCode' and e['ph']=='X':deopt.append({'name':e['name'],'start':e['ts']/1000-offset,'end':(e['ts']+e.get('dur',0))/1000-offset})
assert all(not x for x in stacks.values())
gc.sort(key=lambda x:x['start'])
def overlaps(events,start,end):return [e for e in events if e['start']<end and e['end']>start]
def union_ms(events,start,end):
 intervals=sorted((max(start,e['start']),min(end,e['end'])) for e in events);total=0;stop=start
 for l,h in intervals:
  if h>stop:total+=h-max(l,stop);stop=max(h,stop)
 return total
rows=[]
for rowIndex,row in enumerate(r['performanceRows']):
 # Three reduced smoke scenarios have identical coordinates, so partition by ordinal samples.
 if smoke:
  cr=[x for x in a['runs'] if x['phase']=='construction'][rowIndex*18:(rowIndex+1)*18]
  sr=[x for x in a['runs'] if x['phase']=='steady'][rowIndex*6:(rowIndex+1)*6]
 else:
  matched=[x for x in a['runs'] if (x['count'],x['evidence'],x['background'])==(row['count'],row['evidence'],row['background'])]
  cr=[x for x in matched if x['phase']=='construction'];sr=[x for x in matched if x['phase']=='steady']
  assert len(cr)==1800;assert len(sr)==(18 if row['count']==64 else 30)
 expected=next(x['lanes'] for x in a['arrivals'] if x['count']==row['count'] and x['evidence']==row['evidence'])
 arms=[]
 for candidate in [False,True]:
  cs=[x for x in cr if x['candidate']==candidate];ss=[x for x in sr if x['candidate']==candidate]
  key='candidate' if candidate else 'baseline';ct=[(x['constructionEnd']-x['constructionStart'])*1e6 for x in cs];st=[q(x['timings'],.95) for x in ss]
  assert ct==row['construction'][key],('construct mismatch',rowIndex,key)
  assert st==row['steady'][key],('steady mismatch',rowIndex,key)
  details=[];arrivalCount=0;inputGC=0;inputGcMs=0;phaseMs=collections.defaultdict(float);phaseGC=collections.defaultdict(float)
  for x in cs+ss:
   intervals=[('setup',x['runStart'],x['constructionStart']),('construction',x['constructionStart'],x['constructionEnd']),('subscribe',x['constructionEnd'],x['describeStart']),('describe',x['describeStart'],x['inputsStart']),('inputs',x['inputsStart'],x['cleanupStart']),('cleanup',x['cleanupStart'],x['runEnd'])]
   for phase,start,end in intervals:phaseMs[phase]+=end-start;phaseGC[phase]+=union_ms(overlaps(gc,start,end),start,end)
  for x in ss:
   assert len(expected)==len(x['starts'])==len(x['timings'])
   arrivalCount+=len(x['starts'])
   ranked=sorted(range(len(x['timings'])),key=lambda i:x['timings'][i]);p95index=ranked[math.ceil(.95*len(ranked))-1]
   for i,start in enumerate(x['starts']):
    end=start+x['timings'][i]/1e6;gs=overlaps(gc,start,end)
    if gs:inputGC+=1;inputGcMs+=union_ms(gs,start,end)
   i=p95index;start=x['starts'][i];end=start+x['timings'][i]/1e6;gs=overlaps(gc,start,end)
   details.append({'pair':x['pair'],'inputIndex':i,'lane':expected[i],'startMs':start,'p95Ns':x['timings'][i],'gcOverlapMs':union_ms(gs,start,end),'gc':gs,'deopt':overlaps(deopt,start,end),'runCpuUs':x['cpu'],'runWallMs':x['runEnd']-x['runStart']})
  constructTail=[]
  for x in cs:
   ns=(x['constructionEnd']-x['constructionStart'])*1e6
   if ns>=q(ct,.95):
    gs=overlaps(gc,x['constructionStart'],x['constructionEnd'])
    constructTail.append({'batch':x['batch'],'pair':x['pair'],'durationNs':ns,'startMs':x['constructionStart'],'gcOverlapMs':union_ms(gs,x['constructionStart'],x['constructionEnd']),'gc':gs,'deopt':overlaps(deopt,x['constructionStart'],x['constructionEnd'])})
  arms.append({'candidate':candidate,'constructionP95Ns':q(ct,.95),'steadyMedianP95Ns':q(st),'perRunP95':details,'constructionTopFivePercent':constructTail,'inputCount':arrivalCount,'gcOverlappingInputCount':inputGC,'gcOverlapInputMs':inputGcMs,'totalPhaseMs':dict(phaseMs),'totalPhaseGcMs':dict(phaseGC)})
 rows.append({'count':row['count'],'evidence':row['evidence'],'background':row['background'],'constructionRatio':row['construction']['ratio'],'steadyRatio':row['steady']['ratio'],'rawThresholdsMet':row['construction']['ratio']<=1.2 and row['steady']['ratio']<=1.1,'arms':arms})
summary={'meaning':'All original-layout diagnostic samples retained; overlap is an observed stall in this run, never retrospective proof for old report or a GC-subtracted qualification score.','anchors':anchors,'clockOffsetMs':offset,'clockUncertaintyMs':clockUncertaintyMs,'gcMainThreadEvents':len(gc),'traceSpanMs':[(min(e['ts'] for e in v['traceEvents'] if e['tid']==thread and e['ph']!='M')/1000-offset),(max(e['ts'] for e in v['traceEvents'] if e['tid']==thread and e['ph']!='M')/1000-offset)],'sampleRangeMs':[min(x['runStart'] for x in a['runs']),max(x['runEnd'] for x in a['runs'])],'thresholds':{'construction':1.2,'steady':1.1},'originalQualificationStillFailed':True,'rows':rows,'sourceDigests':{str(p.relative_to(b)):'sha256:'+hashlib.sha256(p.read_bytes()).hexdigest() for p in [intervalFile,traceFile,reportFile]}}
assert summary['traceSpanMs'][0]<=summary['sampleRangeMs'][0] and summary['traceSpanMs'][1]>=summary['sampleRangeMs'][1], 'trace file does not cover complete sample range'
output.write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps({'rows':[{k:v for k,v in x.items() if k!='arms'} for x in rows],'gcMainThreadEvents':len(gc),'anchors':anchors},indent=2))
