
import assert from 'node:assert/strict';
import { performance } from 'node:perf_hooks';
import { writeFileSync } from 'node:fs';
import { Graph as ReferenceGraph } from '/var/folders/1k/6k95mf1117q9_klyvs61pml00000gn/T/attribution-smoke-BYaarZ/reference/graph/graph.ts';
import { causalOccurrenceBundle as referenceBundle } from '/var/folders/1k/6k95mf1117q9_klyvs61pml00000gn/T/attribution-smoke-BYaarZ/reference/solutions/causal-occurrence.ts';
import { Graph } from '/Users/davidchenallio/src/graphrefly-ts/packages/ts/src/graph/graph.ts';
import { causalOccurrenceBundle, causalOccurrenceDigest } from '/Users/davidchenallio/src/graphrefly-ts/packages/ts/src/solutions/causal-occurrence.ts';
import { constructionOf, prepareConstruction, startConstruction } from '/Users/davidchenallio/src/graphrefly-ts/packages/ts/src/graph/construction-scope.ts';
const lanes = ['occurrences','admissions','branch-terminals','effect-proposals','effect-admissions','effect-outcomes','evidence','watermarks'];
const props = ['occurrences','admissions','branchTerminals','effectProposals','effectAdmissions','effectOutcomes','evidence','watermarks'];
const opts = {name:'causal',requiredBranches:['a','b'],requiredEvidenceKinds:['proof'],maxOccurrences:64,maxPending:512,maxEffects:64,maxEvidence:512};
const ok = value => ({kind:'ok',value});
const issue = {kind:'issue',code:'failed',message:'failed'};
function trace(count, evidenceCount, reverse, capacity = 64) {
 const arrivals=[];
 const send=(lane, ...values)=>arrivals.push({lane,values});
 for(let i=1;i<=count;i++) {
  const raw={revisionDomain:'run',occurrenceId:'occ-'+i,revision:i,sourceRefs:[{kind:'input',id:'input-'+i}],value:i};
  const occurrence={...raw,digest:causalOccurrenceDigest(raw)};
  const decision={occurrence,decisionId:'decision-'+i,decisionDigest:'sha256:'+'a'.repeat(64),state:'admitted'};
  const proposal={occurrence,effectId:'effect-'+i,requestRef:{kind:'request',id:'request-'+i},proposalDigest:'sha256:'+'b'.repeat(64)};
  const admission={...proposal,state:'admitted',admissionRef:{kind:'admission',id:'admission-'+i}};
  send('occurrences',occurrence); send('admissions',decision);
  send('watermarks',{revisionDomain:'run',revision:i});
  send('branch-terminals',...['a','b'].map(branch=>({occurrence,branch,state:'completed',result:ok(branch)})));
  send('effect-proposals',proposal); send('effect-admissions',admission);
  send('effect-outcomes',{...admission,admissionRef:{kind:'admission',id:'wrong'},state:'failed',result:{kind:'error',error:issue}});
  send('effect-outcomes',{...admission,state:'succeeded',result:ok(i)});
  for(let j=0;j<Math.floor(evidenceCount/count);j++)send('evidence',{occurrence,evidenceKind:'proof',evidenceId:'proof-'+i+'-'+j,evidenceDigest:'sha256:'+'c'.repeat(64),coverage:'included'});
  send('occurrences',occurrence); send('admissions',decision);
 }
 if(reverse)arrivals.reverse();
 return {arrivals,options:{...opts,maxOccurrences:capacity,maxEvidence:Math.max(1,evidenceCount)},count,evidenceCount,reverse,capacity};
}

const originalPorts=['released','currentness','terminals','conservation','coverage','quiescence','issues'];
const percentile=(xs,p)=>[...xs].sort((a,b)=>a-b)[Math.max(0,Math.ceil(xs.length*p)-1)];
const attributedRuns=[];let attributionContext;
const traceAnchor=performance.mark('causal-attribution-start');
function run(candidate, scenario, background=0) {
 const record=attributionContext;const runStart=performance.now();
 const cpuStart=record?process.cpuUsage():undefined;
 const heapStart=record?process.memoryUsage().heapUsed:undefined;
 const g=candidate?new Graph():new ReferenceGraph(); const stops=[];
 const retain=g.retain.bind(g);g.retain=(n,o)=>{const stop=retain(n,o);stops.push(stop);return stop;};
 for(let i=0;i<background;i++)g.node([],null,{name:'background/'+i});
 const inputs=Object.fromEntries(props.map(prop=>[prop,g.node([],null,{name:'source/'+prop})]));
 const start=performance.now();
 const ports=(candidate?causalOccurrenceBundle:referenceBundle)(g,{...scenario.options,...inputs});
 if(!candidate) {
  // Same physical resources and startup fact deliveries; old runtime has no C ownership guarantee.
  const startup=g.node([],null,{name:'causal/startup',factory:'graphConstructionStartup',initial:{kind:'graph-startup',instance:'causal',epoch:1,state:'starting'}});
  g.node([ports.quiescence],()=>{}, {name:'causal/causal-quiescence',factory:'causalLifecycleQuiescence'});
  g.node([g.find('causal/authority')],()=>{}, {name:'causal/committed-effects',factory:'causalCommittedEffectsProjection'});
  g.retain(startup); startup.down([['DATA',{kind:'graph-startup',instance:'causal',epoch:1,state:'started'}]]);
 }
 const constructionEnd=performance.now();const constructionNs=(constructionEnd-start)*1e6;
 const events=[];const timings=[];const starts=[];
 for(const port of originalPorts)stops.push(ports[port].subscribe(m=>{if(m[0]!=='START')events.push([port,m[0],m.length>1?m[1]:null]);}));
 const describeStart=performance.now();const shape=g.describe().nodes.map(({id,factory,deps})=>({id,factory,deps})).sort((a,b)=>a.id.localeCompare(b.id));
 const inputsStart=performance.now();for(const arrival of scenario.arrivals){const t=performance.now();inputs[props[lanes.indexOf(arrival.lane)]].down(arrival.values.map(v=>['DATA',v]));timings.push((performance.now()-t)*1e6);if(record)starts.push(t);}
 const cleanupStart=performance.now();for(const stop of stops.reverse())stop();
 for(const lease of constructionOf(g,'causal')?.roots??[])lease.unsubscribe?.();
 const group=g.topologyGroup();for(const n of g.describe().nodes)group.add(g.find(n.id));group.release();
 assert.equal(g.describe().nodes.length,0);
 const runEnd=performance.now();
 if(record)attributedRuns.push({...record,candidate,count:scenario.count,evidence:scenario.evidenceCount,background,
 runStart,constructionStart:start,constructionEnd,describeStart,inputsStart,cleanupStart,runEnd,
 starts,timings,heapStart,heapEnd:process.memoryUsage().heapUsed,cpu:process.cpuUsage(cpuStart)});
 return {events,shape,constructionNs,timings};
}
const scenarios=[trace(1,0,false),trace(1,0,false),trace(1,0,false)];
const comparisons=[];
for(const scenario of scenarios){console.log("trace",scenario.count,scenario.evidenceCount,scenario.reverse);const a=run(false,scenario),b=run(true,scenario);assert.deepEqual(b.events,a.events);assert.deepEqual(b.shape,a.shape);comparisons.push({count:scenario.count,evidence:scenario.evidenceCount,reverse:scenario.reverse,capacity:scenario.capacity,matched:true,events:b.events.length,nodes:b.shape.length});}
function paired(scenario, background=0) {
 console.log("paired",scenario.count,scenario.evidenceCount,background);
 const empty={...scenario,arrivals:[]};const a=[],b=[],constructionBatches=[];
 // Freeze the sampling layout before results: three alternating construction batches,
 // independently warmed full-trace pairs for steady state. Never retain whole traces.
 // Revision 2: 100 warm pairs and 300 measured pairs per batch reduce JIT/GC noise
 // observed with 6/30. Keep the prior report; unchanged 1.20/1.10 budgets apply.
 for(let batch=0;batch<3;batch++){
  for(let i=0;i<2;i++){run(false,empty,background);run(true,empty,background);}
  const aa=[],bb=[];
  for(let i=0;i<3;i++){attributionContext={phase:'construction',batch,pair:i};if((i+batch)%2){bb.push(run(true,empty,background).constructionNs);aa.push(run(false,empty,background).constructionNs);}else{aa.push(run(false,empty,background).constructionNs);bb.push(run(true,empty,background).constructionNs);}}
  attributionContext=undefined;a.push(...aa);b.push(...bb);constructionBatches.push({baseline:aa,candidate:bb,ratio:percentile(bb,.95)/percentile(aa,.95)});
 }
 const da=[],db=[];const pairs=scenario.count===64?3:3;
 for(let i=0;i<2;i++){run(false,scenario,background);run(true,scenario,background);}
 const measure=candidate=>percentile(run(candidate,scenario,background).timings,.95);
 for(let i=0;i<pairs;i++){attributionContext={phase:'steady',pair:i};if(i%2){db.push(measure(true));da.push(measure(false));}else{da.push(measure(false));db.push(measure(true));}console.log("steady pair",scenario.count,background,i+1,"of",pairs);}
 attributionContext=undefined;const result={count:scenario.count,evidence:scenario.evidenceCount,background,construction:{baselineP95Ns:percentile(a,.95),candidateP95Ns:percentile(b,.95),ratio:percentile(b,.95)/percentile(a,.95),medianDeltaNs:percentile(b,.5)-percentile(a,.5),baseline:a,candidate:b,batches:constructionBatches},steady:{baselineMedianP95Ns:percentile(da,.5),candidateMedianP95Ns:percentile(db,.5),ratio:percentile(db,.5)/percentile(da,.5),baseline:da,candidate:db}};
 console.log("row complete",JSON.stringify(result));return result;
}
const performanceRows=[paired(scenarios[0]),paired(scenarios[1]),paired(scenarios[2]),paired(scenarios[0],1000)];
function ordinary(candidate){const g=candidate?new Graph():new ReferenceGraph();const a=g.state(1);const b=g.derived([a],v=>v+1);const stop=b.subscribe(()=>{});for(let i=0;i<5;i++)a.set(i);const t=performance.now();for(let i=0;i<20;i++)a.set(i);const ns=(performance.now()-t)*1e6/20000;stop();const group=g.topologyGroup();for(const n of g.describe().nodes)group.add(g.find(n.id));group.release();return ns;}
const ordinaryBefore=[],ordinaryAfter=[];for(let i=0;i<2;i++){ordinary(false);ordinary(true);}for(let i=0;i<2;i++){if(i%2){ordinaryAfter.push(ordinary(true));ordinaryBefore.push(ordinary(false));}else{ordinaryBefore.push(ordinary(false));ordinaryAfter.push(ordinary(true));}}
function dynamic(candidate){const g=candidate?new Graph():new ReferenceGraph();const source=g.state(1,{name:'source'});let peak=process.memoryUsage().heapUsed;const times=[];for(let i=0;i<2;i++){const name='v'+i;const t=performance.now();let nodes,stops;if(candidate){const scope=prepareConstruction(g,{name,epoch:1,inputs:[source],names:[name+'/startup',name+'/root']});const startup=scope.startupSource();const node=scope.node([source],null,{name:name+'/root'});const owner=scope.seal(startup,[node]);scope.transferToGraph(owner);startConstruction(g,owner);nodes=owner.nodes;stops=owner.roots.map(x=>x.unsubscribe);}else{const startup=g.node([],null,{name:name+'/startup',initial:{kind:'graph-startup',instance:name,epoch:1,state:'starting'}});const node=g.node([source],null,{name:name+'/root'});nodes=[startup,node];stops=[g.retain(startup),g.retain(node)];startup.down([['DATA',{kind:'graph-startup',instance:name,epoch:1,state:'started'}]]);}for(const stop of stops)stop();const group=g.topologyGroup();for(const node of nodes)group.add(node);group.release();times.push((performance.now()-t)*1e6);peak=Math.max(peak,process.memoryUsage().heapUsed);assert.equal(g.describe().nodes.length,1);if(candidate)assert.equal(constructionOf(g,name),undefined);}return {p95Ns:percentile(times,.95),totalNs:times.reduce((a,b)=>a+b,0),peakHeapBytes:peak};}
const dynamicRows=[];for(let i=0;i<5;i++){const first=dynamic(i%2===1),second=dynamic(i%2===0);dynamicRows.push(i%2?{baseline:second,candidate:first}:{baseline:first,candidate:second});}
writeFileSync("/Users/davidchenallio/.codex/visualizations/2026/09/06/01a077c7-55e6-7f11-9d4f-e7c51944afb4/committed-view-attribution/smoke-result.json",JSON.stringify({comparisons,performanceRows,ordinary:{baseline:ordinaryBefore,candidate:ordinaryAfter,ratio:percentile(ordinaryAfter,.5)/percentile(ordinaryBefore,.5)},dynamicRows},null,2));

const traceEnd=performance.mark('causal-attribution-end');
writeFileSync("/Users/davidchenallio/.codex/visualizations/2026/09/06/01a077c7-55e6-7f11-9d4f-e7c51944afb4/committed-view-attribution/smoke-intervals.json",JSON.stringify({schema:'graphrefly-ts/causal-performance-attribution/v1',
meaning:'Original layout, diagnostic clocks and allocations added; no requalification claim',
traceAnchors:[{name:traceAnchor.name,startTime:traceAnchor.startTime},{name:traceEnd.name,startTime:traceEnd.startTime}],
arrivals:scenarios.slice(0,3).map(s=>({count:s.count,evidence:s.evidenceCount,lanes:s.arrivals.map(a=>a.lane)})),
runs:attributedRuns}));
