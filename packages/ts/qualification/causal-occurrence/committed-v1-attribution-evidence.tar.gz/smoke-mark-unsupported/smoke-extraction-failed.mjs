import assert from 'node:assert/strict';
import {readFileSync,writeFileSync,mkdirSync,mkdtempSync,rmSync,existsSync} from 'node:fs';
import {spawnSync} from 'node:child_process';
import {tmpdir} from 'node:os';
import {join,dirname} from 'node:path';
import {build} from '/Users/davidchenallio/src/graphrefly-ts/node_modules/esbuild/lib/main.js';
import {attributeCausalPerformance} from '/Users/davidchenallio/src/graphrefly-ts/scripts/fixtures/causal-performance-attribution.mjs';
const root='/Users/davidchenallio/src/graphrefly-ts',base=import.meta.dirname;
const temp=mkdtempSync(join(tmpdir(),'attribution-smoke-')),reference=join(temp,'reference'),src=root+'/packages/ts/src';
const original=readFileSync(root+'/scripts/compare-causal-construction.mjs','utf8');
const previous=readFileSync(root+'/scripts/compare-causal-authority.mjs','utf8');
const traceFixture=previous.slice(previous.indexOf('const lanes ='),previous.indexOf('function graphRun(make, scenario)'));
const literal=original.slice(original.indexOf('const runner = `')+15,original.indexOf('\ntry {\n\tconst bundlePath'));
assert.ok(literal.endsWith(';\n'));
const runner=new Function('reference','src','traceFixture','resultPath','return '+literal)(reference,src,traceFixture,base+'/smoke-result.json');
for(const [name,file] of Object.entries(JSON.parse(readFileSync(root+'/packages/ts/qualification/causal-occurrence/ts-v4-construction-inputs.json','utf8')).files)){
 const p=join(reference,name);mkdirSync(dirname(p),{recursive:true});writeFileSync(p,file.text);
}
let code=attributeCausalPerformance(runner,base+'/smoke-intervals.json');
// Only this disposable preflight uses a reduced layout. The production runner is unchanged.
code=code.replace('const scenarios=[trace(1,0,false),trace(16,128,false),trace(64,512,false),trace(16,128,true),trace(64,512,true),trace(16,128,false,2)];','const scenarios=[trace(1,0,false),trace(1,0,false),trace(1,0,false)];')
 .replaceAll('i<100','i<2').replaceAll('i<300','i<3').replace('scenario.count===64?9:15','scenario.count===64?3:3')
 .replaceAll('i<5000','i<5').replaceAll('i<20000','i<20').replaceAll('i<200','i<2').replaceAll('i<25','i<2').replaceAll('i<8','i<2');
writeFileSync(base+'/smoke.ts',code);
try{
 await build({stdin:{contents:code,resolveDir:root,loader:'ts'},outfile:base+'/smoke-bundle.mjs',bundle:true,platform:'node',format:'esm',nodePaths:[root+'/node_modules'],define:{__GRAPHREFLY_TS_PACKAGE_REVISION__:JSON.stringify('graphrefly-ts:0.9.0')}});
 const p=spawnSync(process.execPath,['--trace-events-enabled','--trace-event-categories=v8,node.perf.usertiming','--trace-event-file-pattern='+base+'/smoke-v8.json',base+'/smoke-bundle.mjs'],{encoding:'utf8',timeout:60000,maxBuffer:2e6});
 writeFileSync(base+'/smoke.log',p.stdout+p.stderr+'\nDONE status='+p.status+'\n');assert.ifError(p.error);assert.equal(p.status,0,p.stderr);
 const r=JSON.parse(readFileSync(base+'/smoke-result.json')),a=JSON.parse(readFileSync(base+'/smoke-intervals.json')),t=JSON.parse(readFileSync(base+'/smoke-v8.json'));
 assert.equal(a.runs.filter(x=>x.phase==='construction').length,72);assert.equal(a.runs.filter(x=>x.phase==='steady').length,24);
 for(const x of a.runs){assert.equal(x.starts.length,x.timings.length);assert.ok(x.runStart<=x.constructionStart&&x.constructionStart<=x.constructionEnd&&x.constructionEnd<=x.describeStart&&x.describeStart<=x.inputsStart&&x.inputsStart<=x.cleanupStart&&x.cleanupStart<=x.runEnd);for(let i=0;i<x.starts.length;i++)assert.ok(x.starts[i]>=x.inputsStart&&x.starts[i]+x.timings[i]/1e6<=x.cleanupStart);}
 for(const anchor of a.traceAnchors)assert.ok(t.traceEvents.some(e=>e.name===anchor.name&&e.ph==='b'));
 assert.equal(r.comparisons.length,3);assert.equal(r.performanceRows.length,4);
 writeFileSync(base+'/smoke-validation.json',JSON.stringify({status:'passed',constructionSamples:72,steadySamples:24,intervalOrdering:true,traceAnchors:true,semanticComparisons:3,qualification:false},null,2));
 console.log('DONE smoke passed');
}finally{rmSync(temp,{recursive:true,force:true});}
