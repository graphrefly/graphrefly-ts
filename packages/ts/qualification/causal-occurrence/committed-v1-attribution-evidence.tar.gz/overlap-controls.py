import ast,json,math
from pathlib import Path
b=Path(__file__).parent
source=ast.parse((b/'analyze.py').read_text())
functions=[n for n in source.body if isinstance(n,ast.FunctionDef) and n.name in ['overlaps','definite','lower_ms','upper_ms','union_ms']]
ctx={'margin':0.002};exec(compile(ast.Module(body=functions,type_ignores=[]),'actual-analyzer-helpers','exec'),ctx)
def eq(actual,expected):assert math.isclose(actual,expected,abs_tol=1e-10),(actual,expected)
beyond=[{'start':1.001,'end':2}]
assert len(ctx['overlaps'](beyond,0,1))==1 and not ctx['definite'](beyond,0,1)
eq(ctx['union_ms'](beyond,0,1),0);eq(ctx['lower_ms'](beyond,0,1),0);eq(ctx['upper_ms'](beyond,0,1),0.001)
inside=[{'start':0.2,'end':0.8}]
assert len(ctx['definite'](inside,0,1))==1
eq(ctx['union_ms'](inside,0,1),0.6);eq(ctx['lower_ms'](inside,0,1),0.596);eq(ctx['upper_ms'](inside,0,1),0.604)
eq(ctx['union_ms'](inside+inside,0,1),0.6)
assert not ctx['overlaps']([{'start':1.01,'end':2}],0,1)
r={'status':'passed','cases':['possible-only outside right boundary has nonnegative zero midpoint overlap','interior event definite and bounded','duplicate intervals unioned, not summed','beyond uncertainty excluded'],'meaning':'Deterministic tests of actual analyzer helper AST, no performance samples removed or changed.'}
(b/'overlap-controls.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r))
