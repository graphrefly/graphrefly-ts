// scripts/fixtures/spending-numeric-plain.ts
function decode(x) {
  if (x === 0) return 0n;
  const b = Buffer.alloc(8);
  b.writeDoubleBE(x);
  const value2 = b.readBigUInt64BE(), field = value2 >> 52n;
  return field === 0n ? value2 : (value2 & 0xfffffffffffffn) + 0x10000000000000n << field - 1n;
}
function raw(x) {
  const b = Buffer.alloc(8);
  b.writeDoubleBE(x);
  return b.readBigUInt64BE();
}
function value(bits) {
  const b = Buffer.alloc(8);
  b.writeBigUInt64BE(bits);
  return b.readDoubleBE();
}
var denominatorUnit = 1n << 1074n;
function roundRoot(n, d, candidate) {
  if (n === 0n) return 0;
  const center = raw(candidate);
  const compare = (sumUnits) => d * sumUnits ** 2n - n * (2n * denominatorUnit) ** 2n;
  for (const bits of [center, center - 1n, center + 1n]) {
    if (bits < 0n || bits > 0x7fefffffffffffffn) continue;
    const here = decode(value(bits));
    const low = bits === 0n ? -1n : compare(here + decode(value(bits - 1n)));
    const high = compare(here + decode(value(bits + 1n)));
    if ((low < 0n || low === 0n && bits % 2n === 0n) && (high > 0n || high === 0n && bits % 2n === 0n))
      return value(bits);
  }
  let lo = 0n, hi = raw(8);
  while (lo + 1n < hi) {
    const mid = lo + hi >> 1n, u = decode(value(mid));
    if (d * u * u <= n * denominatorUnit * denominatorUnit) lo = mid;
    else hi = mid;
  }
  const cmp = compare(decode(value(lo)) + decode(value(hi)));
  return value(cmp < 0n || cmp === 0n && lo % 2n !== 0n ? hi : lo);
}
function plainMoments(amounts) {
  const anchor = decode(amounts[0]), n = BigInt(amounts.length);
  let sum = 0n, sumSquares = 0n;
  for (const x of amounts) {
    const delta2 = decode(x) - anchor;
    sum += delta2;
    sumSquares += delta2 * delta2;
  }
  const dispersion = n * sumSquares - sum * sum;
  const delta = n * (decode(amounts[amounts.length - 1]) - anchor) - sum;
  const numerator = delta * delta * (n - 1n), denominator = n * dispersion;
  return {
    numerator: numerator.toString(),
    denominator: denominator.toString(),
    negative: delta < 0n
  };
}
function plainScore(moments) {
  const numerator = BigInt(moments.numerator), denominator = BigInt(moments.denominator);
  let magnitude = 0;
  if (numerator !== 0n && denominator !== 0n) {
    const shiftN = Math.max(0, numerator.toString(2).length - 53);
    const shiftD = Math.max(0, denominator.toString(2).length - 53);
    const power = shiftN - shiftD;
    const estimate = Math.sqrt(
      Number(numerator >> BigInt(shiftN)) / Number(denominator >> BigInt(shiftD)) * 2 ** (power % 2)
    ) * 2 ** Math.floor(power / 2);
    magnitude = roundRoot(numerator, denominator, estimate);
  }
  return magnitude === 0 ? 0 : moments.negative ? -magnitude : magnitude;
}
function plainNumbers(amounts, dailyAverage) {
  return {
    zScore: plainScore(plainMoments(amounts)),
    dailyRatio: amounts[amounts.length - 1] === 0 ? 0 : amounts[amounts.length - 1] / Math.max(dailyAverage, 1)
  };
}

// scripts/fixtures/spending-publication-oracle.ts
import { createHash } from "node:crypto";
function oracleEncoding(input, maxBytes = 1048576) {
  let remaining = maxBytes, immutable = true;
  const active = /* @__PURE__ */ new Set();
  function charge(text2) {
    remaining -= Buffer.byteLength(text2);
    if (remaining < 0) throw Error("frame bound");
    return text2;
  }
  function string(value2) {
    if (value2.length > remaining) throw Error("frame bound");
    for (let i = 0; i < value2.length; i++) {
      const c = value2.charCodeAt(i);
      if (c >= 55296 && c <= 56319) {
        const next = value2.charCodeAt(++i);
        if (!(next >= 56320 && next <= 57343)) throw Error("surrogate");
      } else if (c >= 56320 && c <= 57343) throw Error("surrogate");
    }
    return charge(JSON.stringify(value2));
  }
  function encode(value2) {
    if (value2 === null || typeof value2 === "boolean") return charge(JSON.stringify(value2));
    if (typeof value2 === "number" && Number.isFinite(value2)) return charge(JSON.stringify(value2));
    if (typeof value2 === "string") return string(value2);
    if (typeof value2 !== "object" || value2 === null || active.has(value2)) throw Error("passive");
    const array = Array.isArray(value2), proto = Object.getPrototypeOf(value2);
    if (array ? proto !== Array.prototype : proto !== Object.prototype && proto !== null)
      throw Error("prototype");
    if (array && value2.length > remaining / 2) throw Error("array bound");
    const keys = Reflect.ownKeys(value2);
    if (keys.length > remaining / 2 || keys.some((k) => typeof k !== "string")) throw Error("keys");
    const names = keys.filter((k) => !array || k !== "length");
    if (array && (names.length !== value2.length || names.some((k, i) => k !== String(i))))
      throw Error("array");
    active.add(value2);
    immutable &&= Object.isFrozen(value2);
    const encoded = [charge(array ? "[" : "{")];
    let first = true;
    for (const key of array ? names : names.sort()) {
      const d = Object.getOwnPropertyDescriptor(value2, key);
      if (!("value" in d) || !d.enumerable) throw Error("descriptor");
      if (!first) encoded.push(charge(","));
      first = false;
      if (!array) encoded.push(string(key), charge(":"));
      encoded.push(encode(d.value));
    }
    encoded.push(charge(array ? "]" : "}"));
    active.delete(value2);
    return encoded.join("");
  }
  return {
    text: encode(input),
    get immutable() {
      return immutable;
    }
  };
}
function oracleCanonical(input, maxBytes = 1048576) {
  return oracleEncoding(input, maxBytes).text;
}
var oracleHash = (s) => `sha256:${createHash("sha256").update(s).digest("hex")}`;
function oracleFreeze(v) {
  if (v !== null && typeof v === "object") {
    Object.values(v).forEach(oracleFreeze);
    Object.freeze(v);
  }
  return v;
}
function oracleMaterial(body) {
  const requestRef = {
    kind: "spending-alerts/request-material/v1",
    id: oracleHash(oracleCanonical(body))
  };
  return oracleFreeze({
    body,
    requestRef,
    proposalDigest: oracleHash(
      oracleCanonical({
        schema: "spending-alerts/effect-proposal/v1",
        occurrence: body.occurrence,
        effectId: body.effectId,
        requestRef
      })
    )
  });
}
function oracleSnapshot(p, materials) {
  const body = { ...p, schema: "spending-alerts/material-snapshot/v1", materials };
  return oracleFreeze({ body, digest: oracleHash(oracleCanonical(body)) });
}

// scripts/fixtures/spending-preset-reference-input.ts
var reject = () => {
  throw new TypeError("reference input contract");
};
var fields = (value2, shape) => {
  if (!value2 || Array.isArray(value2) || typeof value2 !== "object" || Object.keys(value2).sort().join() !== Object.keys(shape).sort().join())
    reject();
  for (const key of Object.keys(shape)) shape[key](value2[key]);
};
var text = (limit = 128) => (v) => {
  if (typeof v !== "string" || !v.length || Buffer.byteLength(v) > limit) reject();
};
var number = (max = Number.MAX_SAFE_INTEGER, min = 0, integer = true) => (v) => {
  if (typeof v !== "number" || !Number.isFinite(v) || v < min || v > max || integer && !Number.isSafeInteger(v))
    reject();
};
var bool = (v) => {
  if (typeof v !== "boolean") reject();
};
var literal = (...values) => (v) => {
  if (!values.includes(v)) reject();
};
var digest = (v) => {
  if (typeof v !== "string" || !/^sha256:[a-f0-9]{64}$/.test(v)) reject();
};
var ref = (v) => fields(v, { kind: text(), id: text() });
var list = (check, max = 64, min = 0) => (v) => {
  if (!Array.isArray(v) || v.length < min || v.length > max) reject();
  for (let i = 0; i < v.length; i++) {
    if (!Object.hasOwn(v, i)) reject();
    check(v[i]);
  }
};
var unique = (items) => {
  if (new Set(items.map((x) => oracleCanonical(x))).size !== items.length) reject();
};
var occurrence = (v) => {
  fields(v, {
    revisionDomain: text(),
    occurrenceId: text(),
    revision: number(void 0, 1),
    digest,
    sourceRefs: list(ref, 64, 1)
  });
  unique(v.sourceRefs);
};
var profile = (v) => {
  fields(v, { dailyAverage: number(1e9, 0, false), typicalCategories: list(text(256), 32) });
  unique(v.typicalCategories);
};
var policy = (v) => fields(v, { zThreshold: number(1e6, 0, false), dailyRatioThreshold: number(1e6, 0, false) });
var transaction = (v) => {
  fields(v, {
    id: text(),
    vendor: text(256),
    category: text(256),
    amount: number(1e9, 0, false),
    timestampIso: text()
  });
  if (!/^\d{4}-\d\d-\d\dT\d\d:\d\d:\d\d\.\d{3}Z$/.test(v.timestampIso) || !Number.isFinite(Date.parse(v.timestampIso)) || new Date(v.timestampIso).toISOString() !== v.timestampIso)
    reject();
};
var evaluation = (e) => {
  fields(e, {
    evaluationRef: text(),
    subjectRef: text(),
    occurrence,
    inputDigest: digest,
    profileRef: ref,
    profile,
    policyRef: ref,
    policyDigest: digest,
    policy,
    prefix: list(transaction, 64, 1)
  });
  unique(e.prefix.map((t) => t.id));
  if (new Set(e.prefix.map((t) => t.vendor)).size !== 1 || Buffer.byteLength(oracleCanonical(e)) > 65536)
    reject();
  if (e.inputDigest !== oracleHash(oracleCanonical({ profileRef: e.profileRef, profile: e.profile, prefix: e.prefix })) || e.policyDigest !== oracleHash(oracleCanonical(e.policy)))
    reject();
};
var binding = (v) => fields(v, {
  packRef: ref,
  sourceDigest: digest,
  runtimeDigest: digest,
  destinationRef: ref,
  compositionEpoch: number(void 0, 1),
  hostEpoch: number(void 0, 1),
  runRef: text(),
  evidenceMode: literal("fixture-observations")
});
var receipt = (v) => fields(v, {
  receiptRef: ref,
  issuerRef: ref,
  verifierRevision: text(),
  occurrence,
  inputDigest: digest,
  policyDigest: digest,
  sourceDigest: digest,
  runtimeDigest: digest,
  requestDigest: digest,
  numericDomainRef: text(),
  verdict: literal("pass", "fail", "unavailable"),
  artifactRef: ref,
  artifactDigest: digest
});
var grant = (v) => {
  fields(v, {
    grantRef: ref,
    ownerRef: ref,
    operation: literal("append-alert"),
    occurrence,
    requestDigest: digest,
    destinationRef: ref,
    hostEpoch: number(void 0, 1),
    validFrom: number(),
    validThrough: number(),
    maxWrites: number(64, 1),
    replayScope: (x) => fields(x, { compositionEpoch: number(void 0, 1), hostEpoch: number(void 0, 1) }),
    revoked: bool
  });
  if (v.validFrom > v.validThrough) reject();
};
var current = (v) => {
  fields(v, {
    revisionDomain: text(),
    occurrence,
    policyRef: ref,
    policyDigest: digest,
    watermark: number()
  });
  if (v.revisionDomain !== v.occurrence.revisionDomain) reject();
};
var outcome = (v) => fields(v, {
  occurrence,
  effectId: text(),
  requestRef: ref,
  admissionRef: ref,
  proposalDigest: digest,
  state: literal("succeeded", "failed", "cancelled", "unknown", "reconcile-required"),
  result: (x) => {
    if (!x || typeof x !== "object" || !["ok", "error"].includes(x.kind)) reject();
  }
});
function referenceInput(lane, raw2, expected) {
  const encoded = oracleCanonical(raw2, lane === "pack" ? 4 * 1048576 : 1048576);
  if (Buffer.byteLength(encoded) > (lane === "pack" ? 4 * 1048576 : 1048576)) reject();
  const v = JSON.parse(encoded);
  if (lane === "arrivals") {
    fields(v, { packRef: ref, evaluationRefs: list(text()) });
    if (oracleCanonical(v.packRef) !== oracleCanonical(expected.packRef)) reject();
  } else {
    const shape = {
      pack: { format: literal("spending-input-v1"), evaluations: list(evaluation) },
      current: { current: list(current) },
      verification: { receipts: list(receipt) },
      local: { tick: number(), stop: bool, grants: list(grant) },
      inbox: {
        issuerRef: ref,
        artifactRef: ref,
        artifactDigest: digest,
        readiness: (x) => fields(x, {
          ready: bool,
          observedAt: number(),
          validThrough: number(),
          availableSlots: number(1)
        }),
        outcomes: list(outcome)
      }
    };
    fields(v, { binding, ...shape[lane] });
    if (oracleCanonical(v.binding) !== oracleCanonical(expected)) reject();
    if (lane === "pack") {
      unique(v.evaluations.map((e) => e.evaluationRef));
      unique(v.evaluations.map((e) => e.occurrence));
      if (new Set(v.evaluations.map((e) => e.prefix[0].vendor)).size > 2) reject();
      const domains = /* @__PURE__ */ new Map();
      for (const e of v.evaluations) {
        const vendor = e.prefix[0].vendor, prior = domains.get(e.occurrence.revisionDomain);
        if (prior !== void 0 && prior !== vendor) reject();
        domains.set(e.occurrence.revisionDomain, vendor);
      }
    } else if (lane === "current") unique(v.current.map((c) => c.revisionDomain));
  }
  return oracleFreeze(v);
}
function referenceBinding(raw2) {
  const value2 = JSON.parse(oracleCanonical(raw2));
  binding(value2);
  return oracleFreeze(value2);
}

// scripts/fixtures/spending-preset-plain.ts
var digest2 = (x) => oracleHash(oracleCanonical(x));
var equal = (a, b) => oracleCanonical(a) === oracleCanonical(b);
function plainBusiness(e) {
  const txn = e.prefix[e.prefix.length - 1];
  const { zScore, dailyRatio } = plainNumbers(
    e.prefix.map((t) => t.amount),
    e.profile.dailyAverage
  );
  const factors = [];
  if (zScore > e.policy.zThreshold)
    factors.push(`Amount is ${zScore.toFixed(2)}\u03C3 above this vendor's historical mean.`);
  if (dailyRatio > e.policy.dailyRatioThreshold)
    factors.push(`Amount is ${dailyRatio.toFixed(1)}\xD7 the user's daily average.`);
  if (!e.profile.typicalCategories.includes(txn.category))
    factors.push("Category is outside the user's typical spend profile.");
  const severity = factors.length >= 3 ? "high" : factors.length === 2 ? "medium" : "low", flagged = factors.length > 0;
  const message = flagged ? `Transaction ${txn.id} flagged \u2014 severity: ${severity}.
Vendor: ${txn.vendor}  Amount: $${txn.amount.toFixed(2)}  Category: ${txn.category}
Reasoning:
${factors.map((f) => `  \u2022 ${f}`).join("\n")}` : `Transaction ${txn.id} ($${txn.amount.toFixed(2)} at ${txn.vendor}) \u2014 normal.`;
  return {
    score: {
      zScore,
      dailyRatio,
      categoryFamiliarity: e.profile.typicalCategories.includes(txn.category) ? "known" : "unknown",
      txn
    },
    flagged,
    reason: { factors, severity, txn },
    message
  };
}
function plainMaterial(e, b, result) {
  const payloadText = oracleCanonical({
    transactionId: result.score.txn.id,
    vendor: result.score.txn.vendor,
    severity: result.reason.severity,
    message: result.message
  });
  if (Buffer.byteLength(payloadText) + 1 > 4096) throw Error("payload capacity");
  return oracleMaterial({
    schema: "spending-alerts/request-material/v1",
    occurrence: e.occurrence,
    effectId: `alert:${e.evaluationRef}`,
    inputDigest: e.inputDigest,
    policyDigest: e.policyDigest,
    payloadText,
    payloadDigest: oracleHash(payloadText),
    sourceDigest: b.sourceDigest,
    runtimeDigest: b.runtimeDigest,
    destinationRef: b.destinationRef,
    compositionEpoch: b.compositionEpoch,
    hostEpoch: b.hostEpoch
  });
}
var PlainSpending = class {
  constructor(binding2) {
    this.binding = binding2;
    this.binding = referenceBinding(binding2);
  }
  binding;
  evaluations = /* @__PURE__ */ new Map();
  assessments = /* @__PURE__ */ new Map();
  materials = /* @__PURE__ */ new Map();
  effects = /* @__PURE__ */ new Map();
  issues = [];
  pending = [];
  eligible = /* @__PURE__ */ new Set();
  occurrenceAdmissions = /* @__PURE__ */ new Set();
  released = /* @__PURE__ */ new Set();
  watermarks = /* @__PURE__ */ new Map();
  identity = /* @__PURE__ */ new Map();
  domains = /* @__PURE__ */ new Set();
  evidenceReceipts = /* @__PURE__ */ new Map();
  evidenceRecords = /* @__PURE__ */ new Map();
  branches = /* @__PURE__ */ new Map();
  pendingTerminals = /* @__PURE__ */ new Map();
  issuedPolicy = /* @__PURE__ */ new Set();
  terminal(id, branch) {
    const e = this.evaluations.get(id);
    if (!this.retainDomain(e.occurrence.revisionDomain)) return;
    const retained = this.identity.get(e.occurrence.revisionDomain)?.get(e.occurrence.revision);
    if (retained && !equal(retained.occurrence, e.occurrence)) return;
    if (this.released.has(id)) {
      this.branches.get(id)?.add(branch);
      return;
    }
    const key = oracleCanonical([id, branch]);
    if (!this.pendingTerminals.has(key) && this.pendingTerminals.size < 64)
      this.pendingTerminals.set(key, { id, branch });
  }
  retainDomain(domain) {
    if (this.domains.has(domain)) return true;
    if (this.domains.size === 64) {
      this.issues.push("domain capacity");
      return false;
    }
    this.domains.add(domain);
    return true;
  }
  receiptHistory = /* @__PURE__ */ new Map();
  receiptConflicts = /* @__PURE__ */ new Set();
  pendingOutcomes = /* @__PURE__ */ new Map();
  pack;
  packText;
  facts = {};
  prepare(lane, raw2) {
    const v = referenceInput(lane, raw2, this.binding);
    if (lane === "verification")
      for (const receipt2 of v.receipts) {
        const key = oracleCanonical(receipt2.receiptRef), prior = this.receiptHistory.get(key), content = oracleCanonical(receipt2);
        if (prior !== void 0 && prior !== content) this.receiptConflicts.add(key);
        if (this.receiptConflicts.has(key)) throw Error("receipt conflict");
        if (prior === void 0 && this.receiptHistory.size >= 64) throw Error("receipt capacity");
        this.receiptHistory.set(key, content);
      }
    return v;
  }
  push(lane, raw2) {
    const arrived = [];
    let value2;
    try {
      value2 = this.prepare(lane, raw2);
    } catch (e) {
      if (lane === "pack") this.pack = void 0;
      else if (lane === "arrivals") this.pending.length = 0;
      else delete this.facts[lane];
      if (lane === "pack" || lane === "arrivals") this.eligible.clear();
      this.issues.push(String(e));
      return;
    }
    if (lane === "pack") {
      const pack = value2, text2 = oracleCanonical(pack, 4 * 1048576);
      if (this.packText !== void 0 && text2 !== this.packText) {
        this.pack = void 0;
        this.eligible.clear();
        this.issues.push("pack conflict");
        return;
      }
      this.pack = pack;
      this.packText = text2;
    } else if (lane === "arrivals") {
      for (const ref2 of value2.evaluationRefs) {
        if (this.pending.length >= 64) {
          this.issues.push("pending capacity");
          break;
        }
        this.pending.push(ref2);
      }
    } else {
      Object.assign(this.facts, { [lane]: value2 });
      if (lane === "current")
        for (const c of value2.current) {
          const prior = this.watermarks.get(c.revisionDomain) ?? 0;
          if (this.retainDomain(c.revisionDomain) && c.watermark >= prior)
            this.watermarks.set(c.revisionDomain, c.watermark);
        }
    }
    if (this.pack) {
      for (const id of this.pending.splice(0)) {
        const e = this.pack.evaluations.find((e2) => e2.evaluationRef === id);
        if (!e) {
          this.issues.push("unknown evaluation");
          continue;
        }
        this.eligible.add(id);
        arrived.push(id);
        if (this.evaluations.has(id)) continue;
        this.evaluations.set(id, e);
        const { occurrence: occurrence2, ...body } = e, { digest: claimed, ...coordinates } = occurrence2;
        if (this.retainDomain(occurrence2.revisionDomain) && claimed === digest2({
          schemaRevision: "graphrefly/causal-occurrence-contract/v1@contract-v2",
          ...coordinates,
          value: body
        })) {
          let domain = this.identity.get(occurrence2.revisionDomain);
          if (!domain) {
            domain = /* @__PURE__ */ new Map();
            this.identity.set(occurrence2.revisionDomain, domain);
          }
          if (!domain.has(occurrence2.revision)) domain.set(occurrence2.revision, e);
        }
        const result = plainBusiness(e);
        if (this.retainDomain(e.occurrence.revisionDomain)) this.branches.set(id, /* @__PURE__ */ new Set());
        this.assessments.set(id, result);
        if (!result.flagged) continue;
        try {
          if (this.materials.size >= 64) throw Error("material capacity");
          const material = plainMaterial(e, this.binding, result);
          const { runRef: _run, evidenceMode: _mode, ...profile2 } = this.binding;
          oracleSnapshot(profile2, [...this.materials.values(), material]);
          this.materials.set(id, material);
          this.effects.set(id, {
            proposal: {
              occurrence: e.occurrence,
              effectId: material.body.effectId,
              requestRef: material.requestRef,
              proposalDigest: material.proposalDigest
            }
          });
        } catch (error) {
          this.issues.push(String(error));
        }
      }
    }
    if (lane === "verification")
      for (const receipt2 of value2.receipts) {
        const key = oracleCanonical(receipt2.receiptRef);
        if (!this.evidenceReceipts.has(key) && this.evidenceReceipts.size < 64)
          this.evidenceReceipts.set(key, receipt2);
      }
    this.reconcile(lane === "inbox" ? value2.outcomes : [], arrived);
  }
  reconcile(incomingOutcomes, arrived) {
    const { current: current2, verification, local, inbox } = this.facts;
    for (const id of this.eligible) {
      const e = this.evaluations.get(id);
      if (current2?.current.some(
        (c) => equal(c.occurrence, e.occurrence) && equal(c.policyRef, e.policyRef) && c.policyDigest === e.policyDigest
      )) {
        if (this.retainDomain(e.occurrence.revisionDomain)) this.occurrenceAdmissions.add(id);
      }
    }
    for (const [name, domain] of this.identity) {
      const through = this.watermarks.get(name);
      if (through === void 0) continue;
      const ordered = [...domain].filter(([n]) => n <= through).sort(([a], [b]) => a - b);
      if (ordered.length !== through || ordered.some(([n, e], i) => n !== i + 1 || !this.occurrenceAdmissions.has(e.evaluationRef)))
        continue;
      const latest = /* @__PURE__ */ new Map();
      for (const [, e] of ordered) latest.set(e.occurrence.occurrenceId, e);
      for (const e of latest.values()) this.released.add(e.evaluationRef);
    }
    for (const [key, { id, branch }] of this.pendingTerminals) {
      const occurrence2 = this.evaluations.get(id).occurrence;
      const retained = this.identity.get(occurrence2.revisionDomain)?.get(occurrence2.revision);
      if (retained && !equal(retained.occurrence, occurrence2)) {
        this.pendingTerminals.delete(key);
        continue;
      }
      if (this.released.has(id)) {
        this.branches.get(id)?.add(branch);
        this.pendingTerminals.delete(key);
      }
    }
    for (const branch of ["assessment", "explanation"])
      for (const id of arrived) this.terminal(id, branch);
    for (const [id, record] of this.effects) {
      if (record.admission || !this.eligible.has(id)) continue;
      const e = this.evaluations.get(id), material = this.materials.get(id);
      const receipts = verification?.receipts.filter(
        (v) => equal(v.occurrence, e.occurrence) && v.inputDigest === e.inputDigest && v.policyDigest === e.policyDigest && v.sourceDigest === this.binding.sourceDigest && v.runtimeDigest === this.binding.runtimeDigest && v.requestDigest === material.body.payloadDigest && v.verifierRevision === "spending-oracle-v2" && v.numericDomainRef === "spending-finite-v1"
      ) ?? [];
      if (receipts.length !== 1 || receipts[0].verdict === "unavailable") continue;
      const receipt2 = receipts[0];
      if (receipt2.verdict === "fail") {
        record.admission = {
          ...record.proposal,
          state: "rejected",
          admissionRef: {
            kind: "spending-admission",
            id: digest2({
              proposal: record.proposal,
              receiptRef: receipt2.receiptRef,
              verdict: "fail",
              binding: this.binding
            })
          }
        };
        continue;
      }
      if (!current2 || !local || !inbox) continue;
      if (!current2.current.some(
        (c) => equal(c.occurrence, e.occurrence) && equal(c.policyRef, e.policyRef) && c.policyDigest === e.policyDigest && c.watermark >= e.occurrence.revision
      ))
        continue;
      const grants = local.grants.filter(
        (g2) => equal(g2.occurrence, e.occurrence) && g2.requestDigest === material.body.payloadDigest && equal(g2.destinationRef, this.binding.destinationRef) && g2.hostEpoch === this.binding.hostEpoch && g2.replayScope.hostEpoch === this.binding.hostEpoch && g2.replayScope.compositionEpoch === this.binding.compositionEpoch
      );
      if (grants.length !== 1) continue;
      const g = grants[0], refused = g.revoked || local.stop || local.tick < g.validFrom || local.tick > g.validThrough;
      if (!refused && (!inbox.readiness.ready || inbox.readiness.availableSlots !== 1 || local.tick < inbox.readiness.observedAt || local.tick > inbox.readiness.validThrough))
        continue;
      record.admission = {
        ...record.proposal,
        state: refused ? "rejected" : "admitted",
        admissionRef: {
          kind: "spending-admission",
          id: digest2({
            proposal: record.proposal,
            receiptRef: receipt2.receiptRef,
            grantRef: g.grantRef,
            binding: this.binding
          })
        }
      };
    }
    const applyOutcome = (o) => {
      const e = [...this.effects.values()].find(
        (e2) => equal(e2.proposal.occurrence, o.occurrence) && e2.proposal.effectId === o.effectId
      );
      if (!e?.admission || ![...this.effects].some(([id, record]) => record === e && this.released.has(id)))
        return false;
      if (e.admission.state === "admitted" && equal(e.proposal.requestRef, o.requestRef) && e.proposal.proposalDigest === o.proposalDigest && equal(e.admission.admissionRef, o.admissionRef) && !e.outcome)
        e.outcome = o;
      return true;
    };
    for (const [key, o] of this.pendingOutcomes)
      if (applyOutcome(o)) this.pendingOutcomes.delete(key);
    for (const o of incomingOutcomes) {
      const result = o.result;
      if (!result || typeof result !== "object") continue;
      if (o.state === "succeeded") {
        if (result.kind !== "ok" || !Object.hasOwn(result, "value")) continue;
      } else {
        if (!["failed", "cancelled", "unknown", "reconcile-required"].includes(o.state)) continue;
        if (result.kind !== "error" || !result.error || result.error.kind !== "issue" || typeof result.error.code !== "string" || !result.error.code || typeof result.error.message !== "string" || !result.error.message)
          continue;
      }
      if (!this.retainDomain(o.occurrence.revisionDomain)) continue;
      const key = digest2({ occurrence: o.occurrence, effectId: o.effectId });
      if (!applyOutcome(o) && !this.pendingOutcomes.has(key) && this.pendingOutcomes.size < 64)
        this.pendingOutcomes.set(key, o);
    }
    for (const id of this.eligible) {
      const e = this.evaluations.get(id), b = this.assessments.get(id);
      if (!this.domains.has(e.occurrence.revisionDomain)) continue;
      if ((!b.flagged || this.effects.get(id)?.admission || !this.materials.has(id)) && !this.issuedPolicy.has(id)) {
        this.issuedPolicy.add(id);
        this.terminal(id, "publication-policy");
      }
      const retain = (v) => {
        const key = oracleCanonical([v.occurrence, v.evidenceKind, v.evidenceId]);
        if (!this.evidenceRecords.has(key) && this.evidenceRecords.size < 512)
          this.evidenceRecords.set(key, v);
      };
      for (const [kind, value2] of [
        ["spending-input", e.inputDigest],
        [
          "spending-code-binding",
          digest2({
            sourceDigest: this.binding.sourceDigest,
            runtimeDigest: this.binding.runtimeDigest
          })
        ]
      ])
        retain({
          occurrence: e.occurrence,
          evidenceKind: kind,
          evidenceId: `${id}:${kind}`,
          evidenceDigest: value2,
          coverage: "included",
          refs: [this.binding.runRef]
        });
      const request = b.flagged ? this.materials.get(id)?.body.payloadDigest : digest2({ kind: "no-publish", evaluationRef: id });
      for (const receipt2 of this.evidenceReceipts.values())
        if (equal(receipt2.occurrence, e.occurrence)) {
          const stale = receipt2.sourceDigest !== this.binding.sourceDigest || receipt2.runtimeDigest !== this.binding.runtimeDigest || receipt2.inputDigest !== e.inputDigest || receipt2.policyDigest !== e.policyDigest || receipt2.verifierRevision !== "spending-oracle-v2" || receipt2.numericDomainRef !== "spending-finite-v1" || request !== void 0 && receipt2.requestDigest !== request;
          retain({
            occurrence: e.occurrence,
            evidenceKind: "spending-verification",
            evidenceId: digest2(receipt2.receiptRef),
            evidenceDigest: digest2(receipt2),
            coverage: stale ? "stale" : receipt2.verdict === "unavailable" || request === void 0 ? "unavailable" : "included",
            refs: [receipt2.artifactRef.id]
          });
        }
    }
  }
  evidenceSnapshot() {
    return [...this.evidenceRecords.values()].filter((v) => {
      const domain = this.identity.get(v.occurrence.revisionDomain);
      return domain && equal(domain.get(v.occurrence.revision)?.occurrence ?? null, v.occurrence) && [...domain.keys()].filter((n) => n <= v.occurrence.revision).length === v.occurrence.revision;
    });
  }
  obligationSnapshot() {
    const evidence = this.evidenceSnapshot();
    return [...this.watermarks].map(([domain, through]) => {
      const rows = [...this.identity.get(domain)?.values() ?? []].filter(
        (e) => e.occurrence.revision <= through
      );
      const sequence = rows.length === through && rows.every((e) => this.occurrenceAdmissions.has(e.evaluationRef));
      const lifecycle = sequence && ![...this.pendingTerminals.values()].some((t) => {
        const ref2 = this.evaluations.get(t.id).occurrence;
        return ref2.revisionDomain === domain && ref2.revision <= through;
      }) && ![...this.pendingOutcomes.values()].some(
        (o) => o.occurrence.revisionDomain === domain && o.occurrence.revision <= through
      ) && rows.every((e) => {
        const effect = this.effects.get(e.evaluationRef);
        return this.released.has(e.evaluationRef) && this.branches.get(e.evaluationRef)?.size === 3 && (!effect || effect.admission?.state === "rejected" || !!effect.outcome);
      });
      const retainedEvidence = lifecycle && rows.every(
        (e) => ["spending-input", "spending-code-binding", "spending-verification"].every(
          (kind) => evidence.some((v) => equal(v.occurrence, e.occurrence) && v.evidenceKind === kind)
        )
      );
      return {
        revisionDomain: domain,
        evaluatedThroughRevision: through,
        lifecycle,
        retainedEvidence
      };
    });
  }
  invalidate(lane) {
    if (lane === "pack" || lane === "arrivals") this.eligible.clear();
    if (lane === "pack") this.pack = void 0;
    else if (lane === "arrivals") this.pending.length = 0;
    else delete this.facts[lane];
  }
  snapshot() {
    return [...this.effects].filter(([id]) => this.released.has(id)).map(([, e]) => ({
      proposal: e.proposal,
      admission: e.admission ?? null,
      outcome: e.outcome ?? null
    }));
  }
};
export {
  PlainSpending,
  plainBusiness,
  plainMaterial
};
