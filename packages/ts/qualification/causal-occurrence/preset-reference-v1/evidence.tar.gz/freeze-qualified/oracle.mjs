// scripts/fixtures/spending-numeric-oracle.ts
function bits(x) {
  const buffer = Buffer.alloc(8);
  buffer.writeDoubleBE(x);
  return buffer.readBigUInt64BE();
}
function number(x) {
  const buffer = Buffer.alloc(8);
  buffer.writeBigUInt64BE(x);
  return buffer.readDoubleBE();
}
function unitsFromBits(b) {
  const exponent = b >> 52n & 2047n, mantissa = b & 0xfffffffffffffn;
  return exponent === 0n ? mantissa : (mantissa | 0x10000000000000n) << exponent - 1n;
}
var units = (x) => unitsFromBits(bits(x));
var unitDenominator = 1n << 1074n;
function referenceRound(numerator, denominator, squareRoot) {
  if (numerator === 0n) return 0;
  const compare = (u, divisor = 1n) => squareRoot ? u * u * denominator - numerator * (unitDenominator * divisor) ** 2n : u * denominator - numerator * unitDenominator * divisor;
  let lo = 0n, hi = 0x7fefffffffffffffn;
  while (lo < hi) {
    const mid = (lo + hi + 1n) / 2n;
    if (compare(unitsFromBits(mid)) <= 0n) lo = mid;
    else hi = mid - 1n;
  }
  const lower = unitsFromBits(lo);
  if (compare(lower) === 0n) return number(lo);
  const midpointComparison = compare(lower + unitsFromBits(lo + 1n), 2n);
  return number(
    midpointComparison < 0n || midpointComparison === 0n && lo % 2n === 1n ? lo + 1n : lo
  );
}
function referenceNumbers(amounts, dailyAverage) {
  const xs = amounts.map(units), count = xs.length, n = BigInt(count);
  let total = 0n, pairs = 0n;
  for (let i = 0; i < count; i++) {
    total += xs[i];
    for (let j = 0; j < i; j++) pairs += (xs[i] - xs[j]) ** 2n;
  }
  const delta = n * xs[count - 1] - total;
  const z = pairs === 0n ? 0 : referenceRound(delta ** 2n * (n - 1n), n * pairs, true);
  return {
    mean: referenceRound(total, n * unitDenominator, false),
    std: count < 2 ? 0 : referenceRound(pairs, n * (n - 1n) * unitDenominator ** 2n, true),
    zScore: z === 0 ? 0 : delta < 0n ? -z : z,
    dailyRatio: referenceRound(xs[count - 1], units(Math.max(dailyAverage, 1)), false),
    varianceNonzero: pairs !== 0n
  };
}
function referenceFixed(x, digits) {
  const negative = x < 0, magnitude = units(Math.abs(x)) * 10n ** BigInt(digits);
  let q = magnitude / unitDenominator;
  if (2n * (magnitude % unitDenominator) >= unitDenominator) q++;
  const text = q.toString().padStart(digits + 1, "0");
  return `${negative ? "-" : ""}${text.slice(0, -digits)}.${text.slice(-digits)}`;
}

// scripts/fixtures/spending-publication-oracle.ts
import { createHash } from "node:crypto";
function oracleEncoding(input, maxBytes = 1048576) {
  let remaining = maxBytes, immutable = true;
  const active = /* @__PURE__ */ new Set();
  function charge(text) {
    remaining -= Buffer.byteLength(text);
    if (remaining < 0) throw Error("frame bound");
    return text;
  }
  function string(value) {
    if (value.length > remaining) throw Error("frame bound");
    for (let i = 0; i < value.length; i++) {
      const c = value.charCodeAt(i);
      if (c >= 55296 && c <= 56319) {
        const next = value.charCodeAt(++i);
        if (!(next >= 56320 && next <= 57343)) throw Error("surrogate");
      } else if (c >= 56320 && c <= 57343) throw Error("surrogate");
    }
    return charge(JSON.stringify(value));
  }
  function encode(value) {
    if (value === null || typeof value === "boolean") return charge(JSON.stringify(value));
    if (typeof value === "number" && Number.isFinite(value)) return charge(JSON.stringify(value));
    if (typeof value === "string") return string(value);
    if (typeof value !== "object" || value === null || active.has(value)) throw Error("passive");
    const array = Array.isArray(value), proto = Object.getPrototypeOf(value);
    if (array ? proto !== Array.prototype : proto !== Object.prototype && proto !== null)
      throw Error("prototype");
    if (array && value.length > remaining / 2) throw Error("array bound");
    const keys = Reflect.ownKeys(value);
    if (keys.length > remaining / 2 || keys.some((k) => typeof k !== "string")) throw Error("keys");
    const names = keys.filter((k) => !array || k !== "length");
    if (array && (names.length !== value.length || names.some((k, i) => k !== String(i))))
      throw Error("array");
    active.add(value);
    immutable &&= Object.isFrozen(value);
    const encoded = [charge(array ? "[" : "{")];
    let first = true;
    for (const key of array ? names : names.sort()) {
      const d = Object.getOwnPropertyDescriptor(value, key);
      if (!("value" in d) || !d.enumerable) throw Error("descriptor");
      if (!first) encoded.push(charge(","));
      first = false;
      if (!array) encoded.push(string(key), charge(":"));
      encoded.push(encode(d.value));
    }
    encoded.push(charge(array ? "]" : "}"));
    active.delete(value);
    return encoded.join("");
  }
  return {
    text: encode(input),
    get immutable() {
      return immutable;
    }
  };
}
function oracleCanonical(input, maxBytes = 1048576) {
  return oracleEncoding(input, maxBytes).text;
}
var oracleHash = (s) => `sha256:${createHash("sha256").update(s).digest("hex")}`;
function oracleFreeze(v) {
  if (v !== null && typeof v === "object") {
    Object.values(v).forEach(oracleFreeze);
    Object.freeze(v);
  }
  return v;
}
function oracleMaterial(body) {
  const requestRef = {
    kind: "spending-alerts/request-material/v1",
    id: oracleHash(oracleCanonical(body))
  };
  return oracleFreeze({
    body,
    requestRef,
    proposalDigest: oracleHash(
      oracleCanonical({
        schema: "spending-alerts/effect-proposal/v1",
        occurrence: body.occurrence,
        effectId: body.effectId,
        requestRef
      })
    )
  });
}

// scripts/fixtures/spending-preset-oracle.ts
function oracleBusiness(e) {
  const { mean, std, zScore, dailyRatio } = referenceNumbers(
    e.prefix.map((t) => t.amount),
    e.profile.dailyAverage
  );
  const txn = e.prefix[e.prefix.length - 1];
  const known = e.profile.typicalCategories.indexOf(txn.category) !== -1;
  const flags = [zScore > e.policy.zThreshold, dailyRatio > e.policy.dailyRatioThreshold, !known], flagged = flags.some(Boolean);
  const factors = [
    `Amount is ${referenceFixed(zScore, 2)}\u03C3 above this vendor's historical mean.`,
    `Amount is ${referenceFixed(dailyRatio, 1)}\xD7 the user's daily average.`,
    "Category is outside the user's typical spend profile."
  ].filter((_, i) => flags[i]);
  const severity = factors.length > 2 ? "high" : factors.length === 2 ? "medium" : "low";
  const message = flagged ? [
    `Transaction ${txn.id} flagged \u2014 severity: ${severity}.`,
    `Vendor: ${txn.vendor}  Amount: $${referenceFixed(txn.amount, 2)}  Category: ${txn.category}`,
    "Reasoning:",
    ...factors.map((f) => `  \u2022 ${f}`)
  ].join("\n") : `Transaction ${txn.id} ($${referenceFixed(txn.amount, 2)} at ${txn.vendor}) \u2014 normal.`;
  return oracleFreeze({ mean, std, zScore, dailyRatio, flagged, factors, severity, message, txn });
}
function oracleRequest(e, b) {
  const result = oracleBusiness(e);
  if (!result.flagged) return void 0;
  const payloadText = oracleCanonical({
    transactionId: result.txn.id,
    vendor: result.txn.vendor,
    severity: result.severity,
    message: result.message
  });
  return oracleMaterial({
    schema: "spending-alerts/request-material/v1",
    occurrence: e.occurrence,
    effectId: `alert:${e.evaluationRef}`,
    inputDigest: e.inputDigest,
    policyDigest: e.policyDigest,
    payloadText,
    payloadDigest: oracleHash(payloadText),
    sourceDigest: b.sourceDigest,
    runtimeDigest: b.runtimeDigest,
    destinationRef: b.destinationRef,
    compositionEpoch: b.compositionEpoch,
    hostEpoch: b.hostEpoch
  });
}
function verifyBusiness(e, observed) {
  if (!Number.isFinite(observed.score.zScore) || !Number.isFinite(observed.score.dailyRatio))
    return false;
  const expected = oracleBusiness(e), close = (a, b) => Number.isFinite(a) && Math.abs(a - b) <= 1e-10 * Math.max(1, Math.abs(b));
  const actualFlags = [
    observed.score.zScore > e.policy.zThreshold,
    observed.score.dailyRatio > e.policy.dailyRatioThreshold,
    !e.profile.typicalCategories.includes(expected.txn.category)
  ];
  const actualFactors = [
    `Amount is ${referenceFixed(observed.score.zScore, 2)}\u03C3 above this vendor's historical mean.`,
    `Amount is ${referenceFixed(observed.score.dailyRatio, 1)}\xD7 the user's daily average.`,
    "Category is outside the user's typical spend profile."
  ].filter((_, i) => actualFlags[i]);
  return observed.flagged === actualFlags.some(Boolean) && oracleCanonical(observed.reason.factors) === oracleCanonical(actualFactors) && close(observed.score.zScore, expected.zScore) && close(observed.score.dailyRatio, expected.dailyRatio) && observed.flagged === expected.flagged && observed.reason.severity === expected.severity && oracleCanonical(observed.reason.factors) === oracleCanonical(expected.factors) && observed.message === expected.message;
}
export {
  oracleBusiness,
  oracleCanonical,
  oracleFreeze,
  oracleHash,
  oracleRequest,
  verifyBusiness
};
