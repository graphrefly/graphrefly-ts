import fs from "node:fs";
const {execute}=await import("file:///Users/davidchenallio/src/graphrefly-ts/docs/design/causal-cost-investigation/aligned-capture/raw/assets/causal-aligned-observation.mjs");
const config=JSON.parse(fs.readFileSync("/Users/davidchenallio/src/graphrefly-ts/docs/design/causal-cost-investigation/aligned-capture/raw/05/config.json","utf8"));
const put=(name,value)=>{const text=JSON.stringify(value);if(name==="profile.json" && Buffer.byteLength(text)>32*1024**2)throw new Error("profile file limit");fs.writeFileSync("/Users/davidchenallio/src/graphrefly-ts/docs/design/causal-cost-investigation/aligned-capture/raw/05"+"/"+name,text,{flag:"wx"});};
put("entry.json",{pid:process.pid,timeOrigin:performance.timeOrigin,node:process.version,execArgv:process.execArgv,platform:process.platform,arch:process.arch});
await execute("GC",config.orientation,async observation=>{
const d=await import("file:///Users/davidchenallio/src/graphrefly-ts/docs/design/causal-cost-investigation/aligned-capture/raw/assets/GC.mjs");
const a=await import("file:///Users/davidchenallio/src/graphrefly-ts/docs/design/causal-cost-investigation/aligned-capture/raw/assets/worker.mjs");
const b=await import("file:///Users/davidchenallio/src/graphrefly-ts/docs/design/causal-cost-investigation/aligned-capture/raw/assets/worker-copy.mjs");
return d.runRow("/Users/davidchenallio/src/graphrefly-ts/docs/design/causal-cost-investigation/aligned-capture/raw/05/config.json",[a,b],observation);
},put);
