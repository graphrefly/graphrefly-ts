import assert from "node:assert/strict";
import {readFileSync,appendFileSync} from "node:fs";
const n=await import("file:///Users/davidchenallio/src/graphrefly-ts/archive/evals/causal-cpu-wall-diagnostic-v1/run/observed.mjs");
appendFileSync("/Users/davidchenallio/src/graphrefly-ts/archive/evals/causal-cpu-wall-diagnostic-v1/run/04-Q-U/entry-events.jsonl",JSON.stringify({module:"n",pid:process.pid})+"\n");
const m0=await import("file:///Users/davidchenallio/src/graphrefly-ts/archive/evals/causal-cpu-wall-diagnostic-v1/run/worker.mjs");
appendFileSync("/Users/davidchenallio/src/graphrefly-ts/archive/evals/causal-cpu-wall-diagnostic-v1/run/04-Q-U/entry-events.jsonl",JSON.stringify({module:"m0",pid:process.pid})+"\n");
const m1=await import("file:///Users/davidchenallio/src/graphrefly-ts/archive/evals/causal-cpu-wall-diagnostic-v1/run/worker-copy.mjs");
appendFileSync("/Users/davidchenallio/src/graphrefly-ts/archive/evals/causal-cpu-wall-diagnostic-v1/run/04-Q-U/entry-events.jsonl",JSON.stringify({module:"m1",pid:process.pid})+"\n");
const config=JSON.parse(readFileSync("/Users/davidchenallio/src/graphrefly-ts/archive/evals/causal-cpu-wall-diagnostic-v1/run/04-Q-U/config.json","utf8"));
assert.deepEqual(m0.RECIPE,m1.RECIPE);const original=JSON.stringify(m0.RECIPE);
const {createObserver}=await import("file:///Users/davidchenallio/src/graphrefly-ts/archive/evals/causal-cpu-wall-diagnostic-v1/run/source/scripts/causal-cpu-observer.mjs");
const observer=createObserver(config);let primary=null;
try {await n.runRow("/Users/davidchenallio/src/graphrefly-ts/archive/evals/causal-cpu-wall-diagnostic-v1/run/04-Q-U/config.json",[m0,m1],observer);} catch(error){primary=error;throw error;}
finally {try {observer.finish(primary);} catch(error){if(primary)throw new AggregateError([primary,error],"consumer and observer finalization");throw error;}}
assert.equal(JSON.stringify(m0.RECIPE),original);assert.equal(JSON.stringify(m1.RECIPE),original);
