import assert from "node:assert/strict";
import {readFileSync,appendFileSync} from "node:fs";
const n=await import("file:///Users/davidchenallio/src/graphrefly-ts/archive/evals/causal-cleanup-segments-v1/run/observed.mjs");
appendFileSync("/Users/davidchenallio/src/graphrefly-ts/archive/evals/causal-cleanup-segments-v1/run/04-S-U/entry-events.jsonl",JSON.stringify({module:"n",pid:process.pid})+"\n");
const m0=await import("file:///Users/davidchenallio/src/graphrefly-ts/archive/evals/causal-cleanup-segments-v1/run/derived-worker.mjs");
appendFileSync("/Users/davidchenallio/src/graphrefly-ts/archive/evals/causal-cleanup-segments-v1/run/04-S-U/entry-events.jsonl",JSON.stringify({module:"m0",pid:process.pid})+"\n");
const m1=await import("file:///Users/davidchenallio/src/graphrefly-ts/archive/evals/causal-cleanup-segments-v1/run/derived-worker-copy.mjs");
appendFileSync("/Users/davidchenallio/src/graphrefly-ts/archive/evals/causal-cleanup-segments-v1/run/04-S-U/entry-events.jsonl",JSON.stringify({module:"m1",pid:process.pid})+"\n");
const config=JSON.parse(readFileSync("/Users/davidchenallio/src/graphrefly-ts/archive/evals/causal-cleanup-segments-v1/run/04-S-U/config.json","utf8"));
assert.deepEqual(m0.RECIPE,m1.RECIPE);const original=JSON.stringify(m0.RECIPE);
const {createObserver}=await import("file:///Users/davidchenallio/src/graphrefly-ts/archive/evals/causal-cleanup-segments-v1/run/source/scripts/causal-cpu-observer.mjs");
const {createGaps,finishBoth}=await import("file:///Users/davidchenallio/src/graphrefly-ts/archive/evals/causal-cleanup-segments-v1/run/source/scripts/causal-cleanup-observer.mjs");
const observer=createObserver(config),gaps=createGaps(config);let primary=null;
try {await n.runRow("/Users/davidchenallio/src/graphrefly-ts/archive/evals/causal-cleanup-segments-v1/run/04-S-U/config.json",[m0,m1],observer,gaps);} catch(error){primary=error;throw error;}
finally {finishBoth(observer,gaps,primary);}
assert.equal(JSON.stringify(m0.RECIPE),original);assert.equal(JSON.stringify(m1.RECIPE),original);
