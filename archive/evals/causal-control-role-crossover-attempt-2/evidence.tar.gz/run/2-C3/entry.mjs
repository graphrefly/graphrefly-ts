import {appendFileSync} from "node:fs";
const record = (event) => appendFileSync("/Users/davidchenallio/src/graphrefly-ts/archive/evals/causal-control-role-crossover-attempt-2/run/2-C3/entry-events.jsonl", JSON.stringify({...event,pid:process.pid})+"\n");
const m1 = await import("file:///Users/davidchenallio/src/graphrefly-ts/archive/evals/causal-control-role-crossover-attempt-2/run/worker-copy.mjs");
record({kind:"loaded",module:1});
const m0 = await import("file:///Users/davidchenallio/src/graphrefly-ts/archive/evals/causal-control-role-crossover-attempt-2/run/worker.mjs");
record({kind:"loaded",module:0});
record({kind:"driver",module:1});
await m1.runRow("/Users/davidchenallio/src/graphrefly-ts/archive/evals/causal-control-role-crossover-attempt-2/run/2-C3/config.json");
