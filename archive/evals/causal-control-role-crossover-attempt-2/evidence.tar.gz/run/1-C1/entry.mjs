import {appendFileSync} from "node:fs";
const record = (event) => appendFileSync("/Users/davidchenallio/src/graphrefly-ts/archive/evals/causal-control-role-crossover-attempt-2/run/1-C1/entry-events.jsonl", JSON.stringify({...event,pid:process.pid})+"\n");
const m0 = await import("file:///Users/davidchenallio/src/graphrefly-ts/archive/evals/causal-control-role-crossover-attempt-2/run/worker.mjs");
record({kind:"loaded",module:0});
const m1 = await import("file:///Users/davidchenallio/src/graphrefly-ts/archive/evals/causal-control-role-crossover-attempt-2/run/worker-copy.mjs");
record({kind:"loaded",module:1});
record({kind:"driver",module:1});
await m1.runRow("/Users/davidchenallio/src/graphrefly-ts/archive/evals/causal-control-role-crossover-attempt-2/run/1-C1/config.json");
