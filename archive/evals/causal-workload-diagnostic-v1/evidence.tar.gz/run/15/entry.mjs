import fs from "node:fs";
const d = await import("file:///Users/davidchenallio/src/graphrefly-ts/archive/evals/causal-workload-diagnostic-v1/run/assets/CPU.mjs");
const a = await import("file:///Users/davidchenallio/src/graphrefly-ts/archive/evals/causal-workload-diagnostic-v1/run/assets/worker.mjs");
const b = await import("file:///Users/davidchenallio/src/graphrefly-ts/archive/evals/causal-workload-diagnostic-v1/run/assets/worker-copy.mjs");
fs.writeFileSync("/Users/davidchenallio/src/graphrefly-ts/archive/evals/causal-workload-diagnostic-v1/run/15/entry.json",JSON.stringify({pid:process.pid,timeOrigin:performance.timeOrigin,node:process.version,execArgv:process.execArgv}));
await d.runRow("/Users/davidchenallio/src/graphrefly-ts/archive/evals/causal-workload-diagnostic-v1/run/15/config.json",[a,b]);
