// packages/ts/src/identity.ts
function canonicalTupleKey(parts) {
  return JSON.stringify(parts);
}

// packages/ts/src/json/codec.ts
var JS_MIN_NORMAL_NUMBER = 2 ** -1022;
function deepFreezeStrictJson(value) {
  if (value !== null && typeof value === "object") {
    if (Array.isArray(value)) {
      for (const item of value) deepFreezeStrictJson(item);
    } else {
      for (const item of Object.values(value)) deepFreezeStrictJson(item);
    }
    Object.freeze(value);
  }
  return value;
}
function assertStableJsonNumber(value, path) {
  if (!Number.isFinite(value)) {
    throw new TypeError(`stableJsonString: non-finite number at ${path}`);
  }
}
function assertStrictJsonNumber(value, path) {
  assertStableJsonNumber(value, path);
  if (Object.is(value, -0)) {
    throw new TypeError(`stableJsonString: non-canonical number at ${path}`);
  }
  const abs = Math.abs(value);
  if (abs > 0 && abs < JS_MIN_NORMAL_NUMBER) {
    throw new TypeError(`stableJsonString: subnormal number at ${path}`);
  }
  if (Number.isInteger(value) && !Number.isSafeInteger(value)) {
    throw new TypeError(`stableJsonString: integer outside safe range at ${path}`);
  }
}
function sortedJsonValue(value, seen = /* @__PURE__ */ new Set(), path = "$", strictNumbers = false) {
  if (value === null) return null;
  if (typeof value === "string" || typeof value === "boolean") return value;
  if (typeof value === "number") {
    if (strictNumbers) assertStrictJsonNumber(value, path);
    else assertStableJsonNumber(value, path);
    return value;
  }
  if (typeof value !== "object") {
    throw new TypeError(`stableJsonString: value at ${path} is not JSON-encodable`);
  }
  if (seen.has(value)) throw new TypeError(`stableJsonString: circular reference at ${path}`);
  const proto = Object.getPrototypeOf(value);
  if (!Array.isArray(value) && proto !== Object.prototype && proto !== null) {
    throw new TypeError(`stableJsonString: non-plain object at ${path}`);
  }
  seen.add(value);
  try {
    if (Array.isArray(value)) {
      if (Object.getOwnPropertySymbols(value).length > 0) {
        throw new TypeError(`stableJsonString: symbol-keyed properties at ${path}`);
      }
      for (const key of Object.getOwnPropertyNames(value)) {
        const isIndex = /^(0|[1-9]\d*)$/.test(key) && Number.isSafeInteger(Number(key)) && Number(key) < value.length;
        const descriptor = Object.getOwnPropertyDescriptor(value, key);
        if (descriptor !== void 0 && ("get" in descriptor || "set" in descriptor)) {
          throw new TypeError(`stableJsonString: accessor property at ${path}.${key}`);
        }
        if (key !== "length" && !isIndex) {
          throw new TypeError(`stableJsonString: non-index array property at ${path}.${key}`);
        }
        if (key !== "length" && descriptor !== void 0 && !descriptor.enumerable) {
          throw new TypeError(`stableJsonString: non-enumerable array property at ${path}.${key}`);
        }
      }
      const out2 = [];
      for (let i = 0; i < value.length; i += 1) {
        if (!(i in value)) {
          throw new TypeError(`stableJsonString: sparse array hole at ${path}[${i}]`);
        }
        out2.push(sortedJsonValue(value[i], seen, `${path}[${i}]`, strictNumbers));
      }
      return out2;
    }
    if (Object.getOwnPropertySymbols(value).length > 0) {
      throw new TypeError(`stableJsonString: symbol-keyed properties at ${path}`);
    }
    for (const key of Object.getOwnPropertyNames(value)) {
      const descriptor = Object.getOwnPropertyDescriptor(value, key);
      if (descriptor !== void 0 && ("get" in descriptor || "set" in descriptor)) {
        throw new TypeError(`stableJsonString: accessor property at ${path}.${key}`);
      }
      if (descriptor !== void 0 && !descriptor.enumerable) {
        throw new TypeError(`stableJsonString: non-enumerable property at ${path}.${key}`);
      }
    }
    const out = /* @__PURE__ */ Object.create(null);
    for (const key of Object.keys(value).sort()) {
      out[key] = sortedJsonValue(
        value[key],
        seen,
        `${path}.${key}`,
        strictNumbers
      );
    }
    return out;
  } finally {
    seen.delete(value);
  }
}
function stableJsonString(value) {
  return JSON.stringify(sortedJsonValue(value));
}
function strictStableJsonString(value) {
  return JSON.stringify(cloneStrictJsonValue(value));
}
function jsonCodecFor() {
  const encoder = new TextEncoder();
  const decoder = new TextDecoder();
  return {
    encode(value) {
      return encoder.encode(stableJsonString(value));
    },
    decode(bytes) {
      return JSON.parse(decoder.decode(bytes));
    }
  };
}
var jsonCodec = jsonCodecFor();
function bytesEqual(a, b) {
  if (a.byteLength !== b.byteLength) return false;
  for (let i = 0; i < a.byteLength; i += 1) {
    if (a[i] !== b[i]) return false;
  }
  return true;
}
function hasUnpairedSurrogate(value) {
  for (let i = 0; i < value.length; i += 1) {
    const code = value.charCodeAt(i);
    if (code >= 55296 && code <= 56319) {
      const next = value.charCodeAt(i + 1);
      if (next >= 56320 && next <= 57343) {
        i += 1;
        continue;
      }
      return true;
    }
    if (code >= 56320 && code <= 57343) return true;
  }
  return false;
}
function assertNoUnpairedSurrogates(value, seen = /* @__PURE__ */ new Set(), path = "$") {
  if (typeof value === "string") {
    if (hasUnpairedSurrogate(value)) {
      throw new TypeError(`strictJsonCodec: unpaired surrogate at ${path}`);
    }
    return;
  }
  if (value === null || typeof value !== "object") return;
  if (seen.has(value)) return;
  seen.add(value);
  try {
    if (Array.isArray(value)) {
      for (let i = 0; i < value.length; i += 1) {
        const descriptor = Object.getOwnPropertyDescriptor(value, String(i));
        if (descriptor === void 0 || "get" in descriptor || "set" in descriptor) continue;
        assertNoUnpairedSurrogates(descriptor.value, seen, `${path}[${i}]`);
      }
      return;
    }
    for (const key of Object.keys(value)) {
      if (hasUnpairedSurrogate(key)) {
        throw new TypeError(`strictJsonCodec: unpaired surrogate at ${path}.${key}`);
      }
      const descriptor = Object.getOwnPropertyDescriptor(value, key);
      if (descriptor === void 0 || "get" in descriptor || "set" in descriptor) continue;
      assertNoUnpairedSurrogates(descriptor.value, seen, `${path}.${key}`);
    }
  } finally {
    seen.delete(value);
  }
}
function strictJsonDataErrorsInner(value, label, seen) {
  if (value === null || typeof value === "string" || typeof value === "boolean") {
    if (typeof value === "string" && hasUnpairedSurrogate(value)) {
      return { errors: [`${label} must not contain unpaired surrogate strings`] };
    }
    return { errors: [], value };
  }
  if (typeof value === "number") {
    try {
      assertStrictJsonNumber(value, label);
    } catch (error) {
      return { errors: [error instanceof Error ? error.message : String(error)] };
    }
    return { errors: [], value };
  }
  if (typeof value !== "object") {
    return { errors: [`${label} is not JSON-encodable`] };
  }
  if (seen.has(value)) return { errors: [`${label} must not contain circular references`] };
  const proto = Object.getPrototypeOf(value);
  if (!Array.isArray(value) && proto !== Object.prototype && proto !== null) {
    return { errors: [`stableJsonString: non-plain object at ${label}`] };
  }
  seen.add(value);
  try {
    if (Array.isArray(value)) {
      const errors2 = [];
      if (Object.getOwnPropertySymbols(value).length > 0) {
        errors2.push(`${label} must not carry symbol keys`);
      }
      for (const key of Object.getOwnPropertyNames(value)) {
        const descriptor = Object.getOwnPropertyDescriptor(value, key);
        if (descriptor === void 0) continue;
        const isIndex = /^(0|[1-9]\d*)$/.test(key) && Number.isSafeInteger(Number(key)) && Number(key) < value.length;
        if ("get" in descriptor || "set" in descriptor) {
          errors2.push(`${label}.${key} must be a data property`);
        }
        if (key !== "length" && !isIndex) {
          errors2.push(`${label}.${key} must be an indexed data property`);
        }
        if (key !== "length" && isIndex && !descriptor.enumerable) {
          errors2.push(`${label}.${key} must be enumerable`);
        }
      }
      const out2 = [];
      for (let index = 0; index < value.length; index += 1) {
        const descriptor = Object.getOwnPropertyDescriptor(value, String(index));
        if (descriptor === void 0) {
          errors2.push(`stableJsonString: sparse array hole at ${label}[${index}]`);
          continue;
        }
        if ("get" in descriptor || "set" in descriptor) {
          errors2.push(`${label}[${index}] must be a data property`);
          continue;
        }
        if (!descriptor.enumerable) {
          errors2.push(`${label}[${index}] must be enumerable`);
          continue;
        }
        const nested = strictJsonDataErrorsInner(descriptor.value, `${label}[${index}]`, seen);
        errors2.push(...nested.errors);
        if (nested.errors.length === 0 && nested.value !== void 0) out2.push(nested.value);
      }
      if (errors2.length > 0) return { errors: errors2 };
      return { errors: [], value: Object.freeze(out2) };
    }
    const errors = [];
    if (Object.getOwnPropertySymbols(value).length > 0) {
      errors.push(`${label} must not carry symbol keys`);
    }
    for (const key of Object.getOwnPropertyNames(value)) {
      const descriptor = Object.getOwnPropertyDescriptor(value, key);
      if (descriptor === void 0) continue;
      if ("get" in descriptor || "set" in descriptor) {
        errors.push(`${label}.${key} must be a data property`);
      }
      if (!descriptor.enumerable) {
        errors.push(`${label}.${key} must be enumerable`);
      }
      if (hasUnpairedSurrogate(key)) {
        errors.push(`${label}.${key} must not contain unpaired surrogate keys`);
      }
    }
    const out = {};
    for (const key of Object.keys(value).sort()) {
      const descriptor = Object.getOwnPropertyDescriptor(value, key);
      if (descriptor === void 0 || "get" in descriptor || "set" in descriptor) continue;
      const nested = strictJsonDataErrorsInner(descriptor.value, `${label}.${key}`, seen);
      errors.push(...nested.errors);
      if (nested.errors.length === 0 && nested.value !== void 0) {
        Object.defineProperty(out, key, {
          value: nested.value,
          enumerable: true,
          configurable: true,
          writable: true
        });
      }
    }
    if (errors.length > 0) return { errors };
    return { errors: [], value: Object.freeze(out) };
  } finally {
    seen.delete(value);
  }
}
function cloneStrictJsonValue(value, label = "strictJsonValue") {
  const result = strictJsonDataErrorsInner(value, label, /* @__PURE__ */ new Set());
  if (result.errors.length > 0 || result.value === void 0) {
    throw new TypeError(`${label}: ${result.errors.join("; ")}`);
  }
  return deepFreezeStrictJson(result.value);
}
function assertNoDuplicateJsonObjectKeys(text) {
  let index = 0;
  function fail(message) {
    throw new TypeError(`strictJsonCodec: ${message}`);
  }
  function skipWhitespace() {
    while (/\s/.test(text[index] ?? "")) index += 1;
  }
  function readJsonString() {
    const start = index;
    index += 1;
    while (index < text.length) {
      const ch = text[index];
      if (ch === '"') {
        index += 1;
        try {
          return JSON.parse(text.slice(start, index));
        } catch {
          fail("malformed JSON string");
        }
      }
      if (ch === "\\") {
        index += 2;
        continue;
      }
      index += 1;
    }
    fail("unterminated JSON string");
  }
  function consumeLiteral(literal) {
    if (text.slice(index, index + literal.length) !== literal) {
      fail(`malformed JSON near byte ${index}`);
    }
    index += literal.length;
  }
  function consumeNumber() {
    const match = /^-?(0|[1-9]\d*)(\.\d+)?([eE][+-]?\d+)?/.exec(text.slice(index));
    if (!match) fail(`malformed JSON number near byte ${index}`);
    index += match[0].length;
  }
  function parseValue(path) {
    skipWhitespace();
    const ch = text[index];
    if (ch === "{") {
      parseObject(path);
      return;
    }
    if (ch === "[") {
      parseArray(path);
      return;
    }
    if (ch === '"') {
      readJsonString();
      return;
    }
    if (ch === "t") {
      consumeLiteral("true");
      return;
    }
    if (ch === "f") {
      consumeLiteral("false");
      return;
    }
    if (ch === "n") {
      consumeLiteral("null");
      return;
    }
    if (ch === "-" || ch !== void 0 && ch >= "0" && ch <= "9") {
      consumeNumber();
      return;
    }
    fail(`malformed JSON near byte ${index}`);
  }
  function parseObject(path) {
    const keys = /* @__PURE__ */ new Set();
    index += 1;
    skipWhitespace();
    if (text[index] === "}") {
      index += 1;
      return;
    }
    while (index < text.length) {
      skipWhitespace();
      if (text[index] !== '"') fail(`expected object key near byte ${index}`);
      const key = readJsonString();
      if (keys.has(key)) {
        throw new TypeError(
          `strictJsonCodec: duplicate object key ${JSON.stringify(key)} at ${path}`
        );
      }
      keys.add(key);
      skipWhitespace();
      if (text[index] !== ":") fail(`expected ':' after object key near byte ${index}`);
      index += 1;
      parseValue(`${path}.${key}`);
      skipWhitespace();
      if (text[index] === ",") {
        index += 1;
        continue;
      }
      if (text[index] === "}") {
        index += 1;
        return;
      }
      fail(`expected ',' or '}' near byte ${index}`);
    }
    fail("unterminated JSON object");
  }
  function parseArray(path) {
    index += 1;
    skipWhitespace();
    if (text[index] === "]") {
      index += 1;
      return;
    }
    let item = 0;
    while (index < text.length) {
      parseValue(`${path}[${item}]`);
      item += 1;
      skipWhitespace();
      if (text[index] === ",") {
        index += 1;
        continue;
      }
      if (text[index] === "]") {
        index += 1;
        return;
      }
      fail(`expected ',' or ']' near byte ${index}`);
    }
    fail("unterminated JSON array");
  }
  parseValue("$");
  skipWhitespace();
  if (index !== text.length) fail(`trailing JSON token near byte ${index}`);
}
function strictJsonCodecFor() {
  const encoder = new TextEncoder();
  const decoder = new TextDecoder("utf-8", { fatal: true });
  return {
    encode(value) {
      assertNoUnpairedSurrogates(value);
      return encoder.encode(strictStableJsonString(value));
    },
    decode(bytes) {
      const text = decoder.decode(bytes);
      assertNoDuplicateJsonObjectKeys(text);
      const decoded = JSON.parse(text);
      assertNoUnpairedSurrogates(decoded);
      const canonical = encoder.encode(strictStableJsonString(decoded));
      if (!bytesEqual(bytes, canonical)) {
        throw new TypeError("strictJsonCodec: bytes are not canonical stable JSON");
      }
      return decoded;
    }
  };
}
var strictJsonCodec = strictJsonCodecFor();

// packages/ts/src/solutions/causal-occurrence/identity.ts
var digestPattern = /^sha256:[0-9a-f]{64}$/u;
var CAUSAL_OCCURRENCE_SCHEMA_REVISION = "graphrefly/causal-occurrence-contract/v1@contract-v2";
var terminalCoverage = /* @__PURE__ */ new Set([
  "included",
  "excluded",
  "redacted",
  "sampled",
  "external-only",
  "stale",
  "unavailable",
  "retention-gap",
  "skipped-revision"
]);
function issue(code, message, refs = []) {
  return Object.freeze({ kind: "issue", code, message, severity: "error", refs });
}
function dataKey(value) {
  return stableJsonString(value);
}
var sha256Constants = Object.freeze([
  1116352408,
  1899447441,
  3049323471,
  3921009573,
  961987163,
  1508970993,
  2453635748,
  2870763221,
  3624381080,
  310598401,
  607225278,
  1426881987,
  1925078388,
  2162078206,
  2614888103,
  3248222580,
  3835390401,
  4022224774,
  264347078,
  604807628,
  770255983,
  1249150122,
  1555081692,
  1996064986,
  2554220882,
  2821834349,
  2952996808,
  3210313671,
  3336571891,
  3584528711,
  113926993,
  338241895,
  666307205,
  773529912,
  1294757372,
  1396182291,
  1695183700,
  1986661051,
  2177026350,
  2456956037,
  2730485921,
  2820302411,
  3259730800,
  3345764771,
  3516065817,
  3600352804,
  4094571909,
  275423344,
  430227734,
  506948616,
  659060556,
  883997877,
  958139571,
  1322822218,
  1537002063,
  1747873779,
  1955562222,
  2024104815,
  2227730452,
  2361852424,
  2428436474,
  2756734187,
  3204031479,
  3329325298
]);
function rotateRight(value, count) {
  return value >>> count | value << 32 - count;
}
function sha256(value) {
  const input = new TextEncoder().encode(value);
  const bitLength = input.length * 8;
  const paddedLength = Math.ceil((input.length + 9) / 64) * 64;
  const bytes = new Uint8Array(paddedLength);
  bytes.set(input);
  bytes[input.length] = 128;
  const view = new DataView(bytes.buffer);
  view.setUint32(paddedLength - 8, Math.floor(bitLength / 4294967296), false);
  view.setUint32(paddedLength - 4, bitLength >>> 0, false);
  const hash = new Uint32Array([
    1779033703,
    3144134277,
    1013904242,
    2773480762,
    1359893119,
    2600822924,
    528734635,
    1541459225
  ]);
  const words = new Uint32Array(64);
  for (let offset = 0; offset < bytes.length; offset += 64) {
    for (let index = 0; index < 16; index += 1)
      words[index] = view.getUint32(offset + index * 4, false);
    for (let index = 16; index < 64; index += 1) {
      const s0 = rotateRight(words[index - 15], 7) ^ rotateRight(words[index - 15], 18) ^ words[index - 15] >>> 3;
      const s1 = rotateRight(words[index - 2], 17) ^ rotateRight(words[index - 2], 19) ^ words[index - 2] >>> 10;
      words[index] = words[index - 16] + s0 + words[index - 7] + s1 >>> 0;
    }
    let [a, b, c, d, e, f, g, h] = hash;
    for (let index = 0; index < 64; index += 1) {
      const sum1 = rotateRight(e, 6) ^ rotateRight(e, 11) ^ rotateRight(e, 25);
      const choice = e & f ^ ~e & g;
      const temporary1 = h + sum1 + choice + sha256Constants[index] + words[index] >>> 0;
      const sum0 = rotateRight(a, 2) ^ rotateRight(a, 13) ^ rotateRight(a, 22);
      const majority = a & b ^ a & c ^ b & c;
      const temporary2 = sum0 + majority >>> 0;
      h = g;
      g = f;
      f = e;
      e = d + temporary1 >>> 0;
      d = c;
      c = b;
      b = a;
      a = temporary1 + temporary2 >>> 0;
    }
    hash[0] = hash[0] + a >>> 0;
    hash[1] = hash[1] + b >>> 0;
    hash[2] = hash[2] + c >>> 0;
    hash[3] = hash[3] + d >>> 0;
    hash[4] = hash[4] + e >>> 0;
    hash[5] = hash[5] + f >>> 0;
    hash[6] = hash[6] + g >>> 0;
    hash[7] = hash[7] + h >>> 0;
  }
  return `sha256:${[...hash].map((word) => word.toString(16).padStart(8, "0")).join("")}`;
}
function causalOccurrenceDigest(value) {
  return sha256(
    dataKey({
      schemaRevision: CAUSAL_OCCURRENCE_SCHEMA_REVISION,
      revisionDomain: value.revisionDomain,
      occurrenceId: value.occurrenceId,
      revision: value.revision,
      value: value.value,
      sourceRefs: value.sourceRefs
    })
  );
}
function canonicalSnapshot(value) {
  const freeze = (item) => {
    if (item === null || typeof item !== "object") return item;
    if (Array.isArray(item)) return Object.freeze(item.map(freeze));
    return Object.freeze(
      Object.fromEntries(Object.entries(item).map(([key, child]) => [key, freeze(child)]))
    );
  };
  return freeze(JSON.parse(dataKey(value)));
}
function canonicalEntry(value) {
  try {
    return Object.freeze({ key: dataKey(value), snapshot: canonicalSnapshot(value) });
  } catch {
    return void 0;
  }
}
function refKey(value) {
  return canonicalTupleKey([
    value.revisionDomain,
    String(value.revision),
    value.occurrenceId,
    value.digest,
    dataKey(value.sourceRefs)
  ]);
}
function occurrenceIdKey(value) {
  return canonicalTupleKey([value.revisionDomain, value.occurrenceId]);
}
function revisionKey(domain, revision) {
  return canonicalTupleKey([domain, String(revision)]);
}
function effectKey(value) {
  return canonicalTupleKey([refKey(value.occurrence), value.effectId]);
}
function validToken(value) {
  return typeof value === "string" && value.length > 0;
}
function validSourceRef(value) {
  return value !== null && typeof value === "object" && "kind" in value && validToken(value.kind) && "id" in value && validToken(value.id);
}
function validRef(value) {
  return value !== null && typeof value === "object" && "revisionDomain" in value && validToken(value.revisionDomain) && "occurrenceId" in value && validToken(value.occurrenceId) && "revision" in value && Number.isSafeInteger(value.revision) && value.revision > 0 && "digest" in value && typeof value.digest === "string" && digestPattern.test(value.digest) && "sourceRefs" in value && Array.isArray(value.sourceRefs) && value.sourceRefs.length > 0 && value.sourceRefs.every(validSourceRef) && new Set(value.sourceRefs.map((ref) => canonicalTupleKey([ref.kind, ref.id]))).size === value.sourceRefs.length;
}
function validAdmissionState(value) {
  return value === "admitted" || value === "rejected";
}
function validOutcomeState(value) {
  return value === "succeeded" || value === "failed" || value === "cancelled" || value === "reconcile-required" || value === "unknown";
}
function validTerminal(value) {
  return (value.state === "completed" || value.state === "failed" || value.state === "skipped") && validResult(value.result) && value.state === "completed" === (value.result.kind === "ok");
}
function sameRef(left, right) {
  return refKey(left) === refKey(right);
}
function validResult(value) {
  if (value === null || typeof value !== "object") return false;
  if (value.kind === "ok") return Object.hasOwn(value, "value");
  return value.kind === "error" && value.error?.kind === "issue" && validToken(value.error.code) && validToken(value.error.message);
}
function pushIssue(outputs, value) {
  outputs.push({ kind: "issue", value });
}
var retainPending = (opts, outputs, map, key, value, label) => {
  const prior = map.get(key);
  if (prior !== void 0) {
    if (dataKey(prior) !== dataKey(value))
      pushIssue(
        outputs,
        issue(
          `causal-occurrence/${label}-conflict`,
          `Pending ${label} replay conflicts with retained DATA.`,
          [key]
        )
      );
    return;
  }
  if (map.size >= opts.maxPending) {
    pushIssue(
      outputs,
      issue(
        `causal-occurrence/${label}-pending-bound`,
        `Pending ${label} exceeded bounded retention.`,
        [key]
      )
    );
    return;
  }
  map.set(key, value);
};
function retainDomain(context, domain) {
  const { state, opts, outputs } = context;
  if (state.domains.has(domain)) return true;
  if (state.domains.size >= opts.maxOccurrences) {
    pushIssue(
      outputs,
      issue("causal-occurrence/domain-bound", "Revision-domain retention bound was reached.", [
        domain
      ])
    );
    return false;
  }
  state.domains.add(domain);
  return true;
}
function findOccurrence(context, ref) {
  const { state } = context;
  return state.byRevision.get(revisionKey(ref.revisionDomain, ref.revision))?.value;
}
function exactOccurrence(context, ref) {
  const retained = findOccurrence(context, ref);
  return retained !== void 0 && sameRef(retained, ref) ? retained : void 0;
}
function rejectDefinitiveMissingRef(context, ref, label) {
  const { state, outputs } = context;
  const retained = findOccurrence(context, ref);
  const floor = state.retentionFloorByDomain.get(ref.revisionDomain) ?? 0;
  const highWater = state.highWaterByDomain.get(ref.revisionDomain) ?? 0;
  if (retained !== void 0 && !sameRef(retained, ref)) {
    pushIssue(
      outputs,
      issue(
        `causal-occurrence/${label}-occurrence-conflict`,
        `${label} references a conflicting occurrence revision.`,
        [refKey(ref)]
      )
    );
    return true;
  }
  if (ref.revision <= floor || ref.revision <= highWater && retained === void 0) {
    pushIssue(
      outputs,
      issue(
        ref.revision <= floor ? `causal-occurrence/${label}-retention-gap` : `causal-occurrence/${label}-stale`,
        `${label} references a revision that cannot regain authority.`,
        [refKey(ref)]
      )
    );
    return true;
  }
  return false;
}
function maybeRelease(context, occurrence) {
  const { state, outputs } = context;
  const key = refKey(occurrence);
  const admission = state.admissions.get(key);
  const currentness = state.currentness.get(key);
  if (admission?.state !== "admitted" || !sameRef(admission.occurrence, occurrence) || currentness?.state !== "current" || state.released.has(key) || currentness.evaluatedThroughRevision < occurrence.revision)
    return;
  state.released.add(key);
  outputs.push({ kind: "release", value: occurrence });
}
function exactAdmission(context, occurrence) {
  const { state } = context;
  const admission = state.admissions.get(refKey(occurrence));
  return admission !== void 0 && sameRef(admission.occurrence, occurrence) ? admission : void 0;
}
function currentnessMetadata(value, occurrence) {
  if (value === null || typeof value !== "object" || Object.getPrototypeOf(value) !== Object.prototype)
    return;
  const keys = Reflect.ownKeys(value);
  if (keys.length !== 4 || !keys.every(
    (key) => key === "kind" || key === "occurrence" || key === "evaluatedThroughRevision" || key === "state"
  ))
    return;
  const fields = Object.getOwnPropertyDescriptors(value);
  for (const key of keys) {
    const field = fields[key];
    if (field === void 0 || !("value" in field) || !field.enumerable) return;
  }
  if (fields.kind.value !== "causal-currentness" || fields.occurrence.value !== occurrence || typeof fields.evaluatedThroughRevision.value !== "number" || !Number.isSafeInteger(fields.evaluatedThroughRevision.value) || fields.evaluatedThroughRevision.value < 0 || fields.state.value !== "current" && fields.state.value !== "stale")
    return;
  return {
    kind: fields.kind.value,
    occurrence: null,
    evaluatedThroughRevision: fields.evaluatedThroughRevision.value,
    state: fields.state.value
  };
}
function currentnessChanged(prior, value, occurrence) {
  if (Object.isFrozen(occurrence)) {
    const before = currentnessMetadata(prior, occurrence);
    const after = currentnessMetadata(value, occurrence);
    if (before !== void 0 && after !== void 0) return dataKey(before) !== dataKey(after);
  }
  return dataKey(prior) !== dataKey(value);
}
function recomputeCurrentness(context, revisionDomain) {
  const { state, outputs } = context;
  const watermark = state.watermarks.get(revisionDomain);
  if (watermark === void 0) return;
  const floor = state.retentionFloorByDomain.get(revisionDomain) ?? 0;
  const occurrences = [...state.byRevision.values()].map((entry) => entry.value).filter((value) => value.revisionDomain === revisionDomain && value.revision <= watermark).sort((left, right) => left.revision - right.revision);
  const evaluated = occurrences.map((occurrence) => ({
    occurrence,
    admission: exactAdmission(context, occurrence)
  }));
  const sequenceComplete = (state.highWaterByDomain.get(revisionDomain) ?? 0) >= watermark && (state.retentionGapThroughByDomain.get(revisionDomain) ?? 0) === 0 && ![...state.pending.values()].some(
    (entry) => entry.value.revisionDomain === revisionDomain && entry.value.revision <= watermark
  ) && evaluated.filter(({ occurrence }) => occurrence.revision > floor).every(({ admission }) => admission !== void 0);
  const latestAdmitted = /* @__PURE__ */ new Map();
  for (const { occurrence, admission } of evaluated) {
    if (admission?.state === "admitted")
      latestAdmitted.set(occurrenceIdKey(occurrence), occurrence);
  }
  for (const { occurrence, admission } of evaluated) {
    const newer = latestAdmitted.get(occurrenceIdKey(occurrence));
    const value = admission === void 0 || !sequenceComplete ? {
      kind: "causal-currentness",
      occurrence,
      evaluatedThroughRevision: watermark,
      state: "unverifiable",
      ...(state.retentionGapThroughByDomain.get(revisionDomain) ?? 0) > 0 ? {
        gapRef: {
          revisionDomain,
          afterRevision: state.retentionGapThroughByDomain.get(revisionDomain),
          reason: "retention-gap",
          evidenceRef: {
            kind: "causal-evidence",
            id: state.occurrenceRetentionGaps.get(revisionDomain).evidenceId
          }
        }
      } : {}
    } : admission.state === "rejected" ? {
      kind: "causal-currentness",
      occurrence,
      evaluatedThroughRevision: watermark,
      state: "stale"
    } : newer !== void 0 && newer !== occurrence ? {
      kind: "causal-currentness",
      occurrence,
      evaluatedThroughRevision: watermark,
      state: "superseded",
      supersededBy: newer
    } : {
      kind: "causal-currentness",
      occurrence,
      evaluatedThroughRevision: watermark,
      state: "current"
    };
    const key = refKey(occurrence);
    const prior = state.currentness.get(key);
    state.currentness.set(key, value);
    if (prior === void 0 || currentnessChanged(prior, value, occurrence))
      outputs.push({ kind: "currentness", value });
    maybeRelease(context, occurrence);
  }
  return { watermark, occurrences, sequenceComplete, latestAdmitted };
}
function flushAdmissions(context) {
  const { state, outputs } = context;
  for (const [key, admission] of state.admissions) {
    const retained = findOccurrence(context, admission.occurrence);
    if (retained !== void 0 && !sameRef(retained, admission.occurrence)) {
      pushIssue(
        outputs,
        issue(
          "causal-occurrence/admission-mismatch",
          "Deferred admission conflicts with the retained occurrence revision.",
          [key]
        )
      );
      state.admissions.delete(key);
    }
    if (retained === void 0 && rejectDefinitiveMissingRef(context, admission.occurrence, "admission"))
      state.admissions.delete(key);
  }
}
function receiveAdmissions(context, arrival) {
  const { state, opts, outputs } = context;
  for (const admission of arrival.values) {
    if (admission === null || typeof admission !== "object" || !validRef(admission.occurrence) || !validToken(admission.decisionId) || typeof admission.decisionDigest !== "string" || !digestPattern.test(admission.decisionDigest) || !validAdmissionState(admission.state)) {
      pushIssue(
        outputs,
        issue("causal-occurrence/invalid-admission", "Occurrence admission identity is invalid.")
      );
      continue;
    }
    const canonical = canonicalEntry(admission);
    if (canonical === void 0) {
      pushIssue(
        outputs,
        issue("causal-occurrence/non-data-admission", "Admission must be canonical DATA.")
      );
      continue;
    }
    if (!retainDomain(context, admission.occurrence.revisionDomain)) continue;
    const key = refKey(admission.occurrence);
    const prior = state.admissions.get(key);
    if (prior !== void 0) {
      if (dataKey(prior) !== canonical.key)
        pushIssue(
          outputs,
          issue(
            "causal-occurrence/admission-conflict",
            "Admission replay conflicts with retained decision.",
            [key]
          )
        );
      continue;
    }
    const retained = findOccurrence(context, admission.occurrence);
    if (retained !== void 0 && !sameRef(retained, admission.occurrence)) {
      pushIssue(
        outputs,
        issue(
          "causal-occurrence/admission-mismatch",
          "Admission does not match the retained occurrence.",
          [key]
        )
      );
      continue;
    }
    if (retained === void 0 && state.admissions.size >= opts.maxPending) {
      pushIssue(
        outputs,
        issue(
          "causal-occurrence/admission-bound",
          "Unmatched admission exceeded bounded pending retention.",
          [key]
        )
      );
      continue;
    }
    state.admissions.set(key, canonical.snapshot);
  }
}
function receiveWatermarks(context, arrival) {
  const { state, outputs } = context;
  for (const watermark of arrival.values) {
    if (watermark === null || typeof watermark !== "object" || !validToken(watermark.revisionDomain) || !Number.isSafeInteger(watermark.revision) || watermark.revision < 0) {
      pushIssue(outputs, issue("causal-occurrence/invalid-watermark", "Watermark is invalid."));
      continue;
    }
    if (!retainDomain(context, watermark.revisionDomain)) continue;
    const prior = state.watermarks.get(watermark.revisionDomain) ?? 0;
    if (watermark.revision < prior) {
      pushIssue(
        outputs,
        issue("causal-occurrence/stale-watermark", "Watermark cannot move backwards.")
      );
      continue;
    }
    state.watermarks.set(watermark.revisionDomain, watermark.revision);
  }
}

// packages/ts/src/solutions/causal-occurrence/evidence.ts
function emitCoverage(context, occurrence) {
  const { state, opts, outputs } = context;
  let occurrenceKey;
  const entries = [...state.evidence.values(), ...state.coverageGaps.values()].filter((value) => {
    const entryKey = refKey(value.occurrence);
    occurrenceKey ??= refKey(occurrence);
    return entryKey === occurrenceKey;
  });
  const byKind = new Map(entries.map((value) => [value.evidenceKind, value]));
  const missingKinds = opts.requiredEvidenceKinds.filter((kind) => !byKind.has(kind));
  const terminalGapKinds = opts.requiredEvidenceKinds.filter((kind) => {
    const value = byKind.get(kind);
    return value !== void 0 && value.coverage !== "included" && value.coverage !== "external-only";
  });
  outputs.push({
    kind: "coverage",
    value: {
      kind: "causal-evidence-coverage",
      occurrence,
      complete: missingKinds.length === 0 && entries.every(
        (value) => value.coverage !== "retention-gap" && value.coverage !== "skipped-revision"
      ),
      entries: Object.freeze(entries),
      missingKinds: Object.freeze(missingKinds),
      terminalGapKinds: Object.freeze(terminalGapKinds)
    }
  });
}
function retainEvidence(context, key, evidence) {
  const { state, opts, outputs } = context;
  const prior = state.evidence.get(key);
  if (prior !== void 0) {
    if (dataKey(prior) !== dataKey(evidence))
      pushIssue(
        outputs,
        issue("causal-occurrence/evidence-conflict", "Evidence replay conflicts.", [key])
      );
    return;
  }
  if (state.evidence.size >= opts.maxEvidence) {
    pushIssue(
      outputs,
      issue("causal-occurrence/evidence-bound", "Evidence retention bound was reached.", [key])
    );
    const gapKey = JSON.stringify([
      refKey(evidence.occurrence),
      opts.requiredEvidenceKinds.includes(evidence.evidenceKind) ? evidence.evidenceKind : null
    ]);
    if (!state.coverageGaps.has(gapKey))
      state.coverageGaps.set(
        gapKey,
        canonicalSnapshot({ ...evidence, coverage: "retention-gap" })
      );
  } else {
    state.evidence.set(key, evidence);
  }
  emitCoverage(context, evidence.occurrence);
}
function flushEvidence(context) {
  const { state } = context;
  for (const [key, evidence] of state.pendingEvidence) {
    if (exactOccurrence(context, evidence.occurrence) === void 0) {
      if (rejectDefinitiveMissingRef(context, evidence.occurrence, "evidence"))
        state.pendingEvidence.delete(key);
      continue;
    }
    retainEvidence(context, key, evidence);
    state.pendingEvidence.delete(key);
  }
}
function receiveEvidence(context, arrival) {
  const { state, opts, outputs } = context;
  for (const evidence of arrival.values) {
    if (evidence === null || typeof evidence !== "object" || !validRef(evidence.occurrence) || !validToken(evidence.evidenceKind) || !validToken(evidence.evidenceId) || typeof evidence.evidenceDigest !== "string" || !digestPattern.test(evidence.evidenceDigest) || !terminalCoverage.has(evidence.coverage) || evidence.coverage === "external-only" && (!Array.isArray(evidence.refs) || evidence.refs.length === 0 || !evidence.refs.every(validToken))) {
      pushIssue(
        outputs,
        issue(
          "causal-occurrence/evidence-mismatch",
          "Evidence does not match retained occurrence authority."
        )
      );
      continue;
    }
    const canonical = canonicalEntry(evidence);
    if (canonical === void 0) {
      pushIssue(
        outputs,
        issue("causal-occurrence/non-data-evidence", "Evidence must be canonical DATA.")
      );
      continue;
    }
    if (!retainDomain(context, evidence.occurrence.revisionDomain)) continue;
    const key = canonicalTupleKey([
      refKey(evidence.occurrence),
      evidence.evidenceKind,
      evidence.evidenceId
    ]);
    if (exactOccurrence(context, evidence.occurrence) === void 0) {
      if (rejectDefinitiveMissingRef(context, evidence.occurrence, "evidence")) continue;
      retainPending(opts, outputs, state.pendingEvidence, key, canonical.snapshot, "evidence");
      continue;
    }
    retainEvidence(context, key, canonical.snapshot);
  }
}
function isEvidenceTerminal(context, revisionDomain, domain) {
  const { state, opts } = context;
  const { watermark, occurrences } = domain;
  for (const evidence of state.pendingEvidence.values()) {
    if (evidence.occurrence.revisionDomain === revisionDomain && evidence.occurrence.revision <= watermark)
      return false;
  }
  if (occurrences.length === 0 || opts.requiredEvidenceKinds.length === 0) return true;
  const covered = /* @__PURE__ */ new Map();
  for (const records of [state.evidence, state.coverageGaps]) {
    for (const entry of records.values()) {
      if (entry.occurrence.revisionDomain !== revisionDomain || !terminalCoverage.has(entry.coverage))
        continue;
      const key = refKey(entry.occurrence);
      let kinds = covered.get(key);
      if (kinds === void 0) {
        kinds = /* @__PURE__ */ new Set();
        covered.set(key, kinds);
      }
      kinds.add(entry.evidenceKind);
    }
  }
  return occurrences.every((occurrence) => {
    const kinds = covered.get(refKey(occurrence));
    return opts.requiredEvidenceKinds.every((kind) => kinds?.has(kind) === true);
  });
}

// packages/ts/src/solutions/causal-occurrence/lifecycle.ts
function settledForEviction(context, occurrence) {
  const { state } = context;
  const key = refKey(occurrence);
  const admission = state.admissions.get(key);
  if (admission?.state === "rejected") return true;
  if (admission?.state !== "admitted" || !state.released.has(key) || !state.emittedTerminals.has(key))
    return false;
  if ([
    ...state.pendingEffectProposals.values(),
    ...state.pendingEffectAdmissions.values(),
    ...state.pendingEffectOutcomes.values()
  ].some((fact) => sameRef(fact.occurrence, occurrence)))
    return false;
  return [...state.effects.values()].filter((record) => sameRef(record.proposal.occurrence, occurrence)).every(
    (record) => record.admission?.state === "rejected" || record.admission?.state === "admitted" && record.outcome !== void 0
  );
}
function emitConservation(context, occurrence) {
  const { state, outputs } = context;
  const records = [...state.effects.values()].filter(
    (record) => sameRef(record.proposal.occurrence, occurrence)
  );
  const admitted = records.filter((record) => record.admission?.state === "admitted");
  const count = (value) => admitted.filter((record) => record.outcome?.state === value).length;
  outputs.push({
    kind: "conservation",
    value: {
      kind: "causal-effect-conservation",
      occurrence,
      proposed: records.length,
      pendingAdmission: records.filter((record) => record.admission === void 0).length,
      rejected: records.filter((record) => record.admission?.state === "rejected").length,
      admitted: admitted.length,
      active: admitted.filter((record) => record.outcome === void 0).length,
      succeeded: count("succeeded"),
      failed: count("failed"),
      cancelled: count("cancelled"),
      reconcileRequired: count("reconcile-required"),
      unknown: count("unknown")
    }
  });
}
function retainEffectProposal(context, key, proposal) {
  const { state, opts, outputs } = context;
  const pending = state.pendingEffectProposals.get(key);
  if (pending !== void 0 && dataKey(pending) !== dataKey(proposal)) {
    pushIssue(
      outputs,
      issue(
        "causal-occurrence/effect-proposal-conflict",
        "Effect proposal conflicts with its retained pending snapshot.",
        [key]
      )
    );
    return true;
  }
  const prior = state.effects.get(key);
  if (prior !== void 0) {
    if (prior.key !== dataKey(proposal))
      pushIssue(
        outputs,
        issue("causal-occurrence/effect-proposal-conflict", "Effect proposal replay conflicts.", [
          key
        ])
      );
    return true;
  }
  if (state.effects.size >= opts.maxEffects) {
    pushIssue(
      outputs,
      issue("causal-occurrence/effect-bound", "Effect retention bound was reached.", [key])
    );
    return false;
  }
  state.effects.set(key, { proposal, key: dataKey(proposal) });
  context.committedViewChanged = true;
  emitConservation(context, proposal.occurrence);
  return true;
}
function flushEffectsAndTerminals(context) {
  const { state, opts, outputs } = context;
  for (const [key, proposal] of state.pendingEffectProposals) {
    if (exactOccurrence(context, proposal.occurrence) === void 0 && rejectDefinitiveMissingRef(context, proposal.occurrence, "effect-proposal")) {
      state.pendingEffectProposals.delete(key);
      continue;
    }
    if (exactOccurrence(context, proposal.occurrence) === void 0 || !state.released.has(refKey(proposal.occurrence)))
      continue;
    if (retainEffectProposal(context, key, proposal)) state.pendingEffectProposals.delete(key);
  }
  for (const [key, admission] of state.pendingEffectAdmissions) {
    const record = state.effects.get(key);
    if (record === void 0) {
      if (rejectDefinitiveMissingRef(context, admission.occurrence, "effect-admission"))
        state.pendingEffectAdmissions.delete(key);
      continue;
    }
    if (record.proposal.proposalDigest !== admission.proposalDigest || dataKey(record.proposal.requestRef) !== dataKey(admission.requestRef) || !sameRef(record.proposal.occurrence, admission.occurrence)) {
      pushIssue(
        outputs,
        issue(
          "causal-occurrence/effect-admission-mismatch",
          "Deferred effect admission does not match its proposal.",
          [key]
        )
      );
      state.pendingEffectAdmissions.delete(key);
      continue;
    }
    if (record.admission === void 0) {
      state.effects.set(key, { ...record, admission });
      context.committedViewChanged = true;
    } else if (dataKey(record.admission) !== dataKey(admission))
      pushIssue(
        outputs,
        issue(
          "causal-occurrence/effect-admission-conflict",
          "Deferred effect admission conflicts with retained admission.",
          [key]
        )
      );
    state.pendingEffectAdmissions.delete(key);
    emitConservation(context, admission.occurrence);
  }
  for (const [key, outcome] of state.pendingEffectOutcomes) {
    const record = state.effects.get(key);
    if (record?.admission === void 0) {
      if (rejectDefinitiveMissingRef(context, outcome.occurrence, "effect-outcome"))
        state.pendingEffectOutcomes.delete(key);
      continue;
    }
    const matches = record.admission.state === "admitted" && record.proposal.proposalDigest === outcome.proposalDigest && dataKey(record.proposal.requestRef) === dataKey(outcome.requestRef) && dataKey(record.admission.admissionRef) === dataKey(outcome.admissionRef) && sameRef(record.proposal.occurrence, outcome.occurrence) && outcome.state === "succeeded" === (outcome.result.kind === "ok");
    if (!matches) {
      pushIssue(
        outputs,
        issue(
          "causal-occurrence/effect-outcome-mismatch",
          "Deferred effect outcome lacks exact admitted authority.",
          [key]
        )
      );
      state.pendingEffectOutcomes.delete(key);
      continue;
    }
    if (record.outcome === void 0) {
      state.effects.set(key, { ...record, outcome });
      context.committedViewChanged = true;
    } else if (dataKey(record.outcome) !== dataKey(outcome))
      pushIssue(
        outputs,
        issue(
          "causal-occurrence/effect-outcome-conflict",
          "Deferred effect outcome conflicts with retained outcome.",
          [key]
        )
      );
    state.pendingEffectOutcomes.delete(key);
    emitConservation(context, outcome.occurrence);
  }
  for (const [pendingKey, terminal] of state.pendingTerminals) {
    const key = refKey(terminal.occurrence);
    if (exactOccurrence(context, terminal.occurrence) === void 0 && rejectDefinitiveMissingRef(context, terminal.occurrence, "terminal")) {
      state.pendingTerminals.delete(pendingKey);
      continue;
    }
    if (exactOccurrence(context, terminal.occurrence) === void 0 || !state.released.has(key))
      continue;
    const branches = state.terminals.get(key) ?? /* @__PURE__ */ new Map();
    const prior = branches.get(terminal.branch);
    if (prior === void 0) branches.set(terminal.branch, terminal);
    else if (dataKey(prior) !== dataKey(terminal))
      pushIssue(
        outputs,
        issue(
          "causal-occurrence/terminal-conflict",
          "Deferred branch terminal conflicts with retained terminal.",
          [key, terminal.branch]
        )
      );
    state.terminals.set(key, branches);
    state.pendingTerminals.delete(pendingKey);
    if (!state.emittedTerminals.has(key) && opts.requiredBranches.every((branch) => branches.has(branch))) {
      state.emittedTerminals.add(key);
      outputs.push({
        kind: "terminal",
        value: {
          kind: "causal-terminal-fan-in",
          occurrence: terminal.occurrence,
          terminals: Object.freeze(opts.requiredBranches.map((branch) => branches.get(branch)))
        }
      });
    }
  }
}
function receiveTerminals(context, arrival) {
  const { state, opts, outputs } = context;
  for (const terminal of arrival.values) {
    if (terminal === null || typeof terminal !== "object" || !validRef(terminal.occurrence) || !validToken(terminal.branch) || !opts.requiredBranches.includes(terminal.branch) || !validTerminal(terminal)) {
      pushIssue(
        outputs,
        issue(
          "causal-occurrence/terminal-mismatch",
          "Terminal does not match an admitted branch occurrence."
        )
      );
      continue;
    }
    const canonical = canonicalEntry(terminal);
    if (canonical === void 0) {
      pushIssue(
        outputs,
        issue("causal-occurrence/non-data-terminal", "Terminal must be canonical DATA.")
      );
      continue;
    }
    if (!retainDomain(context, terminal.occurrence.revisionDomain)) continue;
    const key = refKey(terminal.occurrence);
    const pendingKey = canonicalTupleKey([key, terminal.branch]);
    if (exactOccurrence(context, terminal.occurrence) === void 0 && rejectDefinitiveMissingRef(context, terminal.occurrence, "terminal"))
      continue;
    if (exactOccurrence(context, terminal.occurrence) === void 0 || !state.released.has(key)) {
      retainPending(
        opts,
        outputs,
        state.pendingTerminals,
        pendingKey,
        canonical.snapshot,
        "terminal"
      );
      continue;
    }
    const branches = state.terminals.get(key) ?? /* @__PURE__ */ new Map();
    const prior = branches.get(terminal.branch);
    if (prior !== void 0 && dataKey(prior) !== canonical.key)
      pushIssue(
        outputs,
        issue(
          "causal-occurrence/terminal-conflict",
          "Branch terminal replay conflicts with retained terminal.",
          [key, terminal.branch]
        )
      );
    else if (prior === void 0) branches.set(terminal.branch, canonical.snapshot);
    state.terminals.set(key, branches);
    if (!state.emittedTerminals.has(key) && opts.requiredBranches.every((branch) => branches.has(branch))) {
      state.emittedTerminals.add(key);
      outputs.push({
        kind: "terminal",
        value: {
          kind: "causal-terminal-fan-in",
          occurrence: terminal.occurrence,
          terminals: Object.freeze(opts.requiredBranches.map((branch) => branches.get(branch)))
        }
      });
    }
  }
}
function receiveProposals(context, arrival) {
  const { state, opts, outputs } = context;
  for (const proposal of arrival.values) {
    if (proposal === null || typeof proposal !== "object" || !validRef(proposal.occurrence) || !validToken(proposal.effectId) || !validSourceRef(proposal.requestRef) || typeof proposal.proposalDigest !== "string" || !digestPattern.test(proposal.proposalDigest)) {
      pushIssue(
        outputs,
        issue(
          "causal-occurrence/effect-proposal-mismatch",
          "Effect proposal lacks exact occurrence authority."
        )
      );
      continue;
    }
    const canonical = canonicalEntry(proposal);
    if (canonical === void 0) {
      pushIssue(
        outputs,
        issue(
          "causal-occurrence/non-data-effect-proposal",
          "Effect proposal must be canonical DATA."
        )
      );
      continue;
    }
    if (!retainDomain(context, proposal.occurrence.revisionDomain)) continue;
    const key = effectKey(proposal);
    if (exactOccurrence(context, proposal.occurrence) === void 0 && rejectDefinitiveMissingRef(context, proposal.occurrence, "effect-proposal"))
      continue;
    if (exactOccurrence(context, proposal.occurrence) === void 0 || !state.released.has(refKey(proposal.occurrence))) {
      retainPending(
        opts,
        outputs,
        state.pendingEffectProposals,
        key,
        canonical.snapshot,
        "effect-proposal"
      );
      continue;
    }
    if (!retainEffectProposal(context, key, canonical.snapshot))
      retainPending(
        opts,
        outputs,
        state.pendingEffectProposals,
        key,
        canonical.snapshot,
        "effect-proposal"
      );
  }
}
function receiveEffectAdmissions(context, arrival) {
  const { state, opts, outputs } = context;
  for (const admission of arrival.values) {
    if (admission === null || typeof admission !== "object" || !validRef(admission.occurrence) || !validToken(admission.effectId) || !validSourceRef(admission.requestRef) || !validSourceRef(admission.admissionRef) || typeof admission.proposalDigest !== "string" || !digestPattern.test(admission.proposalDigest) || !validAdmissionState(admission.state)) {
      pushIssue(
        outputs,
        issue(
          "causal-occurrence/invalid-effect-admission",
          "Effect admission identity or state is invalid."
        )
      );
      continue;
    }
    const canonical = canonicalEntry(admission);
    if (canonical === void 0) {
      pushIssue(
        outputs,
        issue(
          "causal-occurrence/non-data-effect-admission",
          "Effect admission must be canonical DATA."
        )
      );
      continue;
    }
    if (!retainDomain(context, admission.occurrence.revisionDomain)) continue;
    const key = effectKey(admission);
    const record = state.effects.get(key);
    if (record === void 0) {
      if (rejectDefinitiveMissingRef(context, admission.occurrence, "effect-admission")) continue;
      retainPending(
        opts,
        outputs,
        state.pendingEffectAdmissions,
        key,
        canonical.snapshot,
        "effect-admission"
      );
      continue;
    }
    if (record.proposal.proposalDigest !== admission.proposalDigest || dataKey(record.proposal.requestRef) !== dataKey(canonical.snapshot.requestRef) || !sameRef(record.proposal.occurrence, admission.occurrence)) {
      pushIssue(
        outputs,
        issue(
          "causal-occurrence/effect-admission-mismatch",
          "Effect admission has no exact proposal.",
          [key]
        )
      );
      continue;
    }
    if (record.admission !== void 0) {
      if (dataKey(record.admission) !== canonical.key)
        pushIssue(
          outputs,
          issue(
            "causal-occurrence/effect-admission-conflict",
            "Effect admission replay conflicts.",
            [key]
          )
        );
      continue;
    }
    state.effects.set(key, { ...record, admission: canonical.snapshot });
    context.committedViewChanged = true;
    emitConservation(context, admission.occurrence);
  }
}
function receiveOutcomes(context, arrival) {
  const { state, opts, outputs } = context;
  for (const outcome of arrival.values) {
    if (outcome === null || typeof outcome !== "object" || !validRef(outcome.occurrence) || !validToken(outcome.effectId) || !validSourceRef(outcome.requestRef) || !validSourceRef(outcome.admissionRef) || typeof outcome.proposalDigest !== "string" || !digestPattern.test(outcome.proposalDigest) || !validOutcomeState(outcome.state) || !validResult(outcome.result)) {
      pushIssue(
        outputs,
        issue(
          "causal-occurrence/invalid-effect-outcome",
          "Effect outcome identity, state, or D184 result is invalid."
        )
      );
      continue;
    }
    const canonical = canonicalEntry(outcome);
    if (canonical === void 0) {
      pushIssue(
        outputs,
        issue(
          "causal-occurrence/non-data-effect-outcome",
          "Effect outcome must be canonical DATA."
        )
      );
      continue;
    }
    const resultMatchesState = validResult(outcome.result) && outcome.state === "succeeded" === (outcome.result.kind === "ok");
    if (!resultMatchesState) {
      pushIssue(
        outputs,
        issue(
          "causal-occurrence/effect-outcome-mismatch",
          "Effect outcome D184 result must match its terminal state."
        )
      );
      continue;
    }
    if (!retainDomain(context, outcome.occurrence.revisionDomain)) continue;
    const key = effectKey(outcome);
    const record = state.effects.get(key);
    if (record === void 0 || record.admission === void 0) {
      if (rejectDefinitiveMissingRef(context, outcome.occurrence, "effect-outcome")) continue;
      retainPending(
        opts,
        outputs,
        state.pendingEffectOutcomes,
        key,
        canonical.snapshot,
        "effect-outcome"
      );
      continue;
    }
    if (record.admission.state !== "admitted" || record.proposal.proposalDigest !== outcome.proposalDigest || dataKey(record.proposal.requestRef) !== dataKey(canonical.snapshot.requestRef) || dataKey(record.admission.admissionRef) !== dataKey(canonical.snapshot.admissionRef) || !sameRef(record.proposal.occurrence, outcome.occurrence)) {
      pushIssue(
        outputs,
        issue(
          "causal-occurrence/effect-outcome-mismatch",
          "Effect outcome requires exact admitted authority and a D184 result matching its state.",
          [key]
        )
      );
      continue;
    }
    if (record.outcome !== void 0) {
      if (dataKey(record.outcome) !== canonical.key)
        pushIssue(
          outputs,
          issue("causal-occurrence/effect-outcome-conflict", "Effect outcome replay conflicts.", [
            key
          ])
        );
      continue;
    }
    state.effects.set(key, { ...record, outcome: canonical.snapshot });
    context.committedViewChanged = true;
    emitConservation(context, outcome.occurrence);
  }
}
function pendingObligations(context, revisionDomain, domain) {
  const { state } = context;
  const { watermark, occurrences, latestAdmitted } = domain;
  const pending = /* @__PURE__ */ new Map();
  for (const occurrence of occurrences) {
    const key = refKey(occurrence);
    const admission = exactAdmission(context, occurrence);
    const isLatest = latestAdmitted.get(occurrenceIdKey(occurrence)) === occurrence;
    if (admission === void 0 || admission.state === "admitted" && isLatest && !state.released.has(key) || state.released.has(key) && !state.emittedTerminals.has(key))
      pending.set(key, occurrence);
  }
  for (const admission of state.admissions.values()) {
    if (admission.occurrence.revisionDomain === revisionDomain && admission.occurrence.revision <= watermark && exactOccurrence(context, admission.occurrence) === void 0)
      pending.set(refKey(admission.occurrence), admission.occurrence);
  }
  for (const terminal of state.pendingTerminals.values()) {
    if (terminal.occurrence.revisionDomain === revisionDomain && terminal.occurrence.revision <= watermark)
      pending.set(refKey(terminal.occurrence), terminal.occurrence);
  }
  const pendingEffects = [...state.effects.values()].filter(
    (record) => record.proposal.occurrence.revisionDomain === revisionDomain && record.proposal.occurrence.revision <= watermark && (record.admission === void 0 || record.admission.state === "admitted" && record.outcome === void 0)
  );
  const pendingEffectIds = new Set(pendingEffects.map((record) => record.proposal.effectId));
  for (const effect of [
    ...state.pendingEffectProposals.values(),
    ...state.pendingEffectAdmissions.values(),
    ...state.pendingEffectOutcomes.values()
  ]) {
    if (effect.occurrence.revisionDomain === revisionDomain && effect.occurrence.revision <= watermark)
      pendingEffectIds.add(effect.effectId);
  }
  return { pendingOccurrenceRefs: Object.freeze([...pending.values()]), pendingEffectIds };
}

// packages/ts/src/solutions/causal-occurrence/transition.ts
function emptyState() {
  return {
    domains: /* @__PURE__ */ new Set(),
    highWaterByDomain: /* @__PURE__ */ new Map(),
    retentionFloorByDomain: /* @__PURE__ */ new Map(),
    byRevision: /* @__PURE__ */ new Map(),
    pending: /* @__PURE__ */ new Map(),
    admissions: /* @__PURE__ */ new Map(),
    released: /* @__PURE__ */ new Set(),
    terminals: /* @__PURE__ */ new Map(),
    emittedTerminals: /* @__PURE__ */ new Set(),
    effects: /* @__PURE__ */ new Map(),
    evidence: /* @__PURE__ */ new Map(),
    pendingTerminals: /* @__PURE__ */ new Map(),
    pendingEffectProposals: /* @__PURE__ */ new Map(),
    pendingEffectAdmissions: /* @__PURE__ */ new Map(),
    pendingEffectOutcomes: /* @__PURE__ */ new Map(),
    pendingEvidence: /* @__PURE__ */ new Map(),
    coverageGaps: /* @__PURE__ */ new Map(),
    watermarks: /* @__PURE__ */ new Map(),
    currentness: /* @__PURE__ */ new Map(),
    quiescence: /* @__PURE__ */ new Map(),
    retentionGapThroughByDomain: /* @__PURE__ */ new Map(),
    occurrenceRetentionGaps: /* @__PURE__ */ new Map()
  };
}
function cloneState(prior) {
  if (prior === void 0) return emptyState();
  return {
    ...prior,
    domains: new Set(prior.domains),
    highWaterByDomain: new Map(prior.highWaterByDomain),
    retentionFloorByDomain: new Map(prior.retentionFloorByDomain),
    byRevision: new Map(prior.byRevision),
    pending: new Map(prior.pending),
    admissions: new Map(prior.admissions),
    released: new Set(prior.released),
    terminals: new Map([...prior.terminals].map(([key, value]) => [key, new Map(value)])),
    emittedTerminals: new Set(prior.emittedTerminals),
    effects: new Map(prior.effects),
    evidence: new Map(prior.evidence),
    pendingTerminals: new Map(prior.pendingTerminals),
    pendingEffectProposals: new Map(prior.pendingEffectProposals),
    pendingEffectAdmissions: new Map(prior.pendingEffectAdmissions),
    pendingEffectOutcomes: new Map(prior.pendingEffectOutcomes),
    pendingEvidence: new Map(prior.pendingEvidence),
    coverageGaps: new Map(prior.coverageGaps),
    watermarks: new Map(prior.watermarks),
    currentness: new Map(prior.currentness),
    quiescence: new Map(prior.quiescence),
    retentionGapThroughByDomain: new Map(prior.retentionGapThroughByDomain),
    occurrenceRetentionGaps: new Map(prior.occurrenceRetentionGaps)
  };
}
function transitionCausalAuthority(prior, arrivals, opts) {
  const state = cloneState(prior);
  const outputs = [];
  const emitIssue = (value) => pushIssue(outputs, value);
  const context = { state, opts, outputs, committedViewChanged: false };
  const acceptOccurrence = (entry) => {
    const occurrence = entry.value;
    if (state.byRevision.size >= opts.maxOccurrences) {
      const oldest = [...state.byRevision.entries()].sort(([, left], [, right]) => left.value.revision - right.value.revision).find(([, retained]) => settledForEviction(context, retained.value));
      if (oldest === void 0) {
        emitIssue(
          issue(
            "causal-occurrence/retention-capacity",
            "Occurrence retention is full of unsettled causal obligations.",
            [refKey(occurrence)]
          )
        );
        return false;
      }
      state.byRevision.delete(oldest[0]);
      const evicted = oldest[1].value;
      const evictedRefKey = refKey(evicted);
      state.admissions.delete(evictedRefKey);
      state.released.delete(evictedRefKey);
      state.terminals.delete(evictedRefKey);
      state.emittedTerminals.delete(evictedRefKey);
      state.currentness.delete(evictedRefKey);
      for (const [key, record] of state.effects) {
        if (sameRef(record.proposal.occurrence, evicted)) {
          state.effects.delete(key);
          context.committedViewChanged = true;
        }
      }
      for (const [key, evidence] of state.evidence) {
        if (sameRef(evidence.occurrence, evicted)) state.evidence.delete(key);
      }
      for (const map of [
        state.pendingTerminals,
        state.pendingEffectProposals,
        state.pendingEffectAdmissions,
        state.pendingEffectOutcomes,
        state.pendingEvidence,
        state.coverageGaps
      ]) {
        for (const [key, value] of map) {
          if (sameRef(value.occurrence, evicted)) map.delete(key);
        }
      }
      const priorFloor = state.retentionFloorByDomain.get(evicted.revisionDomain) ?? 0;
      const priorGap = state.retentionGapThroughByDomain.get(evicted.revisionDomain) ?? 0;
      if (evicted.revision > priorFloor || evicted.revision > priorGap)
        context.committedViewChanged = true;
      state.retentionFloorByDomain.set(
        evicted.revisionDomain,
        Math.max(state.retentionFloorByDomain.get(evicted.revisionDomain) ?? 0, evicted.revision)
      );
      state.retentionGapThroughByDomain.set(
        evicted.revisionDomain,
        Math.max(
          state.retentionGapThroughByDomain.get(evicted.revisionDomain) ?? 0,
          evicted.revision
        )
      );
      const retentionGap = canonicalSnapshot({
        occurrence: evicted,
        evidenceKind: "occurrence-retention",
        evidenceId: `retention-gap/${evicted.revisionDomain}/${evicted.revision}`,
        evidenceDigest: evicted.digest,
        coverage: "retention-gap",
        refs: Object.freeze([`causal-occurrence:${refKey(evicted)}`])
      });
      state.occurrenceRetentionGaps.set(evicted.revisionDomain, retentionGap);
      outputs.push({
        kind: "coverage",
        value: {
          kind: "causal-evidence-coverage",
          occurrence: evicted,
          complete: false,
          entries: Object.freeze([retentionGap]),
          missingKinds: Object.freeze([...opts.requiredEvidenceKinds]),
          terminalGapKinds: Object.freeze([...opts.requiredEvidenceKinds])
        }
      });
    }
    state.byRevision.set(revisionKey(occurrence.revisionDomain, occurrence.revision), entry);
    state.highWaterByDomain.set(occurrence.revisionDomain, occurrence.revision);
    return true;
  };
  const receiveOccurrences = (arrival) => {
    for (const occurrence of arrival.values) {
      if (!validRef(occurrence)) {
        emitIssue(issue("causal-occurrence/invalid-identity", "Occurrence identity is invalid."));
        continue;
      }
      let key;
      try {
        key = dataKey(occurrence);
      } catch {
        emitIssue(issue("causal-occurrence/non-data", "Occurrence must be canonical DATA."));
        continue;
      }
      const { digest, ...digestMaterial } = occurrence;
      if (causalOccurrenceDigest(digestMaterial) !== digest) {
        emitIssue(
          issue(
            "causal-occurrence/digest-mismatch",
            "Occurrence digest does not bind contract-v2 identity and value material.",
            [refKey(occurrence)]
          )
        );
        continue;
      }
      if (!retainDomain(context, occurrence.revisionDomain)) continue;
      const domainKey = revisionKey(occurrence.revisionDomain, occurrence.revision);
      const existing = state.byRevision.get(domainKey) ?? state.pending.get(domainKey);
      if (existing !== void 0) {
        if (existing.key !== key)
          emitIssue(
            issue(
              "causal-occurrence/replay-conflict",
              "Revision replay conflicts with retained identity.",
              [refKey(occurrence)]
            )
          );
        continue;
      }
      const highWater = state.highWaterByDomain.get(occurrence.revisionDomain) ?? 0;
      const floor = state.retentionFloorByDomain.get(occurrence.revisionDomain) ?? 0;
      if (occurrence.revision <= highWater) {
        emitIssue(
          issue(
            occurrence.revision <= floor ? "causal-occurrence/retention-gap" : "causal-occurrence/stale-revision",
            "Revision cannot regain causal authority.",
            [refKey(occurrence)]
          )
        );
        outputs.push({
          kind: "currentness",
          value: {
            kind: "causal-currentness",
            occurrence,
            evaluatedThroughRevision: highWater,
            state: occurrence.revision <= floor ? "unverifiable" : "stale"
          }
        });
        continue;
      }
      const entry = { value: canonicalSnapshot(occurrence), key };
      if (occurrence.revision > highWater + 1) {
        if (state.pending.size >= opts.maxPending) {
          emitIssue(
            issue(
              "causal-occurrence/pending-bound",
              "Skipped revision exceeded bounded pending retention.",
              [refKey(occurrence)]
            )
          );
          continue;
        }
        state.pending.set(domainKey, entry);
        emitIssue(
          issue("causal-occurrence/skipped-revision", `Revision ${highWater + 1} is missing.`, [
            refKey(occurrence)
          ])
        );
        outputs.push({
          kind: "currentness",
          value: {
            kind: "causal-currentness",
            occurrence,
            evaluatedThroughRevision: highWater,
            state: "unverifiable",
            missingRevision: highWater + 1,
            gapRef: {
              revisionDomain: occurrence.revisionDomain,
              afterRevision: highWater,
              beforeRevision: occurrence.revision,
              reason: "skipped-revision"
            }
          }
        });
        outputs.push({
          kind: "coverage",
          value: {
            kind: "causal-evidence-coverage",
            occurrence,
            complete: false,
            entries: Object.freeze([
              {
                occurrence,
                evidenceKind: "revision-sequence",
                evidenceId: `${occurrence.revisionDomain}/${occurrence.revision}`,
                evidenceDigest: occurrence.digest,
                coverage: "skipped-revision"
              }
            ]),
            missingKinds: Object.freeze([...opts.requiredEvidenceKinds]),
            terminalGapKinds: Object.freeze(["revision-sequence"])
          }
        });
        continue;
      }
      if (!acceptOccurrence(entry)) {
        if (state.pending.size < opts.maxPending) state.pending.set(domainKey, entry);
        continue;
      }
      for (; ; ) {
        const nextRevision = (state.highWaterByDomain.get(occurrence.revisionDomain) ?? 0) + 1;
        const pending = state.pending.get(revisionKey(occurrence.revisionDomain, nextRevision));
        if (pending === void 0) break;
        if (!acceptOccurrence(pending)) break;
        state.pending.delete(revisionKey(occurrence.revisionDomain, nextRevision));
      }
    }
  };
  const recomputeDomain = (revisionDomain) => {
    const domain = recomputeCurrentness(context, revisionDomain);
    if (domain === void 0) return;
    const { watermark, sequenceComplete } = domain;
    const { pendingOccurrenceRefs, pendingEffectIds } = pendingObligations(
      context,
      revisionDomain,
      domain
    );
    const lifecycle = sequenceComplete && pendingOccurrenceRefs.length === 0 && pendingEffectIds.size === 0;
    const evidenceTerminal = lifecycle && isEvidenceTerminal(context, revisionDomain, domain);
    const value = {
      kind: "causal-quiescence",
      revisionDomain,
      evaluatedThroughRevision: watermark,
      lifecycle,
      retainedEvidence: lifecycle && evidenceTerminal && (state.retentionGapThroughByDomain.get(revisionDomain) ?? 0) === 0,
      pendingOccurrenceRefs,
      pendingEffectIds: Object.freeze([...pendingEffectIds])
    };
    const prior2 = state.quiescence.get(revisionDomain);
    state.quiescence.set(revisionDomain, value);
    if (prior2 === void 0 || dataKey(prior2) !== dataKey(value))
      outputs.push({ kind: "quiescence", value });
  };
  const pendingWorkCount = () => state.admissions.size + state.pending.size + state.pendingTerminals.size + state.pendingEffectProposals.size + state.pendingEffectAdmissions.size + state.pendingEffectOutcomes.size + state.pendingEvidence.size;
  const refreshProjections = () => {
    for (const { value: occurrence } of state.byRevision.values()) {
      const watermark = state.watermarks.get(occurrence.revisionDomain);
      if (watermark === void 0 || occurrence.revision > watermark) continue;
      const key = refKey(occurrence);
      const current = state.currentness.get(key);
      state.currentness.set(
        key,
        current.state === "unverifiable" && current.gapRef !== void 0 ? {
          ...current,
          gapRef: { ...current.gapRef, evidenceRef: { ...current.gapRef.evidenceRef } }
        } : { ...current }
      );
    }
    for (const domain of state.watermarks.keys()) {
      const current = state.quiescence.get(domain);
      state.quiescence.set(domain, {
        ...current,
        pendingOccurrenceRefs: Object.freeze([...current.pendingOccurrenceRefs]),
        pendingEffectIds: Object.freeze([...current.pendingEffectIds])
      });
    }
  };
  const flushPending = () => {
    const before = pendingWorkCount();
    let promoted = false;
    flushAdmissions(context);
    flushEffectsAndTerminals(context);
    flushEvidence(context);
    for (const revisionDomain of state.domains) {
      for (; ; ) {
        const revision = (state.highWaterByDomain.get(revisionDomain) ?? 0) + 1;
        const key = revisionKey(revisionDomain, revision);
        const pending = state.pending.get(key);
        if (pending === void 0 || !acceptOccurrence(pending)) break;
        state.pending.delete(key);
        promoted = true;
      }
    }
    return { promoted, changed: promoted || pendingWorkCount() !== before };
  };
  for (const arrival of arrivals) {
    if (arrival.lane === "occurrences") receiveOccurrences(arrival);
    if (arrival.lane === "admissions") receiveAdmissions(context, arrival);
    if (arrival.lane === "branch-terminals") receiveTerminals(context, arrival);
    if (arrival.lane === "effect-proposals") receiveProposals(context, arrival);
    if (arrival.lane === "effect-admissions") receiveEffectAdmissions(context, arrival);
    if (arrival.lane === "effect-outcomes") receiveOutcomes(context, arrival);
    if (arrival.lane === "evidence") receiveEvidence(context, arrival);
    if (arrival.lane === "watermarks") receiveWatermarks(context, arrival);
  }
  for (const revisionDomain of state.watermarks.keys()) recomputeDomain(revisionDomain);
  for (; ; ) {
    const { promoted, changed } = flushPending();
    if (!changed) {
      refreshProjections();
      break;
    }
    const releasedBefore = state.released.size;
    for (const revisionDomain of state.watermarks.keys()) recomputeDomain(revisionDomain);
    if (!promoted && state.released.size === releasedBefore) break;
  }
  return { state, outputs, committedViewChanged: context.committedViewChanged };
}
export {
  causalOccurrenceDigest,
  refKey,
  transitionCausalAuthority
};
