import fs from "node:fs";
const d = await import("file:///Users/davidchenallio/src/graphrefly-ts/archive/evals/causal-recording-diagnostic-v1/run/assets/DEFERRED.mjs");
const a = await import("file:///Users/davidchenallio/src/graphrefly-ts/archive/evals/causal-recording-diagnostic-v1/run/assets/worker.mjs");
const b = await import("file:///Users/davidchenallio/src/graphrefly-ts/archive/evals/causal-recording-diagnostic-v1/run/assets/worker-copy.mjs");
fs.writeFileSync("/Users/davidchenallio/src/graphrefly-ts/archive/evals/causal-recording-diagnostic-v1/run/13/entry.json",JSON.stringify({pid:process.pid,timeOrigin:performance.timeOrigin,node:process.version,execArgv:process.execArgv}));
await d.runRow("/Users/davidchenallio/src/graphrefly-ts/archive/evals/causal-recording-diagnostic-v1/run/13/config.json",[a,b]);
