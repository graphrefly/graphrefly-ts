from pathlib import Path
import subprocess,time,json,os,signal,datetime,re
out=Path(Path('/tmp/graphrefly-soak-audit-location').read_text())
argv=['pnpm','--filter','@graphrefly/ts','exec','vitest','run','--config','vitest.root-eval-soak.config.ts','-t','qualifies five orthogonal mechanisms.*development-(3|4).*target','--reporter=json','--outputFile='+str(out/'tests.json')]
start=time.time();mono=time.monotonic();timed=False
with (out/'tests.log').open('w') as f:
 p=subprocess.Popen(argv,stdout=f,stderr=subprocess.STDOUT,start_new_session=True)
 try:code=p.wait(timeout=1000)
 except subprocess.TimeoutExpired:
  timed=True;os.killpg(p.pid,signal.SIGKILL);p.wait();code=124
 f.write('\nDONE exit='+str(code)+'\n')
end=time.time()
logs=subprocess.run(['/usr/bin/pmset','-g','log'],capture_output=True,text=True,timeout=20)
pattern=re.compile(r'^(\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2} [+-]\d{4})\s+(Sleep|DarkWake|Wake)\s')
old=[];current=[]
for l in logs.stdout.splitlines():
 m=pattern.match(l)
 if not m:continue
 t=datetime.datetime.strptime(m[1],'%Y-%m-%d %H:%M:%S %z').timestamp()
 if l.startswith('2026-09-12 20:') and '20:16:00'<=l[11:19]<='20:51:00':old.append(l)
 if start-1<=t<=end+1:current.append(l)
(out/'power-transitions.log').write_text('\n'.join(old)+'\n')
(out/'retest-power-transitions.log').write_text('\n'.join(current)+'\n')
r={'argv':argv,'start_unix':start,'end_unix':end,'elapsed_wall_s':end-start,'elapsed_monotonic_s':time.monotonic()-mono,'exit_code':code,'supervisor_timeout':timed,'power_log_exit':logs.returncode,'retest_power_transitions':len(current),'performance_samples':0}
(out/'receipt.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r));raise SystemExit(code)
