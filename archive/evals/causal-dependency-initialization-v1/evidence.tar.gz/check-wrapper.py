import subprocess,json,time,sys,pathlib
out=pathlib.Path('/var/folders/1k/6k95mf1117q9_klyvs61pml00000gn/T/graphrefly-dep-final-jbpr9nm3')
name=sys.argv[1]; argv=sys.argv[2:]; begin=time.time()
with (out/(name+'.log')).open('w') as f:
 try:
  p=subprocess.run(argv,stdout=f,stderr=subprocess.STDOUT,timeout=1800)
  code=p.returncode
 except subprocess.TimeoutExpired:code=124
 f.write('\nDONE exit='+str(code)+'\n')
(out/(name+'.json')).write_text(json.dumps({'argv':argv,'exit_code':code,'elapsed_s':time.time()-begin},indent=2)+'\n')
print(name,'DONE',code)
print('\n'.join((out/(name+'.log')).read_text().splitlines()[-12:]))
sys.exit(code)
