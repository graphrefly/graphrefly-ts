import datetime, json, os, pathlib, signal, subprocess, time
root = pathlib.Path(__file__).resolve().parent
assert not (root / "method-supervisor.json").exists(), "one consumed attempt; no retry"
command = ["node", "scripts/compare-spending-preset-repetition.mjs", str(root / "method-validation"), str(root / "reference-qualification/results.json"), "docs/design/causal-performance-repetition-v2-implementation/approval.json"]
record = {"command": command, "startedAt": datetime.datetime.now(datetime.timezone.utc).isoformat(), "timeoutSeconds": 900, "retries": 0, "status": "starting"}
recordPath = root / "method-supervisor.json"
recordPath.write_text(json.dumps(record, indent=2) + "\n")
started = time.monotonic()
child = None
try:
    with (root / "method-supervisor.log").open("w") as log:
        child = subprocess.Popen(command, stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
        record.update(status="running", pid=child.pid)
        recordPath.write_text(json.dumps(record, indent=2) + "\n")
        child.wait(timeout=max(0.001, 900-(time.monotonic()-started)))
        record.update(status="completed" if child.returncode == 0 else "invalid", exitCode=child.returncode)
except BaseException as error:
    if child is not None:
        try:
            os.killpg(child.pid, signal.SIGKILL)
        except ProcessLookupError:
            pass
        child.wait()
    record.update(status="invalid", error=repr(error), exitCode=None if child is None else child.returncode)
finally:
    record["elapsedSeconds"] = time.monotonic()-started
    recordPath.write_text(json.dumps(record, indent=2) + "\n")
    print("METHOD_SUPERVISOR_DONE", record["status"], record.get("exitCode"), flush=True)
