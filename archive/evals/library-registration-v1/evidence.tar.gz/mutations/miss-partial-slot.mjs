// scripts/fixtures/library-registration-probe.ts
import assert from "node:assert/strict";

// packages/ts/src/batch/boundary.ts
var depth = 0;
var pendingCores = [];
var pendingHead = 0;
function enterWave() {
  depth++;
}
function exitWave() {
  depth--;
  if (depth === 0 && pendingHead < pendingCores.length) drain();
}
function deferRewire(core, apply, options = {}) {
  core.enqueueBoundaryTask({ apply, batchToken: options.batchToken, isReady: options.isReady });
  pendingCores.push(core);
}
function scheduleBoundaryDrain(core) {
  for (let i = 0; i < core.boundaryTaskCount(); i++) pendingCores.push(core);
  if (depth === 0 && pendingHead < pendingCores.length) drain();
}
function dropBoundaryTasksForBatch(batchToken) {
  const seen = /* @__PURE__ */ new Set();
  for (let i = pendingHead; i < pendingCores.length; i++) {
    const core = pendingCores[i];
    if (seen.has(core)) continue;
    seen.add(core);
    core.dropBoundaryTasksForBatch(batchToken);
  }
}
function drain() {
  let escaped = null;
  while (pendingHead < pendingCores.length) {
    const core = pendingCores[pendingHead++];
    const task = core.shiftBoundaryTask();
    if (task === void 0) continue;
    if (task.batchToken !== void 0) {
      const committed = task.batchToken.committed === true;
      if (!committed) continue;
    }
    if (task.isReady !== void 0 && !task.isReady()) {
      core.unshiftBoundaryTask(task);
      continue;
    }
    depth++;
    try {
      task.apply();
    } catch (e) {
      if (escaped === null) escaped = { e };
    } finally {
      depth--;
    }
  }
  pendingCores.length = 0;
  pendingHead = 0;
  if (escaped !== null) throw escaped.e;
}

// packages/ts/src/batch/batch.ts
var active = null;
var boundaryOwner = null;
function currentBatch() {
  return active !== null;
}
function currentBoundaryBatchToken() {
  return active ?? boundaryOwner ?? void 0;
}
function deferToBatch(target, tier3Wave) {
  if (active === null) return false;
  if (!active.deferred.has(target)) active.order.push(target);
  active.deferred.set(target, tier3Wave);
  return true;
}
function deferAfterBatchForTarget(target, fn) {
  if (active === null || !active.deferred.has(target)) return false;
  const owner = active;
  target.__deferBoundary(() => {
    if (owner.committed) fn();
  }, owner);
  return true;
}
function commit(b) {
  const prev = boundaryOwner;
  boundaryOwner = b;
  try {
    for (const target of b.order) {
      const wave = b.deferred.get(target);
      if (wave) target.__commitBatchedWave(wave);
    }
    b.committed = true;
  } catch (e) {
    dropBoundaryTasksForBatch(b);
    throw e;
  } finally {
    boundaryOwner = prev;
  }
}
function rollback(b) {
  dropBoundaryTasksForBatch(b);
  for (const target of b.order) target.__rollbackBatched();
}
function batch(fn) {
  enterWave();
  try {
    if (active !== null) {
      const outer = active;
      return fn({
        rollback: () => {
          outer.rolledBack = true;
        }
      });
    }
    const b = { order: [], deferred: /* @__PURE__ */ new Map(), committed: false, rolledBack: false };
    active = b;
    const bctx = {
      rollback: () => {
        b.rolledBack = true;
      }
    };
    let result;
    try {
      result = fn(bctx);
    } catch (e) {
      active = null;
      rollback(b);
      throw e;
    }
    active = null;
    if (b.rolledBack) rollback(b);
    else {
      commit(b);
    }
    return result;
  } finally {
    exitWave();
  }
}

// packages/ts/src/dispatcher/index.ts
var PoolTable = class {
  constructor(kind) {
    this.kind = kind;
  }
  kind;
  fns = [];
  free = [];
  register(fn) {
    const reused = this.free.pop();
    if (reused !== void 0) {
      this.fns[reused] = fn;
      return reused;
    }
    const id = this.fns.length;
    this.fns.push(fn);
    return id;
  }
  unregister(handleId) {
    if (this.fns[handleId] === void 0) return;
    this.fns[handleId] = void 0;
    this.free.push(handleId);
  }
  invoke(handleId, ctx) {
    this.fns[handleId](ctx);
  }
};
var dispatcherHandleStatKey = (h) => JSON.stringify([String(h.poolId), String(h.handleId)]);
var Dispatcher = class {
  pools = [];
  syncPoolId;
  asyncPoolId;
  // opt-in profile recorder (default OFF → zero overhead, F-PERF).
  _recording = false;
  _stats = /* @__PURE__ */ new Map();
  _totalInvokes = 0;
  constructor() {
    this.syncPoolId = this.addPool(new PoolTable("sync"));
    this.asyncPoolId = this.addPool(new PoolTable("async"));
  }
  /** Turn the profile recorder on/off (D39). Off = zero overhead on invoke. */
  setRecording(on) {
    this._recording = on;
  }
  /** Reset accumulated profiling counters. */
  clearStats() {
    this._stats.clear();
    this._totalInvokes = 0;
  }
  /** Read a handle's accumulated counters (undefined if it never ran while recording). */
  statFor(handle) {
    return this._stats.get(dispatcherHandleStatKey(handle));
  }
  /** Total fn invocations recorded across the dispatcher. */
  get totalInvokes() {
    return this._totalInvokes;
  }
  addPool(pool) {
    const id = this.pools.length;
    this.pools.push(pool);
    return id;
  }
  /** Register a fn in a pool, returning its Handle. Default pool = sync (R-sync-core). */
  register(fn, pool = "sync") {
    const poolId = pool === "sync" ? this.syncPoolId : pool === "async" ? this.asyncPoolId : pool;
    const handleId = this.pools[poolId].register(fn);
    return { poolId, handleId };
  }
  /**
   * Release a handle (B15): frees the pool slot (closure GC'd, id reusable) and drops any
   * accumulated profile stat so a reused id never inherits the previous tenant's counters.
   * Called on rewire fn-swap (node._rewire) — the old handle is dropped before the node
   * adopts the new one. Idempotent. NOT called on deactivate (a node's handle survives
   * activate↔deactivate and is reused on reactivation; only a rewire swaps it).
   */
  unregister(handle) {
    this.pools[handle.poolId].unregister(handle.handleId);
    this._stats.delete(dispatcherHandleStatKey(handle));
  }
  /** Uniform sync-void invoke (R-sync-core / R-dispatch-all). */
  invoke(handle, ctx) {
    if (!this._recording) {
      this.pools[handle.poolId].invoke(handle.handleId, ctx);
      return;
    }
    this._totalInvokes++;
    const t0 = performance.now();
    try {
      this.pools[handle.poolId].invoke(handle.handleId, ctx);
    } finally {
      const dur = (performance.now() - t0) * 1e6;
      const key = dispatcherHandleStatKey(handle);
      const s = this._stats.get(key) ?? {
        invokes: 0,
        totalDurationNs: 0,
        lastDurationNs: 0
      };
      s.invokes++;
      s.lastDurationNs = dur;
      s.totalDurationNs += dur;
      this._stats.set(key, s);
    }
  }
  poolKind(poolId) {
    return this.pools[poolId].kind;
  }
};
var defaultDispatcher = new Dispatcher();

// packages/ts/src/json/codec.ts
var JS_MIN_NORMAL_NUMBER = 2 ** -1022;
function deepFreezeStrictJson(value) {
  if (value !== null && typeof value === "object") {
    if (Array.isArray(value)) {
      for (const item of value) deepFreezeStrictJson(item);
    } else {
      for (const item of Object.values(value)) deepFreezeStrictJson(item);
    }
    Object.freeze(value);
  }
  return value;
}
function assertStableJsonNumber(value, path) {
  if (!Number.isFinite(value)) {
    throw new TypeError(`stableJsonString: non-finite number at ${path}`);
  }
}
function assertStrictJsonNumber(value, path) {
  assertStableJsonNumber(value, path);
  if (Object.is(value, -0)) {
    throw new TypeError(`stableJsonString: non-canonical number at ${path}`);
  }
  const abs = Math.abs(value);
  if (abs > 0 && abs < JS_MIN_NORMAL_NUMBER) {
    throw new TypeError(`stableJsonString: subnormal number at ${path}`);
  }
  if (Number.isInteger(value) && !Number.isSafeInteger(value)) {
    throw new TypeError(`stableJsonString: integer outside safe range at ${path}`);
  }
}
function sortedJsonValue(value, seen = /* @__PURE__ */ new Set(), path = "$", strictNumbers = false) {
  if (value === null) return null;
  if (typeof value === "string" || typeof value === "boolean") return value;
  if (typeof value === "number") {
    if (strictNumbers) assertStrictJsonNumber(value, path);
    else assertStableJsonNumber(value, path);
    return value;
  }
  if (typeof value !== "object") {
    throw new TypeError(`stableJsonString: value at ${path} is not JSON-encodable`);
  }
  if (seen.has(value)) throw new TypeError(`stableJsonString: circular reference at ${path}`);
  const proto = Object.getPrototypeOf(value);
  if (!Array.isArray(value) && proto !== Object.prototype && proto !== null) {
    throw new TypeError(`stableJsonString: non-plain object at ${path}`);
  }
  seen.add(value);
  try {
    if (Array.isArray(value)) {
      if (Object.getOwnPropertySymbols(value).length > 0) {
        throw new TypeError(`stableJsonString: symbol-keyed properties at ${path}`);
      }
      for (const key of Object.getOwnPropertyNames(value)) {
        const isIndex = /^(0|[1-9]\d*)$/.test(key) && Number.isSafeInteger(Number(key)) && Number(key) < value.length;
        const descriptor = Object.getOwnPropertyDescriptor(value, key);
        if (descriptor !== void 0 && ("get" in descriptor || "set" in descriptor)) {
          throw new TypeError(`stableJsonString: accessor property at ${path}.${key}`);
        }
        if (key !== "length" && !isIndex) {
          throw new TypeError(`stableJsonString: non-index array property at ${path}.${key}`);
        }
        if (key !== "length" && descriptor !== void 0 && !descriptor.enumerable) {
          throw new TypeError(`stableJsonString: non-enumerable array property at ${path}.${key}`);
        }
      }
      const out2 = [];
      for (let i = 0; i < value.length; i += 1) {
        if (!(i in value)) {
          throw new TypeError(`stableJsonString: sparse array hole at ${path}[${i}]`);
        }
        out2.push(sortedJsonValue(value[i], seen, `${path}[${i}]`, strictNumbers));
      }
      return out2;
    }
    if (Object.getOwnPropertySymbols(value).length > 0) {
      throw new TypeError(`stableJsonString: symbol-keyed properties at ${path}`);
    }
    for (const key of Object.getOwnPropertyNames(value)) {
      const descriptor = Object.getOwnPropertyDescriptor(value, key);
      if (descriptor !== void 0 && ("get" in descriptor || "set" in descriptor)) {
        throw new TypeError(`stableJsonString: accessor property at ${path}.${key}`);
      }
      if (descriptor !== void 0 && !descriptor.enumerable) {
        throw new TypeError(`stableJsonString: non-enumerable property at ${path}.${key}`);
      }
    }
    const out = /* @__PURE__ */ Object.create(null);
    for (const key of Object.keys(value).sort()) {
      out[key] = sortedJsonValue(
        value[key],
        seen,
        `${path}.${key}`,
        strictNumbers
      );
    }
    return out;
  } finally {
    seen.delete(value);
  }
}
function stableJsonString(value) {
  return JSON.stringify(sortedJsonValue(value));
}
function strictStableJsonString(value) {
  return JSON.stringify(cloneStrictJsonValue(value));
}
function jsonCodecFor() {
  const encoder = new TextEncoder();
  const decoder = new TextDecoder();
  return {
    encode(value) {
      return encoder.encode(stableJsonString(value));
    },
    decode(bytes) {
      return JSON.parse(decoder.decode(bytes));
    }
  };
}
var jsonCodec = jsonCodecFor();
function bytesEqual(a, b) {
  if (a.byteLength !== b.byteLength) return false;
  for (let i = 0; i < a.byteLength; i += 1) {
    if (a[i] !== b[i]) return false;
  }
  return true;
}
function hasUnpairedSurrogate(value) {
  for (let i = 0; i < value.length; i += 1) {
    const code = value.charCodeAt(i);
    if (code >= 55296 && code <= 56319) {
      const next = value.charCodeAt(i + 1);
      if (next >= 56320 && next <= 57343) {
        i += 1;
        continue;
      }
      return true;
    }
    if (code >= 56320 && code <= 57343) return true;
  }
  return false;
}
function assertNoUnpairedSurrogates(value, seen = /* @__PURE__ */ new Set(), path = "$") {
  if (typeof value === "string") {
    if (hasUnpairedSurrogate(value)) {
      throw new TypeError(`strictJsonCodec: unpaired surrogate at ${path}`);
    }
    return;
  }
  if (value === null || typeof value !== "object") return;
  if (seen.has(value)) return;
  seen.add(value);
  try {
    if (Array.isArray(value)) {
      for (let i = 0; i < value.length; i += 1) {
        const descriptor = Object.getOwnPropertyDescriptor(value, String(i));
        if (descriptor === void 0 || "get" in descriptor || "set" in descriptor) continue;
        assertNoUnpairedSurrogates(descriptor.value, seen, `${path}[${i}]`);
      }
      return;
    }
    for (const key of Object.keys(value)) {
      if (hasUnpairedSurrogate(key)) {
        throw new TypeError(`strictJsonCodec: unpaired surrogate at ${path}.${key}`);
      }
      const descriptor = Object.getOwnPropertyDescriptor(value, key);
      if (descriptor === void 0 || "get" in descriptor || "set" in descriptor) continue;
      assertNoUnpairedSurrogates(descriptor.value, seen, `${path}.${key}`);
    }
  } finally {
    seen.delete(value);
  }
}
function strictJsonDataErrorsInner(value, label, seen) {
  if (value === null || typeof value === "string" || typeof value === "boolean") {
    if (typeof value === "string" && hasUnpairedSurrogate(value)) {
      return { errors: [`${label} must not contain unpaired surrogate strings`] };
    }
    return { errors: [], value };
  }
  if (typeof value === "number") {
    try {
      assertStrictJsonNumber(value, label);
    } catch (error) {
      return { errors: [error instanceof Error ? error.message : String(error)] };
    }
    return { errors: [], value };
  }
  if (typeof value !== "object") {
    return { errors: [`${label} is not JSON-encodable`] };
  }
  if (seen.has(value)) return { errors: [`${label} must not contain circular references`] };
  const proto = Object.getPrototypeOf(value);
  if (!Array.isArray(value) && proto !== Object.prototype && proto !== null) {
    return { errors: [`stableJsonString: non-plain object at ${label}`] };
  }
  seen.add(value);
  try {
    if (Array.isArray(value)) {
      const errors2 = [];
      if (Object.getOwnPropertySymbols(value).length > 0) {
        errors2.push(`${label} must not carry symbol keys`);
      }
      for (const key of Object.getOwnPropertyNames(value)) {
        const descriptor = Object.getOwnPropertyDescriptor(value, key);
        if (descriptor === void 0) continue;
        const isIndex = /^(0|[1-9]\d*)$/.test(key) && Number.isSafeInteger(Number(key)) && Number(key) < value.length;
        if ("get" in descriptor || "set" in descriptor) {
          errors2.push(`${label}.${key} must be a data property`);
        }
        if (key !== "length" && !isIndex) {
          errors2.push(`${label}.${key} must be an indexed data property`);
        }
        if (key !== "length" && isIndex && !descriptor.enumerable) {
          errors2.push(`${label}.${key} must be enumerable`);
        }
      }
      const out2 = [];
      for (let index = 0; index < value.length; index += 1) {
        const descriptor = Object.getOwnPropertyDescriptor(value, String(index));
        if (descriptor === void 0) {
          errors2.push(`stableJsonString: sparse array hole at ${label}[${index}]`);
          continue;
        }
        if ("get" in descriptor || "set" in descriptor) {
          errors2.push(`${label}[${index}] must be a data property`);
          continue;
        }
        if (!descriptor.enumerable) {
          errors2.push(`${label}[${index}] must be enumerable`);
          continue;
        }
        const nested = strictJsonDataErrorsInner(descriptor.value, `${label}[${index}]`, seen);
        errors2.push(...nested.errors);
        if (nested.errors.length === 0 && nested.value !== void 0) out2.push(nested.value);
      }
      if (errors2.length > 0) return { errors: errors2 };
      return { errors: [], value: Object.freeze(out2) };
    }
    const errors = [];
    if (Object.getOwnPropertySymbols(value).length > 0) {
      errors.push(`${label} must not carry symbol keys`);
    }
    for (const key of Object.getOwnPropertyNames(value)) {
      const descriptor = Object.getOwnPropertyDescriptor(value, key);
      if (descriptor === void 0) continue;
      if ("get" in descriptor || "set" in descriptor) {
        errors.push(`${label}.${key} must be a data property`);
      }
      if (!descriptor.enumerable) {
        errors.push(`${label}.${key} must be enumerable`);
      }
      if (hasUnpairedSurrogate(key)) {
        errors.push(`${label}.${key} must not contain unpaired surrogate keys`);
      }
    }
    const out = {};
    for (const key of Object.keys(value).sort()) {
      const descriptor = Object.getOwnPropertyDescriptor(value, key);
      if (descriptor === void 0 || "get" in descriptor || "set" in descriptor) continue;
      const nested = strictJsonDataErrorsInner(descriptor.value, `${label}.${key}`, seen);
      errors.push(...nested.errors);
      if (nested.errors.length === 0 && nested.value !== void 0) {
        Object.defineProperty(out, key, {
          value: nested.value,
          enumerable: true,
          configurable: true,
          writable: true
        });
      }
    }
    if (errors.length > 0) return { errors };
    return { errors: [], value: Object.freeze(out) };
  } finally {
    seen.delete(value);
  }
}
function cloneStrictJsonValue(value, label = "strictJsonValue") {
  const result = strictJsonDataErrorsInner(value, label, /* @__PURE__ */ new Set());
  if (result.errors.length > 0 || result.value === void 0) {
    throw new TypeError(`${label}: ${result.errors.join("; ")}`);
  }
  return deepFreezeStrictJson(result.value);
}
function cloneStrictJsonObject(value, label = "strictJsonObject") {
  const cloned = cloneStrictJsonValue(value, label);
  if (cloned === null || typeof cloned !== "object" || Array.isArray(cloned)) {
    throw new TypeError(`${label}: value must be a strict JSON object`);
  }
  return cloned;
}
function assertNoDuplicateJsonObjectKeys(text) {
  let index = 0;
  function fail(message) {
    throw new TypeError(`strictJsonCodec: ${message}`);
  }
  function skipWhitespace() {
    while (/\s/.test(text[index] ?? "")) index += 1;
  }
  function readJsonString() {
    const start = index;
    index += 1;
    while (index < text.length) {
      const ch = text[index];
      if (ch === '"') {
        index += 1;
        try {
          return JSON.parse(text.slice(start, index));
        } catch {
          fail("malformed JSON string");
        }
      }
      if (ch === "\\") {
        index += 2;
        continue;
      }
      index += 1;
    }
    fail("unterminated JSON string");
  }
  function consumeLiteral(literal) {
    if (text.slice(index, index + literal.length) !== literal) {
      fail(`malformed JSON near byte ${index}`);
    }
    index += literal.length;
  }
  function consumeNumber() {
    const match = /^-?(0|[1-9]\d*)(\.\d+)?([eE][+-]?\d+)?/.exec(text.slice(index));
    if (!match) fail(`malformed JSON number near byte ${index}`);
    index += match[0].length;
  }
  function parseValue(path) {
    skipWhitespace();
    const ch = text[index];
    if (ch === "{") {
      parseObject(path);
      return;
    }
    if (ch === "[") {
      parseArray(path);
      return;
    }
    if (ch === '"') {
      readJsonString();
      return;
    }
    if (ch === "t") {
      consumeLiteral("true");
      return;
    }
    if (ch === "f") {
      consumeLiteral("false");
      return;
    }
    if (ch === "n") {
      consumeLiteral("null");
      return;
    }
    if (ch === "-" || ch !== void 0 && ch >= "0" && ch <= "9") {
      consumeNumber();
      return;
    }
    fail(`malformed JSON near byte ${index}`);
  }
  function parseObject(path) {
    const keys = /* @__PURE__ */ new Set();
    index += 1;
    skipWhitespace();
    if (text[index] === "}") {
      index += 1;
      return;
    }
    while (index < text.length) {
      skipWhitespace();
      if (text[index] !== '"') fail(`expected object key near byte ${index}`);
      const key = readJsonString();
      if (keys.has(key)) {
        throw new TypeError(
          `strictJsonCodec: duplicate object key ${JSON.stringify(key)} at ${path}`
        );
      }
      keys.add(key);
      skipWhitespace();
      if (text[index] !== ":") fail(`expected ':' after object key near byte ${index}`);
      index += 1;
      parseValue(`${path}.${key}`);
      skipWhitespace();
      if (text[index] === ",") {
        index += 1;
        continue;
      }
      if (text[index] === "}") {
        index += 1;
        return;
      }
      fail(`expected ',' or '}' near byte ${index}`);
    }
    fail("unterminated JSON object");
  }
  function parseArray(path) {
    index += 1;
    skipWhitespace();
    if (text[index] === "]") {
      index += 1;
      return;
    }
    let item = 0;
    while (index < text.length) {
      parseValue(`${path}[${item}]`);
      item += 1;
      skipWhitespace();
      if (text[index] === ",") {
        index += 1;
        continue;
      }
      if (text[index] === "]") {
        index += 1;
        return;
      }
      fail(`expected ',' or ']' near byte ${index}`);
    }
    fail("unterminated JSON array");
  }
  parseValue("$");
  skipWhitespace();
  if (index !== text.length) fail(`trailing JSON token near byte ${index}`);
}
function strictJsonCodecFor() {
  const encoder = new TextEncoder();
  const decoder = new TextDecoder("utf-8", { fatal: true });
  return {
    encode(value) {
      assertNoUnpairedSurrogates(value);
      return encoder.encode(strictStableJsonString(value));
    },
    decode(bytes) {
      const text = decoder.decode(bytes);
      assertNoDuplicateJsonObjectKeys(text);
      const decoded = JSON.parse(text);
      assertNoUnpairedSurrogates(decoded);
      const canonical = encoder.encode(strictStableJsonString(decoded));
      if (!bytesEqual(bytes, canonical)) {
        throw new TypeError("strictJsonCodec: bytes are not canonical stable JSON");
      }
      return decoded;
    }
  };
}
var strictJsonCodec = strictJsonCodecFor();
function strictCanonicalJsonBytes(value) {
  return strictJsonCodec.encode(value);
}
function assertStrictJsonObject(value, label = "strictJsonObject") {
  return cloneStrictJsonObject(value, label);
}

// packages/ts/src/node/versioning.ts
var ABSENT_V1_SEED = Object.freeze({
  "@graphrefly/node-version": "v1-absent"
});
function fnv1a64(input) {
  let hash = 0xcbf29ce484222325n;
  const prime = 0x100000001b3n;
  for (const byte of input) {
    hash ^= BigInt(byte);
    hash = BigInt.asUintN(64, hash * prime);
  }
  return hash.toString(16).padStart(16, "0");
}
function defaultNodeVersionHash(bytes) {
  return `fnv1a64:${fnv1a64(bytes)}`;
}
function computeV1Cid(policy, value) {
  return policy.hash(strictCanonicalJsonBytes(value));
}
function assertNodeVersionDataCompatible(policy, value) {
  if (!policy.enabled || policy.level === 0) return;
  strictCanonicalJsonBytes(value);
}
function snapshotNodeVersionData(policy, value) {
  if (!policy.enabled || policy.level === 0) return value;
  const bytes = strictCanonicalJsonBytes(value);
  return strictJsonCodec.decode(bytes);
}
function resolveNodeVersioningPolicy(policy) {
  if (policy === false) return { enabled: false };
  if (policy === void 0 || policy === 0) return { enabled: true, level: 0 };
  if (policy === 1) return { enabled: true, level: 1, hash: defaultNodeVersionHash };
  if (typeof policy === "object" && policy !== null) {
    if (policy.level === 0) return { enabled: true, level: 0 };
    if (policy.level === 1) {
      return { enabled: true, level: 1, hash: policy.hash ?? defaultNodeVersionHash };
    }
  }
  throw new Error("node: versioning level must be 0 or 1; V2/V3 are not locked yet (D109)");
}
function createNodeVersion(policy, initialValue = ABSENT_V1_SEED) {
  if (!policy.enabled) return void 0;
  if (policy.level === 0) return Object.freeze({ level: 0, counter: 0 });
  return Object.freeze({
    level: 1,
    counter: 0,
    cid: computeV1Cid(policy, initialValue),
    prev: null
  });
}
function advanceNodeVersion(current, policy, value) {
  if (!policy.enabled) return void 0;
  if (current === void 0) return createNodeVersion(policy, value);
  if (policy.level === 0) {
    return Object.freeze({ level: 0, counter: current.counter + 1 });
  }
  const previous = current.level === 1 ? current.cid : null;
  return Object.freeze({
    level: 1,
    counter: current.counter + 1,
    cid: computeV1Cid(policy, value),
    prev: previous
  });
}
function cloneNodeVersion(version) {
  if (version === void 0) return void 0;
  if (version.level === 0) return Object.freeze({ level: 0, counter: version.counter });
  return Object.freeze({
    level: 1,
    counter: version.counter,
    cid: version.cid,
    prev: version.prev
  });
}

// packages/ts/src/node/node-runtime-host.ts
function nodeRuntimeHost(node) {
  return node;
}

// packages/ts/src/node/runtime-accessors.ts
var constructingCore;
var constructingEnvironment;
var registrations = /* @__PURE__ */ new WeakMap();
function issueNodeRegistration(node) {
  registrations.set(node, { kind: "live", host: nodeRuntimeHost(node) });
}
function liveRegistration(node) {
  const record = registrations.get(node);
  return record?.kind === "live" ? record : void 0;
}
function closeNodeRegistration(node) {
  registrations.set(node, { kind: "retired" });
}
function setRuntimeReleaseFailures(node, failures) {
  const record = registrations.get(node);
  if (record?.kind !== "retired") throw new Error("release: node access is not closed");
  record.failures = failures;
}
function runtimeReleaseFailuresOfNode(node) {
  const record = registrations.get(node);
  return record?.kind === "retired" ? record.failures : void 0;
}
function setNodeBackendContributor(node, contributor) {
  const record = liveRegistration(node);
  if (record === void 0) throw new Error("checkpoint: unknown node state");
  record.backendContributor = contributor;
}
function nodeBackendContributor(node) {
  return liveRegistration(node)?.backendContributor;
}
function withNodeCore(core, create) {
  const prev = constructingCore;
  constructingCore = core;
  try {
    return create();
  } finally {
    constructingCore = prev;
  }
}
function takeConstructingNodeCore() {
  const core = constructingCore;
  constructingCore = void 0;
  return core;
}
function withEnvironmentDrivers(environment, create) {
  const prev = constructingEnvironment;
  constructingEnvironment = environment;
  try {
    return create();
  } finally {
    constructingEnvironment = prev;
  }
}
function takeConstructingEnvironmentDrivers() {
  const environment = constructingEnvironment;
  constructingEnvironment = void 0;
  return environment;
}
function getNodeOwner(n) {
  return liveRegistration(n)?.graphAttachment?.owner;
}
function setNodeOwner(n, owner) {
  const record = liveRegistration(n);
  if (record === void 0) throw new Error("graph: unknown node state");
  record.graphAttachment = { owner };
}
function setNodeTopologyDepsChangedObserver(n, observer) {
  const attachment = liveRegistration(n)?.graphAttachment;
  if (attachment === void 0) throw new Error("graph: unknown node owner");
  attachment.observer = observer;
}
function notifyTopologyDepsChanged(node, prevDeps, deps) {
  liveRegistration(node)?.graphAttachment?.observer?.(node, prevDeps, deps);
}
function checkpointStateOfNode(n) {
  const self = liveRegistration(n)?.host;
  if (self === void 0) throw new Error("checkpoint: unknown node state");
  return {
    cache: self._value.cache,
    hasData: self._value.hasData,
    terminal: self._value.terminal,
    activated: self._lifecycle.activated,
    hasCalledFnOnce: self._wave.hasCalledFnOnce,
    ctxState: { value: self._privateState.value, persist: self._privateState.persist },
    version: cloneNodeVersion(self._version.value),
    handle: self._slot.handle
  };
}
function releaseRuntimeOfNode(n) {
  liveRegistration(n)?.host._releaseRuntime();
}
function isNodeRuntimeQuiescentForRelease(n) {
  return liveRegistration(n)?.host._isRuntimeQuiescentForRelease() ?? false;
}
function subscriberCountOfNode(n) {
  return liveRegistration(n)?.host._subscriberCount() ?? 0;
}
function isNodeActiveForRelease(n) {
  return liveRegistration(n)?.host._lifecycle.activated ?? false;
}
function isNodeRuntimeReleased(n) {
  const record = registrations.get(n);
  return record?.kind === "retired" || record?.kind === "live" && record.host._released;
}

// packages/ts/src/protocol/messages.ts
var SENTINEL = void 0;
function isInvalidErrorPayload(v) {
  return v === SENTINEL || typeof v === "boolean";
}
function errorPayload(reason, fallback = "error without a valid payload") {
  return isInvalidErrorPayload(reason) ? new Error(fallback) : reason;
}
var TIER_START = 0;
var TIER_CONTROL = 1;
var TIER_NOTIFICATION = 2;
var TIER_VALUE = 3;
var TIER_SETTLE = 4;
var TIER_TERMINAL = 5;
var TIER_TEARDOWN = 6;
var TIER = {
  START: TIER_START,
  PAUSE: TIER_CONTROL,
  RESUME: TIER_CONTROL,
  PULL: TIER_CONTROL,
  DIRTY: TIER_NOTIFICATION,
  DATA: TIER_VALUE,
  RESOLVED: TIER_VALUE,
  INVALIDATE: TIER_SETTLE,
  COMPLETE: TIER_TERMINAL,
  ERROR: TIER_TERMINAL,
  TEARDOWN: TIER_TEARDOWN
};
function messageTier(t) {
  return TIER[t];
}
function isDeferredTier(t) {
  return TIER[t] >= TIER_VALUE;
}
function isValueTier(t) {
  return TIER[t] === TIER_VALUE;
}
function isPauseBufferedTier(t) {
  const tier = TIER[t];
  return tier === TIER_VALUE || tier === TIER_SETTLE;
}
function isTerminal(t) {
  return TIER[t] === TIER_TERMINAL;
}
function isUpAllowed(t) {
  const tier = TIER[t];
  return tier !== void 0 && tier !== TIER_START && tier !== TIER_VALUE && tier !== TIER_TERMINAL;
}

// packages/ts/src/graph/checkpoint.ts
var GRAPH_CHECKPOINT_VERSION = "graphrefly.checkpoint.v1";
function toCheckpointJson(value, path = "$") {
  try {
    return strictJsonCodec.decode(strictJsonCodec.encode(value));
  } catch (cause) {
    throw new TypeError(`checkpoint: value at ${path} is not strict JSON compatible`, {
      cause
    });
  }
}
function checkpointValue(value, hasData, path) {
  if (!hasData || value === SENTINEL) return { kind: "SENTINEL" };
  return { kind: "DATA", data: toCheckpointJson(value, path) };
}
function checkpointTerminal(value, path) {
  if (value === void 0) return { kind: "none" };
  if (value === true) return { kind: "COMPLETE" };
  return { kind: "ERROR", error: toCheckpointJson(value, path) };
}
function registerBackendStateContributor(node, contributor) {
  setNodeBackendContributor(node, contributor);
}
function checkpointBackendStateOfNode(node, path) {
  const contributor = nodeBackendContributor(node);
  if (contributor === void 0) return void 0;
  return toCheckpointJson(contributor(), path);
}

// packages/ts/src/ctx/types.ts
var CTX_DEP_CACHE = /* @__PURE__ */ Symbol.for("graphrefly.ctx.depCache");
var ctxDepWaveOrigins = /* @__PURE__ */ new WeakMap();
function setCtxDepWaveOrigin(ctx, origin) {
  ctxDepWaveOrigins.set(ctx, origin);
}
var CTX_NODE_BINDING = /* @__PURE__ */ Symbol("graphrefly.ctx.nodeBinding");
function depCount(ctx) {
  return ctx.waveData.length;
}
function depWaves(ctx, depIndex) {
  return ctx.waveData[depIndex] ?? [];
}
function depBatch(ctx, depIndex) {
  const waves = depWaves(ctx, depIndex);
  if (waves.length === 0) return null;
  const flattened = waves.flat().filter((v) => v !== SENTINEL);
  return flattened.length === 0 ? [] : flattened;
}
function depLatest(ctx, depIndex) {
  return ctx[CTX_DEP_CACHE]?.latest[depIndex];
}

// packages/ts/src/node/core.ts
var NodeCore = class {
  nextId = 0;
  slots = [];
  values = [];
  waves = [];
  controls = [];
  lifecycles = [];
  depStates = [];
  privateStates = [];
  hooks = [];
  syncCtxs = [];
  versionStates = [];
  boundary = { queue: [], head: 0 };
  createSlot(slot, state, acquisition) {
    const id = this.nextId++;
    if (acquisition !== void 0) {
      acquisition.core = this;
      void id;
    }
    const full = { ...slot, id };
    this.slots[id] = full;
    this.depStates[id] = state.dep;
    this.lifecycles[id] = state.lifecycle;
    this.values[id] = state.value;
    this.waves[id] = state.wave;
    this.controls[id] = state.control;
    this.privateStates[id] = state.privateState;
    this.hooks[id] = state.hooks;
    this.syncCtxs[id] = state.syncCtx;
    this.versionStates[id] = state.version;
    return { id, slot: full };
  }
  get(id) {
    const slot = this.slots[id];
    if (slot === void 0) throw new Error("NodeCore: unknown node slot");
    return slot;
  }
  getValue(id) {
    const value = this.values[id];
    if (value === void 0) throw new Error("NodeCore: unknown node value state");
    return value;
  }
  getWave(id) {
    const wave = this.waves[id];
    if (wave === void 0) throw new Error("NodeCore: unknown node wave state");
    return wave;
  }
  getControl(id) {
    const control = this.controls[id];
    if (control === void 0) throw new Error("NodeCore: unknown node control state");
    return control;
  }
  getLifecycle(id) {
    const lifecycle = this.lifecycles[id];
    if (lifecycle === void 0) throw new Error("NodeCore: unknown node lifecycle state");
    return lifecycle;
  }
  getDep(id) {
    const dep = this.depStates[id];
    if (dep === void 0) throw new Error("NodeCore: unknown node dep state");
    return dep;
  }
  getPrivateState(id) {
    const state = this.privateStates[id];
    if (state === void 0) throw new Error("NodeCore: unknown node private state");
    return state;
  }
  getHooks(id) {
    const hooks = this.hooks[id];
    if (hooks === void 0) throw new Error("NodeCore: unknown node cleanup hooks");
    return hooks;
  }
  getSyncCtx(id) {
    const state = this.syncCtxs[id];
    if (state === void 0) throw new Error("NodeCore: unknown node ctx state");
    return state;
  }
  getVersion(id) {
    const state = this.versionStates[id];
    if (state === void 0) throw new Error("NodeCore: unknown node version state");
    return state;
  }
  /** @internal D122: release graph-owned ephemeral node runtime state from core retention. */
  releaseSlot(id) {
    this.slots[id] = void 0;
    this.depStates[id] = void 0;
    this.lifecycles[id] = void 0;
    this.values[id] = void 0;
    this.waves[id] = void 0;
    this.controls[id] = void 0;
    this.privateStates[id] = void 0;
    this.hooks[id] = void 0;
    this.syncCtxs[id] = void 0;
    this.versionStates[id] = void 0;
  }
  /** @internal B49: graph-local deferred-boundary queue (rewireNext/upNext/batch-after-commit). */
  enqueueBoundaryTask(task) {
    this.boundary.queue.push(task);
  }
  /** @internal */
  hasBoundaryTasks() {
    return this.boundary.head < this.boundary.queue.length;
  }
  /** @internal */
  boundaryTaskCount() {
    return this.boundary.queue.length - this.boundary.head;
  }
  /** @internal */
  shiftBoundaryTask() {
    if (!this.hasBoundaryTasks()) {
      this.boundary.queue = [];
      this.boundary.head = 0;
      return void 0;
    }
    const task = this.boundary.queue[this.boundary.head++];
    if (!this.hasBoundaryTasks()) {
      this.boundary.queue = [];
      this.boundary.head = 0;
    }
    return task;
  }
  /** @internal Put a not-yet-ready task back at this core's FIFO head. */
  unshiftBoundaryTask(task) {
    const remaining = this.boundary.queue.slice(this.boundary.head);
    this.boundary.queue = [task, ...remaining];
    this.boundary.head = 0;
  }
  /** @internal D110: discard all pending tasks caused by an uncommitted batch. */
  dropBoundaryTasksForBatch(batchToken) {
    const remaining = this.boundary.queue.slice(this.boundary.head).filter((task) => task.batchToken !== batchToken);
    this.boundary.queue = remaining;
    this.boundary.head = 0;
  }
};
function makeDepBookkeeping(depCount2) {
  return {
    batch: new Array(depCount2).fill(null),
    waveData: Array.from({ length: depCount2 }, () => []),
    waveTokens: new Array(depCount2).fill(void 0),
    waveLive: Array.from({ length: depCount2 }, () => []),
    prev: new Array(depCount2).fill(SENTINEL),
    hasData: new Array(depCount2).fill(false),
    dirty: new Array(depCount2).fill(false),
    tier: new Array(depCount2).fill(0),
    terminal: new Array(depCount2).fill(void 0),
    terminalInput: new Array(depCount2).fill(void 0),
    unsubs: [],
    idxBoxes: []
  };
}

// packages/ts/src/graph/environment.ts
var EnvironmentDrivers = class _EnvironmentDrivers {
  process;
  http;
  sse;
  websocket;
  webhook;
  constructor(init = {}) {
    this.process = init.process;
    this.http = init.http;
    this.sse = init.sse;
    this.websocket = init.websocket;
    this.webhook = init.webhook;
    Object.freeze(this);
  }
  static empty() {
    return EMPTY_ENVIRONMENT;
  }
  withProcess(driver) {
    return new _EnvironmentDrivers({ ...this, process: driver });
  }
  withHttp(driver) {
    return new _EnvironmentDrivers({ ...this, http: driver });
  }
  withSse(driver) {
    return new _EnvironmentDrivers({ ...this, sse: driver });
  }
  withWebSocket(driver) {
    return new _EnvironmentDrivers({ ...this, websocket: driver });
  }
  withWebhook(driver) {
    return new _EnvironmentDrivers({ ...this, webhook: driver });
  }
  processDriver() {
    return this.process;
  }
  httpDriver() {
    return this.http;
  }
  sseDriver() {
    return this.sse;
  }
  webSocketDriver() {
    return this.websocket;
  }
  webhookDriver() {
    return this.webhook;
  }
};
var EMPTY_ENVIRONMENT = new EnvironmentDrivers();

// packages/ts/src/node/protocol-guards.ts
function terminalView(t) {
  return t === void 0 ? false : t;
}
function normalizePullDemand(demand) {
  if (typeof demand !== "object" || demand === null || Array.isArray(demand)) {
    throw new Error("ctx.up: PULL requires { pullId, params? } demand payload (D269)");
  }
  const pullId = demand.pullId;
  if (typeof pullId !== "string" && typeof pullId !== "symbol") {
    throw new Error("ctx.up: PULL demand requires a string or symbol pullId (D269)");
  }
  const params = demand.params;
  return params === void 0 ? { pullId } : { pullId, params };
}
function validateDownPayloads(msgs) {
  for (const m of msgs) {
    if (messageTier(m[0]) === void 0) {
      throw new Error(
        `down: ${String(m[0])} is not in the closed message-type set (R-msg-closed-set)`
      );
    }
    if (m[0] === "DATA" && m[1] === void 0) {
      throw new Error("down: DATA requires a non-SENTINEL payload (R-data-payload)");
    }
    if (m[0] === "ERROR" && isInvalidErrorPayload(m[1])) {
      throw new Error("down: ERROR requires a non-SENTINEL, non-boolean payload (R-data-payload)");
    }
  }
}

// packages/ts/src/node/node-context-runtime.ts
function nodeBuildCtx(self) {
  const kind = self._slot.handle ? self._slot.dispatcher.poolKind(self._slot.handle.poolId) : "sync";
  if (kind === "sync") {
    if (self._syncCtx === null) self._syncCtx = self._makeCtx();
    self._refreshCtx(self._syncCtx);
    return self._syncCtx;
  }
  return self._makeCtx({
    waveData: self._dep.waveData.map((waves) => waves.map((w) => [...w])),
    waveLive: self._dep.waveLive.map((waves) => [...waves]),
    terminal: self._dep.terminalInput.map(terminalView),
    latest: [...self._dep.prev]
  });
}
function nodeMakeCtx(self, snapshot) {
  const ctx = {
    // Wave-owner boundary (D47): a SYNC fn's emit nests under the public entry that drove
    // it (cheap inc/dec, no early drain); an ASYNC-pool fn re-enters here from its stashed
    // ctx at depth 0, so this is the boundary that drains any rewireNext it issued.
    up: (msgs, towardDep) => {
      if (self._released) return;
      enterWave();
      try {
        self._up(msgs, towardDep);
      } finally {
        exitWave();
      }
    },
    down: (msgs) => {
      if (self._released) return;
      enterWave();
      try {
        self._down(msgs);
      } finally {
        exitWave();
      }
    },
    waveData: snapshot?.waveData ?? self._dep.waveData,
    terminal: snapshot?.terminal ?? self._dep.terminalInput.map(terminalView),
    state: self._makeState(),
    onDeactivation: (fn) => {
      if (self._released) return;
      self._hooks.onDeactivation.push(fn);
    },
    onInvalidate: (fn) => {
      if (self._released) return;
      self._hooks.onInvalidate.push(fn);
    },
    environment: () => self._slot.environment,
    // R-rewire-deferred (D47): defer a self-dep-set mutation to the committed boundary.
    rewireNext: {
      subscribeDep: (dep, fn) => self._requestRewireNext({ kind: "add", dep, fn }),
      unsubscribeDep: (dep, fn) => self._requestRewireNext({ kind: "remove", dep, fn }),
      replaceDeps: (deps, fn) => self._requestRewireNext({ kind: "set", deps, fn })
    },
    // R-up-routing / R-pull (D269): deferred up — route a control/demand wave (e.g. PULL)
    // up the declared cone at the committed boundary. The SELF-demand path: an
    // immediate ctx.up whose delivery loops back re-enters this fn (D37 / R-reentrancy).
    upNext: (msgs, towardDep) => self._requestUpNext(msgs, towardDep),
    ...self._control.activePull === void 0 ? {} : { pull: self._control.activePull },
    [CTX_DEP_CACHE]: { latest: snapshot?.latest ?? self._dep.prev },
    [CTX_NODE_BINDING]: {
      dispatcher: self._slot.dispatcher,
      create: (factory) => withEnvironmentDrivers(self._slot.environment, () => withNodeCore(self._core, factory))
    }
  };
  setCtxDepWaveOrigin(ctx, { live: snapshot?.waveLive ?? self._dep.waveLive });
  if (self._slot.dynamic) {
    ctx.track = (i) => ctx[CTX_DEP_CACHE]?.latest[i];
  }
  return ctx;
}
function nodeRefreshCtx(self, ctx) {
  ctx.waveData = self._dep.waveData;
  ctx.terminal = self._dep.terminalInput.map(terminalView);
  if (self._control.activePull === void 0) {
    delete ctx.pull;
  } else {
    ctx.pull = self._control.activePull;
  }
  ctx[CTX_DEP_CACHE] = { latest: self._dep.prev };
  setCtxDepWaveOrigin(ctx, { live: self._dep.waveLive });
}
function nodeMakeState(self) {
  return {
    get: () => self._privateState.value,
    set: (v) => {
      self._privateState.value = v;
    },
    persist: (on = true) => {
      self._privateState.persist = on;
    }
  };
}

// packages/ts/src/node/node-input-runtime.ts
function nodeRecordDepProjection(self, idx, delivery) {
  const token = delivery?.wave ?? {};
  if (self._dep.waveTokens[idx] !== token) {
    self._dep.waveData[idx].push([]);
    self._dep.waveLive[idx].push(delivery !== void 0);
    self._dep.waveTokens[idx] = token;
  }
  return self._dep.waveData[idx][self._dep.waveData[idx].length - 1];
}
function nodeDepProjectionHasData(self, idx) {
  const projection = self._dep.waveData[idx][self._dep.waveData[idx].length - 1];
  return projection?.some((v) => v !== SENTINEL) ?? false;
}
function nodeReceiveFromDep(self, idx, msg, delivery) {
  if (self._released) return;
  const t = msg[0];
  if (t === "START") return;
  const isLastInDeliveredWave = delivery?.last ?? true;
  if (self._value.terminal !== void 0) {
    if (t === "TEARDOWN") self._down([["TEARDOWN"]]);
    return;
  }
  if (t === "INVALIDATE") {
    const projection = self._recordDepProjection(idx, delivery);
    projection.push(SENTINEL);
    if (projection.some((v) => v !== SENTINEL) && isLastInDeliveredWave) self._maybeRun();
    self._dep.prev[idx] = SENTINEL;
    self._dep.hasData[idx] = false;
    self._dep.batch[idx] = null;
    if (self._dep.dirty[idx]) {
      self._dep.dirty[idx] = false;
      self._wave.pending--;
    }
    if (self._control.pausedDepWaveOccurred && self._dep.batch.every((b) => b === null)) {
      self._control.pausedDepWaveOccurred = false;
    }
    const hadData = self._value.hasData;
    self._invalidate();
    if (self._wave.pending === 0 && self._wave.emittedDirtyThisWave) {
      if (!hadData) self._down([["RESOLVED"]]);
      else self._wave.emittedDirtyThisWave = false;
    }
    self._fireOwedDemandIfReady();
    return;
  }
  if (isTerminal(t)) {
    const isError = t === "ERROR";
    const errPayload = isError ? msg[1] : void 0;
    self._dep.terminal[idx] = isError ? errPayload : true;
    self._dep.terminalInput[idx] = isError ? errPayload : true;
    self._releaseDepDirty(idx);
    const ranValueBeforeTerminal = self._depProjectionHasData(idx) && isLastInDeliveredWave;
    if (ranValueBeforeTerminal) self._maybeRun();
    if (isError && self._slot.errorWhenDepsError) {
      self._down([["ERROR", errPayload]]);
    } else if (self._slot.terminalAsRealInput) {
      if (ranValueBeforeTerminal) {
        self._fireOwedDemandIfReady();
        return;
      }
      self._maybeRun();
    } else if (self._slot.completeWhenDepsComplete && self._allDepsTerminal()) {
      self._down([["COMPLETE"]]);
    } else {
      self._settleAfterAbsorbedTerminal();
    }
    self._fireOwedDemandIfReady();
    return;
  }
  if (t === "TEARDOWN") {
    self._down([["TEARDOWN"]]);
    return;
  }
  if (t === "DIRTY") {
    if (!self._dep.dirty[idx]) {
      self._dep.dirty[idx] = true;
      self._wave.pending++;
      self._dep.tier[idx] = 2;
      self._markDirty();
    }
    return;
  }
  if (t === "DATA") {
    const v = msg[1];
    self._recordDepProjection(idx, delivery).push(v);
    const b = self._dep.batch[idx];
    if (b === null) self._dep.batch[idx] = [v];
    else b.push(v);
    self._dep.prev[idx] = v;
    self._dep.hasData[idx] = true;
    self._dep.tier[idx] = 3;
    if (self._dep.dirty[idx]) {
      self._dep.dirty[idx] = false;
      self._wave.pending--;
    }
    if (isLastInDeliveredWave) self._maybeRun();
    self._fireOwedDemandIfReady();
    return;
  }
  if (t === "RESOLVED") {
    self._recordDepProjection(idx, delivery);
    self._dep.tier[idx] = 3;
    if (self._dep.dirty[idx]) {
      self._dep.dirty[idx] = false;
      self._wave.pending--;
    }
    if (isLastInDeliveredWave) self._maybeRun();
    self._fireOwedDemandIfReady();
    return;
  }
}
function nodeReleaseDepDirty(self, idx) {
  if (self._dep.dirty[idx]) {
    self._dep.dirty[idx] = false;
    self._wave.pending--;
  }
}
function nodeSettleAfterAbsorbedTerminal(self) {
  if (self._wave.pending !== 0 || !self._wave.emittedDirtyThisWave) return;
  const sawData = self._dep.batch.some((b) => b !== null && b.length > 0);
  if (sawData) self._maybeRun();
  if (self._wave.emittedDirtyThisWave) self._down([["RESOLVED"]]);
}
function nodeMarkDirty(self) {
  self._value.status = "dirty";
  if (self._isPullQuiet()) return;
  if (!self._wave.emittedDirtyThisWave) {
    self._wave.emittedDirtyThisWave = true;
    self._emitToSubs(["DIRTY"]);
  }
}
function nodeMaybeRun(self) {
  if (self._wave.inDepMutation) {
    self._wave.rewireRunPending = true;
    return;
  }
  if (self._slot.pausable === true && (self._isPaused() || self._isPullQuiet())) {
    self._control.pausedDepWaveOccurred = true;
    return;
  }
  self._tryRun();
}
function nodeSettleRewire(self) {
  if (self._slot.pausable === true && self._isPaused()) {
    self._control.pausedDepWaveOccurred = true;
    return;
  }
  if (self._wave.pending > 0) return;
  if (self._slot.handle === null) {
    self._passthroughEmit();
    return;
  }
  if (!self._wave.hasCalledFnOnce && !(self._slot.partial || self._allDepsSettled())) return;
  self._markDirty();
  self._runWave();
}
function nodeTryRun(self) {
  if (self._wave.pending > 0) return;
  if (self._slot.handle === null) {
    self._passthroughEmit();
    return;
  }
  if (!self._wave.hasCalledFnOnce) {
    if (self._slot.partial || self._allDepsSettled()) self._runWave();
    return;
  }
  self._runWave();
}
function nodeAllDepsSettled(self) {
  for (let i = 0; i < self._slot.deps.length; i++) {
    if (self._dep.hasData[i]) continue;
    if (self._slot.terminalAsRealInput && self._dep.terminal[i] !== void 0) continue;
    return false;
  }
  return true;
}
function nodePassthroughEmit(self) {
  const b = self._dep.batch[0];
  if (b !== null && b.length > 0) {
    self._down([["DATA", b[b.length - 1]]]);
  } else if (self._wave.emittedDirtyThisWave) {
    self._down([["RESOLVED"]]);
  }
  self._dep.batch[0] = null;
  self._wave.emittedDirtyThisWave = false;
}
function nodeRunWave(self) {
  if (self._wave.insideRunWave)
    throw new Error(
      "synchronous feedback cycle: node fn re-entered its own wave (R-reentrancy / D37)"
    );
  self._wave.hasCalledFnOnce = true;
  self._hooks.onInvalidate = [];
  self._hooks.onDeactivation = [];
  const ctx = self._buildCtx();
  const wasDirty = self._wave.emittedDirtyThisWave;
  self._wave.emittedSettleThisWave = false;
  self._wave.insideRunWave = true;
  try {
    self._slot.dispatcher.invoke(self._slot.handle, ctx);
  } finally {
    self._wave.insideRunWave = false;
  }
  if (wasDirty && !self._wave.emittedSettleThisWave && self._value.terminal === void 0 && !self._isAsyncPool()) {
    self._down([["RESOLVED"]]);
  }
  for (let i = 0; i < self._dep.batch.length; i++) {
    self._dep.batch[i] = null;
    self._dep.waveData[i] = [];
    self._dep.waveTokens[i] = void 0;
    self._dep.waveLive[i] = [];
    self._dep.terminalInput[i] = void 0;
  }
  self._wave.emittedDirtyThisWave = false;
}

// packages/ts/src/node/node-lifecycle-runtime.ts
function nodeActivate(self) {
  self._lifecycle.activated = true;
  const seedRestoredDeps = self._restoredActivationPending;
  self._restoredActivationPending = false;
  self._dep.unsubs = new Array(self._slot.deps.length);
  self._dep.idxBoxes = new Array(self._slot.deps.length);
  for (const dep of self._slot.deps) self._subscribeDepAt(dep, { seedRestored: seedRestoredDeps });
  if (self._slot.deps.length === 0 && self._slot.handle !== null && !self._wave.hasCalledFnOnce) {
    self._runWave();
  }
}
function nodeSubscribeDepAt(self, depNode, opts = {}) {
  const idx0 = self._slot.deps.indexOf(depNode);
  const box = { v: idx0 };
  let ignoreInitialPush = opts.seedRestored === true;
  if (ignoreInitialPush && idx0 !== -1) {
    self._seedRestoredDepAt(idx0, depNode);
    const dep = nodeRuntimeHost(depNode);
    if (dep._value.terminal !== void 0 && !dep._slot.resubscribable) {
      self._dep.unsubs[idx0] = () => {
      };
      self._dep.idxBoxes[idx0] = box;
      return;
    }
  }
  const sink = (msg, delivery) => {
    if (ignoreInitialPush && delivery === void 0) return;
    if (ignoreInitialPush) ignoreInitialPush = false;
    if (box.v === -1) return;
    self._receiveFromDep(box.v, msg, delivery);
  };
  nodeRuntimeHost(depNode)._subscribeOwned(sink, {
    record: (release) => {
      if (idx0 !== -1) {
        self._dep.unsubs[idx0] = release;
        self._dep.idxBoxes[idx0] = box;
      }
    }
  });
  if (ignoreInitialPush && idx0 !== -1 && box.v !== -1) self._seedRestoredDepAt(idx0, depNode);
  ignoreInitialPush = false;
}
function nodeSeedRestoredDepAt(self, idx, depNode) {
  const dep = nodeRuntimeHost(depNode);
  const seedData = dep._value.hasData && !dep._slot.pull;
  self._dep.batch[idx] = null;
  self._dep.waveData[idx] = [];
  self._dep.waveTokens[idx] = void 0;
  self._dep.waveLive[idx] = [];
  self._dep.prev[idx] = seedData ? dep._value.cache : SENTINEL;
  self._dep.hasData[idx] = seedData;
  self._dep.dirty[idx] = false;
  self._dep.tier[idx] = seedData ? 3 : 0;
  self._dep.terminal[idx] = dep._value.terminal;
  self._dep.terminalInput[idx] = void 0;
}
function nodeDeactivate(self) {
  self._lifecycle.activated = false;
  for (const u of self._dep.unsubs) if (u) u();
  self._dep.unsubs = [];
  self._dep.idxBoxes = [];
  for (const fn of self._hooks.onDeactivation) fn();
  self._hooks.onDeactivation = [];
  self._hooks.onInvalidate = [];
  const isCompute = self._slot.handle !== null || self._slot.deps.length > 0;
  if (isCompute) {
    self._value.cache = SENTINEL;
    self._value.hasData = false;
    self._value.status = "sentinel";
  }
  self._resetDepState();
  self._wave.hasCalledFnOnce = false;
  self._control.pauseLockset.clear();
  self._control.pauseBuffer = [];
  self._control.pausedDepWaveOccurred = false;
  self._control.demandOwed = void 0;
  self._control.activePull = void 0;
  self._control.pullDirtyOwed = false;
  self._value.replayRing = [];
  if (!self._privateState.persist) self._privateState.value = SENTINEL;
}
function nodeSubscriberCount(self) {
  return self._lifecycle.subscribers.size;
}
function nodeIsRuntimeQuiescentForRelease(self) {
  return !self._released && self._value.status !== "dirty" && self._value.status !== "pending" && self._wave.pending === 0 && !self._wave.insideRunWave && !self._wave.inDepMutation && !self._wave.rewireRunPending && !self._wave.batchDirtyOwed && self._dep.dirty.every((dirty) => !dirty) && self._control.pauseBuffer.length === 0 && !self._control.pausedDepWaveOccurred && self._control.demandOwed === void 0 && self._control.activePull === void 0 && !self._control.inDeliverDemand && self._control.pauseLockset.size === 0;
}
function nodeReleaseRuntime(self) {
  if (self._released) return;
  self._released = true;
  const node = self;
  const releaseErrors = [];
  const recordReleaseError = (error, resource, handle) => {
    releaseErrors.push({
      cause: error,
      resource,
      ...handle === void 0 ? {} : { handle, dispatcher: self._slot.dispatcher }
    });
  };
  self._lifecycle.activated = false;
  for (const u of self._dep.unsubs) {
    try {
      u?.();
    } catch (error) {
      recordReleaseError(error, "subscription");
    }
  }
  for (const fn of self._hooks.onDeactivation) {
    try {
      fn();
    } catch (error) {
      recordReleaseError(error, "deactivation");
    }
  }
  self._dep.unsubs = [];
  self._dep.idxBoxes = [];
  self._lifecycle.subscribers.clear();
  if (self._slot.handle !== null) {
    const handle = self._slot.handle;
    try {
      self._slot.dispatcher.unregister(handle);
      self._slot.handle = null;
    } catch (error) {
      recordReleaseError(error, "handle", handle);
    }
  }
  self._slot.deps = [];
  self._dep.batch = [];
  self._dep.waveData = [];
  self._dep.waveTokens = [];
  self._dep.waveLive = [];
  self._dep.prev = [];
  self._dep.hasData = [];
  self._dep.dirty = [];
  self._dep.tier = [];
  self._dep.terminal = [];
  self._dep.terminalInput = [];
  self._value.cache = SENTINEL;
  self._value.hasData = false;
  self._value.status = "sentinel";
  self._value.terminal = void 0;
  self._value.replayRing = [];
  self._privateState.value = SENTINEL;
  self._privateState.persist = false;
  self._syncCtx = null;
  self._resetDepState();
  self._hooks.onDeactivation = [];
  self._hooks.onInvalidate = [];
  self._control.pauseLockset.clear();
  self._control.pauseBuffer = [];
  self._control.pausedDepWaveOccurred = false;
  self._control.demandOwed = void 0;
  self._control.activePull = void 0;
  self._control.pullDirtyOwed = false;
  self._restoredActivationPending = false;
  closeNodeRegistration(node);
  try {
    self._core.releaseSlot(self._id);
  } catch (cause) {
    releaseErrors.push({ resource: "slot", cause, core: self._core, slot: self._id });
  }
  if (releaseErrors.length > 0) {
    setRuntimeReleaseFailures(node, Object.freeze(releaseErrors));
    throw releaseErrors[0].cause;
  }
}
function nodeResetDepState(self) {
  const n = self._slot.deps.length;
  for (let i = 0; i < n; i++) {
    self._dep.batch[i] = null;
    self._dep.waveData[i] = [];
    self._dep.waveTokens[i] = void 0;
    self._dep.waveLive[i] = [];
    self._dep.prev[i] = SENTINEL;
    self._dep.hasData[i] = false;
    self._dep.dirty[i] = false;
    self._dep.tier[i] = 0;
    self._dep.terminal[i] = void 0;
    self._dep.terminalInput[i] = void 0;
  }
  self._wave.pending = 0;
  self._wave.emittedDirtyThisWave = false;
}

// packages/ts/src/node/node-output-runtime.ts
function nodeDown(self, msgs) {
  if (self._released) return;
  validateDownPayloads(msgs);
  const deliveryWave = {};
  const assertVersionDataCompatible = (wave) => {
    for (const m of wave) {
      if (m[0] === "DATA") assertNodeVersionDataCompatible(self._version.policy, m[1]);
    }
  };
  const snapshotVersionData = (wave) => wave.map(
    (m) => m[0] === "DATA" ? ["DATA", snapshotNodeVersionData(self._version.policy, m[1])] : m
  );
  assertVersionDataCompatible(msgs);
  if (self._value.terminal !== void 0) {
    if (!msgs.some((m) => m[0] === "TEARDOWN")) return;
    self._value.hasTorndown = true;
    if (self._slot.resetOnTeardown) {
      self._value.cache = SENTINEL;
      self._value.hasData = false;
    }
    self._emitToSubs(["TEARDOWN"], { wave: deliveryWave, last: true });
    return;
  }
  let sorted = [...msgs].sort((a, b) => messageTier(a[0]) - messageTier(b[0]));
  const firstInvalidate = sorted.findIndex((m) => m[0] === "INVALIDATE");
  if (firstInvalidate !== -1) {
    sorted = sorted.filter((m, i) => m[0] !== "INVALIDATE" || i === firstInvalidate);
  }
  const hasTeardown = sorted.some((m) => m[0] === "TEARDOWN");
  const hasTerminal = sorted.some((m) => m[0] === "COMPLETE" || m[0] === "ERROR");
  if (hasTeardown && !hasTerminal && self._value.terminal === void 0 && !self._value.hasTorndown) {
    sorted = [["COMPLETE"], ...sorted];
  }
  if (!self._wave.insideRunWave && currentBatch()) {
    const deferred = snapshotVersionData(sorted.filter((m) => isDeferredTier(m[0])));
    if (deferred.length > 0) {
      if (!self._wave.emittedDirtyThisWave) {
        self._wave.emittedDirtyThisWave = true;
        self._value.status = "dirty";
        self._emitToSubs(["DIRTY"], { wave: deliveryWave, last: false });
      }
      self._wave.batchDirtyOwed = true;
      deferToBatch(self, deferred);
      return;
    }
  }
  if (self._shouldBufferOnPause()) {
    const buffered = snapshotVersionData(sorted.filter((m) => isPauseBufferedTier(m[0])));
    if (buffered.length > 0) {
      self._wave.emittedSettleThisWave = true;
      self._control.pauseBuffer.push(buffered);
    }
    sorted = sorted.filter((m) => !isPauseBufferedTier(m[0]));
    if (sorted.length === 0) return;
  }
  let dataCount = 0;
  let hasTier3 = false;
  let hasResolved = false;
  for (const m of sorted) {
    if (m[0] === "DATA") dataCount++;
    if (m[0] === "RESOLVED") hasResolved = true;
    if (isValueTier(m[0])) hasTier3 = true;
  }
  if (dataCount >= 1 && hasResolved) {
    throw new Error(
      "down: a wave cannot mix DATA and RESOLVED (tier-3 exclusivity, R-resolved-undirty)"
    );
  }
  const plannedVersions = new Array(sorted.length);
  if (dataCount > 0) {
    let plannedVersion = self._version.value;
    for (let i = 0; i < sorted.length; i++) {
      const m = sorted[i];
      if (m[0] !== "DATA") continue;
      plannedVersion = advanceNodeVersion(plannedVersion, self._version.policy, m[1]);
      plannedVersions[i] = plannedVersion;
    }
  }
  if (hasTier3 && (!self._wave.insideRunWave || self._control.pullDirtyOwed) && !self._wave.emittedDirtyThisWave) {
    self._wave.emittedDirtyThisWave = true;
    self._value.status = "dirty";
    self._emitToSubs(["DIRTY"], { wave: deliveryWave, last: false });
  }
  for (let i = 0; i < sorted.length; i++) {
    const m = sorted[i];
    const delivery = { wave: deliveryWave, last: i === sorted.length - 1 };
    if (isDeferredTier(m[0])) self._wave.emittedSettleThisWave = true;
    if (m[0] === "DIRTY") {
      if (!self._wave.emittedDirtyThisWave) {
        self._wave.emittedDirtyThisWave = true;
        self._value.status = "dirty";
        self._emitToSubs(["DIRTY"], delivery);
      }
      continue;
    }
    if (m[0] === "DATA") {
      const v = m[1];
      self._value.cache = v;
      self._value.hasData = true;
      self._value.status = "settled";
      self._version.value = plannedVersions[i];
      if (self._slot.replayN > 0) {
        self._value.replayRing.push(v);
        if (self._value.replayRing.length > self._slot.replayN) self._value.replayRing.shift();
      }
      self._emitToSubs(["DATA", v], delivery);
      continue;
    }
    if (m[0] === "RESOLVED") {
      self._value.status = self._value.hasData ? "resolved" : "sentinel";
      self._emitToSubs(["RESOLVED"], delivery);
      continue;
    }
    if (m[0] === "INVALIDATE") {
      self._invalidate(delivery);
      continue;
    }
    if (m[0] === "COMPLETE") {
      if (self._value.terminal !== void 0) continue;
      self._value.terminal = true;
      self._control.pauseBuffer = [];
      self._value.status = "completed";
      self._emitToSubs(["COMPLETE"], delivery);
      continue;
    }
    if (m[0] === "ERROR") {
      if (self._value.terminal !== void 0) continue;
      self._value.terminal = m[1];
      self._control.pauseBuffer = [];
      self._value.status = "errored";
      self._emitToSubs(["ERROR", m[1]], delivery);
      continue;
    }
    if (m[0] === "TEARDOWN") {
      self._value.hasTorndown = true;
      if (self._slot.resetOnTeardown) {
        self._value.cache = SENTINEL;
        self._value.hasData = false;
      }
      self._emitToSubs(["TEARDOWN"], delivery);
    }
  }
  if (!self._wave.insideRunWave) self._wave.emittedDirtyThisWave = false;
}
function nodeUp(self, msgs, towardDep, route) {
  if (self._released) return;
  const routeState = route ?? { demandFired: /* @__PURE__ */ new Map() };
  for (const m of msgs) {
    const tier = messageTier(m[0]);
    if (tier === void 0) {
      throw new Error(
        `ctx.up: ${String(m[0])} is not in the closed message-type set (R-msg-closed-set)`
      );
    }
    if (!isUpAllowed(m[0])) {
      throw new Error(
        `ctx.up: ${m[0]} is not up-going (tier ${tier}); up carries control/demand messages only (R-ctx-up)`
      );
    }
  }
  for (const m of msgs) {
    if (m[0] === "PAUSE") {
      self._pauseAcquire(m[1]);
    } else if (m[0] === "RESUME") {
      if (self._control.pauseLockset.has(m[1])) {
        self._pauseRelease(m[1]);
      } else {
        self._forwardUp(m, towardDep, routeState);
      }
    } else if (m[0] === "PULL") {
      const demand = normalizePullDemand(m[1]);
      if (self._slot.pull && demand.pullId === self._slot.pullLock) {
        if (!self._markDemandRouted(demand.pullId, routeState)) self._onDemand(demand);
      } else {
        self._forwardUp(["PULL", demand], towardDep, routeState);
      }
    } else if (self._slot.deps.length === 0) {
      if (m[0] === "INVALIDATE") self._down([["INVALIDATE"]]);
    } else {
      self._forwardUp(m, towardDep, routeState);
    }
  }
}
function nodeMarkDemandRouted(self, lockId, route) {
  let holders = route.demandFired.get(lockId);
  if (holders === void 0) {
    holders = /* @__PURE__ */ new Set();
    route.demandFired.set(lockId, holders);
  }
  const node = self;
  if (holders.has(node)) return true;
  holders.add(node);
  return false;
}
function nodeForwardUp(self, m, towardDep, route) {
  if (self._slot.deps.length === 0) return;
  if (towardDep !== void 0) {
    const d = self._slot.deps[towardDep];
    if (d !== void 0) nodeRuntimeHost(d)._up([m], void 0, route);
  } else {
    for (const dep of self._slot.deps) nodeRuntimeHost(dep)._up([m], void 0, route);
  }
}
function nodeIsPaused(self) {
  return self._control.pauseLockset.size > 0;
}
function nodeHasBoundaryPauseLock(self) {
  if (self._slot.pausable === false) return false;
  return self._control.pauseLockset.size > 0;
}
function nodeIsAsyncPool(self) {
  return self._slot.handle !== null && self._slot.dispatcher.poolKind(self._slot.handle.poolId) === "async";
}
function nodePauseAcquire(self, lockId) {
  self._control.pauseLockset.add(lockId);
}
function nodePauseRelease(self, lockId) {
  if (!self._control.pauseLockset.has(lockId)) return;
  self._control.pauseLockset.delete(lockId);
  if (self._slot.pull && self._control.demandOwed !== void 0) self._fireOwedDemandIfReady();
  if (self._hasBoundaryPauseLock()) return;
  scheduleBoundaryDrain(self._core);
  if (self._slot.pull) return;
  self._onResume();
}
function nodeOnResume(self) {
  if (self._value.terminal !== void 0) {
    self._control.pauseBuffer = [];
    self._control.pausedDepWaveOccurred = false;
    self._control.demandOwed = void 0;
    self._control.activePull = void 0;
    self._control.pullDirtyOwed = false;
    return;
  }
  if (self._control.pauseBuffer.length > 0) {
    const buf = self._control.pauseBuffer;
    self._control.pauseBuffer = [];
    for (const wave of buf) self._down(wave);
  }
  if (self._control.pausedDepWaveOccurred) {
    self._control.pausedDepWaveOccurred = false;
    self._tryRun();
  }
}
function nodeCanFireDemand(self) {
  if (self._value.terminal !== void 0 || self._wave.pending > 0) return false;
  return self._control.pauseLockset.size === 0;
}
function nodeDeliverPullDemand(self, demand) {
  self._control.demandOwed = void 0;
  self._control.activePull = demand;
  self._control.inDeliverDemand = true;
  try {
    self._firePullDemand();
  } finally {
    self._control.activePull = void 0;
    self._control.inDeliverDemand = false;
  }
}
function nodeOnDemand(self, demand) {
  if (self._control.inDeliverDemand) return;
  if (self._canFireDemand()) self._deliverPullDemand(demand);
  else self._control.demandOwed = demand;
}
function nodeFirePullDemand(self) {
  let drainedBuffer = false;
  if (self._control.pauseBuffer.length > 0) {
    const buf = self._control.pauseBuffer;
    self._control.pauseBuffer = [];
    for (const wave of buf) self._down(wave);
    drainedBuffer = true;
  }
  if (drainedBuffer) return;
  if (self._control.pausedDepWaveOccurred) {
    const gated = self._slot.handle !== null && !self._wave.hasCalledFnOnce && !(self._slot.partial || self._allDepsSettled());
    if (self._wave.pending > 0 || gated) return;
    self._control.pausedDepWaveOccurred = false;
    self._wave.emittedDirtyThisWave = false;
    self._control.pullDirtyOwed = true;
    try {
      self._tryRun();
    } finally {
      self._control.pullDirtyOwed = false;
    }
    return;
  }
  if (self._slot.handle !== null) {
    if (!self._wave.hasCalledFnOnce && !(self._slot.partial || self._allDepsSettled())) return;
    self._wave.emittedDirtyThisWave = false;
    self._control.pullDirtyOwed = true;
    try {
      self._runWave();
    } finally {
      self._control.pullDirtyOwed = false;
    }
  }
}
function nodeFireOwedDemandIfReady(self) {
  if (self._control.inDeliverDemand) return;
  if (self._slot.pull && self._control.demandOwed !== void 0 && self._canFireDemand()) {
    self._deliverPullDemand(self._control.demandOwed);
  }
}
function nodeShouldBufferOnPause(self) {
  if (self._slot.pausable === false) return false;
  if (!self._isPaused() && !self._isPullQuiet()) return false;
  if (self._slot.pausable === "resumeAll") return true;
  if (!self._wave.insideRunWave && self._isAsyncPool() && self._slot.deps.length > 0) return true;
  return false;
}
function nodeInvalidate(self, delivery) {
  if (!self._value.hasData) return;
  self._value.cache = SENTINEL;
  self._value.hasData = false;
  self._value.status = "sentinel";
  self._value.replayRing = [];
  for (const fn of self._hooks.onInvalidate) fn();
  self._emitToSubs(["INVALIDATE"], delivery);
}
function nodeAllDepsTerminal(self) {
  if (self._slot.deps.length === 0) return false;
  for (const tm of self._dep.terminal) if (tm === void 0) return false;
  return true;
}
function nodeResetLifecycle(self) {
  for (const u of self._dep.unsubs) if (u) u();
  self._dep.unsubs = [];
  self._dep.idxBoxes = [];
  self._lifecycle.subscribers.clear();
  self._lifecycle.activated = false;
  self._value.terminal = void 0;
  self._value.hasTorndown = false;
  self._wave.hasCalledFnOnce = false;
  self._resetDepState();
  self._control.pauseLockset.clear();
  self._control.pauseBuffer = [];
  self._control.pausedDepWaveOccurred = false;
  self._control.demandOwed = void 0;
  self._control.activePull = void 0;
  self._control.pullDirtyOwed = false;
  self._value.replayRing = [];
  const isCompute = self._slot.handle !== null || self._slot.deps.length > 0;
  if (isCompute) {
    self._value.cache = SENTINEL;
    self._value.hasData = false;
    self._value.status = "sentinel";
  } else {
    self._value.status = self._value.hasData ? "settled" : "sentinel";
  }
  if (!self._privateState.persist) self._privateState.value = SENTINEL;
}
function nodeEmitToSubs(self, msg, delivery) {
  if (self._released) return;
  const subs = [...self._lifecycle.subscribers];
  for (const sink of subs) sink(msg, delivery);
}
function nodeCommitBatchedWave(self, wave) {
  self._wave.batchDirtyOwed = false;
  self._down(wave);
}
function nodeRollbackBatched(self) {
  if (self._wave.batchDirtyOwed) {
    self._wave.batchDirtyOwed = false;
    self._wave.emittedDirtyThisWave = false;
    self._value.status = self._value.hasData ? "settled" : "sentinel";
    self._emitToSubs(["RESOLVED"]);
  }
}
function nodeDeferBoundary(self, fn, batchToken) {
  deferRewire(self._core, fn, {
    batchToken,
    isReady: () => !self._hasBoundaryPauseLock()
  });
}

// packages/ts/src/node/node-rewire-runtime.ts
function nodeRequestRewireNext(self, op) {
  deferRewire(self._core, () => self._applyRewireNext(op), {
    batchToken: currentBoundaryBatchToken(),
    isReady: () => !self._hasBoundaryPauseLock()
  });
}
function nodeRequestUpNext(self, msgs, towardDep) {
  deferRewire(
    self._core,
    () => {
      if (!self._released) self._up(msgs, towardDep);
    },
    {
      batchToken: currentBoundaryBatchToken(),
      isReady: () => !self._hasBoundaryPauseLock()
    }
  );
}
function nodeApplyRewireNext(self, op) {
  if (self._released) return;
  try {
    if (op.kind === "add") {
      const next = self._slot.deps.includes(op.dep) ? [...self._slot.deps] : [...self._slot.deps, op.dep];
      self._rewire(next, op.fn, { allowTerminalOwner: true });
    } else if (op.kind === "remove") {
      self._rewire(
        self._slot.deps.filter((d) => d !== op.dep),
        op.fn,
        { allowTerminalOwner: true }
      );
    } else {
      self._rewire(self._dedupDeps(op.deps), op.fn, { allowTerminalOwner: true });
    }
  } catch (e) {
    self._down([["ERROR", errorPayload(e, "rewireNext op failed")]]);
  }
}
function nodeRewire(self, newDeps, fn, opts = {}) {
  const node = self;
  validateNodeRewire(self, newDeps, opts);
  const oldDeps = self._slot.deps;
  const added = newDeps.filter((d) => !oldDeps.includes(d));
  if (deferAfterBatchForTarget(node, () => {
    self._rewire(newDeps, fn, { ...opts, allowTerminalOwner: true });
  })) {
    return true;
  }
  if (!self._lifecycle.activated) self._restoredActivationPending = false;
  self._wave.inDepMutation = true;
  self._wave.rewireRunPending = false;
  let zeroDepUnDirty = false;
  try {
    const oldHandle = self._slot.handle;
    self._slot.handle = self._slot.dispatcher.register(fn, self._slot.pool);
    if (oldHandle !== null) self._slot.dispatcher.unregister(oldHandle);
    const removed = oldDeps.filter((d) => !newDeps.includes(d));
    let removedDirtyContributor = false;
    for (const d of removed) {
      const oldIdx = oldDeps.indexOf(d);
      if (self._dep.dirty[oldIdx]) {
        removedDirtyContributor = true;
        self._wave.pending--;
      }
      if (self._lifecycle.activated) {
        const box = self._dep.idxBoxes[oldIdx];
        if (box) box.v = -1;
        const unsub = self._dep.unsubs[oldIdx];
        if (unsub) unsub();
      }
    }
    const n = newDeps.length;
    const newBatch = new Array(n).fill(null);
    const newPrev = new Array(n).fill(SENTINEL);
    const newHasData = new Array(n).fill(false);
    const newDirty = new Array(n).fill(false);
    const newTier = new Array(n).fill(0);
    const newTerminal = new Array(n).fill(void 0);
    const newTerminalInput = new Array(n).fill(void 0);
    const newUnsubs = new Array(n);
    const newBoxes = new Array(n);
    for (let j = 0; j < n; j++) {
      const oldIdx = oldDeps.indexOf(newDeps[j]);
      if (oldIdx !== -1) {
        newBatch[j] = self._dep.batch[oldIdx];
        newPrev[j] = self._dep.prev[oldIdx];
        newHasData[j] = self._dep.hasData[oldIdx];
        newDirty[j] = self._dep.dirty[oldIdx];
        newTier[j] = self._dep.tier[oldIdx];
        newTerminal[j] = self._dep.terminal[oldIdx];
        newUnsubs[j] = self._dep.unsubs[oldIdx];
        const box = self._dep.idxBoxes[oldIdx];
        if (box) box.v = j;
        newBoxes[j] = box;
      }
    }
    self._slot.deps = newDeps;
    self._dep.batch = newBatch;
    self._dep.prev = newPrev;
    self._dep.hasData = newHasData;
    self._dep.dirty = newDirty;
    self._dep.tier = newTier;
    self._dep.terminal = newTerminal;
    self._dep.terminalInput = newTerminalInput;
    self._dep.unsubs = newUnsubs;
    self._dep.idxBoxes = newBoxes;
    self._dep.waveData = newDeps.map(() => []);
    self._dep.waveTokens = new Array(newDeps.length).fill(void 0);
    self._dep.waveLive = newDeps.map(() => []);
    self._syncCtx = null;
    if (self._lifecycle.activated) {
      for (const d of added) self._subscribeDepAt(d);
    }
    notifyTopologyDepsChanged(node, oldDeps, newDeps);
    if (removedDirtyContributor && self._wave.pending === 0 && self._value.status === "dirty") {
      if (newDeps.length > 0) self._wave.rewireRunPending = true;
      else zeroDepUnDirty = true;
    }
  } finally {
    self._wave.inDepMutation = false;
  }
  if (self._wave.rewireRunPending) {
    self._wave.rewireRunPending = false;
    self._settleRewire();
  } else if (zeroDepUnDirty) {
    if (self._wave.emittedDirtyThisWave) self._down([["RESOLVED"]]);
    else self._value.status = self._value.hasData ? "settled" : "sentinel";
  }
  return false;
}
function validateNodeRewire(self, newDeps, opts = {}) {
  const node = self;
  if (self._value.terminal !== void 0 && !opts.allowTerminalOwner)
    throw new Error(
      "rewire: node is terminal (completed/errored) \u2014 cannot rewire (R-rewire / D42)"
    );
  if (self._wave.insideRunWave)
    throw new Error(
      "rewire: mid-fn topology mutation \u2014 a fn mutating its own deps mid-wave is the feedback cycle (R-rewire / D37)"
    );
  if (self._wave.inDepMutation)
    throw new Error(
      "rewire: reentrant dep mutation \u2014 another replaceDeps/subscribeDep/unsubscribeDep is in flight (R-rewire)"
    );
  if (newDeps.includes(node)) throw new Error("rewire: self-dependency rejected (R-rewire / D42)");
  const oldDeps = self._slot.deps;
  const added = newDeps.filter((d) => !oldDeps.includes(d));
  for (const d of added) {
    if (self._reachableUpstream(d, node))
      throw new Error(
        "rewire: would create a cycle \u2014 dep already transitively depends on this node (R-rewire / D42)"
      );
    const dep = nodeRuntimeHost(d);
    if (dep._value.terminal !== void 0 && !dep._slot.resubscribable)
      throw new Error(
        "rewire: cannot add a non-resubscribable terminal dep \u2014 would wedge (R-rewire / D42)"
      );
    self._assertRewireDepOwner(d);
  }
}

// packages/ts/src/node/owned-acquisition.ts
var constructionAcquisitions = /* @__PURE__ */ new WeakMap();
function cleanupNodeAcquisition(a) {
  if (a.registered) return [];
  if (a.node !== void 0) {
    try {
      releaseRuntimeOfNode(a.node);
    } catch (cause) {
      return runtimeReleaseFailuresOfNode(a.node) ?? [
        {
          resource: "runtime",
          cause,
          core: a.core,
          slot: a.slot,
          dispatcher: a.dispatcher,
          handle: a.handle
        }
      ];
    }
    return runtimeReleaseFailuresOfNode(a.node) ?? [];
  }
  const failures = [];
  if (a.handle !== void 0) {
    try {
      a.dispatcher.unregister(a.handle);
    } catch (cause) {
      failures.push({ resource: "handle", cause, handle: a.handle, dispatcher: a.dispatcher });
    }
  }
  if (a.slot !== void 0) {
    try {
      a.core.releaseSlot(a.slot);
    } catch (cause) {
      failures.push({ resource: "slot", cause, core: a.core, slot: a.slot });
    }
  }
  return failures;
}
function failNodeAcquisition(a, cause) {
  const failures = cleanupNodeAcquisition(a);
  if (failures.length === 0) throw cause;
  throw new ColdNodeAcquisitionError(cause, failures);
}
var ColdNodeAcquisitionError = class extends Error {
  cleanupErrors;
  constructor(cause, failures) {
    super("node: construction failed with residual resources", { cause });
    this.name = "ColdNodeAcquisitionError";
    this.cleanupErrors = Object.freeze([...failures]);
  }
};

// packages/ts/src/node/node.ts
var Node = class _Node {
  _core;
  _id;
  _slot;
  _dep;
  _value;
  // biome-ignore lint/correctness/noUnusedPrivateClassMembers: accessed through the checked internal runtime host.
  _wave;
  _control;
  _lifecycle;
  _privateState;
  _hooks;
  _syncCtxState;
  _version;
  _restoredActivationPending = false;
  _released = false;
  // biome-ignore lint/correctness/noUnusedPrivateClassMembers: accessed through the checked internal runtime host.
  get _syncCtx() {
    return this._syncCtxState.value;
  }
  // biome-ignore lint/correctness/noUnusedPrivateClassMembers: accessed through the checked internal runtime host.
  set _syncCtx(ctx) {
    this._syncCtxState.value = ctx;
  }
  static _retainIndirectRuntimeMethods(node) {
    void node._dep;
    void node._hooks;
    void node._restoredActivationPending;
    void node._requestRewireNext;
    void node._requestUpNext;
    void node._applyRewireNext;
    void node._reachableUpstream;
    void node._assertRewireDepOwner;
    void node._subscribeDepAt;
    void node._seedRestoredDepAt;
    void node._recordDepProjection;
    void node._depProjectionHasData;
    void node._receiveFromDep;
    void node._releaseDepDirty;
    void node._settleAfterAbsorbedTerminal;
    void node._markDirty;
    void node._maybeRun;
    void node._settleRewire;
    void node._tryRun;
    void node._allDepsSettled;
    void node._passthroughEmit;
    void node._runWave;
    void node._buildCtx;
    void node._makeCtx;
    void node._refreshCtx;
    void node._makeState;
    void node._markDemandRouted;
    void node._forwardUp;
    void node._isPullQuiet;
    void node._isPaused;
    void node._hasBoundaryPauseLock;
    void node._isAsyncPool;
    void node._pauseAcquire;
    void node._pauseRelease;
    void node._onResume;
    void node._canFireDemand;
    void node._deliverPullDemand;
    void node._onDemand;
    void node._firePullDemand;
    void node._fireOwedDemandIfReady;
    void node._shouldBufferOnPause;
    void node._invalidate;
    void node._allDepsTerminal;
    void node._emitToSubs;
  }
  constructor(deps, handleOrFn, opts = {}) {
    const suppliedAcquisition = constructionAcquisitions.get(opts);
    const acquisition = suppliedAcquisition ?? { name: "bare node" };
    constructionAcquisitions.delete(opts);
    const core = takeConstructingNodeCore();
    const dispatcher = opts.dispatcher ?? defaultDispatcher;
    const environment = takeConstructingEnvironmentDrivers() ?? EnvironmentDrivers.empty();
    try {
      const versioning = resolveNodeVersioningPolicy(opts.versioning);
      const pool = opts.pool ?? "sync";
      const pausable = opts.pausable ?? true;
      const pullLock = opts.pullId;
      const pull = opts.pullId !== void 0;
      if (pull && pausable === false)
        throw new Error(
          "node: pullId is incompatible with pausable:false \u2014 a pull node uses the pausable delivery-content axis (R-pull / R-pause-modes / D55,D269)"
        );
      let handle;
      if (handleOrFn === null) handle = null;
      else if (typeof handleOrFn === "function") handle = dispatcher.register(handleOrFn, pool);
      else handle = handleOrFn;
      if (handle !== null && typeof handleOrFn === "function") {
        acquisition.dispatcher = dispatcher;
        acquisition.handle = handle;
      }
      const n = deps.length;
      const dep = makeDepBookkeeping(n);
      const value = {
        cache: SENTINEL,
        hasData: false,
        status: "sentinel",
        terminal: void 0,
        hasTorndown: false,
        replayRing: []
      };
      if (opts.initial !== void 0) {
        value.cache = opts.initial;
        value.hasData = true;
        value.status = "settled";
      }
      const pauseLockset = /* @__PURE__ */ new Set();
      this._core = core ?? new NodeCore();
      const created = this._core.createSlot(
        {
          deps,
          handle,
          pool,
          dispatcher,
          environment,
          partial: opts.partial ?? false,
          terminalAsRealInput: opts.terminalAsRealInput ?? false,
          completeWhenDepsComplete: opts.completeWhenDepsComplete ?? true,
          errorWhenDepsError: opts.errorWhenDepsError ?? true,
          resubscribable: opts.resubscribable ?? false,
          resetOnTeardown: opts.resetOnTeardown ?? false,
          pausable,
          pull,
          pullLock,
          replayN: opts.replayBuffer ?? 0,
          dynamic: opts.dynamic ?? false,
          name: opts.name,
          factory: opts.factory
        },
        {
          dep,
          lifecycle: { subscribers: /* @__PURE__ */ new Set(), activated: false },
          value,
          wave: {
            pending: 0,
            hasCalledFnOnce: false,
            emittedDirtyThisWave: false,
            emittedSettleThisWave: false,
            insideRunWave: false,
            inDepMutation: false,
            rewireRunPending: false,
            batchDirtyOwed: false
          },
          control: {
            pauseLockset,
            pausedDepWaveOccurred: false,
            pauseBuffer: [],
            demandOwed: void 0,
            activePull: void 0,
            pullDirtyOwed: false,
            inDeliverDemand: false
          },
          privateState: { value: SENTINEL, persist: false },
          hooks: { onDeactivation: [], onInvalidate: [] },
          syncCtx: { value: null },
          version: {
            policy: versioning,
            value: createNodeVersion(
              versioning,
              opts.initial !== void 0 ? opts.initial : void 0
            )
          }
        },
        acquisition
      );
      acquisition.core = this._core;
      acquisition.slot = created.id;
      this._id = created.id;
      this._slot = this._core.get(this._id);
      this._dep = this._core.getDep(this._id);
      this._value = this._core.getValue(this._id);
      this._wave = this._core.getWave(this._id);
      this._control = this._core.getControl(this._id);
      this._lifecycle = this._core.getLifecycle(this._id);
      this._privateState = this._core.getPrivateState(this._id);
      this._hooks = this._core.getHooks(this._id);
      this._syncCtxState = this._core.getSyncCtx(this._id);
      this._version = this._core.getVersion(this._id);
      _Node._retainIndirectRuntimeMethods(this);
      issueNodeRegistration(this);
      acquisition.node = this;
    } catch (cause) {
      if (suppliedAcquisition !== void 0) throw cause;
      failNodeAcquisition(acquisition, cause);
    }
  }
  /** R-pull (D55/D272): true while a pull node is not serving a PULL demand pulse. */
  _isPullQuiet() {
    return this._slot.pull && this._control.activePull === void 0;
  }
  /**
   * R-pull (D269/D272): this pull node's pullId (pure data, like {@link cache}/{@link handle} —
   * never triggers computation). A consumer demands one delivery by cone-routing PULL of it (no
   * node reference): `ctx.up([["PULL", { pullId }]])` (immediate; loops back → D37 for a self-read
   * dep) or `ctx.upNext([["PULL", { pullId }]])` (boundary-deferred self-demand). Undefined for a
   * non-pull node. The author writes the pullId verbatim; routing matches by identity.
   */
  get pullId() {
    return this._slot.pullLock;
  }
  get cache() {
    return this._value.cache;
  }
  get status() {
    return this._value.status;
  }
  get version() {
    return cloneNodeVersion(this._version.value);
  }
  get name() {
    return this._slot.name;
  }
  /** R-describe/D51: real factory name for a standalone graph-less node (a runtime *Map inner). */
  get factory() {
    return this._slot.factory;
  }
  /**
   * The node's CURRENT/LIVE deps (R-describe / R-edges-derived / D51) — readonly view of the
   * live `_deps`, which a rewire (C-8 / C-11) mutates. The graph's describe() reads this (NOT a
   * construction-time snapshot) so every edge corresponds to a real current subscription (D3).
   * Inspection-only, like cache/status; never triggers computation.
   */
  get deps() {
    return this._slot.deps;
  }
  /**
   * The fn handle (pure data `(poolId, handleId)`, D7) or null for state/passthrough
   * nodes. Inspection-only (L1.6 handle is referenceable/inspectable) — lets the graph
   * layer key a dispatcher-backed profile recorder WITHOUT putting counters on the node
   * (R-node-thin / D39).
   */
  get handle() {
    return this._slot.handle;
  }
  /** R-push-subscribe: a new sink receives START, then cached DATA (or DIRTY if dirty). */
  subscribe(sink) {
    return this._subscribeOwned(sink);
  }
  _subscribeOwned(sink, acquisition) {
    this._assertNotReleased("subscribe");
    enterWave();
    try {
      if (this._value.terminal !== void 0) {
        if (this._slot.resubscribable) {
          this._restoredActivationPending = false;
          this._resetLifecycle();
        } else
          throw new Error(
            "subscribe: node is non-resubscribable and has terminated; the stream is permanently over (R-terminal / R2.2.7.b)"
          );
      }
      this._lifecycle.subscribers.add(sink);
      const unsubscribe = () => {
        if (!this._lifecycle.subscribers.delete(sink)) return;
        if (this._lifecycle.subscribers.size === 0) this._deactivate();
      };
      acquisition?.record(unsubscribe);
      sink(["START"]);
      if (this._slot.replayN > 0 && this._value.replayRing.length > 0) {
        for (const v of this._value.replayRing) sink(["DATA", v]);
      } else if (this._value.hasData && !this._slot.pull) {
        sink(["DATA", this._value.cache]);
      } else if (this._value.status === "dirty" && !this._slot.pull) {
        sink(["DIRTY"]);
      }
      if (!this._lifecycle.activated) this._activate();
      return unsubscribe;
    } finally {
      exitWave();
    }
  }
  /** External emission toward sinks (state-node push, or async late-emit). One call = one wave. */
  down(msgs) {
    this._assertNotReleased("down");
    enterWave();
    try {
      this._down(msgs);
    } finally {
      exitWave();
    }
  }
  /**
   * Emit upstream toward deps — control tiers only (R-ctx-up). `towardDep` (a dep index) routes up
   * ONE declared edge (R-up-routing directed-up); omitted = broadcast up all deps.
   */
  up(msgs, towardDep) {
    this._assertNotReleased("up");
    enterWave();
    try {
      this._up(msgs, towardDep);
    } finally {
      exitWave();
    }
  }
  // ── rewire (R-rewire / D42): intra-graph runtime topology mutation ──
  /**
   * Replace this node's deps atomically (surgical, Option-C). Requires an explicit
   * `fn` (SD-1 fn-deps pairing — user fns read dep input positionally). Kept deps
   * keep their subscription + per-dep state; only removed deps unsubscribe and only
   * added deps fresh-subscribe (push-on-subscribe for an added cached dep). The
   * first-run gate and cache are PRESERVED (R-rewire Q2/Q7). Intra-graph only (D22).
   */
  replaceDeps(newDeps, fn) {
    this._assertNotReleased("replaceDeps");
    this._rewire(this._dedupDeps(newDeps), fn);
  }
  /** Subscribe to one dep (special case of replaceDeps); returns its index. fn required (SD-1). */
  subscribeDep(depNode, fn) {
    this._assertNotReleased("subscribeDep");
    const next = this._slot.deps.includes(depNode) ? [...this._slot.deps] : [...this._slot.deps, depNode];
    const deferred = this._rewire(next, fn);
    return deferred ? next.indexOf(depNode) : this._slot.deps.indexOf(depNode);
  }
  /** Unsubscribe from one dep (special case of replaceDeps); idempotent if absent (fn swap still applies). */
  unsubscribeDep(depNode, fn) {
    this._assertNotReleased("unsubscribeDep");
    this._rewire(
      this._slot.deps.filter((d) => d !== depNode),
      fn
    );
  }
  _requestRewireNext(op) {
    nodeRequestRewireNext(nodeRuntimeHost(this), op);
  }
  _requestUpNext(msgs, towardDep) {
    nodeRequestUpNext(nodeRuntimeHost(this), msgs, towardDep);
  }
  _applyRewireNext(op) {
    nodeApplyRewireNext(nodeRuntimeHost(this), op);
  }
  _dedupDeps(deps) {
    const seen = /* @__PURE__ */ new Set();
    const out = [];
    for (const d of deps)
      if (!seen.has(d)) {
        seen.add(d);
        out.push(d);
      }
    return out;
  }
  _reachableUpstream(from, target) {
    const seen = /* @__PURE__ */ new Set();
    const stack = [from];
    while (stack.length > 0) {
      const n = stack.pop();
      if (n === void 0) continue;
      if (n === target) return true;
      if (seen.has(n)) continue;
      seen.add(n);
      for (const d of nodeRuntimeHost(n)._slot.deps) stack.push(d);
    }
    return false;
  }
  _assertRewireDepOwner(dep) {
    const selfOwner = getNodeOwner(this);
    const depOwner = getNodeOwner(dep);
    if (selfOwner !== void 0 && depOwner !== void 0 && selfOwner !== depOwner)
      throw new Error(
        "rewire: dep belongs to a different graph; cross-graph deps require a wire bridge (D22 / R-graph-domain)"
      );
  }
  _rewire(newDeps, fn, opts = {}) {
    return nodeRewire(nodeRuntimeHost(this), newDeps, fn, opts);
  }
  // ── activation / deactivation (lazy; R-rom-ram) ──
  _activate() {
    nodeActivate(nodeRuntimeHost(this));
  }
  _deactivate() {
    nodeDeactivate(nodeRuntimeHost(this));
  }
  _assertNotReleased(op) {
    if (this._released)
      throw new Error(`${op}: node has been released from its graph lifecycle (D122)`);
  }
  // biome-ignore lint/correctness/noUnusedPrivateClassMembers: accessed through the checked internal runtime host.
  _subscriberCount() {
    return nodeSubscriberCount(nodeRuntimeHost(this));
  }
  // biome-ignore lint/correctness/noUnusedPrivateClassMembers: accessed through the checked internal runtime host.
  _isRuntimeQuiescentForRelease() {
    return nodeIsRuntimeQuiescentForRelease(nodeRuntimeHost(this));
  }
  // biome-ignore lint/correctness/noUnusedPrivateClassMembers: accessed through the checked internal runtime host.
  _releaseRuntime() {
    nodeReleaseRuntime(nodeRuntimeHost(this));
  }
  // biome-ignore lint/correctness/noUnusedPrivateClassMembers: accessed through the checked internal runtime host.
  _resetDepState() {
    nodeResetDepState(nodeRuntimeHost(this));
  }
  _subscribeDepAt(depNode, opts = {}) {
    nodeSubscribeDepAt(nodeRuntimeHost(this), depNode, opts);
  }
  _seedRestoredDepAt(idx, depNode) {
    nodeSeedRestoredDepAt(nodeRuntimeHost(this), idx, depNode);
  }
  _recordDepProjection(idx, delivery) {
    return nodeRecordDepProjection(nodeRuntimeHost(this), idx, delivery);
  }
  _depProjectionHasData(idx) {
    return nodeDepProjectionHasData(nodeRuntimeHost(this), idx);
  }
  _receiveFromDep(idx, msg, delivery) {
    nodeReceiveFromDep(nodeRuntimeHost(this), idx, msg, delivery);
  }
  _releaseDepDirty(idx) {
    nodeReleaseDepDirty(nodeRuntimeHost(this), idx);
  }
  _settleAfterAbsorbedTerminal() {
    nodeSettleAfterAbsorbedTerminal(nodeRuntimeHost(this));
  }
  _markDirty() {
    nodeMarkDirty(nodeRuntimeHost(this));
  }
  _maybeRun() {
    nodeMaybeRun(nodeRuntimeHost(this));
  }
  _settleRewire() {
    nodeSettleRewire(nodeRuntimeHost(this));
  }
  _tryRun() {
    nodeTryRun(nodeRuntimeHost(this));
  }
  _allDepsSettled() {
    return nodeAllDepsSettled(nodeRuntimeHost(this));
  }
  _passthroughEmit() {
    nodePassthroughEmit(nodeRuntimeHost(this));
  }
  _runWave() {
    nodeRunWave(nodeRuntimeHost(this));
  }
  _buildCtx() {
    return nodeBuildCtx(nodeRuntimeHost(this));
  }
  _makeCtx(snapshot) {
    return nodeMakeCtx(nodeRuntimeHost(this), snapshot);
  }
  _refreshCtx(ctx) {
    nodeRefreshCtx(nodeRuntimeHost(this), ctx);
  }
  _makeState() {
    return nodeMakeState(nodeRuntimeHost(this));
  }
  // ── downstream emission pipeline (the unified waist) ──
  _down(msgs) {
    nodeDown(nodeRuntimeHost(this), msgs);
  }
  _up(msgs, towardDep, route) {
    nodeUp(nodeRuntimeHost(this), msgs, towardDep, route);
  }
  _markDemandRouted(lockId, route) {
    return nodeMarkDemandRouted(nodeRuntimeHost(this), lockId, route);
  }
  _forwardUp(m, towardDep, route) {
    nodeForwardUp(nodeRuntimeHost(this), m, towardDep, route);
  }
  _isPaused() {
    return nodeIsPaused(nodeRuntimeHost(this));
  }
  _hasBoundaryPauseLock() {
    return nodeHasBoundaryPauseLock(nodeRuntimeHost(this));
  }
  _isAsyncPool() {
    return nodeIsAsyncPool(nodeRuntimeHost(this));
  }
  _pauseAcquire(lockId) {
    nodePauseAcquire(nodeRuntimeHost(this), lockId);
  }
  _pauseRelease(lockId) {
    nodePauseRelease(nodeRuntimeHost(this), lockId);
  }
  _onResume() {
    nodeOnResume(nodeRuntimeHost(this));
  }
  _canFireDemand() {
    return nodeCanFireDemand(nodeRuntimeHost(this));
  }
  _deliverPullDemand(demand) {
    nodeDeliverPullDemand(nodeRuntimeHost(this), demand);
  }
  _onDemand(demand) {
    nodeOnDemand(nodeRuntimeHost(this), demand);
  }
  _firePullDemand() {
    nodeFirePullDemand(nodeRuntimeHost(this));
  }
  _fireOwedDemandIfReady() {
    nodeFireOwedDemandIfReady(nodeRuntimeHost(this));
  }
  _shouldBufferOnPause() {
    return nodeShouldBufferOnPause(nodeRuntimeHost(this));
  }
  _invalidate(delivery) {
    nodeInvalidate(nodeRuntimeHost(this), delivery);
  }
  _allDepsTerminal() {
    return nodeAllDepsTerminal(nodeRuntimeHost(this));
  }
  _emitToSubs(msg, delivery) {
    nodeEmitToSubs(nodeRuntimeHost(this), msg, delivery);
  }
  /** R-terminal: resubscribable reset clears terminal + dep state + re-arms the gate. */
  _resetLifecycle() {
    nodeResetLifecycle(nodeRuntimeHost(this));
  }
  /** Batch commit (R-batch-coalesce): deliver the deferred tier-3 wave now. */
  __commitBatchedWave(wave) {
    nodeCommitBatchedWave(nodeRuntimeHost(this), wave);
  }
  /** Batch rollback: balance the immediate DIRTY with a RESOLVED so downstream un-dirties. */
  __rollbackBatched() {
    nodeRollbackBatched(nodeRuntimeHost(this));
  }
  /** B49: enqueue a committed-boundary task on this node's graph-local core. */
  __deferBoundary(fn, batchToken) {
    nodeDeferBoundary(nodeRuntimeHost(this), fn, batchToken);
  }
};

// packages/ts/src/identity.ts
function canonicalTupleKey(parts) {
  return JSON.stringify(parts);
}

// packages/ts/src/graph/blueprint.ts
var GRAPH_BLUEPRINT_VERSION = "graphrefly.blueprint.v2";
function normalizeTopologyMeta(meta, label = "meta", kind = "graph meta") {
  try {
    return assertStrictJsonObject(meta, label);
  } catch (error) {
    const message = error instanceof Error ? error.message : String(error);
    throw new TypeError(`${label}: ${kind} must be strict JSON-compatible data (D177): ${message}`);
  }
}
function normalizeTopology(snapshot) {
  return normalizeTopologySnapshot(snapshot, /* @__PURE__ */ new WeakSet(), "$");
}
function normalizeTopologySnapshot(snapshot, seen, path) {
  if (snapshot === null || typeof snapshot !== "object") {
    throw new TypeError(`normalizeTopology: snapshot at ${path} must be an object`);
  }
  if (seen.has(snapshot)) {
    throw new TypeError(`normalizeTopology: circular subgraph reference at ${path}`);
  }
  seen.add(snapshot);
  try {
    const nodes = mapDense(snapshot.nodes, `${path}.nodes`, (node, index) => {
      const nodePath = `${path}.nodes[${index}]`;
      assertTopologyObject(node, nodePath);
      const id = topologyString(node.id, `${nodePath}.id`);
      const factory = topologyString(node.factory, `${nodePath}.factory`);
      const out2 = {
        id,
        factory,
        deps: mapDense(
          node.deps,
          `${labelForNode(id)}.deps`,
          (dep, depIndex) => topologyString(dep, `${labelForNode(id)}.deps[${depIndex}]`)
        )
      };
      if (node.name !== void 0) {
        out2.name = topologyString(node.name, `${nodePath}.name`);
      }
      if (node.meta !== void 0) {
        out2.meta = normalizeTopologyMeta(node.meta, `${labelForNode(id)}.meta`);
      }
      return out2;
    }).sort(compareNodes);
    const out = {
      nodes,
      edges: deriveEdges(nodes)
    };
    if (snapshot.mountId !== void 0) {
      out.mountId = topologyString(snapshot.mountId, `${path}.mountId`);
    }
    if (snapshot.name !== void 0) {
      out.name = topologyString(snapshot.name, `${path}.name`);
    }
    if (snapshot.subgraphs !== void 0) {
      out.subgraphs = mapDense(
        snapshot.subgraphs,
        `${path}.subgraphs`,
        (subgraph, index) => normalizeTopologySnapshot(subgraph, seen, `${path}.subgraphs[${index}]`)
      ).sort(compareTopologies);
    }
    return out;
  } finally {
    seen.delete(snapshot);
  }
}
function mapDense(values, path, mapper) {
  if (!Array.isArray(values)) {
    throw new TypeError(`normalizeTopology: ${path} must be an array`);
  }
  const out = [];
  for (let i = 0; i < values.length; i += 1) {
    if (!(i in values)) {
      throw new TypeError(`normalizeTopology: sparse array hole at ${path}[${i}]`);
    }
    out.push(mapper(values[i], i));
  }
  return out;
}
function assertTopologyObject(value, path) {
  if (value === null || typeof value !== "object" || Array.isArray(value)) {
    throw new TypeError(`normalizeTopology: ${path} must be an object`);
  }
}
function topologyString(value, path) {
  if (typeof value !== "string") {
    throw new TypeError(`normalizeTopology: ${path} must be a string`);
  }
  return value;
}
function graphBlueprintDiagnostics(topology) {
  const issues = [];
  collectDiagnostics(topology, issues);
  issues.sort(compareIssues);
  return { ok: !issues.some((issue) => issue.severity === "error"), issues };
}
function collectDiagnostics(topology, issues) {
  const seen = /* @__PURE__ */ new Set();
  const duplicateIds = /* @__PURE__ */ new Set();
  for (const node of topology.nodes) {
    if (seen.has(node.id)) duplicateIds.add(node.id);
    seen.add(node.id);
  }
  for (const id of duplicateIds) {
    issues.push({
      severity: "error",
      code: "duplicate-node-id",
      nodeId: id,
      message: `duplicate topology node id '${id}'`
    });
  }
  const dependents = /* @__PURE__ */ new Map();
  for (const node of topology.nodes) dependents.set(node.id, 0);
  for (const node of topology.nodes) {
    for (const dep of node.deps) {
      if (!seen.has(dep)) {
        issues.push({
          severity: "error",
          code: "dangling-dep",
          nodeId: node.id,
          from: dep,
          to: node.id,
          message: `node '${node.id}' depends on missing node '${dep}'`
        });
        continue;
      }
      dependents.set(dep, (dependents.get(dep) ?? 0) + 1);
    }
  }
  for (const node of topology.nodes) {
    if (node.deps.length === 0 && (dependents.get(node.id) ?? 0) === 0) {
      issues.push({
        severity: "warning",
        code: "island-node",
        nodeId: node.id,
        message: `node '${node.id}' has no deps and no dependents`
      });
    }
  }
  for (const subgraph of topology.subgraphs ?? []) collectDiagnostics(subgraph, issues);
}
function deriveEdges(nodes) {
  const seen = /* @__PURE__ */ new Set();
  const edges = [];
  for (const node of nodes) {
    for (const from of node.deps) {
      const key = canonicalTupleKey([from, node.id]);
      if (seen.has(key)) continue;
      seen.add(key);
      edges.push({ from, to: node.id });
    }
  }
  return edges.sort(compareEdges);
}
function labelForNode(id) {
  return id === "" ? "node" : `node '${id}'`;
}
function compareText(a, b) {
  return a < b ? -1 : a > b ? 1 : 0;
}
function compareNodes(a, b) {
  return compareText(a.id, b.id);
}
function compareEdges(a, b) {
  return compareText(a.from, b.from) || compareText(a.to, b.to);
}
function compareTopologies(a, b) {
  return compareText(a.mountId ?? "", b.mountId ?? "") || compareText(stableJsonString(a), stableJsonString(b));
}
function compareIssues(a, b) {
  return compareText(a.code, b.code) || compareText(a.nodeId ?? "", b.nodeId ?? "") || compareText(a.from ?? "", b.from ?? "") || compareText(a.to ?? "", b.to ?? "");
}

// packages/ts/src/graph/describe.ts
function topologyFromDescribe(snapshot) {
  const nodes = snapshot.nodes.map((node) => {
    const topologyNode = {
      id: node.id,
      factory: node.factory,
      deps: [...node.deps]
    };
    if (node.name !== void 0) topologyNode.name = node.name;
    if (node.meta !== void 0) topologyNode.meta = cloneTopologyMeta(node.meta);
    return topologyNode;
  });
  const out = {
    nodes,
    edges: snapshot.edges.map((edge) => ({ from: edge.from, to: edge.to }))
  };
  if (snapshot.mountId !== void 0) out.mountId = snapshot.mountId;
  if (snapshot.name !== void 0) out.name = snapshot.name;
  if (snapshot.subgraphs !== void 0)
    out.subgraphs = snapshot.subgraphs.map(topologyFromDescribe);
  return out;
}
function cloneTopologyMeta(meta) {
  return cloneTopologyValue(meta, /* @__PURE__ */ new WeakMap());
}
function cloneTopologyValue(value, seen) {
  if (value === null) return null;
  const kind = typeof value;
  if (kind === "string" || kind === "boolean") return value;
  if (kind === "number") {
    if (!Number.isFinite(value)) {
      throw new Error("topology(): meta must be finite JSON-compatible data (D39/D173)");
    }
    return value;
  }
  if (kind !== "object") {
    throw new Error("topology(): meta must be JSON-compatible data (D39/D173)");
  }
  const objectValue = value;
  const cached = seen.get(objectValue);
  if (cached !== void 0) return cached;
  if (Array.isArray(value)) {
    const out2 = new Array(value.length);
    seen.set(objectValue, out2);
    for (let i = 0; i < value.length; i += 1) {
      if (!(i in value)) {
        throw new Error("topology(): meta arrays must be dense JSON-compatible data (D39/D173)");
      }
      out2[i] = cloneTopologyValue(value[i], seen);
    }
    return out2;
  }
  const proto = Object.getPrototypeOf(objectValue);
  if (proto !== Object.prototype && proto !== null) {
    throw new Error("topology(): meta must be plain JSON-compatible data (D39/D173)");
  }
  const out = {};
  seen.set(objectValue, out);
  for (const [key, item] of Object.entries(value))
    out[key] = cloneTopologyValue(item, seen);
  return out;
}

// packages/ts/src/graph/graph-lifecycle.ts
var graphRegistrations = /* @__PURE__ */ new WeakMap();

// packages/ts/src/graph/graph-support.ts
function isNonAuthoritativeCollectionHelperMeta(meta) {
  return meta?.kind === "collection_delta" || meta?.kind === "collection_intent" || meta?.kind === "collection_policy_apply" || meta?.kind === "collection_snapshot" || meta?.kind === "collection_snapshot_prep";
}
function assertCheckpointQuiescentStatus(status, id, op) {
  if (status === "pending" || status === "dirty") {
    throw new Error(
      `${op}: node '${id}' has non-quiescent status '${status}' that cannot be checkpoint-restored yet`
    );
  }
}
function topologyPathMatches(eventPath, path) {
  return eventPath === path || eventPath.startsWith(`${path}::`);
}
function prefixTopologyPath(prefix, path) {
  return `${prefix}::${path}`;
}
function cloneTopologyEvent(event) {
  const deps = Object.freeze([...event.deps]);
  const prevDeps = event.prevDeps === void 0 ? void 0 : Object.freeze([...event.prevDeps]);
  return Object.freeze({
    kind: event.kind,
    path: event.path,
    deps,
    ...prevDeps !== void 0 ? { prevDeps } : {},
    ...event.factory !== void 0 ? { factory: event.factory } : {},
    seq: event.seq
  });
}
function checkpointFactory(name, node, unregistered, restore, meta) {
  const state = checkpointStateOfNode(node);
  if (unregistered) {
    return {
      kind: "local-only",
      name,
      reason: "node is an unregistered live dependency auto-discovered from topology"
    };
  }
  if (restore === void 0 && typeof meta?.kind === "string" && meta.kind.startsWith("collection_")) {
    return {
      kind: "local-only",
      name,
      reason: "collection helper node has no backend checkpoint restore metadata"
    };
  }
  if (restore !== void 0) {
    const out = {
      kind: "registry-ref",
      ref: toCheckpointJson(restore.ref, `${name}.factory.ref`)
    };
    if (restore.config !== void 0)
      out.config = toCheckpointJson(restore.config, `${name}.factory.config`);
    if (restore.configVersion !== void 0)
      out.configVersion = toCheckpointJson(restore.configVersion, `${name}.factory.configVersion`);
    return out;
  }
  if (state.handle !== null) {
    return {
      kind: "local-only",
      name,
      reason: "node uses a function body; first-cut checkpoints do not serialize local functions"
    };
  }
  return { kind: "registry-ref", ref: name };
}
function explainSubset(snap, chain) {
  const fwd = /* @__PURE__ */ new Map();
  const rev = /* @__PURE__ */ new Map();
  const push = (map, k, v) => {
    const a = map.get(k);
    if (a) a.push(v);
    else map.set(k, [v]);
  };
  for (const e of snap.edges) {
    push(fwd, e.from, e.to);
    push(rev, e.to, e.from);
  }
  const reach = (start, adj) => {
    const seen = /* @__PURE__ */ new Set([start]);
    const stack = [start];
    while (stack.length > 0) {
      const cur = stack.pop();
      for (const nxt of adj.get(cur) ?? []) {
        if (!seen.has(nxt)) {
          seen.add(nxt);
          stack.push(nxt);
        }
      }
    }
    return seen;
  };
  const onPath = new Set([...reach(chain.from, fwd)].filter((id) => reach(chain.to, rev).has(id)));
  return {
    ...snap.name !== void 0 ? { name: snap.name } : {},
    nodes: snap.nodes.filter((n) => onPath.has(n.id)),
    edges: snap.edges.filter((e) => onPath.has(e.from) && onPath.has(e.to))
  };
}

// packages/ts/src/graph/graph-topology-group.ts
var GraphTopologyGroup = class {
  name;
  _graph;
  _members = [];
  _released = false;
  constructor(graph, opts = {}) {
    this._graph = graph;
    this.name = opts.name;
  }
  get released() {
    return this._released;
  }
  add(node) {
    this._assertLive();
    const lifecycle = graphRegistrations.get(this._graph);
    if (lifecycle === void 0) throw new Error("topologyGroup: graph lifecycle unavailable");
    lifecycle.assertRegisteredNode(node, `topology group '${this.name ?? "group"}' member`);
    if (!this._members.includes(node)) this._members.push(node);
    return node;
  }
  node(deps = [], fn = null, opts = {}) {
    this._assertLive();
    return this.add(this._graph.node(deps, fn, opts));
  }
  state(initial, opts = {}) {
    this._assertLive();
    return this.add(this._graph.state(initial, opts));
  }
  producer(fn, opts = {}) {
    this._assertLive();
    return this.add(this._graph.producer(fn, opts));
  }
  derived(deps, fn, opts = {}) {
    this._assertLive();
    return this.add(this._graph.derived(deps, fn, opts));
  }
  effect(deps, fn, opts = {}) {
    this._assertLive();
    return this.add(this._graph.effect(deps, fn, opts));
  }
  initNode(op, deps, opts = {}) {
    this._assertLive();
    return this.add(this._graph.initNode(op, deps, opts));
  }
  release(opts = {}) {
    if (this._released) return;
    const lifecycle = graphRegistrations.get(this._graph);
    if (lifecycle === void 0) throw new Error("topologyGroup: graph lifecycle unavailable");
    lifecycle.releaseNodes([...this._members], {
      reason: opts.reason ?? this.name
    });
    this._members.length = 0;
    this._released = true;
  }
  _assertLive() {
    if (this._released) {
      throw new Error(`topology group '${this.name ?? "group"}' has been released (D152)`);
    }
  }
};

// packages/ts/src/graph/operators.ts
function initNodeWithCore(core, op, deps, opts = {}, acquired) {
  return withNodeCore(core, () => makeInitNode(op, deps, opts, acquired));
}
function makeInitNode(op, deps, opts, acquired) {
  const body = operatorNodeFn(op);
  const merged = { factory: op.factory, ...op.opts, ...opts };
  if (acquired !== void 0) constructionAcquisitions.set(merged, acquired);
  try {
    return new Node([...deps], body, merged);
  } finally {
    constructionAcquisitions.delete(merged);
  }
}
function operatorNodeFn(op) {
  return (ctx) => {
    try {
      op.body(ctx);
    } catch (e) {
      ctx.down([["ERROR", errorPayload(e, "operator threw without a valid error payload")]]);
    }
  };
}

// packages/ts/src/graph/graph.ts
function nodeOwner(n) {
  return getNodeOwner(n);
}
function assertGraphLocalNode(owner, n, label) {
  if (isNodeRuntimeReleased(n)) {
    throw new Error(`${label} has been released from its graph lifecycle (D122)`);
  }
  const existing = nodeOwner(n);
  if (existing !== void 0 && existing !== owner) {
    throw new Error(
      `${label} belongs to a different graph; cross-graph deps require a wire bridge`
    );
  }
}
var StateNode = class extends Node {
  set(v) {
    this.down([["DATA", v]]);
  }
};
var Graph = class {
  name;
  _dispatcher;
  _versioning;
  _environment;
  _core = new NodeCore();
  _entries = /* @__PURE__ */ new Map();
  _byId = /* @__PURE__ */ new Map();
  _retiredIds = /* @__PURE__ */ new Set();
  _mounts = [];
  _seq = 0;
  _clock = 0;
  // graph-local monotonic clock for observe seq (D26)
  _topologyObserverSeq = 0;
  _topologyObservers = /* @__PURE__ */ new Map();
  _topologyDelivering = false;
  _topologyQueue = [];
  // D51: stable synthetic ids for unregistered live deps (runtime *Map inners) auto-discovered by
  // describe(). WeakMap-cached so successive describes agree + the inner's id is freed when it is.
  // A dedicated counter (NOT _seq) so a describe() call never perturbs registered-node id numbering.
  _synthSeq = 0;
  _synthIds = /* @__PURE__ */ new WeakMap();
  constructor(opts = {}) {
    this.name = opts.name;
    this._dispatcher = opts.dispatcher ?? defaultDispatcher;
    this._versioning = opts.versioning;
    this._environment = opts.environment ?? EnvironmentDrivers.empty();
    if (opts.profile) this._dispatcher.setRecording(true);
    graphRegistrations.set(this, new GraphRegistration(this));
  }
  // ── registration / inspection index ──
  /** D167: retain acquisition ownership until Graph publication, including operator factories. */
  _createRegistered(factory, deps, opts, create, id, supplied) {
    this._assertDepsLocal(deps, `dep of '${opts.name ?? factory}'`);
    const name = id ?? opts.name;
    if (name !== void 0) this._assertAvailableId(name);
    const nodeOpts = this._nodeOpts(opts);
    const acquired = supplied ?? { name: name ?? factory };
    constructionAcquisitions.set(nodeOpts, acquired);
    try {
      const n = this._construct(() => create(nodeOpts, acquired));
      this._addWithId(n, factory, deps, opts, name ?? `${factory}#${this._seq++}`, acquired);
      return n;
    } catch (cause) {
      if (supplied !== void 0 || acquired.registered) throw cause;
      failNodeAcquisition(acquired, cause);
    } finally {
      constructionAcquisitions.delete(nodeOpts);
    }
  }
  _assertAvailableId(id) {
    if (this._byId.has(id))
      throw new Error(`graph: duplicate node id '${id}' (checkpoint/describe ids must be unique)`);
    if (this._retiredIds.has(id))
      throw new Error(`graph: node id '${id}' was released and cannot be reused (D152/D153)`);
  }
  _addWithId(n, factory, deps, opts, id, acquired) {
    assertGraphLocalNode(this, n, `graph node '${opts.name ?? factory}'`);
    for (const dep of deps) assertGraphLocalNode(this, dep, `dep of '${opts.name ?? factory}'`);
    this._assertAvailableId(id);
    const meta = opts.meta === void 0 ? void 0 : normalizeTopologyMeta(opts.meta, `graph node '${id}' meta`);
    const entry = {
      node: n,
      id,
      name: opts.name,
      factory,
      deps,
      meta,
      restore: opts.restore
    };
    this._assertAvailableId(id);
    this._assertDepsLocal(deps, `dep of '${id}'`);
    this._entries.set(n, entry);
    setNodeOwner(n, this);
    this._byId.set(id, n);
    if (acquired !== void 0) acquired.registered = true;
    setNodeTopologyDepsChangedObserver(n, emitRegisteredDepsChanged);
    const seqMatch = /#(\d+)$/.exec(id);
    if (seqMatch) this._seq = Math.max(this._seq, Number(seqMatch[1]) + 1);
    this._emitTopologyNodeRegistered(n);
    return n;
  }
  _assertDepsLocal(deps, label) {
    for (const dep of deps) assertGraphLocalNode(this, dep, label);
  }
  // biome-ignore lint/correctness/noUnusedPrivateClassMembers: accessed through the checked internal runtime host.
  _assertRegisteredNode(node, label) {
    assertGraphLocalNode(this, node, label);
    if (!this._entries.has(node)) {
      throw new Error(`${label} is not a registered graph node (D152)`);
    }
  }
  _nodeOpts(opts) {
    if (opts.meta !== void 0) {
      normalizeTopologyMeta(opts.meta, `graph node '${opts.name ?? opts.factory ?? "node"}' meta`);
    }
    const { name: _n, meta: _m, restore: _r, ...rest } = opts;
    return {
      ...rest,
      versioning: rest.versioning ?? this._versioning,
      dispatcher: this._dispatcher
    };
  }
  _construct(create) {
    return withEnvironmentDrivers(this._environment, () => withNodeCore(this._core, create));
  }
  /** Look up a registered node by its id. */
  find(id) {
    const local = this._byId.get(id);
    if (local !== void 0) return local;
    const separator = id.indexOf("::");
    if (separator < 0) return void 0;
    const mountPath = id.slice(0, separator);
    const childPath = id.slice(separator + 2);
    return this._mounts.find((mount) => mount.at === mountPath)?.graph.find(childPath);
  }
  // biome-ignore lint/correctness/noUnusedPrivateClassMembers: accessed through the checked internal runtime host.
  _releaseNodes(nodes, _opts = {}) {
    const seen = /* @__PURE__ */ new Set();
    const entries = [];
    for (const node of nodes) {
      if (seen.has(node)) continue;
      seen.add(node);
      const entry = this._entries.get(node);
      if (entry === void 0) continue;
      entries.push({ node, entry });
    }
    const releaseSet = new Set(entries.map(({ node }) => node));
    const releaseIds = new Map(entries.map(({ node, entry }) => [node, entry.id]));
    for (const entry of this._entries.values()) {
      if (releaseSet.has(entry.node)) continue;
      for (const dep of entry.node.deps) {
        if (!releaseSet.has(dep)) continue;
        const depId = releaseIds.get(dep) ?? dep.name ?? dep.factory ?? "released node";
        throw new Error(
          `graph: cannot release node group; '${entry.id}' still depends on '${depId}' (D122)`
        );
      }
    }
    for (const { node, entry } of entries) {
      if (!isNodeRuntimeQuiescentForRelease(node)) {
        throw new Error(
          `graph: cannot release node group; '${entry.id}' is not runtime-quiescent (D124)`
        );
      }
      let internalSubscribers = 0;
      for (const { node: dependent } of entries) {
        if (dependent === node || !isNodeActiveForRelease(dependent)) continue;
        for (const dep of dependent.deps) {
          if (dep === node) internalSubscribers += 1;
        }
      }
      if (subscriberCountOfNode(node) > internalSubscribers) {
        throw new Error(
          `graph: cannot release node group; '${entry.id}' still has live subscribers (D124)`
        );
      }
    }
    const releasedEvents = this._topologyObservers.size === 0 ? [] : entries.map(({ node, entry }) => ({
      path: entry.id,
      factory: entry.factory,
      deps: this._topologyDeps(node.deps)
    }));
    for (const { node, entry } of entries) {
      this._entries.delete(node);
      this._byId.delete(entry.id);
      this._retiredIds.add(entry.id);
    }
    let releaseError;
    let releaseFailed = false;
    for (const { node } of entries) {
      try {
        releaseRuntimeOfNode(node);
      } catch (error) {
        if (!releaseFailed) releaseError = error;
        releaseFailed = true;
      }
    }
    if (!releaseFailed) {
      const constructions = graphRegistrations.get(this).existingConstructions;
      for (const [name, owner] of constructions ?? []) {
        if (owner.nodes.every(
          (node) => isNodeRuntimeReleased(node) && !runtimeReleaseFailuresOfNode(node)
        ))
          constructions.delete(name);
      }
    }
    for (const event of releasedEvents) this._emitTopologyNodeReleased(event);
    if (releaseFailed) throw releaseError;
  }
  // ── 8 verbs (core: node/state/batch + sugar: producer/derived/effect/mount) ──
  /** ctx-level power surface: a raw `(ctx)=>void` fn (or a passthrough/state when null). */
  node(deps = [], fn = null, opts = {}) {
    this._assertDepsLocal(deps, `dep of '${opts.name ?? "node"}'`);
    return this._createRegistered(
      opts.factory ?? "node",
      deps,
      opts,
      (nodeOpts) => new Node(deps, fn, nodeOpts)
    );
  }
  /** A manual source with `.set(v)` (L4-Q1). */
  state(initial, opts = {}) {
    return this._createRegistered(
      "state",
      [],
      { ...opts, initial },
      (nodeOpts) => new StateNode([], null, nodeOpts)
    );
  }
  /** ctx-level depless source; its fn runs on activation (R-rom-ram). */
  producer(fn, opts = {}) {
    return this._createRegistered(
      "producer",
      [],
      opts,
      (nodeOpts) => new Node([], fn, nodeOpts)
    );
  }
  /** value-level pure transform: deps → value (D27 wrapped; D30 throw→ERROR). */
  derived(deps, fn, opts = {}) {
    this._assertDepsLocal(deps, `dep of '${opts.name ?? "derived"}'`);
    const ctxFn = (ctx) => {
      try {
        const args = Array.from(
          { length: depCount(ctx) },
          (_, i) => depLatest(ctx, i)
        );
        const result = fn(...args);
        if (result !== void 0) ctx.down([["DATA", result]]);
      } catch (e) {
        ctx.down([["ERROR", errorPayload(e, "derived threw without a valid error payload")]]);
      }
    };
    return this._createRegistered(
      "derived",
      deps,
      opts,
      (nodeOpts) => new Node([...deps], ctxFn, nodeOpts)
    );
  }
  /** value-level sink: deps → effect; return value (a fn) becomes onDeactivation (D28). */
  effect(deps, fn, opts = {}) {
    this._assertDepsLocal(deps, `dep of '${opts.name ?? "effect"}'`);
    const ctxFn = (ctx) => {
      try {
        const args = Array.from(
          { length: depCount(ctx) },
          (_, i) => depLatest(ctx, i)
        );
        const cleanup = fn(...args);
        if (typeof cleanup === "function") ctx.onDeactivation(cleanup);
      } catch (e) {
        ctx.down([["ERROR", errorPayload(e, "effect threw without a valid error payload")]]);
      }
    };
    return this._createRegistered(
      "effect",
      deps,
      opts,
      (nodeOpts) => new Node([...deps], ctxFn, nodeOpts)
    );
  }
  /** Declarative batch (D12): one wave, success→commit / throw→rollback. */
  batch(fn) {
    return batch(fn);
  }
  /** Embed a child graph addressable under `at` (R-mount; mount has no deps). */
  mount(child, opts) {
    if (typeof opts.at !== "string" || opts.at.length === 0) {
      throw new TypeError("graph.mount: at must be a non-empty string");
    }
    if (this._mounts.some((mounted) => mounted.at === opts.at)) {
      throw new Error(`graph.mount: duplicate sibling mount id '${opts.at}'`);
    }
    const mount = { at: opts.at, graph: child };
    this._mounts.push(mount);
    if (this._topologyObservers.size > 0) this._ensureMountedTopologyForwarders();
    this._emitTopologyMountChanged(opts.at);
  }
  // ── operator funnel (D43): instantiate any free-standing Operator (node sugar, D6/L1.5) ──
  // g.initNode is the single graph-bound entry for the whole operator/source catalog (D40):
  // it delegates to the FREE initNode (graph/operators.ts — the D30 throw→ERROR boundary +
  // dispatcher binding live there) and records the operator's REAL factory name in the
  // inspection index (_add) so describe shows it (D6/R-describe) while the node stays thin
  // (R-node-thin). Operators are free-standing factory definitions (graph/operators.ts,
  // graph/sources.ts) usable bare via the free initNode(); this funnel is the inspectable
  // path. Replaces the per-operator methods.
  /**
   * Instantiate an operator (or source) factory as a registered graph node. `deps` are
   * type-checked against the operator's input element type; the output type flows from the
   * operator. A source is a depless operator — pass `[]`. Caller `opts` (name/meta/behavioral
   * overrides) win over the operator's baked-in `opts`.
   */
  initNode(op, deps, opts = {}) {
    const entryOpts = op.restore !== void 0 && !("restore" in opts) ? { ...opts, restore: op.restore } : opts;
    for (const dep of deps)
      assertGraphLocalNode(this, dep, `dep of '${entryOpts.name ?? op.factory}'`);
    const erased = deps;
    return this._createRegistered(
      op.factory,
      erased,
      entryOpts,
      (nodeOpts, acquired) => initNodeWithCore(this._core, op, erased, nodeOpts, acquired)
    );
  }
  /**
   * Graph-owned activation root for internal helper nodes. This is the sanctioned keepalive shape:
   * a graph, not a helper closure, owns the subscription and returns the release handle.
   */
  retain(node, opts = {}) {
    assertGraphLocalNode(this, node, opts.reason ?? "retained node");
    return node.subscribe(() => {
    });
  }
  /**
   * D152 graph-owned topology/release group. Members are ordinary registered graph nodes;
   * release is quiescent-only and removes ids atomically without synthesizing protocol messages.
   */
  topologyGroup(opts = {}) {
    return new GraphTopologyGroup(this, opts);
  }
  // ── inspection: describe / observe / profile (D39) ──
  /** Live point-in-time structure snapshot (R-describe / D39 / D51). `_prefix` carries the mount path. */
  describe(opts = {}, _prefix = "") {
    const snap = this._describe(_prefix);
    return opts.explain ? explainSubset(snap, opts.explain) : snap;
  }
  /** B1: share discovery order; only materialization is local. Mount reads stay unchanged. */
  _describe(_prefix, incoming) {
    const discovered = /* @__PURE__ */ new Map();
    const localId = (n) => {
      const e = this._entries.get(n);
      if (e) return `${_prefix}${e.id}`;
      let sid = this._synthIds.get(n);
      if (sid === void 0) {
        do {
          sid = `~${n.factory ?? "?"}#${this._synthSeq++}`;
        } while (this._byId.has(sid));
        this._synthIds.set(n, sid);
      }
      discovered.set(n, sid);
      return `${_prefix}${sid}`;
    };
    const nodes = [];
    const edges = [];
    for (const entry of this._entries.values()) {
      const id = `${_prefix}${entry.id}`;
      const liveIds = entry.node.deps.map(localId);
      if (incoming === void 0) {
        const dnode = {
          id,
          factory: entry.factory,
          status: entry.node.status,
          deps: liveIds
        };
        if (entry.name !== void 0) dnode.name = entry.name;
        if (entry.node.cache !== void 0) dnode.value = entry.node.cache;
        if (entry.node.version !== void 0) dnode.version = entry.node.version;
        if (entry.meta !== void 0) dnode.meta = entry.meta;
        nodes.push(dnode);
      }
      if (incoming === void 0 || incoming.has(entry.node)) {
        for (const from of liveIds) edges.push({ from, to: id });
      }
    }
    const visited = /* @__PURE__ */ new Set();
    const queue = [...discovered.keys()];
    for (let i = 0; i < queue.length; i += 1) {
      const inner = queue[i];
      if (visited.has(inner)) continue;
      visited.add(inner);
      const sid = discovered.get(inner);
      if (sid === void 0) continue;
      const liveIds = inner.deps.map(localId);
      for (const dep of inner.deps) {
        if (!this._entries.has(dep) && !visited.has(dep)) queue.push(dep);
      }
      if (incoming === void 0) {
        const dnode = {
          id: `${_prefix}${sid}`,
          factory: inner.factory ?? "?",
          status: inner.status,
          deps: liveIds
        };
        if (inner.cache !== void 0) dnode.value = inner.cache;
        if (inner.version !== void 0) dnode.version = inner.version;
        nodes.push(dnode);
        for (const from of liveIds) edges.push({ from, to: dnode.id });
      }
    }
    const snap = { nodes, edges };
    if (this.name !== void 0) snap.name = this.name;
    if (this._mounts.length > 0) {
      snap.subgraphs = this._mounts.map((m) => {
        const child = m.graph.describe({}, `${_prefix}${m.at}::`);
        child.mountId = m.at;
        return child;
      });
    }
    return snap;
  }
  /**
   * D173 pure-structure topology snapshot over the same live truth source as describe().
   * Runtime status/value/version remain on describe(); blueprint metadata is a later envelope.
   */
  topology() {
    return topologyFromDescribe(this.describe());
  }
  /**
   * D177 synchronous audit/collaboration envelope over the pure topology snapshot.
   * Hashing and environment provenance enrichment stay in pure helpers outside Graph core.
   */
  blueprint(opts = {}) {
    const topology = normalizeTopology(this.topology());
    const out = {
      version: GRAPH_BLUEPRINT_VERSION,
      topology
    };
    if (opts.diagnostics) {
      out.diagnostics = graphBlueprintDiagnostics(topology);
    }
    if (opts.provenance !== void 0) {
      out.provenance = normalizeTopologyMeta(
        opts.provenance,
        "graph blueprint provenance",
        "provenance"
      );
    }
    return out;
  }
  _observeTargets(path) {
    const all = [...this._entries.values()].map((e) => [
      e.id,
      e.node
    ]);
    if (path === void 0) return all;
    const exact = this._byId.get(path);
    if (exact) return [[path, exact]];
    return all.filter(([id]) => id.startsWith(`${path}::`));
  }
  /**
   * observe(path?) = read-only enveloped EGRESS (R-observe / D39). NOT a graph node — it
   * taps the target node(s) via subscribe and forwards each Message as an ObserveEvent.
   * No path = whole graph; an exact id = a single node; otherwise a `::`-prefix subtree.
   */
  // NOTE (R-observe/D19): observe is a real, lazily-ACTIVATING subscriber — observing a
  // cold node runs its fn (and activates upstream); whole-graph observe() activates the
  // graph. "Read-only" means it never emits/mutates node state, NOT that it avoids
  // activation. Use it knowing inspection of a cold graph wakes it.
  observe(path) {
    const targets = this._observeTargets(path);
    return {
      subscribe: (sink) => {
        const unsubs = targets.map(
          ([id, n]) => n.subscribe((msg) => {
            sink({ path: id, msg, tier: messageTier(msg[0]), seq: this._clock++ });
          })
        );
        return () => {
          for (const u of unsubs) u();
        };
      }
    };
  }
  /**
   * D145 observeTopology(path?) = read-only graph lifecycle egress over the existing
   * graph registry. It is not a graph node, does not subscribe to nodes, and emits no DATA.
   */
  observeTopology(path) {
    return {
      subscribe: (sink) => {
        const id = this._topologyObserverSeq++;
        this._topologyObservers.set(id, { path, sink });
        this._ensureMountedTopologyForwarders();
        return () => {
          this._topologyObservers.delete(id);
          if (this._topologyObservers.size === 0) this._releaseMountedTopologyForwarders();
        };
      }
    };
  }
  _idForTopologyNode(n) {
    const e = this._entries.get(n);
    if (e) return e.id;
    let sid = this._synthIds.get(n);
    if (sid === void 0) {
      do {
        sid = `~${n.factory ?? "?"}#${this._synthSeq++}`;
      } while (this._byId.has(sid));
      this._synthIds.set(n, sid);
    }
    return sid;
  }
  _topologyDeps(deps) {
    return deps.map((dep) => this._idForTopologyNode(dep));
  }
  _emitTopologyNodeRegistered(node) {
    if (this._topologyObservers.size === 0) return;
    const entry = this._entries.get(node);
    if (entry === void 0) return;
    this._emitTopologyEvent({
      kind: "node-registered",
      path: entry.id,
      factory: entry.factory,
      deps: this._topologyDeps(node.deps),
      seq: this._clock++
    });
  }
  // biome-ignore lint/correctness/noUnusedPrivateClassMembers: accessed through the checked internal runtime host.
  _emitTopologyDepsChanged(node, prevDeps, nextDeps) {
    if (this._topologyObservers.size === 0) return;
    const entry = this._entries.get(node);
    if (entry === void 0) return;
    this._emitTopologyEvent({
      kind: "deps-changed",
      path: entry.id,
      prevDeps: this._topologyDeps(prevDeps),
      deps: this._topologyDeps(nextDeps),
      seq: this._clock++
    });
  }
  // biome-ignore lint/correctness/noUnusedPrivateClassMembers: accessed through the checked internal runtime host.
  _emitTopologyNodeReleased(event) {
    if (this._topologyObservers.size === 0) return;
    this._emitTopologyEvent({
      kind: "node-released",
      path: event.path,
      factory: event.factory,
      deps: [...event.deps],
      seq: this._clock++
    });
  }
  _emitTopologyMountChanged(path) {
    if (this._topologyObservers.size === 0) return;
    this._emitTopologyEvent({
      kind: "mount-changed",
      path,
      factory: "mount",
      deps: [],
      seq: this._clock++
    });
  }
  _ensureMountedTopologyForwarders() {
    if (this._topologyObservers.size === 0) return;
    for (const mount of this._mounts) {
      if (mount.topologyUnsub !== void 0) continue;
      const mountPath = mount.at;
      mount.topologyUnsub = mount.graph.observeTopology().subscribe((event) => {
        this._emitMountedTopologyEvent(mountPath, event);
      });
    }
  }
  _releaseMountedTopologyForwarders() {
    for (const mount of this._mounts) {
      mount.topologyUnsub?.();
      mount.topologyUnsub = void 0;
    }
  }
  _emitMountedTopologyEvent(mountPath, event) {
    if (this._topologyObservers.size === 0) return;
    this._emitTopologyEvent({
      kind: event.kind,
      path: prefixTopologyPath(mountPath, event.path),
      deps: event.deps.map((dep) => prefixTopologyPath(mountPath, dep)),
      ...event.prevDeps !== void 0 ? { prevDeps: event.prevDeps.map((dep) => prefixTopologyPath(mountPath, dep)) } : {},
      ...event.factory !== void 0 ? { factory: event.factory } : {},
      seq: this._clock++
    });
  }
  _emitTopologyEvent(event) {
    if (this._topologyDelivering) {
      this._topologyQueue.push(event);
      return;
    }
    this._topologyDelivering = true;
    try {
      let current = event;
      while (current !== void 0) {
        const observers = [...this._topologyObservers.entries()];
        for (const [id, observer] of observers) {
          if (this._topologyObservers.get(id) !== observer) continue;
          if (observer.path !== void 0 && !topologyPathMatches(current.path, observer.path))
            continue;
          try {
            observer.sink(cloneTopologyEvent(current));
          } catch {
          }
        }
        current = this._topologyQueue.shift();
      }
    } finally {
      this._topologyDelivering = false;
    }
  }
  /**
   * profile() = accumulated-counter snapshot (R-profile / D39). invokes + duration are
   * dispatcher-backed (the invoke funnel, F-DISPATCH-ALL) — counters never live on the
   * thin node (R-node-thin). Requires `graph({ profile: true })` (opt-in, F-PERF).
   */
  profile() {
    const nodes = {};
    let totalInvokes = 0;
    for (const e of this._entries.values()) {
      const h = e.node.handle;
      const stat = h ? this._dispatcher.statFor(h) : void 0;
      const invokes = stat?.invokes ?? 0;
      nodes[e.id] = {
        invokes,
        totalDurationNs: stat?.totalDurationNs ?? 0,
        lastDurationNs: stat?.lastDurationNs ?? 0,
        status: e.node.status
      };
      totalInvokes += invokes;
    }
    return { totalInvokes, nodes };
  }
  /** Versioned graph lifecycle checkpoint (R-snapshot / D83 / D90). Pure capture, no storage I/O. */
  checkpoint() {
    return this._checkpoint("", /* @__PURE__ */ new WeakSet());
  }
  _checkpoint(_prefix, stack) {
    if (stack.has(this)) {
      throw new Error("checkpoint: cyclic graph mount detected");
    }
    stack.add(this);
    const discovered = /* @__PURE__ */ new Map();
    const localId = (n) => {
      const e = this._entries.get(n);
      if (e) return `${_prefix}${e.id}`;
      let sid = this._synthIds.get(n);
      if (sid === void 0) {
        do {
          sid = `~${n.factory ?? "?"}#${this._synthSeq++}`;
        } while (this._byId.has(sid));
        this._synthIds.set(n, sid);
      }
      discovered.set(n, sid);
      return `${_prefix}${sid}`;
    };
    const nodes = [];
    const edges = [];
    for (const entry of this._entries.values()) {
      const id = `${_prefix}${entry.id}`;
      const liveIds = entry.node.deps.map(localId);
      nodes.push(
        this._checkpointNode(entry.node, id, {
          name: entry.name,
          factory: checkpointFactory(entry.factory, entry.node, false, entry.restore, entry.meta),
          deps: liveIds,
          meta: entry.meta
        })
      );
      for (const from of liveIds) edges.push({ from, to: id });
    }
    const visited = /* @__PURE__ */ new Set();
    const queue = [...discovered.keys()];
    for (let i = 0; i < queue.length; i += 1) {
      const inner = queue[i];
      if (visited.has(inner)) continue;
      visited.add(inner);
      const sid = discovered.get(inner);
      if (sid === void 0) continue;
      const liveIds = inner.deps.map(localId);
      for (const dep of inner.deps) {
        if (!this._entries.has(dep) && !visited.has(dep)) queue.push(dep);
      }
      const id = `${_prefix}${sid}`;
      nodes.push(
        this._checkpointNode(inner, id, {
          factory: checkpointFactory(inner.factory ?? "?", inner, true),
          deps: liveIds
        })
      );
      for (const from of liveIds) edges.push({ from, to: id });
    }
    const checkpoint = {
      version: GRAPH_CHECKPOINT_VERSION,
      nodes,
      edges
    };
    if (this.name !== void 0) checkpoint.name = this.name;
    if (this._mounts.length > 0) {
      checkpoint.mounts = this._mounts.map((m) => ({
        at: m.at,
        checkpoint: m.graph._checkpoint("", stack)
      }));
    }
    stack.delete(this);
    return toCheckpointJson(checkpoint, "checkpoint");
  }
  _checkpointNode(node, id, opts) {
    const state = checkpointStateOfNode(node);
    assertCheckpointQuiescentStatus(node.status, id, "checkpoint");
    const nonAuthoritativeCollectionHelper = isNonAuthoritativeCollectionHelperMeta(opts.meta);
    const out = {
      id,
      factory: opts.factory,
      status: node.status,
      deps: opts.deps,
      value: nonAuthoritativeCollectionHelper ? { kind: "SENTINEL" } : checkpointValue(state.cache, state.hasData, `${id}.value`),
      terminal: checkpointTerminal(state.terminal, `${id}.terminal`),
      lifecycle: { activated: state.activated, hasCalledFnOnce: state.hasCalledFnOnce },
      ctxState: {
        persist: state.ctxState.persist,
        value: nonAuthoritativeCollectionHelper ? { kind: "SENTINEL" } : checkpointValue(
          state.ctxState.value,
          state.ctxState.value !== SENTINEL,
          `${id}.ctxState`
        )
      }
    };
    if (opts.name !== void 0) out.name = opts.name;
    const backendState = checkpointBackendStateOfNode(node, `${id}.backendState`);
    if (backendState !== void 0) out.backendState = backendState;
    if (state.version !== void 0) out.version = state.version;
    if (opts.meta !== void 0)
      out.meta = toCheckpointJson(opts.meta, `${id}.meta`);
    return out;
  }
};
var nativeDescribe = Graph.prototype.describe;
function releaseGraphNodes(graph, nodes, opts = {}) {
  const registrar = graphRegistrations.get(graph);
  if (registrar === void 0) throw new Error("graph: unknown lifecycle registrar");
  registrar.releaseNodes(nodes, opts);
}
function restoreStateNodeInGraph(graph, id, opts = {}) {
  const registrar = graphRegistrations.get(graph);
  if (registrar === void 0) throw new Error("restoreGraph: unknown graph restore registrar");
  return registrar.stateNode(id, opts);
}
var GraphRegistration = class {
  constructor(graph) {
    this.graph = graph;
    this.host = graph;
  }
  graph;
  host;
  owners;
  get existingConstructions() {
    return this.owners;
  }
  get constructions() {
    if (this.owners === void 0) this.owners = /* @__PURE__ */ new Map();
    return this.owners;
  }
  assertRegisteredNode(node, label) {
    this.host._assertRegisteredNode(node, label);
  }
  readIncoming(nodes) {
    const describe = this.graph.describe;
    return describe === nativeDescribe ? this.host._describe("", nodes) : Reflect.apply(describe, this.graph, []);
  }
  releaseNodes(nodes, opts) {
    this.host._releaseNodes(nodes, opts);
  }
  assertAvailableName(name) {
    if (this.host._byId.has(name) || this.host._retiredIds.has(name))
      throw new Error(`construction: live or retired node name ${name}`);
  }
  createOwned(deps, fn, opts, acquired) {
    for (const dep of deps) this.host._assertRegisteredNode(dep, "construction node dependency");
    return this.host._createRegistered(
      opts.factory ?? "node",
      deps,
      opts,
      (nodeOpts) => new Node([...deps], fn, nodeOpts),
      acquired.name,
      acquired
    );
  }
  stateNode(id, opts = {}) {
    return this.host._createRegistered(
      "state",
      [],
      opts,
      (nodeOpts) => new StateNode([], null, nodeOpts),
      id
    );
  }
  node(id, factory, deps, fn, opts = {}) {
    return this.host._createRegistered(
      factory,
      deps,
      opts,
      (nodeOpts) => new Node([...deps], fn, nodeOpts),
      id
    );
  }
};
function emitRegisteredDepsChanged(node, prev, deps) {
  const graph = nodeOwner(node);
  if (graph !== void 0)
    graph._emitTopologyDepsChanged(node, prev, deps);
}

// packages/ts/src/messaging/internal.ts
var busStates = /* @__PURE__ */ new WeakMap();
function registerMessageBusState(bus, state) {
  busStates.set(bus, state);
}
function getMessageBusState(bus) {
  return busStates.get(bus);
}
function attachMessageBusCommandSource(graph, bus, commands) {
  const state = getMessageBusState(bus);
  if (state === void 0) throw new Error("messageBus: unknown implementation");
  if (state.graph !== graph) throw new Error("messageBus: command source graph must match");
  const busCommands = bus.commands;
  if (busCommands === void 0) throw new Error("messageBus: missing commands node");
  const host = nodeRuntimeHost(busCommands);
  let ownsBinding = false;
  const nextDeps = (add) => add ? busCommands.deps.includes(commands) ? [...busCommands.deps] : [...busCommands.deps, commands] : busCommands.deps.filter((dep) => dep !== commands);
  const apply = (add, deferred) => {
    const present = busCommands.deps.includes(commands);
    if (add ? present : !ownsBinding || !present) return;
    host._assertNotReleased("replaceDeps");
    const next = nextDeps(add);
    validateNodeRewire(host, next, { allowTerminalOwner: deferred });
    try {
      host._rewire(next, state.commandBody, { allowTerminalOwner: deferred });
    } finally {
      ownsBinding = busCommands.deps.includes(commands);
    }
  };
  const request = (add) => {
    if (!add && (!ownsBinding || !busCommands.deps.includes(commands))) {
      deferAfterBatchForTarget(busCommands, () => apply(false, true));
      return;
    }
    host._assertNotReleased("replaceDeps");
    validateNodeRewire(host, nextDeps(add));
    if (!deferAfterBatchForTarget(busCommands, () => apply(add, true))) apply(add, false);
  };
  request(true);
  return () => request(false);
}

// packages/ts/src/messaging/utils.ts
function pullParams(pull) {
  return isObjectRecord(pull?.params) ? pull.params : {};
}
function publishCommand(commandNode, command) {
  commandNode.down([["DATA", command]]);
  return command;
}
function makeTopicState() {
  return { closed: false, headSeq: 1, nextSeq: 1, messages: [] };
}
function uniqueTopics(topics) {
  const unique = [...new Set(topics)];
  if (unique.length !== topics.length) throw new Error("messageBus: duplicate topic");
  for (const topic of unique) assertTopicKey(topic, "messageBus");
  return Object.freeze(unique.sort());
}
function assertTopicKey(topic, owner) {
  const error = validateTopicKey(topic, owner);
  if (error !== void 0) throw new Error(error);
}
function validateTopicKey(topic, owner) {
  if (typeof topic !== "string" || topic.length === 0)
    return `${owner}: topic must be a non-empty string`;
  return void 0;
}
function assertNonEmpty(value, owner) {
  if (typeof value !== "string" || value.length === 0)
    throw new Error(`${owner}: must be a non-empty string`);
}
function positiveLimit(limit) {
  if (limit === void 0) return 100;
  if (!Number.isInteger(limit) || limit < 1)
    throw new Error("messageBus: limit must be a positive integer");
  return limit;
}
function isPositiveSeq(value) {
  return Number.isInteger(value) && value >= 1;
}
function isObjectRecord(value) {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}
function commandTopic(command) {
  return isObjectRecord(command) && typeof command.topic === "string" ? command.topic : void 0;
}
function commandIdOf(command) {
  return isObjectRecord(command) && typeof command.commandId === "string" ? command.commandId : void 0;
}
function idempotencyKey(topic, key) {
  return canonicalTupleKey([topic, key]);
}

// packages/ts/src/messaging/index.ts
function messageBus(graph, opts = {}) {
  const name = opts.name ?? "messageBus";
  const initialTopics = uniqueTopics(opts.topics ?? []);
  const commandBody = (ctx) => {
    for (let i = 0; i < depCount(ctx); i++) {
      for (const command of depBatch(ctx, i) ?? []) ctx.down([["DATA", command]]);
    }
  };
  const commands = graph.node([], commandBody, {
    name: `${name}/commands`,
    factory: "messageBusCommands",
    completeWhenDepsComplete: false,
    errorWhenDepsError: false
  });
  const state = {
    graph,
    name,
    now: opts.now ?? Date.now,
    topicPolicy: opts.topicPolicy ?? "strict",
    retention: opts.retention ?? {},
    dedupe: opts.dedupe ?? { commandId: "status" },
    topics: new Map(initialTopics.map((topic) => [topic, makeTopicState()])),
    subscriptions: /* @__PURE__ */ new Map(),
    seenCommandIds: /* @__PURE__ */ new Set(),
    seenIdempotencyKeys: /* @__PURE__ */ new Set(),
    deadLetters: [],
    deadLetterSeq: 0,
    commandBody
  };
  const runtime = graph.node(
    [commands],
    (ctx) => {
      for (const command of depBatch(ctx, 0) ?? []) {
        for (const event of reduceMessageBusCommand(state, command)) {
          ctx.down([["DATA", event]]);
        }
      }
    },
    {
      name: `${name}/runtime`,
      factory: "messageBusRuntime",
      completeWhenDepsComplete: false,
      errorWhenDepsError: false
    }
  );
  graph.retain(runtime, { reason: `${name}.messageBus.runtime` });
  const messages = graph.node(
    [runtime],
    (ctx) => {
      for (const event of depBatch(ctx, 0) ?? []) {
        const typed = event;
        if (typed.kind === "message") ctx.down([["DATA", typed.message]]);
      }
    },
    {
      name: `${name}/messages`,
      factory: "messageBusMessages",
      completeWhenDepsComplete: false,
      errorWhenDepsError: false
    }
  );
  const status = graph.node(
    [runtime],
    (ctx) => {
      for (const event of depBatch(ctx, 0) ?? []) {
        const typed = event;
        if (typed.kind === "status") ctx.down([["DATA", typed.status]]);
      }
    },
    {
      name: `${name}/status`,
      factory: "messageBusStatus",
      completeWhenDepsComplete: false,
      errorWhenDepsError: false
    }
  );
  const issues = graph.node(
    [runtime],
    (ctx) => {
      for (const event of depBatch(ctx, 0) ?? []) {
        const typed = event;
        if (typed.kind === "issue") ctx.down([["DATA", typed.issue]]);
      }
    },
    {
      name: `${name}/issues`,
      factory: "messageBusIssues",
      completeWhenDepsComplete: false,
      errorWhenDepsError: false
    }
  );
  const bus = {
    commands,
    messages,
    status,
    issues,
    ensureTopic(topic, commandOpts = {}) {
      return publishCommand(commands, {
        kind: "ensure-topic",
        topic,
        ...commandOpts.commandId === void 0 ? {} : { commandId: commandOpts.commandId }
      });
    },
    closeTopic(topic, commandOpts = {}) {
      return publishCommand(commands, {
        kind: "close-topic",
        topic,
        ...commandOpts.commandId === void 0 ? {} : { commandId: commandOpts.commandId }
      });
    },
    publish(topic, payload, publishOpts = {}) {
      return publishCommand(commands, {
        kind: "publish",
        topic,
        payload,
        ...publishOpts.key === void 0 ? {} : { key: publishOpts.key },
        ...publishOpts.commandId === void 0 ? {} : { commandId: publishOpts.commandId },
        ...publishOpts.idempotencyKey === void 0 ? {} : { idempotencyKey: publishOpts.idempotencyKey }
      });
    },
    topic(topic, projectionOpts = {}) {
      assertTopicKey(topic, "messageBus.topic");
      const snapshotPullId = /* @__PURE__ */ Symbol(`${name}/${topic}/topicSnapshot`);
      const snapshot = graph.node(
        [messages],
        (ctx) => {
          const params = pullParams(ctx.pull);
          ctx.down([["DATA", topicPage(state, topic, params)]]);
        },
        {
          name: projectionOpts.name ?? `${name}/${topic}/topic`,
          factory: "messageBusTopicProjection",
          meta: { topic },
          pullId: snapshotPullId,
          partial: true,
          completeWhenDepsComplete: false,
          errorWhenDepsError: false
        }
      );
      return { snapshot, snapshotPullId, status, issues };
    },
    catalog(projectionOpts = {}) {
      const snapshotPullId = /* @__PURE__ */ Symbol(`${name}/catalogSnapshot`);
      const snapshot = graph.node(
        [runtime],
        (ctx) => {
          const params = pullParams(ctx.pull);
          ctx.down([["DATA", catalogPage(state, params)]]);
        },
        {
          name: projectionOpts.name ?? `${name}/catalog`,
          factory: "messageBusCatalog",
          pullId: snapshotPullId,
          partial: true,
          completeWhenDepsComplete: false,
          errorWhenDepsError: false
        }
      );
      return { snapshot, snapshotPullId, status, issues };
    },
    deadLetter(projectionOpts = {}) {
      const snapshotPullId = /* @__PURE__ */ Symbol(`${name}/deadLetterSnapshot`);
      const snapshot = graph.node(
        [runtime],
        (ctx) => {
          const params = pullParams(ctx.pull);
          ctx.down([["DATA", deadLetterPage(state, params)]]);
        },
        {
          name: projectionOpts.name ?? `${name}/deadLetter`,
          factory: "messageBusDeadLetter",
          pullId: snapshotPullId,
          partial: true,
          completeWhenDepsComplete: false,
          errorWhenDepsError: false
        }
      );
      return { snapshot, snapshotPullId, status, issues };
    },
    subscription(subscriptionOpts) {
      assertTopicKey(subscriptionOpts.topic, "messageBus.subscription");
      assertNonEmpty(subscriptionOpts.subscriptionId, "messageBus.subscriptionId");
      const sub = ensureSubscription(state, {
        topic: subscriptionOpts.topic,
        subscriptionId: subscriptionOpts.subscriptionId,
        from: subscriptionOpts.from ?? "earliest"
      });
      const availablePullId = /* @__PURE__ */ Symbol(
        `${name}/${subscriptionOpts.topic}/${subscriptionOpts.subscriptionId}/available`
      );
      const projectionName = subscriptionOpts.name ?? `${name}/${subscriptionOpts.topic}/${subscriptionOpts.subscriptionId}`;
      const available = graph.node(
        [messages, status],
        (ctx) => {
          const params = pullParams(ctx.pull);
          ctx.down([["DATA", availablePage(state, sub, params)]]);
        },
        {
          name: `${projectionName}/available`,
          factory: "messageBusSubscriptionAvailable",
          meta: { topic: subscriptionOpts.topic, subscriptionId: subscriptionOpts.subscriptionId },
          pullId: availablePullId,
          partial: true,
          completeWhenDepsComplete: false,
          errorWhenDepsError: false
        }
      );
      const cursor = graph.node(
        [status],
        (ctx) => {
          for (const fact of depBatch(ctx, 0) ?? []) {
            const typed = fact;
            const subscriptionMoved = typed.topic === sub.topic && typed.subscriptionId === sub.subscriptionId && (typed.kind === "subscription-acked" || typed.kind === "subscription-sought" || typed.kind === "subscription-closed");
            const retentionMoved = typed.topic === sub.topic && typed.kind === "retention-trimmed";
            if (subscriptionMoved || retentionMoved) {
              ctx.down([["DATA", cursorSnapshot(state, sub)]]);
            }
          }
        },
        {
          name: `${projectionName}/cursor`,
          factory: "messageBusSubscriptionCursor",
          completeWhenDepsComplete: false,
          errorWhenDepsError: false
        }
      );
      return {
        available,
        availablePullId,
        cursor,
        status,
        issues,
        ack(seq, commandOpts = {}) {
          return publishCommand(commands, {
            kind: "ack",
            topic: sub.topic,
            subscriptionId: sub.subscriptionId,
            seq,
            ...commandOpts.commandId === void 0 ? {} : { commandId: commandOpts.commandId }
          });
        },
        seek(nextSeq, commandOpts = {}) {
          return publishCommand(commands, {
            kind: "seek",
            topic: sub.topic,
            subscriptionId: sub.subscriptionId,
            nextSeq,
            ...commandOpts.commandId === void 0 ? {} : { commandId: commandOpts.commandId }
          });
        },
        close(commandOpts = {}) {
          return publishCommand(commands, {
            kind: "close-subscription",
            topic: sub.topic,
            subscriptionId: sub.subscriptionId,
            ...commandOpts.commandId === void 0 ? {} : { commandId: commandOpts.commandId }
          });
        }
      };
    }
  };
  registerMessageBusState(bus, state);
  return bus;
}
function reduceMessageBusCommand(state, command) {
  const malformed = validateCommand(command);
  if (malformed !== void 0) return rejectCommand(state, command, malformed);
  if (command.commandId !== void 0) {
    if (state.seenCommandIds.has(command.commandId)) {
      return duplicateCommandEvents(state, command, "duplicate commandId");
    }
    state.seenCommandIds.add(command.commandId);
  }
  if (command.kind === "publish" && command.idempotencyKey !== void 0 && state.seenIdempotencyKeys.has(idempotencyKey(command.topic, command.idempotencyKey))) {
    return duplicateCommandEvents(state, command, "duplicate idempotencyKey");
  }
  switch (command.kind) {
    case "ensure-topic":
      return ensureTopic(state, command.topic, command.commandId);
    case "close-topic": {
      const topic = state.topics.get(command.topic);
      if (topic === void 0) {
        return issueEvents(state, command, "unknown-topic", `unknown topic '${command.topic}'`);
      }
      topic.closed = true;
      return [
        {
          kind: "status",
          status: statusFact(state, "topic-closed", {
            topic: command.topic,
            commandId: command.commandId
          })
        }
      ];
    }
    case "topic-policy":
      state.topicPolicy = command.topicPolicy;
      return [
        {
          kind: "status",
          status: statusFact(state, "projection-ready", {
            commandId: command.commandId,
            details: { topicPolicy: command.topicPolicy }
          })
        }
      ];
    case "publish":
      return publishMessage(state, command);
    case "ack":
      return ackSubscription(state, command);
    case "seek":
      return seekSubscription(state, command);
    case "close-subscription":
      return closeSubscription(state, command);
  }
}
function publishMessage(state, command) {
  let topic = state.topics.get(command.topic);
  const events = [];
  if (topic === void 0) {
    if (state.topicPolicy !== "create-as-fact") {
      return issueEvents(state, command, "unknown-topic", `unknown topic '${command.topic}'`);
    }
    events.push(...ensureTopic(state, command.topic, command.commandId));
    topic = state.topics.get(command.topic);
  }
  if (topic === void 0)
    return issueEvents(state, command, "unknown-topic", `unknown topic '${command.topic}'`);
  if (topic.closed)
    return issueEvents(state, command, "closed-topic", `closed topic '${command.topic}'`);
  const message = {
    topic: command.topic,
    seq: topic.nextSeq++,
    payload: command.payload,
    timestampMs: state.now(),
    ...command.key === void 0 ? {} : { key: command.key },
    ...command.idempotencyKey === void 0 ? {} : { idempotencyKey: command.idempotencyKey },
    ...command.commandId === void 0 ? {} : { commandId: command.commandId }
  };
  if (command.idempotencyKey !== void 0) {
    state.seenIdempotencyKeys.add(idempotencyKey(command.topic, command.idempotencyKey));
  }
  topic.messages.push(message);
  events.push({ kind: "message", message });
  events.push({
    kind: "status",
    status: statusFact(state, "message-published", {
      topic: command.topic,
      seq: message.seq,
      commandId: command.commandId
    })
  });
  events.push(...trimRetention(state, command.topic, topic));
  return events;
}
function ensureTopic(state, topic, commandId) {
  assertTopicKey(topic, "messageBus");
  if (!state.topics.has(topic)) state.topics.set(topic, makeTopicState());
  return [
    {
      kind: "status",
      status: statusFact(state, "topic-created", { topic, commandId })
    }
  ];
}
function trimRetention(state, topicName, topic) {
  const max = state.retention.maxMessages;
  if (max === void 0 || topic.messages.length <= max) return [];
  if (!Number.isInteger(max) || max < 1) {
    return issueEvents(
      state,
      { kind: "publish", topic: topicName, payload: void 0 },
      "policy-rejected",
      "retention.maxMessages must be a positive integer"
    );
  }
  const trimCount = topic.messages.length - max;
  topic.messages.splice(0, trimCount);
  topic.headSeq = topic.messages[0]?.seq ?? topic.nextSeq;
  const events = [
    {
      kind: "status",
      status: statusFact(state, "retention-trimmed", {
        topic: topicName,
        headSeq: topic.headSeq,
        details: { trimCount }
      })
    }
  ];
  for (const sub of state.subscriptions.values()) {
    if (sub.closed || sub.topic !== topicName || sub.nextSeq >= topic.headSeq) continue;
    sub.retentionGap = true;
    events.push(
      ...issueEvents(
        state,
        {
          kind: "seek",
          topic: topicName,
          subscriptionId: sub.subscriptionId,
          nextSeq: sub.nextSeq
        },
        "retention-gap",
        `subscription '${sub.subscriptionId}' is before retained headSeq`
      )
    );
  }
  return events;
}
function ackSubscription(state, command) {
  const topic = state.topics.get(command.topic);
  if (topic === void 0)
    return issueEvents(state, command, "unknown-topic", `unknown topic '${command.topic}'`);
  const sub = getSubscription(state, command.topic, command.subscriptionId);
  if (sub === void 0)
    return issueEvents(
      state,
      command,
      "unknown-subscription",
      `unknown subscription '${command.subscriptionId}'`
    );
  if (sub.closed)
    return issueEvents(state, command, "subscription-closed", "subscription is closed");
  if (sub.retentionGap)
    return issueEvents(state, command, "retention-gap", "subscription must seek before ack");
  if (command.seq < sub.nextSeq)
    return issueEvents(state, command, "source-cursor-stale", "ack is behind subscription cursor");
  if (command.seq >= topic.nextSeq)
    return issueEvents(state, command, "cursor-out-of-range", "ack is beyond topic tail");
  sub.nextSeq = Math.max(sub.nextSeq, command.seq + 1);
  return [
    {
      kind: "status",
      status: statusFact(state, "subscription-acked", {
        topic: command.topic,
        subscriptionId: command.subscriptionId,
        nextSeq: sub.nextSeq,
        commandId: command.commandId
      })
    }
  ];
}
function seekSubscription(state, command) {
  const topic = state.topics.get(command.topic);
  if (topic === void 0)
    return issueEvents(state, command, "unknown-topic", `unknown topic '${command.topic}'`);
  const sub = getSubscription(state, command.topic, command.subscriptionId);
  if (sub === void 0)
    return issueEvents(
      state,
      command,
      "unknown-subscription",
      `unknown subscription '${command.subscriptionId}'`
    );
  if (sub.closed)
    return issueEvents(state, command, "subscription-closed", "subscription is closed");
  if (command.nextSeq < topic.headSeq)
    return issueEvents(state, command, "retention-gap", "seek is before retained headSeq");
  if (command.nextSeq > topic.nextSeq)
    return issueEvents(state, command, "cursor-out-of-range", "seek is beyond topic tail");
  sub.nextSeq = command.nextSeq;
  sub.retentionGap = false;
  return [
    {
      kind: "status",
      status: statusFact(state, "subscription-sought", {
        topic: command.topic,
        subscriptionId: command.subscriptionId,
        nextSeq: sub.nextSeq,
        commandId: command.commandId
      })
    }
  ];
}
function closeSubscription(state, command) {
  if (!state.topics.has(command.topic))
    return issueEvents(state, command, "unknown-topic", `unknown topic '${command.topic}'`);
  const sub = getSubscription(state, command.topic, command.subscriptionId);
  if (sub === void 0)
    return issueEvents(
      state,
      command,
      "unknown-subscription",
      `unknown subscription '${command.subscriptionId}'`
    );
  sub.closed = true;
  return [
    {
      kind: "status",
      status: statusFact(state, "subscription-closed", {
        topic: command.topic,
        subscriptionId: command.subscriptionId,
        nextSeq: sub.nextSeq,
        commandId: command.commandId
      })
    }
  ];
}
function issueEvents(state, command, code, message) {
  const topic = commandTopic(command);
  const commandId = commandIdOf(command);
  const issue = {
    kind: "issue",
    code,
    message,
    severity: "error",
    source: "messageBus",
    details: command,
    metadata: topic === void 0 ? void 0 : { topic }
  };
  const entry = {
    entrySeq: ++state.deadLetterSeq,
    ...topic === void 0 ? {} : { topic },
    ...isObjectRecord(command) ? { command } : {},
    issue,
    timestampMs: state.now()
  };
  state.deadLetters.push(entry);
  return [
    { kind: "issue", issue },
    { kind: "dead-letter", entry },
    {
      kind: "status",
      status: statusFact(state, "command-rejected", {
        topic,
        commandId,
        issueCode: code
      })
    }
  ];
}
function rejectCommand(state, command, reason) {
  return issueEvents(state, command, "malformed-command", reason);
}
function duplicateCommandEvents(state, command, message) {
  const status = statusFact(state, "duplicate-command", {
    topic: "topic" in command ? command.topic : void 0,
    commandId: command.commandId
  });
  if (state.dedupe.commandId === "issue") {
    return [
      { kind: "status", status },
      ...issueEvents(state, command, "duplicate-command", message)
    ];
  }
  return [{ kind: "status", status }];
}
function statusFact(state, kind, fields) {
  return {
    kind,
    timestampMs: state.now(),
    ...fields.topic === void 0 ? {} : { topic: fields.topic },
    ...fields.seq === void 0 ? {} : { seq: fields.seq },
    ...fields.headSeq === void 0 ? {} : { headSeq: fields.headSeq },
    ...fields.subscriptionId === void 0 ? {} : { subscriptionId: fields.subscriptionId },
    ...fields.nextSeq === void 0 ? {} : { nextSeq: fields.nextSeq },
    ...fields.commandId === void 0 ? {} : { commandId: fields.commandId },
    ...fields.issueCode === void 0 ? {} : { issueCode: fields.issueCode },
    ...fields.details === void 0 ? {} : { details: fields.details }
  };
}
function validateCommand(command) {
  if (!isObjectRecord(command)) return "command must be an object";
  if (typeof command.kind !== "string") return "command kind is required";
  if (!isMessageBusCommandKind(command.kind)) return `unknown command kind '${command.kind}'`;
  if ("topic" in command) {
    if (typeof command.topic !== "string") return "messageBus: topic must be a non-empty string";
    const topicError = validateTopicKey(command.topic, "messageBus");
    if (topicError !== void 0) return topicError;
  }
  if ("subscriptionId" in command && typeof command.subscriptionId !== "string") {
    return "subscriptionId must be a string";
  }
  if (command.kind === "publish" && command.payload === void 0)
    return "publish payload is required";
  if (command.kind === "ack" && !isPositiveSeq(command.seq))
    return "ack seq must be a positive integer";
  if (command.kind === "seek" && !isPositiveSeq(command.nextSeq)) {
    return "seek nextSeq must be a positive integer";
  }
  if (command.kind === "topic-policy" && command.topicPolicy !== "strict" && command.topicPolicy !== "create-as-fact") {
    return "topicPolicy is not recognized";
  }
  return void 0;
}
function isMessageBusCommandKind(kind) {
  return kind === "ensure-topic" || kind === "close-topic" || kind === "publish" || kind === "topic-policy" || kind === "ack" || kind === "seek" || kind === "close-subscription";
}
function catalogPage(state, params) {
  const limit = positiveLimit(params.limit);
  const topics = [...state.topics.entries()].filter(
    ([topic, value]) => (params.includeClosed ? true : !value.closed) && (params.afterTopic === void 0 || topic > params.afterTopic)
  ).sort(([a], [b]) => a < b ? -1 : a > b ? 1 : 0);
  const page = topics.slice(0, limit);
  const hasMore = topics.length > limit;
  return {
    topics: page.map(([topic, value]) => ({
      topic,
      closed: value.closed,
      headSeq: value.headSeq,
      nextSeq: value.nextSeq,
      messageCount: value.messages.length
    })),
    ...hasMore && page.length > 0 ? { nextAfterTopic: page[page.length - 1]?.[0] } : {},
    hasMore
  };
}
function topicPage(state, topicName, params) {
  const topic = state.topics.get(topicName);
  const start = params.afterSeq === void 0 ? topic?.headSeq ?? 1 : params.afterSeq + 1;
  const all = (topic?.messages ?? []).filter((message) => message.seq >= start);
  const limit = positiveLimit(params.limit);
  const messages = all.slice(0, limit);
  const hasMore = all.length > limit;
  return {
    topic: topicName,
    messages,
    fromSeq: start,
    ...messages.length > 0 ? { throughSeq: messages[messages.length - 1]?.seq } : {},
    ...hasMore && messages.length > 0 ? { nextAfterSeq: messages[messages.length - 1]?.seq } : {},
    hasMore
  };
}
function availablePage(state, sub, params) {
  const cursor = cursorSnapshot(state, sub);
  const start = params.afterSeq === void 0 ? sub.nextSeq : params.afterSeq + 1;
  const topic = state.topics.get(sub.topic);
  const all = sub.retentionGap ? [] : (topic?.messages ?? []).filter((message) => message.seq >= start);
  const limit = positiveLimit(params.limit);
  const messages = all.slice(0, limit);
  const hasMore = all.length > limit;
  return {
    topic: sub.topic,
    subscriptionId: sub.subscriptionId,
    cursor,
    messages,
    fromSeq: start,
    ...messages.length > 0 ? { throughSeq: messages[messages.length - 1]?.seq } : {},
    ...hasMore && messages.length > 0 ? { nextAfterSeq: messages[messages.length - 1]?.seq } : {},
    hasMore
  };
}
function deadLetterPage(state, params) {
  const limit = positiveLimit(params.limit);
  const entries = state.deadLetters.filter((entry) => {
    if (params.afterEntrySeq !== void 0 && entry.entrySeq <= params.afterEntrySeq) return false;
    if (params.topic !== void 0 && entry.topic !== params.topic) return false;
    if (params.code !== void 0 && entry.issue.code !== params.code) return false;
    return true;
  });
  const page = entries.slice(0, limit);
  const hasMore = entries.length > limit;
  return {
    entries: page,
    ...hasMore && page.length > 0 ? { nextAfterEntrySeq: page[page.length - 1]?.entrySeq } : {},
    hasMore
  };
}
function cursorSnapshot(state, sub) {
  const topic = state.topics.get(sub.topic);
  return {
    topic: sub.topic,
    subscriptionId: sub.subscriptionId,
    nextSeq: sub.nextSeq,
    closed: sub.closed,
    retentionGap: sub.retentionGap,
    headSeq: topic?.headSeq ?? 1
  };
}
function ensureSubscription(state, opts) {
  const key = canonicalTupleKey([opts.topic, opts.subscriptionId]);
  const existing = state.subscriptions.get(key);
  if (existing !== void 0) return existing;
  const topic = state.topics.get(opts.topic);
  const nextSeq = opts.from === "earliest" ? topic?.headSeq ?? 1 : opts.from === "latest" ? topic?.nextSeq ?? 1 : opts.from;
  const sub = {
    topic: opts.topic,
    subscriptionId: opts.subscriptionId,
    nextSeq,
    closed: false,
    retentionGap: topic !== void 0 && nextSeq < topic.headSeq
  };
  state.subscriptions.set(key, sub);
  return sub;
}
function getSubscription(state, topic, subscriptionId) {
  return state.subscriptions.get(canonicalTupleKey([topic, subscriptionId]));
}

// scripts/fixtures/library-registration-probe.ts
var CountingDispatcher = class extends Dispatcher {
  live = /* @__PURE__ */ new Set();
  register(...args) {
    const h = super.register(...args);
    this.live.add(h);
    return h;
  }
  unregister(h) {
    super.unregister(h);
    this.live.delete(h);
  }
};
var idle = () => {
};
function probe() {
  const passed = [];
  function check(name, fn) {
    fn();
    passed.push(name);
  }
  check("exact-node-identity", () => {
    const n = new Node([], null, { initial: 5 });
    assert.throws(() => checkpointStateOfNode(Object.create(n)), /unknown node state/);
    assert.equal(checkpointStateOfNode(n).cache, 5);
    releaseRuntimeOfNode(n);
  });
  check("release-timing-and-backend", () => {
    const n = new Node([], null);
    let backendCalls = 0;
    let atHook;
    registerBackendStateContributor(n, () => {
      backendCalls++;
      return 1;
    });
    nodeRuntimeHost(n)._hooks.onDeactivation.push(() => {
      atHook = [isNodeRuntimeReleased(n), checkpointStateOfNode(n).hasData];
    });
    releaseRuntimeOfNode(n);
    assert.deepEqual(atHook, [true, false]);
    assert.equal(checkpointBackendStateOfNode(n, "backend"), void 0);
    assert.equal(backendCalls, 0);
    assert.throws(() => checkpointStateOfNode(n), /unknown/);
  });
  check("cold-handle-cleanup", () => {
    const d = new CountingDispatcher();
    assert.throws(
      () => new Node([], idle, {
        dispatcher: d,
        get initial() {
          throw new Error("cold");
        }
      }),
      /cold/
    );
    assert.equal(d.live.size, 0);
    const borrowed = d.register(idle, "sync");
    assert.throws(
      () => new Node([], borrowed, {
        dispatcher: d,
        get initial() {
          throw new Error("cold");
        }
      }),
      /cold/
    );
    assert.deepEqual([...d.live], [borrowed]);
    d.unregister(borrowed);
  });
  check("partial-slot-cleanup", () => {
    const create = NodeCore.prototype.createSlot;
    let core;
    let acquiredId = -1;
    NodeCore.prototype.createSlot = function(slot, state, acquisition) {
      core = this;
      const badState = {
        ...state,
        get wave() {
          acquiredId = acquisition?.slot ?? -1;
          throw new Error("partial");
        }
      };
      return create.call(this, slot, badState, acquisition);
    };
    try {
      assert.throws(() => new Node([], idle), /partial/);
    } finally {
      NodeCore.prototype.createSlot = create;
    }
    assert.notEqual(acquiredId, -1);
    assert.throws(() => core.get(acquiredId), /unknown node slot/);
  });
  check("graph-publication-reentry", () => {
    const d = new CountingDispatcher();
    const graph = new Graph({ dispatcher: d });
    let winner;
    let reads = 0;
    assert.throws(
      () => graph.node([], idle, {
        name: "same",
        get restore() {
          reads++;
          if (reads === 2) winner = graph.state(1, { name: "same" });
          return void 0;
        }
      }),
      /duplicate/
    );
    assert.equal(d.live.size, 0);
    assert.equal(graph.find("same"), winner);
    assert.equal(graph.describe().nodes.length, 1);
    assert.throws(() => restoreStateNodeInGraph(Object.create(graph), "fake"), /unknown graph/);
    releaseGraphNodes(graph, [winner]);
  });
  for (const rollback2 of [false, true])
    check(`deferred-adds-${rollback2}`, () => {
      const g = new Graph();
      const bus = messageBus(g);
      const a = g.node();
      const b = g.node();
      batch((ctx) => {
        bus.commands.down([["DATA", { kind: "declareTopic", topic: "x" }]]);
        attachMessageBusCommandSource(g, bus, a);
        attachMessageBusCommandSource(g, bus, b);
        assert.deepEqual(bus.commands.deps, []);
        if (rollback2) ctx.rollback();
      });
      assert.deepEqual(bus.commands.deps, rollback2 ? [] : [a, b]);
    });
  check("rollback-removal-and-duplicate", () => {
    const g = new Graph();
    const bus = messageBus(g);
    const a = g.node();
    const remove = attachMessageBusCommandSource(g, bus, a);
    const duplicate = attachMessageBusCommandSource(g, bus, a);
    duplicate();
    assert.deepEqual(bus.commands.deps, [a]);
    batch((ctx) => {
      bus.commands.down([["DATA", { kind: "declareTopic", topic: "x" }]]);
      remove();
      ctx.rollback();
    });
    assert.deepEqual(bus.commands.deps, [a]);
    remove();
    assert.deepEqual(bus.commands.deps, []);
    bus.commands.down([["COMPLETE"]]);
    remove();
    duplicate();
  });
  return passed;
}
export {
  probe
};
