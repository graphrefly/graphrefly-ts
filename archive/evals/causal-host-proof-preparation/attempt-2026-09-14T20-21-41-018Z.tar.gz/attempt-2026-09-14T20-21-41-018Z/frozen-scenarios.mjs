// scripts/fixtures/spending-proof-verifier.ts
import { createHash } from "node:crypto";

// scripts/fixtures/spending-numeric-oracle.ts
function bits(x) {
  const buffer = Buffer.alloc(8);
  buffer.writeDoubleBE(x);
  return buffer.readBigUInt64BE();
}
function number(x) {
  const buffer = Buffer.alloc(8);
  buffer.writeBigUInt64BE(x);
  return buffer.readDoubleBE();
}
function unitsFromBits(b) {
  const exponent = b >> 52n & 2047n, mantissa = b & 0xfffffffffffffn;
  return exponent === 0n ? mantissa : (mantissa | 0x10000000000000n) << exponent - 1n;
}
var units = (x) => unitsFromBits(bits(x));
var unitDenominator = 1n << 1074n;
function referenceRound(numerator, denominator, squareRoot) {
  if (numerator === 0n) return 0;
  const compare = (u, divisor = 1n) => squareRoot ? u * u * denominator - numerator * (unitDenominator * divisor) ** 2n : u * denominator - numerator * unitDenominator * divisor;
  let lo = 0n, hi = 0x7fefffffffffffffn;
  while (lo < hi) {
    const mid = (lo + hi + 1n) / 2n;
    if (compare(unitsFromBits(mid)) <= 0n) lo = mid;
    else hi = mid - 1n;
  }
  const lower = unitsFromBits(lo);
  if (compare(lower) === 0n) return number(lo);
  const midpointComparison = compare(lower + unitsFromBits(lo + 1n), 2n);
  return number(
    midpointComparison < 0n || midpointComparison === 0n && lo % 2n === 1n ? lo + 1n : lo
  );
}
function referenceNumbers(amounts, dailyAverage) {
  const xs = amounts.map(units), count = xs.length, n = BigInt(count);
  let total = 0n, pairs = 0n;
  for (let i = 0; i < count; i++) {
    total += xs[i];
    for (let j = 0; j < i; j++) pairs += (xs[i] - xs[j]) ** 2n;
  }
  const delta = n * xs[count - 1] - total;
  const z = pairs === 0n ? 0 : referenceRound(delta ** 2n * (n - 1n), n * pairs, true);
  return {
    mean: referenceRound(total, n * unitDenominator, false),
    std: count < 2 ? 0 : referenceRound(pairs, n * (n - 1n) * unitDenominator ** 2n, true),
    zScore: z === 0 ? 0 : delta < 0n ? -z : z,
    dailyRatio: referenceRound(xs[count - 1], units(Math.max(dailyAverage, 1)), false),
    varianceNonzero: pairs !== 0n
  };
}
function referenceFixed(x, digits) {
  const negative = x < 0, magnitude = units(Math.abs(x)) * 10n ** BigInt(digits);
  let q = magnitude / unitDenominator;
  if (2n * (magnitude % unitDenominator) >= unitDenominator) q++;
  const text = q.toString().padStart(digits + 1, "0");
  return `${negative ? "-" : ""}${text.slice(0, -digits)}.${text.slice(-digits)}`;
}

// scripts/fixtures/spending-proof-verifier.ts
function proofCanonical(input) {
  const active = /* @__PURE__ */ new Set();
  function encode(value, depth) {
    if (depth > 64) throw new TypeError("proof nesting limit");
    if (value === null || typeof value === "boolean") return String(value);
    if (typeof value === "number") {
      if (!Number.isFinite(value)) throw new TypeError("proof nonfinite number");
      return JSON.stringify(value);
    }
    if (typeof value === "string") {
      if (/[\uD800-\uDBFF](?![\uDC00-\uDFFF])|(?<![\uD800-\uDBFF])[\uDC00-\uDFFF]/u.test(value))
        throw new TypeError("proof unpaired surrogate");
      return JSON.stringify(value);
    }
    if (typeof value !== "object" || active.has(value)) throw new TypeError("proof non-data value");
    const array = Array.isArray(value);
    const proto = Object.getPrototypeOf(value);
    if (array ? proto !== Array.prototype : proto !== Object.prototype && proto !== null)
      throw new TypeError("proof non-data prototype");
    const descriptors = Object.getOwnPropertyDescriptors(value);
    const keys = Reflect.ownKeys(descriptors);
    if (keys.some((key) => typeof key !== "string")) throw new TypeError("proof symbol");
    const names = keys.filter((key) => !array || key !== "length");
    if (array && (names.length !== value.length || names.some((key, i) => key !== String(i))))
      throw new TypeError("proof sparse or extended array");
    active.add(value);
    const parts = (array ? names : names.sort()).map((key) => {
      const descriptor = descriptors[key];
      if (!("value" in descriptor) || !descriptor.enumerable) throw new TypeError("proof accessor");
      const item = encode(descriptor.value, depth + 1);
      return array ? item : `${encode(key, depth + 1)}:${item}`;
    });
    active.delete(value);
    return array ? `[${parts.join(",")}]` : `{${parts.join(",")}}`;
  }
  const text = encode(input, 0);
  if (Buffer.byteLength(text) > 4 * 1048576) throw new TypeError("proof byte limit");
  return text;
}
function proofHash(bytes) {
  return `sha256:${createHash("sha256").update(bytes).digest("hex")}`;
}
function proofFreeze(value) {
  if (value && typeof value === "object") {
    for (const child of Object.values(value)) proofFreeze(child);
    Object.freeze(value);
  }
  return value;
}
function expectedBusiness(raw) {
  const e = JSON.parse(proofCanonical(raw));
  if (!e.prefix.length || e.prefix.length > 64 || e.prefix.some((t) => !Number.isFinite(t.amount) || t.amount < 0 || t.amount > 1e9) || !Number.isFinite(e.profile.dailyAverage) || e.profile.dailyAverage < 0 || e.profile.dailyAverage > 1e9)
    throw new TypeError("outside frozen numeric domain");
  const numeric = referenceNumbers(
    e.prefix.map((t) => t.amount),
    e.profile.dailyAverage
  );
  const txn = e.prefix[e.prefix.length - 1];
  const known = e.profile.typicalCategories.includes(txn.category);
  const factors = [];
  if (numeric.zScore > e.policy.zThreshold)
    factors.push(
      `Amount is ${referenceFixed(numeric.zScore, 2)}\u03C3 above this vendor's historical mean.`
    );
  if (numeric.dailyRatio > e.policy.dailyRatioThreshold)
    factors.push(`Amount is ${referenceFixed(numeric.dailyRatio, 1)}\xD7 the user's daily average.`);
  if (!known) factors.push("Category is outside the user's typical spend profile.");
  const flagged = factors.length !== 0;
  const severity = factors.length >= 3 ? "high" : factors.length === 2 ? "medium" : "low";
  const message = flagged ? `Transaction ${txn.id} flagged \u2014 severity: ${severity}.
Vendor: ${txn.vendor}  Amount: $${referenceFixed(txn.amount, 2)}  Category: ${txn.category}
Reasoning:
${factors.map((f) => `  \u2022 ${f}`).join("\n")}` : `Transaction ${txn.id} ($${referenceFixed(txn.amount, 2)} at ${txn.vendor}) \u2014 normal.`;
  return proofFreeze({
    score: {
      zScore: numeric.zScore,
      dailyRatio: numeric.dailyRatio,
      categoryFamiliarity: known ? "known" : "unknown",
      txn
    },
    flagged,
    reason: { factors, severity, txn },
    message
  });
}
function expectedRequest(e, b) {
  const result = expectedBusiness(e);
  if (!result.flagged) return void 0;
  const payloadText = proofCanonical({
    transactionId: result.score.txn.id,
    vendor: result.score.txn.vendor,
    severity: result.reason.severity,
    message: result.message
  });
  if (Buffer.byteLength(payloadText) + 1 > 4096) throw new TypeError("proof payload capacity");
  const body = {
    schema: "spending-alerts/request-material/v1",
    occurrence: e.occurrence,
    effectId: `alert:${e.evaluationRef}`,
    inputDigest: e.inputDigest,
    policyDigest: e.policyDigest,
    payloadText,
    payloadDigest: proofHash(payloadText),
    sourceDigest: b.sourceDigest,
    runtimeDigest: b.runtimeDigest,
    destinationRef: b.destinationRef,
    compositionEpoch: b.compositionEpoch,
    hostEpoch: b.hostEpoch
  };
  const requestRef = { kind: body.schema, id: proofHash(proofCanonical(body)) };
  return proofFreeze({
    body,
    requestRef,
    proposalDigest: proofHash(
      proofCanonical({
        schema: "spending-alerts/effect-proposal/v1",
        occurrence: e.occurrence,
        effectId: body.effectId,
        requestRef
      })
    )
  });
}
function proofFacts(e, binding) {
  const request = expectedRequest(e, binding);
  const requestDigest = request?.body.payloadDigest ?? proofHash(proofCanonical({ kind: "no-publish", evaluationRef: e.evaluationRef }));
  const artifactDigest = proofHash(
    proofCanonical({
      verifier: "independent-proof-v1",
      evaluation: e,
      binding,
      business: expectedBusiness(e)
    })
  );
  const receipt = {
    receiptRef: { kind: "proof-verification", id: artifactDigest },
    issuerRef: { kind: "proof-verifier", id: "independent-proof-v1" },
    verifierRevision: "spending-oracle-v2",
    occurrence: e.occurrence,
    inputDigest: e.inputDigest,
    policyDigest: e.policyDigest,
    sourceDigest: binding.sourceDigest,
    runtimeDigest: binding.runtimeDigest,
    requestDigest,
    numericDomainRef: "spending-finite-v1",
    verdict: "pass",
    artifactRef: { kind: "proof-artifact", id: artifactDigest },
    artifactDigest
  };
  return proofFreeze({
    current: {
      binding,
      current: [
        {
          revisionDomain: e.occurrence.revisionDomain,
          occurrence: e.occurrence,
          policyRef: e.policyRef,
          policyDigest: e.policyDigest,
          watermark: e.occurrence.revision
        }
      ]
    },
    verification: { binding, receipts: [receipt] },
    local: {
      binding,
      tick: 1,
      stop: false,
      grants: [
        {
          grantRef: { kind: "proof-grant", id: e.evaluationRef },
          ownerRef: { kind: "proof-owner", id: "frozen-local-owner" },
          operation: "append-alert",
          occurrence: e.occurrence,
          requestDigest,
          destinationRef: binding.destinationRef,
          hostEpoch: binding.hostEpoch,
          validFrom: 0,
          validThrough: 100,
          maxWrites: 64,
          replayScope: { compositionEpoch: binding.compositionEpoch, hostEpoch: binding.hostEpoch },
          revoked: false
        }
      ]
    }
  });
}

// scripts/fixtures/spending-proof-scenarios.ts
var numericMutationTargets = {
  "sample-to-population": {
    path: "examples/spending-alerts/causal-numeric.ts",
    symbol: "exactZScore",
    from: "rounded(delta * delta * (n - 1n), n * d, 0, true)",
    to: "rounded(delta * delta * n, n * d, 0, true)",
    scope: "Changes actual sample score to population score; displayed sample std expression is unchanged."
  },
  "equivalent-score": {
    path: "examples/spending-alerts/causal-numeric.ts",
    symbol: "exactZScore",
    from: "rounded(delta * delta * (n - 1n), n * d, 0, true)",
    to: "rounded(delta * delta * n - delta * delta, n * d, 0, true)",
    scope: "Exact BigInt algebra preserves the rational and RN64 rounding; loaded source bytes change."
  }
};
var edit = (path, from, to) => ({ path, from, to });
var proofMutationTargets = proofFreeze({
  "sample-to-population": { ...numericMutationTargets["sample-to-population"], arms: {
    graph: [numericMutationTargets["sample-to-population"]],
    plain: [edit("scripts/fixtures/spending-numeric-plain.ts", "delta * delta * (n - 1n)", "delta * delta * n")]
  } },
  "equivalent-score": { ...numericMutationTargets["equivalent-score"], arms: {
    graph: [numericMutationTargets["equivalent-score"]],
    plain: [edit("scripts/fixtures/spending-numeric-plain.ts", "delta * delta * (n - 1n)", "delta * delta * n - delta * delta")]
  } },
  "cli-title": {
    ...edit("examples/spending-alerts/causal-graded-demo.ts", '"offline-spending-app"', '"proof-cli-title-only"'),
    scope: "Outside proof-worker closure. No algorithm-preservation or whole-repository attestation.",
    arms: {
      graph: [edit("examples/spending-alerts/causal-graded-demo.ts", '"offline-spending-app"', '"proof-cli-title-only"')],
      plain: [edit("examples/spending-alerts/causal-graded-demo.ts", '"offline-spending-app"', '"proof-cli-title-only"')]
    }
  },
  "missing-terminal-report": { scope: "Explanation business runs; only its terminal report is suppressed. Effect can succeed but lifecycle stays pending.", arms: {
    graph: [edit("examples/spending-alerts/causal-admission.ts", "for (let i = 0; i < 3; i++)", "for (const i of [0, 2])")],
    plain: [edit("scripts/fixtures/spending-preset-plain.ts", 'for (const branch of ["assessment", "explanation"])', 'for (const branch of ["assessment"])')]
  } },
  "missing-business-branch": { scope: "Graph reasonFactors emits no business rows, withholding alertMessage/assessment/material. Plain monolithic business result is withheld along with dependent reports; identity input is retained, no invented terminal.", arms: {
    graph: [edit(
      "examples/spending-alerts/causal-business.ts",
      'if (rows.length || issues.length) ctx.down([["DATA", frame(rows, issues)]]);',
      'if (name !== "reasonFactors" && (rows.length || issues.length)) ctx.down([["DATA", frame(rows, issues)]]);'
    )],
    plain: [
      edit("scripts/fixtures/spending-preset-plain.ts", "const result = plainBusiness(e);", "if (true) continue;\n				const result = plainBusiness(e);"),
      edit("scripts/fixtures/spending-preset-plain.ts", "for (const id of arrived) this.terminal(id, branch);", "for (const id of arrived) if (this.assessments.has(id)) this.terminal(id, branch);"),
      edit("scripts/fixtures/spending-preset-plain.ts", "if (!this.domains.has(e.occurrence.revisionDomain)) continue;", "if (!b || !this.domains.has(e.occurrence.revisionDomain)) continue;")
    ]
  } },
  "wrong-admission-outcome": { scope: "Transport and host record succeed, but completion delivery alters admission identity; authority must retain pending effect.", arms: {
    graph: [edit(
      "examples/spending-alerts/causal-admission.ts",
      'if (f.valid) for (const outcome of f.value.outcomes) emit([["DATA", outcome]]);',
      'if (f.valid) for (const outcome of f.value.outcomes) emit([["DATA", { ...outcome, admissionRef: { kind: "spending-admission", id: "wrong-admission" } }]]);'
    )],
    plain: [edit(
      "scripts/fixtures/spending-preset-plain.ts",
      "for (const o of incomingOutcomes) {",
      'for (const item of incomingOutcomes) { const o = { ...item, admissionRef: { kind: "spending-admission", id: "wrong-admission" } };'
    )]
  } }
});
function proofEvaluation(options = {}) {
  const vendor = options.vendor ?? "coffee";
  const revision = options.revision ?? 1;
  const id = options.id ?? `proof-${vendor}-${revision}`;
  const prefix = (options.amounts ?? [1, 2, 3]).map((amount, i) => ({
    id: `${id}:tx${i}`,
    vendor,
    category: "coffee",
    amount,
    timestampIso: "2026-09-14T00:00:00.000Z"
  }));
  const profile = { dailyAverage: options.dailyAverage ?? 100, typicalCategories: ["coffee"] };
  const profileRef = { kind: "profile", id: `profile-${revision}` };
  const policy = { zThreshold: options.threshold ?? 0.9, dailyRatioThreshold: 100 };
  const value = {
    evaluationRef: id,
    subjectRef: id,
    inputDigest: proofHash(proofCanonical({ profileRef, profile, prefix })),
    profileRef,
    profile,
    policyRef: { kind: "policy", id: `policy-${revision}` },
    policyDigest: proofHash(proofCanonical(policy)),
    policy,
    prefix
  };
  const coordinates = {
    revisionDomain: `proof-${vendor}`,
    occurrenceId: id,
    revision,
    sourceRefs: [{ kind: "evaluation", id }]
  };
  return proofFreeze({
    ...value,
    occurrence: {
      ...coordinates,
      digest: proofHash(
        proofCanonical({
          schemaRevision: "graphrefly/causal-occurrence-contract/v1@contract-v2",
          ...coordinates,
          value
        })
      )
    }
  });
}
var feed = (lane, value) => ({
  kind: "feed",
  lane,
  value
});
var drain = { kind: "drain" };
var checkpoint = (label, expectedCalls = 0) => ({ kind: "checkpoint", label, expectedCalls });
var settle = (call, result = "full") => ({
  kind: "settle",
  call,
  result
});
function proofScenarios(binding) {
  const normal = proofEvaluation({ threshold: 1.1 });
  const alert = proofEvaluation();
  const pack = (evaluations) => feed("pack", { format: "spending-input-v1", binding, evaluations });
  const arrivals = (e) => feed("arrivals", { packRef: binding.packRef, evaluationRefs: [e.evaluationRef] });
  const begin = (e, previousCalls = 0) => {
    const facts2 = proofFacts(e, binding);
    return [
      feed("current", facts2.current),
      feed("local", facts2.local),
      arrivals(e),
      drain,
      checkpoint(`business-observed:${e.evaluationRef}`, previousCalls)
    ];
  };
  const verify = (e) => [
    feed("verification", proofFacts(e, binding).verification),
    drain
  ];
  const stop = (e) => [
    feed("local", { ...proofFacts(e, binding).local, stop: true }),
    drain
  ];
  const attempt = (e, outcome = "succeeded", readback = "full") => ({ evaluationRef: e.evaluationRef, outcome, readback });
  const success = [
    pack([alert]),
    drain,
    ...begin(alert),
    ...verify(alert),
    settle(0),
    drain,
    ...stop(alert)
  ];
  const cases = [];
  const add = (id, family, evaluations, steps, expected, scope, mutation = "none") => cases.push({ id, family, evaluations, steps, expected: {
    ...expected,
    checkpoints: steps.flatMap((step) => step.kind === "checkpoint" ? [{ label: step.label, attemptedCalls: step.expectedCalls }] : [])
  }, scope, mutation });
  const quiet = { business: "match", attempts: [], normalEndReady: false };
  add(
    "S1-baseline",
    "S1",
    [normal],
    [pack([normal]), drain, ...begin(normal), ...verify(normal), ...stop(normal)],
    { ...quiet, normalEndReady: true },
    "Positive no-mutation control: sample=1, threshold=1.1, no alert."
  );
  add(
    "S1-score-mutant",
    "S1",
    [normal],
    [pack([normal]), drain, ...begin(normal), ...verify(normal), ...stop(normal)],
    { ...quiet, business: "mismatch" },
    "Actual score mutation changes 1 to about 1.224; verifier must reject observed business before a write.",
    "sample-to-population"
  );
  add(
    "S2-baseline",
    "S2",
    [alert],
    success,
    { business: "match", attempts: [attempt(alert)], normalEndReady: true },
    "Positive unmodified full request/readback control."
  );
  add(
    "S2-equivalent",
    "S2",
    [alert],
    success,
    { business: "match", attempts: [attempt(alert)], normalEndReady: true },
    "BigInt equivalent score rewrite, original topology, exact expected request bytes.",
    "equivalent-score"
  );
  const revisions = [
    alert,
    proofEvaluation({ vendor: "tea" }),
    proofEvaluation({ revision: 2, dailyAverage: 101 }),
    proofEvaluation({ vendor: "tea", revision: 2, dailyAverage: 102 })
  ];
  const interleaved = [pack(revisions), drain];
  for (const [i, e] of revisions.entries())
    interleaved.push(
      ...begin(e, i),
      checkpoint(`await-verification:${e.evaluationRef}`, i),
      ...verify(e),
      settle(i),
      drain
    );
  interleaved.push(...stop(revisions[3]));
  add(
    "S3-interleaved-revisions",
    "S3",
    revisions,
    interleaved,
    { business: "match", attempts: revisions.map((e) => attempt(e)), normalEndReady: true },
    "One instance; coffee/tea and policy/profile revisions interleave, pending verification precedes each exact release. This does not inject a missing internal terminal branch."
  );
  add(
    "S3-missing-terminal-report",
    "S3",
    [alert],
    success,
    {
      business: "match",
      attempts: [attempt(alert)],
      normalEndReady: false,
      authority: [{ evaluationRef: alert.evaluationRef, outcome: "succeeded", lifecycle: false }]
    },
    "Business and effect succeed, but missing explanation terminal report keeps lifecycle pending; not a missing business input.",
    "missing-terminal-report"
  );
  add(
    "S3-missing-business-branch",
    "S3",
    [alert],
    [pack([alert]), drain, ...begin(alert), ...verify(alert), ...stop(alert)],
    {
      business: "unavailable",
      attempts: [],
      normalEndReady: false,
      authority: [{ evaluationRef: alert.evaluationRef, outcome: "absent", lifecycle: false }]
    },
    "Actual explanation business output is absent, so no complete assessment/material/request can reach the host; retained identity remains pending.",
    "missing-business-branch"
  );
  const facts = proofFacts(alert, binding);
  add(
    "S4-stale-current",
    "S4",
    [alert],
    [
      pack([alert]),
      drain,
      feed("current", {
        ...facts.current,
        current: [{ ...facts.current.current[0], policyDigest: proofHash("wrong-policy") }]
      }),
      feed("local", facts.local),
      arrivals(alert),
      drain,
      ...verify(alert),
      ...stop(alert)
    ],
    quiet,
    "Exact occurrence with incorrect current policy digest never establishes current admission."
  );
  const gap = proofEvaluation({ revision: 2 });
  add(
    "S4-revision-gap",
    "S4",
    [gap],
    [pack([gap]), drain, ...begin(gap), ...verify(gap), ...stop(gap)],
    quiet,
    "Revision 2 without revision 1 retains an honest sequence gap; no quiet success or request execution."
  );
  add(
    "S5-exact-replay",
    "S5",
    [alert],
    [
      ...success.slice(0, -2),
      arrivals(alert),
      drain,
      checkpoint("read-only-analysis-replay", 1),
      ...stop(alert)
    ],
    { business: "match", attempts: [attempt(alert)], normalEndReady: true },
    "Exact arrival replay in one lifecycle retains one request/write. Analysis is the read-only verifier, with no writer parameter."
  );
  const changed = proofEvaluation({ amounts: [1, 2, 4] });
  add(
    "S5-conflicting-pack",
    "S5",
    [alert],
    [...success.slice(0, -2), pack([changed]), drain, arrivals(changed), drain, ...stop(alert)],
    { business: "match", attempts: [attempt(alert)], normalEndReady: false },
    "Same evaluation ID changed payload cannot replace the immutable pack; existing successful record stays retained."
  );
  for (const [suffix, result, outcome, bytes] of [
    ["success", "full", "succeeded", "full"],
    ["short", "short", "unknown", 1],
    ["rejection", "reject", "unknown", 0]
  ])
    add(
      `S6-${suffix}`,
      "S6",
      [alert],
      [
        pack([alert]),
        drain,
        ...begin(alert),
        ...verify(alert),
        settle(0, result),
        drain,
        ...stop(alert)
      ],
      {
        business: "match",
        attempts: [attempt(alert, outcome, bytes)],
        normalEndReady: outcome === "succeeded"
      },
      "Independent bytes distinguish full/partial/zero readback; rejection never proves known-no-submit."
    );
  add(
    "S6-unreturned",
    "S6",
    [alert],
    [pack([alert]), drain, ...begin(alert), ...verify(alert), ...stop(alert)],
    { business: "match", attempts: [attempt(alert, "pending", 0)], normalEndReady: false },
    "Unreturned writer retains one exact pending request despite stop."
  );
  add(
    "S6-known-no-submit",
    "S6",
    [alert],
    [
      pack([alert]),
      drain,
      feed("current", facts.current),
      feed("local", { ...facts.local, stop: true }),
      arrivals(alert),
      drain,
      ...verify(alert)
    ],
    { ...quiet, normalEndReady: true, authority: [{ evaluationRef: alert.evaluationRef, outcome: "rejected", lifecycle: true }] },
    "Stop is present before admission; no transport call is attempted."
  );
  add(
    "S6-wrong-admission-outcome",
    "S6",
    [alert],
    success,
    {
      business: "match",
      attempts: [attempt(alert)],
      normalEndReady: false,
      authority: [{ evaluationRef: alert.evaluationRef, outcome: "pending", lifecycle: false }]
    },
    "Full independent readback and host success do not settle an authority receiving a different admission identity.",
    "wrong-admission-outcome"
  );
  add(
    "S7-missing-verifier",
    "S7",
    [alert],
    [pack([alert]), drain, ...begin(alert), ...stop(alert)],
    quiet,
    "Absent independent verification is not an implicit pass."
  );
  add(
    "S7-stale-source",
    "S7",
    [alert],
    [
      pack([alert]),
      drain,
      ...begin(alert),
      feed("verification", {
        ...facts.verification,
        receipts: [{ ...facts.verification.receipts[0], sourceDigest: proofHash("stale-source") }]
      }),
      drain,
      ...stop(alert)
    ],
    quiet,
    "Receipt with stale source binding is not refreshed from a nominal candidate pass."
  );
  add(
    "S7-over-capacity",
    "S7",
    [alert],
    [
      pack(Array.from({ length: 65 }, () => alert)),
      drain,
      ...begin(alert),
      ...verify(alert),
      ...stop(alert)
    ],
    { ...quiet, business: "unavailable" },
    "Invalid over-capacity pack yields no business proof, no writer call, no normal end."
  );
  add(
    "S8-normal",
    "S8",
    [normal],
    [pack([normal]), drain, ...begin(normal), ...verify(normal), ...stop(normal)],
    { ...quiet, normalEndReady: true },
    "Known category, daily ratio below threshold, normal sample score: no request."
  );
  add(
    "S8-cli-title",
    "S8",
    [alert],
    success,
    { business: "match", attempts: [attempt(alert)], normalEndReady: true },
    "CLI-title source is outside proof-worker closure; do not infer arbitrary source equivalence.",
    "cli-title"
  );
  return proofFreeze(cases);
}
export {
  proofEvaluation,
  proofMutationTargets,
  proofScenarios
};
//# sourceMappingURL=frozen-scenarios.mjs.map
