import json, subprocess, time
from pathlib import Path
base=Path("archive/evals/library-registration-check-v1")
assert (base/"offline-gates.json").exists(), "Wait for offline supervisor completion before invoking"
soak=json.loads((base/"soak-result.json").read_text())
assert soak["exitCode"] == 1, "Reviewed initial soak had one timeout"
steps=[("soak-isolated", ["pnpm", "--filter", "@graphrefly/ts", "exec", "vitest", "run", "--config", "vitest.root-eval-soak.config.ts", "-t", "settles thirty output-truncated Together responses through the root Graph"]),("full-isolated", ["pnpm", "test"]), ("performance", ["node", "scripts/compare-library-registration-check.mjs"])]
for name,command in steps:
    started=time.monotonic()
    with (base/f"{name}.log").open("w") as log:
        result=subprocess.run(command, stdout=log, stderr=subprocess.STDOUT)
    record={"name":name,"command":command,"exitCode":result.returncode,"seconds":time.monotonic()-started,"log":f"{name}.log","isolation":"No batch soak, mutation, build, lint, or other batch test commands running concurrently"}
    (base/f"{name}-result.json").write_text(json.dumps(record,indent=2)+"\n")
    print(f"DONE {name}: {result.returncode}",flush=True)
    output=(base/f"{name}.log").read_text()
    if name=="soak-isolated":
        if result.returncode != 0 or "1 passed | 220 skipped" not in output:
            raise SystemExit("Targeted soak retest failed; inspect before proceeding")
    elif name=="full-isolated":
        expected=result.returncode==1 and "2 failed | 2547 passed | 4 skipped" in output and "Failed Tests 2" in output and "Unhandled Errors" not in output and "Test timed out" not in output
        if not expected: raise SystemExit("Isolated full suite needs inspection; performance NOT started")
    elif result.returncode != 0:
        raise SystemExit("Performance attempt failed; no automatic retry")
