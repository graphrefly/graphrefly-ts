import pathlib,json,statistics,sys,re,csv
p=pathlib.Path(sys.argv[1]);out={};csvrows=[]
for name,exitname in [('run-01','run'),('core-01','core'),('steps-01','steps')]:
 assert json.loads((p/(exitname+'-exit.json')).read_text())['exitCode']==0
 done=json.loads((p/name/'completion.json').read_text());assert done['completed'] and done['samples']==12800
 rs=json.loads((p/name/'summary.json').read_text());rows=[]
 for mode in ['off','summary']:
  for arm in ['candidate','reference']:
   for variant in ['original','swapped']:
    batches=sorted([x for x in rs if x['mode']==mode and x['arm']==arm and x['variant']==variant],key=lambda x:x['batch']);assert len(batches)==4
    for role in ['currentFacts','verificationFacts']:
     values=[x['nodes']['spending/'+role] for x in batches]
     row={'mode':mode,'arm':arm,'variant':variant,'role':role,'ordinal':values[0]['ordinal'],'medianBatchP50Us':statistics.median(x['p50Us'] for x in values),'batchP50Us':[x['p50Us'] for x in values],'batchMeanUs':[x['meanUs'] for x in values]}
     if name=='core-01':row['coreMedianBatchP50Us']=statistics.median(x['core']['p50Us'] for x in values)
     if name=='steps-01':row['stepsMedianBatchP50Us']={k:statistics.median(x['steps'][k]['p50Us'] for x in values) for k in values[0]['steps']}
     rows.append(row)
     if name=='run-01':csvrows.append(row)
 out[name]=rows
 # Assert reversal in every mode and batch; do not assert a new performance budget.
 if name=='run-01':
  for mode in ['off','summary']:
   for variant in ['original','swapped']:
    current=next(x for x in rows if x['mode']==mode and x['arm']=='candidate' and x['variant']==variant and x['role']=='currentFacts')
    verification=next(x for x in rows if x['mode']==mode and x['arm']=='candidate' and x['variant']==variant and x['role']=='verificationFacts')
    for c,v in zip(current['batchP50Us'],verification['batchP50Us']):assert (c>v) if variant=='original' else (v>c)
# V8 print exposes backing table identity, not capacity or exclusive CPU cost.
log=(p/'capacity.txt').read_text();observed={}
for ordinal,stage,addr in re.findall(r'CAPACITY (\d+) (before|after).*? - table: (0x[0-9a-f]+)',log,re.S):observed.setdefault(ordinal,{})[stage]=addr
assert observed['21']['before']==observed['21']['after'];assert observed['22']['before']!=observed['22']['after'];assert observed['23']['before']==observed['23']['after'];assert 'CAPACITY_CHECK_DONE 60' in log
out['backingTableObservation']={'ordinals':observed,'table':'checkpointReaders','capacityMeasured':False,'interpretation':'Backing table replaced at insertion22; consistent with table maintenance/rehash/growth, not exact capacity proof or exclusive cost attribution'}
out['limits']=['Separate probe passes are not directly subtractable','Node.constructor explicit body excludes automatic field initialization','createOwned nests other steps; p50/p95 steps cannot be summed','All raw samples retained; no new formal qualification estimate','One backing table observation does not quantify all registry costs or establish original p95 failure cause']
(p/'analysis.json').write_text(json.dumps(out,indent=2)+'\n')
with (p/'order-comparison.csv').open('w',newline='') as f:
 w=csv.DictWriter(f,fieldnames=list(csvrows[0]),lineterminator='\n');w.writeheader();w.writerows(csvrows)
print('ORDER_ANALYSIS_DONE 3 completed measurement runs; reversal in all candidate mode/batches; backing replacement at22')
