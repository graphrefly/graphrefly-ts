import assert from 'node:assert/strict';
import {readFileSync,writeFileSync,existsSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {resolve} from 'node:path';
import {pathToFileURL} from 'node:url';
const base=resolve(process.argv[2]),dest=`${base}/capacity.mjs`,original=readFileSync(`${base}/run-01/original.mjs`,'utf8');
const hash=b=>`sha256:${createHash('sha256').update(b).digest('hex')}`;
assert.equal(hash(original),JSON.parse(readFileSync(`${base}/run-01/freeze.json`)).bundles.original);assert.ok(!existsSync(dest));
let source=original;
for(const [needle,label]of [['checkpointReaders.set(this,','before'],['restoreWriters.set(this,','after']]){
 assert.equal(source.split(needle).length,2);
 source=source.replace(needle,`globalThis.__weakCapacity(checkpointReaders,this._id,"${label}");\n${needle}`);
}
writeFileSync(dest,source);
writeFileSync(`${base}/capacity-bindings.json`,JSON.stringify({sourceBundleDigest:hash(original),generatedBundleDigest:hash(source),scope:'single fresh candidate summary graph; before/after checkpointReaders.set only; not timing, not repair'},null,2)+'\n');
globalThis.__spendingNodeRecord=()=>{};globalThis.__spendingColdMark=()=>{};
const debug=new Function('x','%DebugPrint(x);');
globalThis.__weakCapacity=(table,id,stage)=>{if(id===20||id===21||id===22){console.log('CAPACITY',id+1,stage);debug(table);}};
let run;try{const mod=await import(pathToFileURL(dest).href);run=mod.graphArm('candidate','summary');console.log('CAPACITY_CHECK_DONE',run.graph.describe().nodes.length);}finally{run?.cleanup();delete globalThis.__spendingNodeRecord;delete globalThis.__spendingColdMark;delete globalThis.__weakCapacity;}
